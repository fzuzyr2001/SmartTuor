features= [
	{
	  "type" : "Feature",
	  "id" : 0,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43608511047097,
		  26.533629353496153
		]
	  },
	  "properties" : {
		"FID" : 0,
		"name" : "石佛亭",
		"lng" : 119.441013,
		"lat" : 26.530428000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45919191643588,
		  26.567920983426713
		]
	  },
	  "properties" : {
		"FID" : 1,
		"name" : "圣寿寺",
		"lng" : 119.46406,
		"lat" : 26.564665000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.48119940331971,
		  26.526506927582787
		]
	  },
	  "properties" : {
		"FID" : 2,
		"name" : "云泉禅寺",
		"lng" : 119.485989,
		"lat" : 26.523198000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.48510810044786,
		  26.587987262617094
		]
	  },
	  "properties" : {
		"FID" : 3,
		"name" : "罗源中房叠石三清观",
		"lng" : 119.48988799999999,
		"lat" : 26.584657
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 4,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50528190038366,
		  26.531096618407236
		]
	  },
	  "properties" : {
		"FID" : 4,
		"name" : "罗源紫峰寺",
		"lng" : 119.50998199999999,
		"lat" : 26.527715000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 5,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4381855031675,
		  26.590293686910993
		]
	  },
	  "properties" : {
		"FID" : 5,
		"name" : "罗源县中房镇金峰寺",
		"lng" : 119.443113,
		"lat" : 26.58708
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 6,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39359941253774,
		  26.494313630401376
		]
	  },
	  "properties" : {
		"FID" : 6,
		"name" : "兴祥禅寺",
		"lng" : 119.398574,
		"lat" : 26.491154000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 7,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50257091779548,
		  26.542487711501703
		]
	  },
	  "properties" : {
		"FID" : 7,
		"name" : "金瓠石",
		"lng" : 119.507282,
		"lat" : 26.539111999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 8,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37864348048828,
		  26.569474352407745
		]
	  },
	  "properties" : {
		"FID" : 8,
		"name" : "状元亭",
		"lng" : 119.38361999999999,
		"lat" : 26.566293000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 9,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51509861554182,
		  26.509029486368711
		]
	  },
	  "properties" : {
		"FID" : 9,
		"name" : "开善寺",
		"lng" : 119.519761,
		"lat" : 26.505624000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 10,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49895254361019,
		  26.499951957215401
		]
	  },
	  "properties" : {
		"FID" : 10,
		"name" : "庆田寺",
		"lng" : 119.503674,
		"lat" : 26.496596
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 11,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51876044593476,
		  26.539328021661706
		]
	  },
	  "properties" : {
		"FID" : 11,
		"name" : "罗源鲸鱼麦苗露营地",
		"lng" : 119.52341199999999,
		"lat" : 26.535906000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 12,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50809724146788,
		  26.559292902657734
		]
	  },
	  "properties" : {
		"FID" : 12,
		"name" : "曹垄宫",
		"lng" : 119.512789,
		"lat" : 26.555897999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 13,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.42736589907571,
		  26.6064894815045
		]
	  },
	  "properties" : {
		"FID" : 13,
		"name" : "陈氏宗祠",
		"lng" : 119.432317,
		"lat" : 26.603290999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 14,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51269686781824,
		  26.509555736767101
		]
	  },
	  "properties" : {
		"FID" : 14,
		"name" : "磹香禅寺",
		"lng" : 119.517368,
		"lat" : 26.506157000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 15,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37493716365469,
		  26.503120944860708
		]
	  },
	  "properties" : {
		"FID" : 15,
		"name" : "普明禅寺",
		"lng" : 119.37990600000001,
		"lat" : 26.499949000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 16,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51555925253001,
		  26.50933486288293
		]
	  },
	  "properties" : {
		"FID" : 16,
		"name" : "莲池别院",
		"lng" : 119.52021999999999,
		"lat" : 26.505928000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 17,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47704069632425,
		  26.469451058491686
		]
	  },
	  "properties" : {
		"FID" : 17,
		"name" : "万寿寺",
		"lng" : 119.481841,
		"lat" : 26.466168
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 18,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52352390210444,
		  26.514939102493823
		]
	  },
	  "properties" : {
		"FID" : 18,
		"name" : "黄氏宗祠",
		"lng" : 119.52815699999999,
		"lat" : 26.511509
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 19,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52560570209216,
		  26.532525267649124
		]
	  },
	  "properties" : {
		"FID" : 19,
		"name" : "西山白马尊王宫",
		"lng" : 119.530233,
		"lat" : 26.529086
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 20,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41720463245406,
		  26.470363840642374
		]
	  },
	  "properties" : {
		"FID" : 20,
		"name" : "亭音观境七",
		"lng" : 119.422161,
		"lat" : 26.467202
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 21,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47223185172241,
		  26.612054557348767
		]
	  },
	  "properties" : {
		"FID" : 21,
		"name" : "黄厝里",
		"lng" : 119.47705999999999,
		"lat" : 26.608758999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 22,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.42785911873868,
		  26.615242899566177
		]
	  },
	  "properties" : {
		"FID" : 22,
		"name" : "林家祖厅",
		"lng" : 119.43281,
		"lat" : 26.612043
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 23,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.44006604439784,
		  26.614812489511703
		]
	  },
	  "properties" : {
		"FID" : 23,
		"name" : "中共河洋区苏维埃政府旧址",
		"lng" : 119.444991,
		"lat" : 26.611592999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 24,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53743199538727,
		  26.516967358006163
		]
	  },
	  "properties" : {
		"FID" : 24,
		"name" : "华祖庙",
		"lng" : 119.54201999999999,
		"lat" : 26.513501999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 25,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.44032664360188,
		  26.615171001941832
		]
	  },
	  "properties" : {
		"FID" : 25,
		"name" : "岳峰宫",
		"lng" : 119.445251,
		"lat" : 26.611951000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 26,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.42510210771886,
		  26.617112471178352
		]
	  },
	  "properties" : {
		"FID" : 26,
		"name" : "林氏宗祠",
		"lng" : 119.430058,
		"lat" : 26.613916
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 27,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54058918805616,
		  26.5337489063817
		]
	  },
	  "properties" : {
		"FID" : 27,
		"name" : "龙华禅寺",
		"lng" : 119.545169,
		"lat" : 26.530273000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 28,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45527099056513,
		  26.435878201339168
		]
	  },
	  "properties" : {
		"FID" : 28,
		"name" : "禾山风景区",
		"lng" : 119.46014099999999,
		"lat" : 26.432663000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 29,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54185257321765,
		  26.510703851283974
		]
	  },
	  "properties" : {
		"FID" : 29,
		"name" : "起步大公园",
		"lng" : 119.54642699999999,
		"lat" : 26.50723
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 30,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53886247728794,
		  26.514755141326035
		]
	  },
	  "properties" : {
		"FID" : 30,
		"name" : "神光禅寺",
		"lng" : 119.543446,
		"lat" : 26.511286999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 31,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53354495069884,
		  26.489623737121327
		]
	  },
	  "properties" : {
		"FID" : 31,
		"name" : "先锋庙",
		"lng" : 119.53814300000001,
		"lat" : 26.486173999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 32,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53110763351827,
		  26.496468455216124
		]
	  },
	  "properties" : {
		"FID" : 32,
		"name" : "慈云禅寺",
		"lng" : 119.535714,
		"lat" : 26.493023000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 33,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47058568216538,
		  26.434165100516431
		]
	  },
	  "properties" : {
		"FID" : 33,
		"name" : "隐峰禅寺",
		"lng" : 119.47540600000001,
		"lat" : 26.430910999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 34,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53324867237423,
		  26.494189163979261
		]
	  },
	  "properties" : {
		"FID" : 34,
		"name" : "罗源县西来禅寺",
		"lng" : 119.537848,
		"lat" : 26.490739000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 35,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53208538158943,
		  26.501940195738676
		]
	  },
	  "properties" : {
		"FID" : 35,
		"name" : "梅峰禅寺",
		"lng" : 119.536689,
		"lat" : 26.498491000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 36,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32956580104748,
		  26.454925135373568
		]
	  },
	  "properties" : {
		"FID" : 36,
		"name" : "罗源飞竹西洋宫",
		"lng" : 119.334464,
		"lat" : 26.451696999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 37,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.457855173075,
		  26.627684910787206
		]
	  },
	  "properties" : {
		"FID" : 37,
		"name" : "佳溪寺",
		"lng" : 119.462732,
		"lat" : 26.624426
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 38,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58746871860978,
		  26.481798772391212
		]
	  },
	  "properties" : {
		"FID" : 38,
		"name" : "罗源滨海基督教堂",
		"lng" : 119.591954,
		"lat" : 26.478275
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 39,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60044936896699,
		  26.456885352800416
		]
	  },
	  "properties" : {
		"FID" : 39,
		"name" : "福州罗源湾海洋世界旅游度假区",
		"lng" : 119.60492600000001,
		"lat" : 26.453368999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 40,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5861169289483,
		  26.47658698684155
		]
	  },
	  "properties" : {
		"FID" : 40,
		"name" : "关公广场",
		"lng" : 119.590603,
		"lat" : 26.473064999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 41,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4219348566166,
		  26.450664756638158
		]
	  },
	  "properties" : {
		"FID" : 41,
		"name" : "光化禅寺",
		"lng" : 119.426883,
		"lat" : 26.447503999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 42,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55799792089039,
		  26.485901964931934
		]
	  },
	  "properties" : {
		"FID" : 42,
		"name" : "江滨公园",
		"lng" : 119.562529,
		"lat" : 26.482403999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 43,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55386781478897,
		  26.506382232560512
		]
	  },
	  "properties" : {
		"FID" : 43,
		"name" : "港头天主教堂",
		"lng" : 119.55840999999999,
		"lat" : 26.502886
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 44,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5346456385559,
		  26.500133980330943
		]
	  },
	  "properties" : {
		"FID" : 44,
		"name" : "紫霄岩寺",
		"lng" : 119.539241,
		"lat" : 26.496679
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 45,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52508487883517,
		  26.479504627182514
		]
	  },
	  "properties" : {
		"FID" : 45,
		"name" : "凤山镇管柄公园",
		"lng" : 119.52970999999999,
		"lat" : 26.476078999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 46,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57899052093939,
		  26.473356707463122
		]
	  },
	  "properties" : {
		"FID" : 46,
		"name" : "天后宫",
		"lng" : 119.583484,
		"lat" : 26.469839
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 47,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5498127465942,
		  26.492022488993566
		]
	  },
	  "properties" : {
		"FID" : 47,
		"name" : "闽星广场",
		"lng" : 119.55436400000001,
		"lat" : 26.488537000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 48,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54220349437439,
		  26.498409737916756
		]
	  },
	  "properties" : {
		"FID" : 48,
		"name" : "梅岭公园",
		"lng" : 119.54677599999999,
		"lat" : 26.494938000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 49,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53371147616132,
		  26.489644145308581
		]
	  },
	  "properties" : {
		"FID" : 49,
		"name" : "西外路关帝庙",
		"lng" : 119.538309,
		"lat" : 26.486194000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 50,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55368692768434,
		  26.485368763456485
		]
	  },
	  "properties" : {
		"FID" : 50,
		"name" : "莲花山广场",
		"lng" : 119.558228,
		"lat" : 26.481877999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 51,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54888855723549,
		  26.489131009463424
		]
	  },
	  "properties" : {
		"FID" : 51,
		"name" : "妈祖宫",
		"lng" : 119.553442,
		"lat" : 26.485648000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 52,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33729001308699,
		  26.470713269668313
		]
	  },
	  "properties" : {
		"FID" : 52,
		"name" : "罗源县飞竹镇凤山寺",
		"lng" : 119.342204,
		"lat" : 26.467495
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 53,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56441631776107,
		  26.486028092426157
		]
	  },
	  "properties" : {
		"FID" : 53,
		"name" : "渡头湿地公园",
		"lng" : 119.568934,
		"lat" : 26.482520999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 54,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54153312825079,
		  26.490712386361867
		]
	  },
	  "properties" : {
		"FID" : 54,
		"name" : "罗源城关基督教堂",
		"lng" : 119.54610700000001,
		"lat" : 26.487244
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 55,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58493782883509,
		  26.476661603316952
		]
	  },
	  "properties" : {
		"FID" : 55,
		"name" : "师公宫",
		"lng" : 119.58942500000001,
		"lat" : 26.473140000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 56,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58576791263056,
		  26.499732800580354
		]
	  },
	  "properties" : {
		"FID" : 56,
		"name" : "金粟寺",
		"lng" : 119.590256,
		"lat" : 26.496205
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 57,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3393561454443,
		  26.458919104545966
		]
	  },
	  "properties" : {
		"FID" : 57,
		"name" : "飞竹镇集镇文体公园",
		"lng" : 119.344273,
		"lat" : 26.455708000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 58,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54277077935085,
		  26.489489737868315
		]
	  },
	  "properties" : {
		"FID" : 58,
		"name" : "凤蝶广场",
		"lng" : 119.547341,
		"lat" : 26.486018999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 59,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53458829426155,
		  26.488867055971152
		]
	  },
	  "properties" : {
		"FID" : 59,
		"name" : "舒心亭",
		"lng" : 119.53918299999999,
		"lat" : 26.485415
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 60,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55104628934565,
		  26.486740428208659
		]
	  },
	  "properties" : {
		"FID" : 60,
		"name" : "江夏流芳-黄氏大宗祠",
		"lng" : 119.555594,
		"lat" : 26.483253999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 61,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50724678519347,
		  26.456596929251788
		]
	  },
	  "properties" : {
		"FID" : 61,
		"name" : "罗源县西湖寺",
		"lng" : 119.511934,
		"lat" : 26.453227999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 62,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53979512301224,
		  26.489524260853013
		]
	  },
	  "properties" : {
		"FID" : 62,
		"name" : "罗源县水陆寺",
		"lng" : 119.544374,
		"lat" : 26.486059999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 63,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43449402927835,
		  26.437587808913364
		]
	  },
	  "properties" : {
		"FID" : 63,
		"name" : "凤坂基督教堂",
		"lng" : 119.439418,
		"lat" : 26.434414
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 64,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54309702315568,
		  26.485235336110495
		]
	  },
	  "properties" : {
		"FID" : 64,
		"name" : "圣水寺",
		"lng" : 119.54766600000001,
		"lat" : 26.481764999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 65,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21788340672842,
		  26.444733665159742
		]
	  },
	  "properties" : {
		"FID" : 65,
		"name" : "中国畲山水景区",
		"lng" : 119.22269,
		"lat" : 26.441414999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 66,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53972928889206,
		  26.484647857541237
		]
	  },
	  "properties" : {
		"FID" : 66,
		"name" : "南门天主教堂",
		"lng" : 119.544308,
		"lat" : 26.481185
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 67,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54333818785852,
		  26.492263640623008
		]
	  },
	  "properties" : {
		"FID" : 67,
		"name" : "凤山公园",
		"lng" : 119.547907,
		"lat" : 26.488790999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 68,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61807273570898,
		  26.468476023372006
		]
	  },
	  "properties" : {
		"FID" : 68,
		"name" : "白马尊王庙(迹头)",
		"lng" : 119.622553,
		"lat" : 26.464967999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 69,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54195595972996,
		  26.509513805913983
		]
	  },
	  "properties" : {
		"FID" : 69,
		"name" : "进水宫",
		"lng" : 119.54653,
		"lat" : 26.506039999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 70,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54248533840664,
		  26.484414820131576
		]
	  },
	  "properties" : {
		"FID" : 70,
		"name" : "万世宗师",
		"lng" : 119.547056,
		"lat" : 26.480945999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 71,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55879762695417,
		  26.513930914075981
		]
	  },
	  "properties" : {
		"FID" : 71,
		"name" : "忠烈庙",
		"lng" : 119.563329,
		"lat" : 26.510425000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 72,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56708846267233,
		  26.470774248521099
		]
	  },
	  "properties" : {
		"FID" : 72,
		"name" : "隐岩禅寺",
		"lng" : 119.5716,
		"lat" : 26.467268000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 73,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55687005422163,
		  26.530921454137619
		]
	  },
	  "properties" : {
		"FID" : 73,
		"name" : "广源禅寺",
		"lng" : 119.561407,
		"lat" : 26.527415000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 74,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54716115584046,
		  26.513741506592265
		]
	  },
	  "properties" : {
		"FID" : 74,
		"name" : "桂林村健身活动中心陈氏宗祠",
		"lng" : 119.551721,
		"lat" : 26.510255999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 75,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60470671060425,
		  26.473233357762407
		]
	  },
	  "properties" : {
		"FID" : 75,
		"name" : "白马尊王庙(下店)",
		"lng" : 119.609184,
		"lat" : 26.469714
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 76,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5422958279533,
		  26.483967297041652
		]
	  },
	  "properties" : {
		"FID" : 76,
		"name" : "红军解放罗源城纪念碑",
		"lng" : 119.54686700000001,
		"lat" : 26.480498999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 77,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73361467901582,
		  26.527174993097397
		]
	  },
	  "properties" : {
		"FID" : 77,
		"name" : "白马禅寺",
		"lng" : 119.738213,
		"lat" : 26.523824000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 78,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4322539210693,
		  26.430056771038196
		]
	  },
	  "properties" : {
		"FID" : 78,
		"name" : "祝丰禅寺",
		"lng" : 119.43718200000001,
		"lat" : 26.426888999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 79,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43501513049324,
		  26.437881759654275
		]
	  },
	  "properties" : {
		"FID" : 79,
		"name" : "鼓流宫",
		"lng" : 119.439938,
		"lat" : 26.434707
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 80,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55859800319043,
		  26.529984967805262
		]
	  },
	  "properties" : {
		"FID" : 80,
		"name" : "茶山仙茅禅寺",
		"lng" : 119.563131,
		"lat" : 26.526475999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 81,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54683670209056,
		  26.494524367924811
		]
	  },
	  "properties" : {
		"FID" : 81,
		"name" : "罗源城关天主教堂",
		"lng" : 119.551396,
		"lat" : 26.491043999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 82,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5421329599609,
		  26.489373343211632
		]
	  },
	  "properties" : {
		"FID" : 82,
		"name" : "万寿塔",
		"lng" : 119.546705,
		"lat" : 26.485904000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 83,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55325106798369,
		  26.482668300752994
		]
	  },
	  "properties" : {
		"FID" : 83,
		"name" : "陈氏总祠",
		"lng" : 119.557793,
		"lat" : 26.479178999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 84,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41533400194946,
		  26.435299581059496
		]
	  },
	  "properties" : {
		"FID" : 84,
		"name" : "青云寺(观音阁)",
		"lng" : 119.42028999999999,
		"lat" : 26.43215
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 85,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55033079769818,
		  26.495824398530278
		]
	  },
	  "properties" : {
		"FID" : 85,
		"name" : "岐阳郑氏宗祠",
		"lng" : 119.55488099999999,
		"lat" : 26.492336999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 86,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28210832521434,
		  26.51013476026516
		]
	  },
	  "properties" : {
		"FID" : 86,
		"name" : "旃檀寺",
		"lng" : 119.28692700000001,
		"lat" : 26.506810000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 87,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54177457102396,
		  26.4941757763109
		]
	  },
	  "properties" : {
		"FID" : 87,
		"name" : "慈林观音堂",
		"lng" : 119.54634799999999,
		"lat" : 26.490705999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 88,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55095309015499,
		  26.48624112866209
		]
	  },
	  "properties" : {
		"FID" : 88,
		"name" : "江夏流芳",
		"lng" : 119.55550100000001,
		"lat" : 26.482755000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 89,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43272050265374,
		  26.434939114747525
		]
	  },
	  "properties" : {
		"FID" : 89,
		"name" : "林氏宗祠",
		"lng" : 119.437648,
		"lat" : 26.431768999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 90,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55881666510224,
		  26.513980953990721
		]
	  },
	  "properties" : {
		"FID" : 90,
		"name" : "齐天大圣府",
		"lng" : 119.563348,
		"lat" : 26.510475
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 91,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54861784952948,
		  26.489095482176332
		]
	  },
	  "properties" : {
		"FID" : 91,
		"name" : "天后宫",
		"lng" : 119.553172,
		"lat" : 26.485613000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 92,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57141436633403,
		  26.491385360788083
		]
	  },
	  "properties" : {
		"FID" : 92,
		"name" : "杨夫人宫",
		"lng" : 119.57592,
		"lat" : 26.487869
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 93,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56714252142233,
		  26.484911134088708
		]
	  },
	  "properties" : {
		"FID" : 93,
		"name" : "渡头境",
		"lng" : 119.57165500000001,
		"lat" : 26.481401000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 94,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28208801966123,
		  26.488236516550096
		]
	  },
	  "properties" : {
		"FID" : 94,
		"name" : "廷洋宫",
		"lng" : 119.286905,
		"lat" : 26.484916999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 95,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58661638552564,
		  26.476407090139435
		]
	  },
	  "properties" : {
		"FID" : 95,
		"name" : "滨海古街",
		"lng" : 119.59110200000001,
		"lat" : 26.472885000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 96,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56971615552297,
		  26.442441673096745
		]
	  },
	  "properties" : {
		"FID" : 96,
		"name" : "观音寺",
		"lng" : 119.57422099999999,
		"lat" : 26.438941
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 97,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.42934777055868,
		  26.435562298468788
		]
	  },
	  "properties" : {
		"FID" : 97,
		"name" : "余氏宗祠",
		"lng" : 119.434282,
		"lat" : 26.432397000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 98,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43582313249135,
		  26.4348251082288
		]
	  },
	  "properties" : {
		"FID" : 98,
		"name" : "凤坂天主教堂",
		"lng" : 119.440744,
		"lat" : 26.431650000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 99,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43020961607084,
		  26.433103726194972
		]
	  },
	  "properties" : {
		"FID" : 99,
		"name" : "郑氏宗祠",
		"lng" : 119.435142,
		"lat" : 26.429938
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 100,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57192342361702,
		  26.488082012645016
		]
	  },
	  "properties" : {
		"FID" : 100,
		"name" : "罗源县渡头村观音堂",
		"lng" : 119.57642800000001,
		"lat" : 26.484566000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 101,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55971552366708,
		  26.51531459346192
		]
	  },
	  "properties" : {
		"FID" : 101,
		"name" : "陈氏宗祠",
		"lng" : 119.564245,
		"lat" : 26.511807000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 102,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62173350188738,
		  26.442620369123929
		]
	  },
	  "properties" : {
		"FID" : 102,
		"name" : "巽屿村红色主题公园",
		"lng" : 119.626214,
		"lat" : 26.439124
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 103,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54298885143065,
		  26.469866944330452
		]
	  },
	  "properties" : {
		"FID" : 103,
		"name" : "圣安寺",
		"lng" : 119.547557,
		"lat" : 26.466401000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 104,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41615417215704,
		  26.433126541044871
		]
	  },
	  "properties" : {
		"FID" : 104,
		"name" : "马鞍宫",
		"lng" : 119.421109,
		"lat" : 26.429977000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 105,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.68092210076327,
		  26.565282369758407
		]
	  },
	  "properties" : {
		"FID" : 105,
		"name" : "白马仙峰三清宫",
		"lng" : 119.685486,
		"lat" : 26.561858000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 106,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6026532667198,
		  26.463478508249093
		]
	  },
	  "properties" : {
		"FID" : 106,
		"name" : "罗源音乐喷泉",
		"lng" : 119.60713,
		"lat" : 26.459961
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 107,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32206797354867,
		  26.537831711761246
		]
	  },
	  "properties" : {
		"FID" : 107,
		"name" : "共罗源县守善区党支部(旧址)",
		"lng" : 119.326958,
		"lat" : 26.534569000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 108,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40250612254208,
		  26.431312617021131
		]
	  },
	  "properties" : {
		"FID" : 108,
		"name" : "白马尊王宫",
		"lng" : 119.407473,
		"lat" : 26.428170999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 109,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57331141966446,
		  26.544646560163308
		]
	  },
	  "properties" : {
		"FID" : 109,
		"name" : "飞鸾岭",
		"lng" : 119.57781799999999,
		"lat" : 26.541117
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 110,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54340638357542,
		  26.492228775676445
		]
	  },
	  "properties" : {
		"FID" : 110,
		"name" : "曲艺亭",
		"lng" : 119.54797499999999,
		"lat" : 26.488755999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 111,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61311027415523,
		  26.435017288541232
		]
	  },
	  "properties" : {
		"FID" : 111,
		"name" : "东岳泰山府",
		"lng" : 119.617586,
		"lat" : 26.431515000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 112,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43279185430019,
		  26.432279346921653
		]
	  },
	  "properties" : {
		"FID" : 112,
		"name" : "水尾宫",
		"lng" : 119.437719,
		"lat" : 26.429110000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 113,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28507265455818,
		  26.439987589981499
		]
	  },
	  "properties" : {
		"FID" : 113,
		"name" : "福湖畲族公园",
		"lng" : 119.28989,
		"lat" : 26.436686000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 114,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5741890093025,
		  26.459327118348856
		]
	  },
	  "properties" : {
		"FID" : 114,
		"name" : "罗源站站前广场",
		"lng" : 119.578688,
		"lat" : 26.455817
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 115,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.600937442857,
		  26.4572873162417
		]
	  },
	  "properties" : {
		"FID" : 115,
		"name" : "罗源湾海洋世界旅游度假区-售货亭",
		"lng" : 119.605414,
		"lat" : 26.453771
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 116,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58137320689823,
		  26.475329639144697
		]
	  },
	  "properties" : {
		"FID" : 116,
		"name" : "松海禅寺",
		"lng" : 119.585864,
		"lat" : 26.471810000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 117,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32206797354867,
		  26.537831711761246
		]
	  },
	  "properties" : {
		"FID" : 117,
		"name" : "罗源县苏维埃政府(旧址)",
		"lng" : 119.326958,
		"lat" : 26.534569000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 118,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57297809111014,
		  26.515013389411482
		]
	  },
	  "properties" : {
		"FID" : 118,
		"name" : "翠峰禅寺",
		"lng" : 119.577483,
		"lat" : 26.511489999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 119,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.75177958230175,
		  26.55676129074563
		]
	  },
	  "properties" : {
		"FID" : 119,
		"name" : "宝明寺",
		"lng" : 119.75636900000001,
		"lat" : 26.553407
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 120,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5698243194514,
		  26.442698868415516
		]
	  },
	  "properties" : {
		"FID" : 120,
		"name" : "静心居",
		"lng" : 119.57432900000001,
		"lat" : 26.439198000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 121,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59988122251268,
		  26.457055573408685
		]
	  },
	  "properties" : {
		"FID" : 121,
		"name" : "旋转木马",
		"lng" : 119.604358,
		"lat" : 26.453538999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 122,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65259020939259,
		  26.441210734483253
		]
	  },
	  "properties" : {
		"FID" : 122,
		"name" : "文体公园",
		"lng" : 119.657104,
		"lat" : 26.437761999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 123,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.75216446073374,
		  26.550199300934878
		]
	  },
	  "properties" : {
		"FID" : 123,
		"name" : "集福亭",
		"lng" : 119.756753,
		"lat" : 26.546845999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 124,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77030847199701,
		  26.567810526528845
		]
	  },
	  "properties" : {
		"FID" : 124,
		"name" : "井水渔村旅游度假区",
		"lng" : 119.774873,
		"lat" : 26.564444000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 125,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63171963715146,
		  26.439017474986056
		]
	  },
	  "properties" : {
		"FID" : 125,
		"name" : "红树林公园",
		"lng" : 119.636208,
		"lat" : 26.435535000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 126,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73477228595171,
		  26.482663149354426
		]
	  },
	  "properties" : {
		"FID" : 126,
		"name" : "碧岩寺",
		"lng" : 119.739367,
		"lat" : 26.479323000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 127,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.88472284805557,
		  26.325584184165148
		]
	  },
	  "properties" : {
		"FID" : 127,
		"name" : "簸箕山",
		"lng" : 119.88899000000001,
		"lat" : 26.322123999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 128,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.88644526581932,
		  26.325504016243212
		]
	  },
	  "properties" : {
		"FID" : 128,
		"name" : "白坛顶公园(旧车站公园)",
		"lng" : 119.89071,
		"lat" : 26.322043000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 129,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.85360391510645,
		  26.333862260889518
		]
	  },
	  "properties" : {
		"FID" : 129,
		"name" : "顺天尊王宫",
		"lng" : 119.857935,
		"lat" : 26.330431999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 130,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.88990380313332,
		  26.32416577048156
		]
	  },
	  "properties" : {
		"FID" : 130,
		"name" : "何氏宗祠",
		"lng" : 119.894164,
		"lat" : 26.320703999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 131,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.89017092784894,
		  26.326906136507958
		]
	  },
	  "properties" : {
		"FID" : 131,
		"name" : "基督教堂",
		"lng" : 119.894431,
		"lat" : 26.323443000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 132,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.8411644219745,
		  26.338800832642352
		]
	  },
	  "properties" : {
		"FID" : 132,
		"name" : "普照禅寺",
		"lng" : 119.845529,
		"lat" : 26.335388999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 133,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.89542560173238,
		  26.326262914581289
		]
	  },
	  "properties" : {
		"FID" : 133,
		"name" : "黄岐沙滩",
		"lng" : 119.89968,
		"lat" : 26.322799
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 134,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.84776618177658,
		  26.369408408985525
		]
	  },
	  "properties" : {
		"FID" : 134,
		"name" : "白云寺",
		"lng" : 119.852115,
		"lat" : 26.365971999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 135,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.81304871839437,
		  26.327553550492265
		]
	  },
	  "properties" : {
		"FID" : 135,
		"name" : "天福渔夫岛景区",
		"lng" : 119.817493,
		"lat" : 26.324199
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 136,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.85454065500173,
		  26.356397696778849
		]
	  },
	  "properties" : {
		"FID" : 136,
		"name" : "沙沃沙滩",
		"lng" : 119.85887099999999,
		"lat" : 26.352955999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 137,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.85121331600334,
		  26.368286549563734
		]
	  },
	  "properties" : {
		"FID" : 137,
		"name" : "奇达旗冠顶",
		"lng" : 119.855553,
		"lat" : 26.364844999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 138,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.85750122829258,
		  26.352779520553927
		]
	  },
	  "properties" : {
		"FID" : 138,
		"name" : "沙沃村虎头山栈道",
		"lng" : 119.861824,
		"lat" : 26.349335
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 139,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.89669120208987,
		  26.320103103100564
		]
	  },
	  "properties" : {
		"FID" : 139,
		"name" : "畚箕山战备遗址游览区",
		"lng" : 119.900944,
		"lat" : 26.316642000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 140,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.86227868199114,
		  26.378255799185283
		]
	  },
	  "properties" : {
		"FID" : 140,
		"name" : "奇达观音座",
		"lng" : 119.866592,
		"lat" : 26.374794000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 141,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.85476287338122,
		  26.36110204391353
		]
	  },
	  "properties" : {
		"FID" : 141,
		"name" : "白云岭道观",
		"lng" : 119.859093,
		"lat" : 26.357658000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 142,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.85494627926695,
		  26.361835631981883
		]
	  },
	  "properties" : {
		"FID" : 142,
		"name" : "白云庵",
		"lng" : 119.85927599999999,
		"lat" : 26.358391000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 143,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.81979011765151,
		  26.326408571302874
		]
	  },
	  "properties" : {
		"FID" : 143,
		"name" : "连江灵山寺",
		"lng" : 119.824215,
		"lat" : 26.323042000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 144,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.80638160116473,
		  26.32002696778844
		]
	  },
	  "properties" : {
		"FID" : 144,
		"name" : "七彩海公园",
		"lng" : 119.810844,
		"lat" : 26.316687999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 145,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.82769724742667,
		  26.336663172820419
		]
	  },
	  "properties" : {
		"FID" : 145,
		"name" : "上牛顶普照寺",
		"lng" : 119.8321,
		"lat" : 26.333276999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 146,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.80618324030448,
		  26.290052916884513
		]
	  },
	  "properties" : {
		"FID" : 146,
		"name" : "海潮寺",
		"lng" : 119.810644,
		"lat" : 26.286729000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 147,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.86847049744897,
		  26.374748965393774
		]
	  },
	  "properties" : {
		"FID" : 147,
		"name" : "金师公之庙",
		"lng" : 119.87277,
		"lat" : 26.371281
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 148,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.87028743542848,
		  26.371866784689399
		]
	  },
	  "properties" : {
		"FID" : 148,
		"name" : "恩向门",
		"lng" : 119.874583,
		"lat" : 26.368397999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 149,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.92653337262448,
		  26.353924691808945
		]
	  },
	  "properties" : {
		"FID" : 149,
		"name" : "廣安寺",
		"lng" : 119.930784,
		"lat" : 26.350466999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 150,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78820948763635,
		  26.311037356287994
		]
	  },
	  "properties" : {
		"FID" : 150,
		"name" : "永宁禅寺",
		"lng" : 119.79271799999999,
		"lat" : 26.307732000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 151,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79052931773391,
		  26.279680005009823
		]
	  },
	  "properties" : {
		"FID" : 151,
		"name" : "定海古城",
		"lng" : 119.79503,
		"lat" : 26.276387
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 152,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.9205739906545,
		  26.353582471502673
		]
	  },
	  "properties" : {
		"FID" : 152,
		"name" : "虎东境",
		"lng" : 119.92482200000001,
		"lat" : 26.350117999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 153,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79236458878339,
		  26.282530225983564
		]
	  },
	  "properties" : {
		"FID" : 153,
		"name" : "定海村甘棠观景平台",
		"lng" : 119.79686100000001,
		"lat" : 26.279233000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 154,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.94615613228504,
		  26.3691267978685
		]
	  },
	  "properties" : {
		"FID" : 154,
		"name" : "妈祖娘娘像",
		"lng" : 119.950428,
		"lat" : 26.365696
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 155,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.7904460434433,
		  26.280679399264351
		]
	  },
	  "properties" : {
		"FID" : 155,
		"name" : "连江定海城隍庙",
		"lng" : 119.79494699999999,
		"lat" : 26.277386
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 156,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79457985989106,
		  26.381525047320775
		]
	  },
	  "properties" : {
		"FID" : 156,
		"name" : "厦宫革命老区纪念馆",
		"lng" : 119.79907799999999,
		"lat" : 26.378178999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 157,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79120145291071,
		  26.286444482388408
		]
	  },
	  "properties" : {
		"FID" : 157,
		"name" : "自在禅寺",
		"lng" : 119.79570099999999,
		"lat" : 26.283147
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 158,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.92560344298182,
		  26.360177559119695
		]
	  },
	  "properties" : {
		"FID" : 158,
		"name" : "长林寺",
		"lng" : 119.92985400000001,
		"lat" : 26.356715999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 159,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78262562588668,
		  26.299929386026164
		]
	  },
	  "properties" : {
		"FID" : 159,
		"name" : "玄天上帝",
		"lng" : 119.78714600000001,
		"lat" : 26.296637
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 160,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.92605910841037,
		  26.361379494197514
		]
	  },
	  "properties" : {
		"FID" : 160,
		"name" : "白马尊王府",
		"lng" : 119.93031000000001,
		"lat" : 26.357918000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 161,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79518611790812,
		  26.385280489742129
		]
	  },
	  "properties" : {
		"FID" : 161,
		"name" : "陈氏宗祠",
		"lng" : 119.799683,
		"lat" : 26.381931999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 162,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.94608427283715,
		  26.368617736309851
		]
	  },
	  "properties" : {
		"FID" : 162,
		"name" : "苔菉镇北茭公园",
		"lng" : 119.950356,
		"lat" : 26.365186999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 163,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79260261443889,
		  26.385698643752225
		]
	  },
	  "properties" : {
		"FID" : 163,
		"name" : "厦宫红军纪念公园",
		"lng" : 119.797106,
		"lat" : 26.382353999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 164,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73808551240263,
		  26.36035770570556
		]
	  },
	  "properties" : {
		"FID" : 164,
		"name" : "海滨公园",
		"lng" : 119.74267,
		"lat" : 26.357061000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 165,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79273126512659,
		  26.381173046514832
		]
	  },
	  "properties" : {
		"FID" : 165,
		"name" : "聚贤亭",
		"lng" : 119.797234,
		"lat" : 26.377829999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 166,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.94591654604076,
		  26.368181903441201
		]
	  },
	  "properties" : {
		"FID" : 166,
		"name" : "东昇禅寺",
		"lng" : 119.950188,
		"lat" : 26.364750999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 167,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.75799125051495,
		  26.332805280822509
		]
	  },
	  "properties" : {
		"FID" : 167,
		"name" : "泰山府公园",
		"lng" : 119.762557,
		"lat" : 26.329519000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 168,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.94616321682942,
		  26.367807235601724
		]
	  },
	  "properties" : {
		"FID" : 168,
		"name" : "北茭文体广场",
		"lng" : 119.950435,
		"lat" : 26.364377000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 169,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76744267248471,
		  26.337311300483204
		]
	  },
	  "properties" : {
		"FID" : 169,
		"name" : "连江县坑里龙峰禅寺",
		"lng" : 119.771995,
		"lat" : 26.334016999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 170,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.94977918079005,
		  26.375347579562259
		]
	  },
	  "properties" : {
		"FID" : 170,
		"name" : "中国好望角",
		"lng" : 119.95405700000001,
		"lat" : 26.371922000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 171,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.75762395151271,
		  26.317083760866144
		]
	  },
	  "properties" : {
		"FID" : 171,
		"name" : "东山弥勒寺",
		"lng" : 119.76218900000001,
		"lat" : 26.313804999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 172,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.70574151522315,
		  26.301435288858769
		]
	  },
	  "properties" : {
		"FID" : 172,
		"name" : "慈云寺",
		"lng" : 119.710314,
		"lat" : 26.298138000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 173,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.69671566481445,
		  26.280184901547841
		]
	  },
	  "properties" : {
		"FID" : 173,
		"name" : "妈祖庙",
		"lng" : 119.701278,
		"lat" : 26.276885
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 174,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76286016154545,
		  26.301962263863182
		]
	  },
	  "properties" : {
		"FID" : 174,
		"name" : "天仙府",
		"lng" : 119.76741699999999,
		"lat" : 26.298687999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 175,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66905650999578,
		  26.303118151944069
		]
	  },
	  "properties" : {
		"FID" : 175,
		"name" : "连江官坂峡山寺",
		"lng" : 119.67358400000001,
		"lat" : 26.299757
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 176,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.7631208518237,
		  26.338436687501318
		]
	  },
	  "properties" : {
		"FID" : 176,
		"name" : "澄清宫",
		"lng" : 119.76768,
		"lat" : 26.335145000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 177,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73207251817328,
		  26.283212792897142
		]
	  },
	  "properties" : {
		"FID" : 177,
		"name" : "定海湾沙滩",
		"lng" : 119.736653,
		"lat" : 26.279949999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 178,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.723209543324,
		  26.312742447991578
		]
	  },
	  "properties" : {
		"FID" : 178,
		"name" : "龙峰山积圣寺",
		"lng" : 119.72779199999999,
		"lat" : 26.309459
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 179,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76383858616568,
		  26.302299070542549
		]
	  },
	  "properties" : {
		"FID" : 179,
		"name" : "陈氏宗祠",
		"lng" : 119.768394,
		"lat" : 26.299023999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 180,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.75009511898142,
		  26.325763539762011
		]
	  },
	  "properties" : {
		"FID" : 180,
		"name" : "连江龙古山燕峰寺",
		"lng" : 119.75466900000001,
		"lat" : 26.322482999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 181,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76857327821521,
		  26.354628892249249
		]
	  },
	  "properties" : {
		"FID" : 181,
		"name" : "坛主祠",
		"lng" : 119.77312499999999,
		"lat" : 26.351326
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 182,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.70544676895638,
		  26.301289621003313
		]
	  },
	  "properties" : {
		"FID" : 182,
		"name" : "连江莲花山永兴寺",
		"lng" : 119.710019,
		"lat" : 26.297992000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 183,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.72804533865266,
		  26.281595314665132
		]
	  },
	  "properties" : {
		"FID" : 183,
		"name" : "定海湾小木屋",
		"lng" : 119.732626,
		"lat" : 26.278331000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 184,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79229341753044,
		  26.28247408903885
		]
	  },
	  "properties" : {
		"FID" : 184,
		"name" : "定海古城观景台",
		"lng" : 119.79679,
		"lat" : 26.279177000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 185,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73593070494037,
		  26.320140335389993
		]
	  },
	  "properties" : {
		"FID" : 185,
		"name" : "王氏宗祠",
		"lng" : 119.74051300000001,
		"lat" : 26.316860999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 186,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.72022685209377,
		  26.278513931064833
		]
	  },
	  "properties" : {
		"FID" : 186,
		"name" : "九仙宫",
		"lng" : 119.724806,
		"lat" : 26.275245000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 187,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76093505483858,
		  26.361092286764247
		]
	  },
	  "properties" : {
		"FID" : 187,
		"name" : "湖山禅寺",
		"lng" : 119.76549900000001,
		"lat" : 26.357792
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 188,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62534405403105,
		  26.194805836537395
		]
	  },
	  "properties" : {
		"FID" : 188,
		"name" : "赶海一号",
		"lng" : 119.62980899999999,
		"lat" : 26.19143
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 189,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.94463330922171,
		  26.368879821693401
		]
	  },
	  "properties" : {
		"FID" : 189,
		"name" : "基督教北茭堂",
		"lng" : 119.948903,
		"lat" : 26.365445999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 190,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78356360624818,
		  26.30105314907334
		]
	  },
	  "properties" : {
		"FID" : 190,
		"name" : "文武太平王祖庙",
		"lng" : 119.788082,
		"lat" : 26.297758999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 191,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65843654960256,
		  26.241990291103249
		]
	  },
	  "properties" : {
		"FID" : 191,
		"name" : "百胜广场",
		"lng" : 119.662944,
		"lat" : 26.238641000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 192,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78932805652032,
		  26.284841908067353
		]
	  },
	  "properties" : {
		"FID" : 192,
		"name" : "基督教定海堂",
		"lng" : 119.79383199999999,
		"lat" : 26.281548000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 193,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60007079049785,
		  26.217036823436356
		]
	  },
	  "properties" : {
		"FID" : 193,
		"name" : "云居寺",
		"lng" : 119.60453,
		"lat" : 26.213628
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 194,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6531844276314,
		  26.209185343033944
		]
	  },
	  "properties" : {
		"FID" : 194,
		"name" : "晓澳海滩",
		"lng" : 119.65768199999999,
		"lat" : 26.205845
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 195,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77378146385485,
		  26.437506156211676
		]
	  },
	  "properties" : {
		"FID" : 195,
		"name" : "油杭观音禅院",
		"lng" : 119.77833,
		"lat" : 26.434166999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 196,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.68765711488597,
		  26.309954992306107
		]
	  },
	  "properties" : {
		"FID" : 196,
		"name" : "光严寺",
		"lng" : 119.692211,
		"lat" : 26.306625
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 197,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53441987418405,
		  26.202622669963393
		]
	  },
	  "properties" : {
		"FID" : 197,
		"name" : "陈第公园",
		"lng" : 119.538994,
		"lat" : 26.199296
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 198,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60170681443594,
		  26.262526649686443
		]
	  },
	  "properties" : {
		"FID" : 198,
		"name" : "浦口镇保福寺",
		"lng" : 119.60616899999999,
		"lat" : 26.259093
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 199,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62214595897188,
		  26.350832135903918
		]
	  },
	  "properties" : {
		"FID" : 199,
		"name" : "连江透堡三仙观",
		"lng" : 119.62662,
		"lat" : 26.347370999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 200,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53998769027359,
		  26.204304532985663
		]
	  },
	  "properties" : {
		"FID" : 200,
		"name" : "百凤公园",
		"lng" : 119.544545,
		"lat" : 26.200963999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 201,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.75875155586394,
		  26.301209577367391
		]
	  },
	  "properties" : {
		"FID" : 201,
		"name" : "元帅府",
		"lng" : 119.76331399999999,
		"lat" : 26.297937999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 202,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62900327886931,
		  26.369261468516967
		]
	  },
	  "properties" : {
		"FID" : 202,
		"name" : "廣修寺",
		"lng" : 119.633484,
		"lat" : 26.365801000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 203,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62527255104231,
		  26.380455839519527
		]
	  },
	  "properties" : {
		"FID" : 203,
		"name" : "报国寺",
		"lng" : 119.629751,
		"lat" : 26.376985999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 204,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62000317008568,
		  26.21551515834005
		]
	  },
	  "properties" : {
		"FID" : 204,
		"name" : "旗福禅寺",
		"lng" : 119.624466,
		"lat" : 26.212121
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 205,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60769205102645,
		  26.371699692341707
		]
	  },
	  "properties" : {
		"FID" : 205,
		"name" : "罗汉禅寺",
		"lng" : 119.612162,
		"lat" : 26.368217000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 206,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61697106370694,
		  26.238988579381331
		]
	  },
	  "properties" : {
		"FID" : 206,
		"name" : "东岱南门公园",
		"lng" : 119.62143399999999,
		"lat" : 26.235578
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 207,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.7786485433177,
		  26.33599570670621
		]
	  },
	  "properties" : {
		"FID" : 207,
		"name" : "连江县南山禅寺",
		"lng" : 119.78318,
		"lat" : 26.332691000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 208,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60966223829139,
		  26.228288560279999
		]
	  },
	  "properties" : {
		"FID" : 208,
		"name" : "连江龙山寺",
		"lng" : 119.61412199999999,
		"lat" : 26.224878
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 209,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.576252502656,
		  26.328949005196588
		]
	  },
	  "properties" : {
		"FID" : 209,
		"name" : "广应寺",
		"lng" : 119.58073899999999,
		"lat" : 26.325486999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 210,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73055262473432,
		  26.319701645530394
		]
	  },
	  "properties" : {
		"FID" : 210,
		"name" : "红下基督教堂",
		"lng" : 119.735136,
		"lat" : 26.316420000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 211,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.75227763495113,
		  26.36103971841856
		]
	  },
	  "properties" : {
		"FID" : 211,
		"name" : "岐峰公园",
		"lng" : 119.75685199999999,
		"lat" : 26.357742999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 212,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62419790448104,
		  26.249849782480986
		]
	  },
	  "properties" : {
		"FID" : 212,
		"name" : "目莲寺",
		"lng" : 119.628666,
		"lat" : 26.246441000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 213,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64386775933576,
		  26.374184704204559
		]
	  },
	  "properties" : {
		"FID" : 213,
		"name" : "城隍庙",
		"lng" : 119.648365,
		"lat" : 26.370744999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 214,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59842099321811,
		  26.345224241896535
		]
	  },
	  "properties" : {
		"FID" : 214,
		"name" : "炉峰山观景台",
		"lng" : 119.60289,
		"lat" : 26.341749
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 215,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52496818195665,
		  26.199625010460522
		]
	  },
	  "properties" : {
		"FID" : 215,
		"name" : "莲湖公园",
		"lng" : 119.529573,
		"lat" : 26.196324000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 216,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.69265998080819,
		  26.283301110308074
		]
	  },
	  "properties" : {
		"FID" : 216,
		"name" : "张氏宗祠",
		"lng" : 119.69721800000001,
		"lat" : 26.279993000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 217,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76573439675165,
		  26.344411176065652
		]
	  },
	  "properties" : {
		"FID" : 217,
		"name" : "连江圆通寺",
		"lng" : 119.77029,
		"lat" : 26.341114999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 218,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51520635317986,
		  26.194622195259512
		]
	  },
	  "properties" : {
		"FID" : 218,
		"name" : "宝华后岩寺",
		"lng" : 119.519845,
		"lat" : 26.191351000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 219,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73523952853051,
		  26.360138583445639
		]
	  },
	  "properties" : {
		"FID" : 219,
		"name" : "白马尊王宫",
		"lng" : 119.739825,
		"lat" : 26.356840999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 220,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66252263675943,
		  26.37742701682614
		]
	  },
	  "properties" : {
		"FID" : 220,
		"name" : "马鼻双泉陈氏宗祠",
		"lng" : 119.667046,
		"lat" : 26.374020000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 221,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54025599655056,
		  26.197249950889191
		]
	  },
	  "properties" : {
		"FID" : 221,
		"name" : "平水庙",
		"lng" : 119.54481199999999,
		"lat" : 26.193912999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 222,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73523952853051,
		  26.360138583445639
		]
	  },
	  "properties" : {
		"FID" : 222,
		"name" : "白马尊王宫",
		"lng" : 119.739825,
		"lat" : 26.356840999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 223,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66252263675943,
		  26.37742701682614
		]
	  },
	  "properties" : {
		"FID" : 223,
		"name" : "马鼻双泉陈氏宗祠",
		"lng" : 119.667046,
		"lat" : 26.374020000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 224,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60192427988552,
		  26.242873850722049
		]
	  },
	  "properties" : {
		"FID" : 224,
		"name" : "中兴公园",
		"lng" : 119.606385,
		"lat" : 26.239450999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 225,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65400411086054,
		  26.374958017105293
		]
	  },
	  "properties" : {
		"FID" : 225,
		"name" : "英显宫",
		"lng" : 119.65851499999999,
		"lat" : 26.371535999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 226,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60897073536538,
		  26.373848764728425
		]
	  },
	  "properties" : {
		"FID" : 226,
		"name" : "连江仙踪寺",
		"lng" : 119.61344099999999,
		"lat" : 26.370366000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 227,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.68455189818965,
		  26.340286685970053
		]
	  },
	  "properties" : {
		"FID" : 227,
		"name" : "蓝氏宗祠",
		"lng" : 119.689104,
		"lat" : 26.336936999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 228,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.72029782651254,
		  26.278556887562821
		]
	  },
	  "properties" : {
		"FID" : 228,
		"name" : "蛤沙文体公园",
		"lng" : 119.72487700000001,
		"lat" : 26.275288
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 229,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66595139177078,
		  26.380199585022119
		]
	  },
	  "properties" : {
		"FID" : 229,
		"name" : "马头石公园",
		"lng" : 119.67048,
		"lat" : 26.376798000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 230,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55062258482582,
		  26.209245112709361
		]
	  },
	  "properties" : {
		"FID" : 230,
		"name" : "荷山寺",
		"lng" : 119.555151,
		"lat" : 26.205880000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 231,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62117906324535,
		  26.275817156461933
		]
	  },
	  "properties" : {
		"FID" : 231,
		"name" : "龙泉禅寺",
		"lng" : 119.625647,
		"lat" : 26.272390999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 232,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63908206561769,
		  26.339872865435758
		]
	  },
	  "properties" : {
		"FID" : 232,
		"name" : "报慈寺",
		"lng" : 119.64357099999999,
		"lat" : 26.33644
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 233,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58248837241877,
		  26.257334827180642
		]
	  },
	  "properties" : {
		"FID" : 233,
		"name" : "连江浦口浦元寺",
		"lng" : 119.586962,
		"lat" : 26.253905
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 234,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53600875949935,
		  26.203342866048747
		]
	  },
	  "properties" : {
		"FID" : 234,
		"name" : "林氏宗祠",
		"lng" : 119.540578,
		"lat" : 26.200012000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 235,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45349494497684,
		  26.262165143506174
		]
	  },
	  "properties" : {
		"FID" : 235,
		"name" : "广福寺",
		"lng" : 119.45835700000001,
		"lat" : 26.259029999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 236,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55470371114353,
		  26.20795956354435
		]
	  },
	  "properties" : {
		"FID" : 236,
		"name" : "含光生态公园",
		"lng" : 119.55922200000001,
		"lat" : 26.204588000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 237,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53536398381277,
		  26.227625423578171
		]
	  },
	  "properties" : {
		"FID" : 237,
		"name" : "九龙山公园",
		"lng" : 119.53993699999999,
		"lat" : 26.224281999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 238,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59203097439372,
		  26.236100661565775
		]
	  },
	  "properties" : {
		"FID" : 238,
		"name" : "文体公园",
		"lng" : 119.596495,
		"lat" : 26.232679999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 239,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.70675319405197,
		  26.28126572677736
		]
	  },
	  "properties" : {
		"FID" : 239,
		"name" : "大王庙",
		"lng" : 119.711325,
		"lat" : 26.277979999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 240,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52301027798362,
		  26.202438449252849
		]
	  },
	  "properties" : {
		"FID" : 240,
		"name" : "玉泉公园",
		"lng" : 119.52762199999999,
		"lat" : 26.199141000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 241,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58872091367768,
		  26.24658307305517
		]
	  },
	  "properties" : {
		"FID" : 241,
		"name" : "慈福禅寺",
		"lng" : 119.593188,
		"lat" : 26.243157
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 242,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47058568216538,
		  26.434165100516431
		]
	  },
	  "properties" : {
		"FID" : 242,
		"name" : "隐峰禅寺",
		"lng" : 119.47540600000001,
		"lat" : 26.430910999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 243,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.96854978752161,
		  26.218141724831614
		]
	  },
	  "properties" : {
		"FID" : 243,
		"name" : "玉皇府",
		"lng" : 119.972852,
		"lat" : 26.214841
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 244,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67500814787817,
		  26.326333953016221
		]
	  },
	  "properties" : {
		"FID" : 244,
		"name" : "隐安寺",
		"lng" : 119.679546,
		"lat" : 26.322973000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 245,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65702019192109,
		  26.329118459911239
		]
	  },
	  "properties" : {
		"FID" : 245,
		"name" : "隐峰寺",
		"lng" : 119.66153199999999,
		"lat" : 26.325721999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 246,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63135341093175,
		  26.378804126882692
		]
	  },
	  "properties" : {
		"FID" : 246,
		"name" : "文体公园",
		"lng" : 119.635837,
		"lat" : 26.375343000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 247,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62173350188738,
		  26.442620369123929
		]
	  },
	  "properties" : {
		"FID" : 247,
		"name" : "巽屿村红色主题公园",
		"lng" : 119.626214,
		"lat" : 26.439124
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 248,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.75390367645062,
		  26.451050159658781
		]
	  },
	  "properties" : {
		"FID" : 248,
		"name" : "三学寺",
		"lng" : 119.758483,
		"lat" : 26.44772
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 249,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65676298130589,
		  26.377753027971092
		]
	  },
	  "properties" : {
		"FID" : 249,
		"name" : "连江慈音寺",
		"lng" : 119.661278,
		"lat" : 26.374334999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 250,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.99298369771057,
		  26.23030012993226
		]
	  },
	  "properties" : {
		"FID" : 250,
		"name" : "中山露营区",
		"lng" : 119.997345,
		"lat" : 26.227063999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 251,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.69878839070037,
		  26.281624404995753
		]
	  },
	  "properties" : {
		"FID" : 251,
		"name" : "廻龙陈氏支祠",
		"lng" : 119.70335300000001,
		"lat" : 26.278327000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 252,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.75966613558451,
		  26.444724593350177
		]
	  },
	  "properties" : {
		"FID" : 252,
		"name" : "临水宫",
		"lng" : 119.76423800000001,
		"lat" : 26.441393999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 253,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.99304955325461,
		  26.230017770051301
		]
	  },
	  "properties" : {
		"FID" : 253,
		"name" : "一柱擎天碑",
		"lng" : 119.997411,
		"lat" : 26.226782
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 254,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64887014294689,
		  26.225576608716789
		]
	  },
	  "properties" : {
		"FID" : 254,
		"name" : "龟山公园",
		"lng" : 119.653363,
		"lat" : 26.222218999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 255,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64094436618102,
		  26.278528068742702
		]
	  },
	  "properties" : {
		"FID" : 255,
		"name" : "大雄宝殿",
		"lng" : 119.645431,
		"lat" : 26.275127999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 256,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65966977405419,
		  26.377845599956231
		]
	  },
	  "properties" : {
		"FID" : 256,
		"name" : "马鼻基督教堂",
		"lng" : 119.66418899999999,
		"lat" : 26.374433
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 257,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.94986805355516,
		  26.375151303470489
		]
	  },
	  "properties" : {
		"FID" : 257,
		"name" : "武圣庙",
		"lng" : 119.95414599999999,
		"lat" : 26.371725999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 258,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53596400114237,
		  26.211802723080623
		]
	  },
	  "properties" : {
		"FID" : 258,
		"name" : "三尊王宫",
		"lng" : 119.54053399999999,
		"lat" : 26.208466999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 259,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76812855467945,
		  26.35431138648406
		]
	  },
	  "properties" : {
		"FID" : 259,
		"name" : "金峰寺",
		"lng" : 119.77268100000001,
		"lat" : 26.351009000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 260,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.99581775296849,
		  26.228113275041796
		]
	  },
	  "properties" : {
		"FID" : 260,
		"name" : "马祖北竿机场旅游服务中心",
		"lng" : 120.000186,
		"lat" : 26.224886999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 261,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.98771237406561,
		  26.222922892705128
		]
	  },
	  "properties" : {
		"FID" : 261,
		"name" : "中兴公园",
		"lng" : 119.99206,
		"lat" : 26.219674999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 262,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.99189244444298,
		  26.230082320228657
		]
	  },
	  "properties" : {
		"FID" : 262,
		"name" : "胜利门(北竿乡)",
		"lng" : 119.996251,
		"lat" : 26.226842999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 263,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59903053021141,
		  26.216833988724755
		]
	  },
	  "properties" : {
		"FID" : 263,
		"name" : "云居寺·水中观音",
		"lng" : 119.60348999999999,
		"lat" : 26.213425000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 264,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57569905442172,
		  26.351916908498147
		]
	  },
	  "properties" : {
		"FID" : 264,
		"name" : "光化寺",
		"lng" : 119.58018800000001,
		"lat" : 26.348445000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 265,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54413665419253,
		  26.203751141320303
		]
	  },
	  "properties" : {
		"FID" : 265,
		"name" : "基督教真理堂",
		"lng" : 119.548682,
		"lat" : 26.200402
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 266,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62360883632778,
		  26.242899650621325
		]
	  },
	  "properties" : {
		"FID" : 266,
		"name" : "后山阁",
		"lng" : 119.62807599999999,
		"lat" : 26.239494000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 267,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66439591399403,
		  26.241145510491663
		]
	  },
	  "properties" : {
		"FID" : 267,
		"name" : "百胜海堤休闲步道",
		"lng" : 119.66891200000001,
		"lat" : 26.237808000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 268,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62092913310308,
		  26.345438115681237
		]
	  },
	  "properties" : {
		"FID" : 268,
		"name" : "连江透堡文昌祠",
		"lng" : 119.62540199999999,
		"lat" : 26.341978000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 269,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60309108108208,
		  26.247701056330364
		]
	  },
	  "properties" : {
		"FID" : 269,
		"name" : "浦东公园",
		"lng" : 119.607552,
		"lat" : 26.244275999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 270,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55104241901589,
		  26.19869766578617
		]
	  },
	  "properties" : {
		"FID" : 270,
		"name" : "文新村(下斗门)文体公园",
		"lng" : 119.55556900000001,
		"lat" : 26.195338
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 271,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.545226732708,
		  26.203050976978869
		]
	  },
	  "properties" : {
		"FID" : 271,
		"name" : "永宁禅寺",
		"lng" : 119.549769,
		"lat" : 26.1997
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 272,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63096805253554,
		  26.224623844097213
		]
	  },
	  "properties" : {
		"FID" : 272,
		"name" : "湖里旗山公园",
		"lng" : 119.63544,
		"lat" : 26.221238
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 273,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60333968309307,
		  26.267243517916491
		]
	  },
	  "properties" : {
		"FID" : 273,
		"name" : "聚峰禅寺",
		"lng" : 119.60780200000001,
		"lat" : 26.263808000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 274,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6208169009781,
		  26.349558055691947
		]
	  },
	  "properties" : {
		"FID" : 274,
		"name" : "二三革命纪念园",
		"lng" : 119.62529000000001,
		"lat" : 26.346095999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 275,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59474631796125,
		  26.251947422230572
		]
	  },
	  "properties" : {
		"FID" : 275,
		"name" : "锦山寺",
		"lng" : 119.59921,
		"lat" : 26.248518000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 276,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64537000276779,
		  26.235674452615633
		]
	  },
	  "properties" : {
		"FID" : 276,
		"name" : "功德亭",
		"lng" : 119.64985900000001,
		"lat" : 26.232305
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 277,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.99993068800043,
		  26.224864930271881
		]
	  },
	  "properties" : {
		"FID" : 277,
		"name" : "塘歧尚书庙",
		"lng" : 120.00430900000001,
		"lat" : 26.221653
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 278,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.98078640618392,
		  26.221566787092428
		]
	  },
	  "properties" : {
		"FID" : 278,
		"name" : "戦争和平记念公园",
		"lng" : 119.985117,
		"lat" : 26.218298999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 279,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.97027249498322,
		  26.19749088529111
		]
	  },
	  "properties" : {
		"FID" : 279,
		"name" : "蛤蜊岛",
		"lng" : 119.974577,
		"lat" : 26.194206999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 280,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.98204318194321,
		  26.22421758990712
		]
	  },
	  "properties" : {
		"FID" : 280,
		"name" : "碧山公园(北竿乡)",
		"lng" : 119.986377,
		"lat" : 26.220952
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 281,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.98039997468433,
		  26.226552775083956
		]
	  },
	  "properties" : {
		"FID" : 281,
		"name" : "安宁步道",
		"lng" : 119.98473,
		"lat" : 26.223281
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 282,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  120.00039469198356,
		  26.236389040617969
		]
	  },
	  "properties" : {
		"FID" : 282,
		"name" : "风山",
		"lng" : 120.004775,
		"lat" : 26.233172
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 283,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.99175403698237,
		  26.226679808951864
		]
	  },
	  "properties" : {
		"FID" : 283,
		"name" : "万寿尚书公",
		"lng" : 119.996112,
		"lat" : 26.223441999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 284,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77559067409796,
		  26.41394299834662
		]
	  },
	  "properties" : {
		"FID" : 284,
		"name" : "聚福寺",
		"lng" : 119.780134,
		"lat" : 26.410609999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 285,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.98334098958101,
		  26.280091184104862
		]
	  },
	  "properties" : {
		"FID" : 285,
		"name" : "高登之光纪念碑",
		"lng" : 119.98768200000001,
		"lat" : 26.276799
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 286,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.98815222651253,
		  26.223710016550275
		]
	  },
	  "properties" : {
		"FID" : 286,
		"name" : "榕园",
		"lng" : 119.992501,
		"lat" : 26.220462999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 287,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  120.0084483066787,
		  26.229481939460317
		]
	  },
	  "properties" : {
		"FID" : 287,
		"name" : "战争和平纪念公园",
		"lng" : 120.01284800000001,
		"lat" : 26.226292999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 288,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.99238551554497,
		  26.225877435180649
		]
	  },
	  "properties" : {
		"FID" : 288,
		"name" : "怡园",
		"lng" : 119.996745,
		"lat" : 26.222642
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 289,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.98544357800864,
		  26.228417845396066
		]
	  },
	  "properties" : {
		"FID" : 289,
		"name" : "璧山观景台",
		"lng" : 119.989786,
		"lat" : 26.225159999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 290,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.99282573177523,
		  26.235288421162029
		]
	  },
	  "properties" : {
		"FID" : 290,
		"name" : "雷山",
		"lng" : 119.997187,
		"lat" : 26.232049
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 291,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49746145490444,
		  26.306293025140199
		]
	  },
	  "properties" : {
		"FID" : 291,
		"name" : "佛降寺",
		"lng" : 119.502174,
		"lat" : 26.303013
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 292,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66850415924422,
		  26.278132561581845
		]
	  },
	  "properties" : {
		"FID" : 292,
		"name" : "庄严寺",
		"lng" : 119.673029,
		"lat" : 26.274782999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 293,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6285393154154,
		  26.347035575063856
		]
	  },
	  "properties" : {
		"FID" : 293,
		"name" : "透堡净安禅寺",
		"lng" : 119.63301800000001,
		"lat" : 26.343584
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 294,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65494914311377,
		  26.397108974437518
		]
	  },
	  "properties" : {
		"FID" : 294,
		"name" : "村前滨海公园",
		"lng" : 119.659463,
		"lat" : 26.39368
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 295,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59330729147094,
		  26.324370305755981
		]
	  },
	  "properties" : {
		"FID" : 295,
		"name" : "连江县玉佛寺",
		"lng" : 119.59777699999999,
		"lat" : 26.320903999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 296,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61803299640495,
		  26.246469695547383
		]
	  },
	  "properties" : {
		"FID" : 296,
		"name" : "东岱公园",
		"lng" : 119.622497,
		"lat" : 26.243055999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 297,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61311027415523,
		  26.435017288541232
		]
	  },
	  "properties" : {
		"FID" : 297,
		"name" : "东岳泰山府",
		"lng" : 119.617586,
		"lat" : 26.431515000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 298,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6950237411957,
		  26.290645968645997
		]
	  },
	  "properties" : {
		"FID" : 298,
		"name" : "太子宫",
		"lng" : 119.699585,
		"lat" : 26.287337999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 299,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53827013366765,
		  26.196684152371191
		]
	  },
	  "properties" : {
		"FID" : 299,
		"name" : "连江县妈祖庙",
		"lng" : 119.542832,
		"lat" : 26.193352000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 300,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61294814943439,
		  26.42378264297993
		]
	  },
	  "properties" : {
		"FID" : 300,
		"name" : "罗源瑞云寺",
		"lng" : 119.617423,
		"lat" : 26.420283999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 301,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55186310013566,
		  26.203873215654646
		]
	  },
	  "properties" : {
		"FID" : 301,
		"name" : "含光寺",
		"lng" : 119.556388,
		"lat" : 26.200509
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 302,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.98704755226818,
		  26.229387577646513
		]
	  },
	  "properties" : {
		"FID" : 302,
		"name" : "壁山",
		"lng" : 119.991394,
		"lat" : 26.226133999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 303,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.97983644152519,
		  26.224933508790794
		]
	  },
	  "properties" : {
		"FID" : 303,
		"name" : "赵元帅府",
		"lng" : 119.984165,
		"lat" : 26.221661000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 304,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66522871841561,
		  26.376634531648445
		]
	  },
	  "properties" : {
		"FID" : 304,
		"name" : "连江马鼻东升寺",
		"lng" : 119.66975600000001,
		"lat" : 26.373232999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 305,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53905867303459,
		  26.2215444873259
		]
	  },
	  "properties" : {
		"FID" : 305,
		"name" : "连江县禁毒主题公园",
		"lng" : 119.54362,
		"lat" : 26.218195999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 306,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65619404781906,
		  26.210915788611619
		]
	  },
	  "properties" : {
		"FID" : 306,
		"name" : "横仑观海平台",
		"lng" : 119.660696,
		"lat" : 26.20758
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 307,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56834348279006,
		  26.296361889835108
		]
	  },
	  "properties" : {
		"FID" : 307,
		"name" : "下洋公园",
		"lng" : 119.57284,
		"lat" : 26.292922999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 308,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57487248394943,
		  26.247663590465628
		]
	  },
	  "properties" : {
		"FID" : 308,
		"name" : "连江祇园寺",
		"lng" : 119.57935500000001,
		"lat" : 26.244243999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 309,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58781714162888,
		  26.247315277073938
		]
	  },
	  "properties" : {
		"FID" : 309,
		"name" : "连江金山禅寺",
		"lng" : 119.592285,
		"lat" : 26.243888999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 310,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66364021384459,
		  26.374474688455642
		]
	  },
	  "properties" : {
		"FID" : 310,
		"name" : "连江马鼻净土寺",
		"lng" : 119.668165,
		"lat" : 26.371071000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 311,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65077972924874,
		  26.236859568833715
		]
	  },
	  "properties" : {
		"FID" : 311,
		"name" : "慈恩寺",
		"lng" : 119.655276,
		"lat" : 26.233498999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 312,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65180533217531,
		  26.22301586695686
		]
	  },
	  "properties" : {
		"FID" : 312,
		"name" : "晓澳基督教堂",
		"lng" : 119.656302,
		"lat" : 26.219664999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 313,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.98380294980491,
		  26.223558981925677
		]
	  },
	  "properties" : {
		"FID" : 313,
		"name" : "碧园公园",
		"lng" : 119.988141,
		"lat" : 26.220299000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 314,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.9846957545297,
		  26.223707400642379
		]
	  },
	  "properties" : {
		"FID" : 314,
		"name" : "殉职阵亡官兵纪念塔",
		"lng" : 119.989036,
		"lat" : 26.22045
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 315,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.99367016019717,
		  26.227788620026061
		]
	  },
	  "properties" : {
		"FID" : 315,
		"name" : "北竿卫理堂",
		"lng" : 119.99803300000001,
		"lat" : 26.224556
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 316,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.97262564625261,
		  26.219480163948965
		]
	  },
	  "properties" : {
		"FID" : 316,
		"name" : "阪里据点",
		"lng" : 119.97693700000001,
		"lat" : 26.216190000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 317,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31595450255587,
		  26.21535911837519
		]
	  },
	  "properties" : {
		"FID" : 317,
		"name" : "林阳禅寺",
		"lng" : 119.320808,
		"lat" : 26.212212999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 318,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31672946928532,
		  26.209250092296319
		]
	  },
	  "properties" : {
		"FID" : 318,
		"name" : "玉佛园",
		"lng" : 119.321584,
		"lat" : 26.206109000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 319,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33952146527112,
		  26.216090055681107
		]
	  },
	  "properties" : {
		"FID" : 319,
		"name" : "五峰寺",
		"lng" : 119.34442,
		"lat" : 26.212987999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 320,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30588620039154,
		  26.21973428445807
		]
	  },
	  "properties" : {
		"FID" : 320,
		"name" : "齐大大圣",
		"lng" : 119.310721,
		"lat" : 26.216567000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 321,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33999248452727,
		  26.217818204450317
		]
	  },
	  "properties" : {
		"FID" : 321,
		"name" : "桂湖观音堂",
		"lng" : 119.344892,
		"lat" : 26.214715999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 322,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30416684863981,
		  26.199756676628095
		]
	  },
	  "properties" : {
		"FID" : 322,
		"name" : "苞犧胜境",
		"lng" : 119.30899700000001,
		"lat" : 26.196598000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 323,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32997217985522,
		  26.19133521241266
		]
	  },
	  "properties" : {
		"FID" : 323,
		"name" : "牛项胜境",
		"lng" : 119.334851,
		"lat" : 26.188230000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 324,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27504333873273,
		  26.185546908203516
		]
	  },
	  "properties" : {
		"FID" : 324,
		"name" : "福建寿山国家矿山公园",
		"lng" : 119.27982900000001,
		"lat" : 26.182354
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 325,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34937333945552,
		  26.232154169424604
		]
	  },
	  "properties" : {
		"FID" : 325,
		"name" : "大洋感应坛",
		"lng" : 119.35429000000001,
		"lat" : 26.22906
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 326,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36317549744275,
		  26.195919669754719
		]
	  },
	  "properties" : {
		"FID" : 326,
		"name" : "福州八中北峰分校旧址",
		"lng" : 119.368109,
		"lat" : 26.192867
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 327,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2830278343697,
		  26.196965168154073
		]
	  },
	  "properties" : {
		"FID" : 327,
		"name" : "振兴广场",
		"lng" : 119.287824,
		"lat" : 26.193774999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 328,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36246087675215,
		  26.215406059259369
		]
	  },
	  "properties" : {
		"FID" : 328,
		"name" : "晋安区湖中伽蓝寺",
		"lng" : 119.367395,
		"lat" : 26.212340999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 329,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27146799923288,
		  26.238395340507875
		]
	  },
	  "properties" : {
		"FID" : 329,
		"name" : "九峰村",
		"lng" : 119.27625399999999,
		"lat" : 26.235168000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 330,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27680756249264,
		  26.19647551058981
		]
	  },
	  "properties" : {
		"FID" : 330,
		"name" : "三十三天监雷法主张圣真君",
		"lng" : 119.28159599999999,
		"lat" : 26.193277999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 331,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30210624252348,
		  26.256621598037292
		]
	  },
	  "properties" : {
		"FID" : 331,
		"name" : "芙蓉山-天池",
		"lng" : 119.306937,
		"lat" : 26.253426999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 332,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35912315366538,
		  26.21564976318092
		]
	  },
	  "properties" : {
		"FID" : 332,
		"name" : "溪南胜境",
		"lng" : 119.364053,
		"lat" : 26.212579999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 333,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3446602992597,
		  26.165149403502959
		]
	  },
	  "properties" : {
		"FID" : 333,
		"name" : "大北岭公园",
		"lng" : 119.349564,
		"lat" : 26.162087
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 334,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30872662166388,
		  26.276560352383612
		]
	  },
	  "properties" : {
		"FID" : 334,
		"name" : "芙蓉洞",
		"lng" : 119.313571,
		"lat" : 26.273367
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 335,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36638945657566,
		  26.187312496192977
		]
	  },
	  "properties" : {
		"FID" : 335,
		"name" : "宦溪镇坂桥村孔子广场",
		"lng" : 119.371326,
		"lat" : 26.184269
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 336,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27282961210113,
		  26.239116400546116
		]
	  },
	  "properties" : {
		"FID" : 336,
		"name" : "九峰樟溪境",
		"lng" : 119.27761700000001,
		"lat" : 26.235890000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 337,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27071133840127,
		  26.190167064354618
		]
	  },
	  "properties" : {
		"FID" : 337,
		"name" : "岭头桃枝境",
		"lng" : 119.275493,
		"lat" : 26.186966999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 338,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26159820999801,
		  26.204133503529995
		]
	  },
	  "properties" : {
		"FID" : 338,
		"name" : "飞云峡风景区",
		"lng" : 119.266374,
		"lat" : 26.200918000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 339,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33402141711105,
		  26.166099220792155
		]
	  },
	  "properties" : {
		"FID" : 339,
		"name" : "小岭半山亭",
		"lng" : 119.33890599999999,
		"lat" : 26.163017
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 340,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29631628591528,
		  26.163448054877612
		]
	  },
	  "properties" : {
		"FID" : 340,
		"name" : "古城山长安堂",
		"lng" : 119.30113,
		"lat" : 26.160298000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 341,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27142193773713,
		  26.186609247543146
		]
	  },
	  "properties" : {
		"FID" : 341,
		"name" : "八·一七公园",
		"lng" : 119.27620400000001,
		"lat" : 26.183412000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 342,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38554801355831,
		  26.211630349049162
		]
	  },
	  "properties" : {
		"FID" : 342,
		"name" : "福州普光寺",
		"lng" : 119.3905,
		"lat" : 26.208589
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 343,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33435148908211,
		  26.170157106993663
		]
	  },
	  "properties" : {
		"FID" : 343,
		"name" : "观景亭",
		"lng" : 119.339237,
		"lat" : 26.167072999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 344,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32113557453181,
		  26.161113626703266
		]
	  },
	  "properties" : {
		"FID" : 344,
		"name" : "八神车山府道观",
		"lng" : 119.32599500000001,
		"lat" : 26.158010000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 345,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2716537149724,
		  26.253087274536274
		]
	  },
	  "properties" : {
		"FID" : 345,
		"name" : "九峰寺",
		"lng" : 119.27644100000001,
		"lat" : 26.249852000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 346,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35779529263249,
		  26.172103660640097
		]
	  },
	  "properties" : {
		"FID" : 346,
		"name" : "茶峰胜境",
		"lng" : 119.36272,
		"lat" : 26.169058
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 347,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31921668683657,
		  26.287617364856466
		]
	  },
	  "properties" : {
		"FID" : 347,
		"name" : "天使之泪",
		"lng" : 119.324082,
		"lat" : 26.284438000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 348,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33659861921502,
		  26.1529222345664
		]
	  },
	  "properties" : {
		"FID" : 348,
		"name" : "象峰崇福寺",
		"lng" : 119.341487,
		"lat" : 26.149853
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 349,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2940336482434,
		  26.287747437405571
		]
	  },
	  "properties" : {
		"FID" : 349,
		"name" : "寿山石古矿洞景区",
		"lng" : 119.29885299999999,
		"lat" : 26.284523
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 350,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32070333544004,
		  26.162157101184714
		]
	  },
	  "properties" : {
		"FID" : 350,
		"name" : "莲花山莲花寺",
		"lng" : 119.32556200000001,
		"lat" : 26.159051999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 351,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37732727992513,
		  26.233295223296949
		]
	  },
	  "properties" : {
		"FID" : 351,
		"name" : "长发胜境",
		"lng" : 119.382277,
		"lat" : 26.230236000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 352,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36531474376181,
		  26.173059139499561
		]
	  },
	  "properties" : {
		"FID" : 352,
		"name" : "松峰勝境",
		"lng" : 119.370249,
		"lat" : 26.170023
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 353,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36601863510755,
		  26.151099647669902
		]
	  },
	  "properties" : {
		"FID" : 353,
		"name" : "福州快乐园",
		"lng" : 119.370952,
		"lat" : 26.148078000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 354,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32341992311035,
		  26.150725764024202
		]
	  },
	  "properties" : {
		"FID" : 354,
		"name" : "真武殿",
		"lng" : 119.328283,
		"lat" : 26.147632999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 355,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3285556605272,
		  26.155010640824269
		]
	  },
	  "properties" : {
		"FID" : 355,
		"name" : "善扬堂",
		"lng" : 119.333429,
		"lat" : 26.151924999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 356,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33251189605619,
		  26.144628625196063
		]
	  },
	  "properties" : {
		"FID" : 356,
		"name" : "维多利亚公园",
		"lng" : 119.33739199999999,
		"lat" : 26.141556999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 357,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32873934201483,
		  26.154554005677916
		]
	  },
	  "properties" : {
		"FID" : 357,
		"name" : "天母殿",
		"lng" : 119.333613,
		"lat" : 26.151468999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 358,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38227987711396,
		  26.163802410715071
		]
	  },
	  "properties" : {
		"FID" : 358,
		"name" : "鹅峰寺",
		"lng" : 119.387227,
		"lat" : 26.160788
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 359,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40639344053081,
		  26.251787878810564
		]
	  },
	  "properties" : {
		"FID" : 359,
		"name" : "福州贵安新天地休闲旅游度假区",
		"lng" : 119.411344,
		"lat" : 26.248725
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 360,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29787364789699,
		  26.150362312337883
		]
	  },
	  "properties" : {
		"FID" : 360,
		"name" : "莲花山风景区",
		"lng" : 119.302689,
		"lat" : 26.147223
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 361,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32038164537252,
		  26.15312708282131
		]
	  },
	  "properties" : {
		"FID" : 361,
		"name" : "光华境",
		"lng" : 119.325239,
		"lat" : 26.150027000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 362,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37874945545501,
		  26.258431964971297
		]
	  },
	  "properties" : {
		"FID" : 362,
		"name" : "港里境",
		"lng" : 119.383702,
		"lat" : 26.25536
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 363,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2843616860816,
		  26.095161268245622
		]
	  },
	  "properties" : {
		"FID" : 363,
		"name" : "西湖公园",
		"lng" : 119.289152,
		"lat" : 26.092037000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 364,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34373492164475,
		  26.164778784506016
		]
	  },
	  "properties" : {
		"FID" : 364,
		"name" : "文昌阁",
		"lng" : 119.348637,
		"lat" : 26.161715000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 365,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29249318222429,
		  26.088081746373721
		]
	  },
	  "properties" : {
		"FID" : 365,
		"name" : "三坊七巷-天后宫(郎官巷)",
		"lng" : 119.29729500000001,
		"lat" : 26.084973999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 366,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31553802170323,
		  26.126749547379628
		]
	  },
	  "properties" : {
		"FID" : 366,
		"name" : "福州财神庙",
		"lng" : 119.320384,
		"lat" : 26.123657000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 367,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30508572811841,
		  26.126327557346002
		]
	  },
	  "properties" : {
		"FID" : 367,
		"name" : "琴亭湖公园",
		"lng" : 119.309912,
		"lat" : 26.123215999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 368,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26834269954982,
		  26.146651371923049
		]
	  },
	  "properties" : {
		"FID" : 368,
		"name" : "升山寺",
		"lng" : 119.27311899999999,
		"lat" : 26.143476
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 369,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28268449604273,
		  26.10111040789948
		]
	  },
	  "properties" : {
		"FID" : 369,
		"name" : "福州左海公园海底世界",
		"lng" : 119.28747300000001,
		"lat" : 26.09798
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 370,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2924257896052,
		  26.108022950996801
		]
	  },
	  "properties" : {
		"FID" : 370,
		"name" : "屏山公园",
		"lng" : 119.297229,
		"lat" : 26.104901999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 371,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29113043133677,
		  26.086569844441016
		]
	  },
	  "properties" : {
		"FID" : 371,
		"name" : "衣锦坊水榭戏台",
		"lng" : 119.29593,
		"lat" : 26.083461
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 372,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29292181400892,
		  26.083922324022261
		]
	  },
	  "properties" : {
		"FID" : 372,
		"name" : "严復翰墨馆",
		"lng" : 119.297724,
		"lat" : 26.080818000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 373,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32825625504447,
		  26.154769059562202
		]
	  },
	  "properties" : {
		"FID" : 373,
		"name" : "古田临水宫",
		"lng" : 119.333129,
		"lat" : 26.151682999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 374,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33484149698275,
		  26.158003665979265
		]
	  },
	  "properties" : {
		"FID" : 374,
		"name" : "状元岭文昌庙",
		"lng" : 119.339727,
		"lat" : 26.154928000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 375,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29277583050595,
		  26.086794454411113
		]
	  },
	  "properties" : {
		"FID" : 375,
		"name" : "小黄楼",
		"lng" : 119.297578,
		"lat" : 26.083687999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 376,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30087971652262,
		  26.080469934358057
		]
	  },
	  "properties" : {
		"FID" : 376,
		"name" : "定光寺",
		"lng" : 119.305695,
		"lat" : 26.077380999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 377,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29419973162986,
		  26.09758632597525
		]
	  },
	  "properties" : {
		"FID" : 377,
		"name" : "冶山古迹",
		"lng" : 119.29900499999999,
		"lat" : 26.094474999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 378,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30973619752815,
		  26.138396834316968
		]
	  },
	  "properties" : {
		"FID" : 378,
		"name" : "临水宫",
		"lng" : 119.314572,
		"lat" : 26.135286000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 379,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34114956222713,
		  26.110897095908935
		]
	  },
	  "properties" : {
		"FID" : 379,
		"name" : "灵峰寺",
		"lng" : 119.34604299999999,
		"lat" : 26.107862999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 380,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2206382441364,
		  26.101167287010586
		]
	  },
	  "properties" : {
		"FID" : 380,
		"name" : "分水岭",
		"lng" : 119.225416,
		"lat" : 26.098022
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 381,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36850547457875,
		  26.092466928088328
		]
	  },
	  "properties" : {
		"FID" : 381,
		"name" : "鳝溪风景区",
		"lng" : 119.373437,
		"lat" : 26.089486000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 382,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27408214309676,
		  26.121825042856994
		]
	  },
	  "properties" : {
		"FID" : 382,
		"name" : "林则徐墓",
		"lng" : 119.278862,
		"lat" : 26.118670999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 383,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30161242302914,
		  26.080500689744166
		]
	  },
	  "properties" : {
		"FID" : 383,
		"name" : "于山风景区-戚公祠",
		"lng" : 119.30642899999999,
		"lat" : 26.077413
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 384,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28766173245235,
		  26.152090315876595
		]
	  },
	  "properties" : {
		"FID" : 384,
		"name" : "福州植物园",
		"lng" : 119.292461,
		"lat" : 26.148934000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 385,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28652302789959,
		  26.143481513008751
		]
	  },
	  "properties" : {
		"FID" : 385,
		"name" : "福州动物园-海狮表演馆",
		"lng" : 119.29132,
		"lat" : 26.140329000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 386,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29365651447266,
		  26.085554249717799
		]
	  },
	  "properties" : {
		"FID" : 386,
		"name" : "新四军驻办事处旧址",
		"lng" : 119.29846000000001,
		"lat" : 26.082450000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 387,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24006362678259,
		  26.216366415705096
		]
	  },
	  "properties" : {
		"FID" : 387,
		"name" : "鹏飞生态园",
		"lng" : 119.244837,
		"lat" : 26.213139000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 388,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26693470047509,
		  26.095207337934927
		]
	  },
	  "properties" : {
		"FID" : 388,
		"name" : "悬空栈道",
		"lng" : 119.27170599999999,
		"lat" : 26.092064000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 389,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39314713289728,
		  26.094495561893417
		]
	  },
	  "properties" : {
		"FID" : 389,
		"name" : "柳杉王公园",
		"lng" : 119.39809099999999,
		"lat" : 26.091529999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 390,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38489256984882,
		  26.076282441274962
		]
	  },
	  "properties" : {
		"FID" : 390,
		"name" : "白云洞",
		"lng" : 119.38983399999999,
		"lat" : 26.073326000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 391,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29532716720111,
		  26.080577278343846
		]
	  },
	  "properties" : {
		"FID" : 391,
		"name" : "三坊七巷-邓拓故居",
		"lng" : 119.300133,
		"lat" : 26.077479
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 392,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29102844017601,
		  26.088555312999034
		]
	  },
	  "properties" : {
		"FID" : 392,
		"name" : "三坊七巷-林觉民故居",
		"lng" : 119.295828,
		"lat" : 26.085445
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 393,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25375253646597,
		  26.084738993858615
		]
	  },
	  "properties" : {
		"FID" : 393,
		"name" : "月崖观景台",
		"lng" : 119.258516,
		"lat" : 26.081595
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 394,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29342504367624,
		  26.096766013983615
		]
	  },
	  "properties" : {
		"FID" : 394,
		"name" : "福建都城隍庙",
		"lng" : 119.29822900000001,
		"lat" : 26.093654000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 395,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40591454723378,
		  26.245851430579208
		]
	  },
	  "properties" : {
		"FID" : 395,
		"name" : "钟楼",
		"lng" : 119.410865,
		"lat" : 26.242792000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 396,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33405532966347,
		  26.126959470309188
		]
	  },
	  "properties" : {
		"FID" : 396,
		"name" : "石林古寺",
		"lng" : 119.338937,
		"lat" : 26.123902000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 397,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29838696955471,
		  26.094657551907048
		]
	  },
	  "properties" : {
		"FID" : 397,
		"name" : "七星井临水宫",
		"lng" : 119.30319900000001,
		"lat" : 26.091555
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 398,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29220285227326,
		  26.08526933574651
		]
	  },
	  "properties" : {
		"FID" : 398,
		"name" : "三坊七巷-安民巷",
		"lng" : 119.297004,
		"lat" : 26.082163000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 399,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29672092814849,
		  26.079546321225997
		]
	  },
	  "properties" : {
		"FID" : 399,
		"name" : "明城墙遗址公园",
		"lng" : 119.301529,
		"lat" : 26.076450999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 400,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3208753023559,
		  26.105399551577282
		]
	  },
	  "properties" : {
		"FID" : 400,
		"name" : "金鸡山公园",
		"lng" : 119.32572999999999,
		"lat" : 26.102331
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 401,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34609941253299,
		  26.065875695358788
		]
	  },
	  "properties" : {
		"FID" : 401,
		"name" : "水上公园",
		"lng" : 119.350998,
		"lat" : 26.06288
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 402,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33040600197205,
		  26.064214090139256
		]
	  },
	  "properties" : {
		"FID" : 402,
		"name" : "光明港公园",
		"lng" : 119.33527599999999,
		"lat" : 26.061191000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 403,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3115921983469,
		  26.09197229404047
		]
	  },
	  "properties" : {
		"FID" : 403,
		"name" : "晋安河公园",
		"lng" : 119.316428,
		"lat" : 26.088895000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 404,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26593358988654,
		  26.093622087313356
		]
	  },
	  "properties" : {
		"FID" : 404,
		"name" : "梅峰山地公园",
		"lng" : 119.27070399999999,
		"lat" : 26.090478999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 405,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24162625737024,
		  26.266498541063577
		]
	  },
	  "properties" : {
		"FID" : 405,
		"name" : "福州翠微寺",
		"lng" : 119.246403,
		"lat" : 26.263242999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 406,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39151427071072,
		  26.248709103231985
		]
	  },
	  "properties" : {
		"FID" : 406,
		"name" : "五官大帝宫",
		"lng" : 119.39646999999999,
		"lat" : 26.245649
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 407,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23686820102924,
		  26.10024644213706
		]
	  },
	  "properties" : {
		"FID" : 407,
		"name" : "观音亭普觉寺",
		"lng" : 119.241634,
		"lat" : 26.097092
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 408,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30200450356031,
		  26.083485990146031
		]
	  },
	  "properties" : {
		"FID" : 408,
		"name" : "观巷基督教堂",
		"lng" : 119.306822,
		"lat" : 26.080397000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 409,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29152942811054,
		  26.091661599097225
		]
	  },
	  "properties" : {
		"FID" : 409,
		"name" : "曙光水族",
		"lng" : 119.29633,
		"lat" : 26.088550000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 410,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3895719390943,
		  26.097733614928423
		]
	  },
	  "properties" : {
		"FID" : 410,
		"name" : "映月湖公园",
		"lng" : 119.394516,
		"lat" : 26.094764999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 411,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28043725952455,
		  26.142779153560596
		]
	  },
	  "properties" : {
		"FID" : 411,
		"name" : "福州动物园",
		"lng" : 119.28522599999999,
		"lat" : 26.139619
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 412,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28844675489071,
		  26.123129747614051
		]
	  },
	  "properties" : {
		"FID" : 412,
		"name" : "义井登山公园",
		"lng" : 119.293245,
		"lat" : 26.119993000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 413,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29412090344601,
		  26.083702286206147
		]
	  },
	  "properties" : {
		"FID" : 413,
		"name" : "坊巷讲习所",
		"lng" : 119.298925,
		"lat" : 26.0806
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 414,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28528805385439,
		  26.086514295195258
		]
	  },
	  "properties" : {
		"FID" : 414,
		"name" : "西水关公园",
		"lng" : 119.29007900000001,
		"lat" : 26.083397000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 415,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32172137137805,
		  26.069548229410003
		]
	  },
	  "properties" : {
		"FID" : 415,
		"name" : "瑞云寺",
		"lng" : 119.32657500000001,
		"lat" : 26.066504999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 416,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2848859168657,
		  26.095789968855755
		]
	  },
	  "properties" : {
		"FID" : 416,
		"name" : "开化寺",
		"lng" : 119.289677,
		"lat" : 26.092666000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 417,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3576430153625,
		  26.060510768586482
		]
	  },
	  "properties" : {
		"FID" : 417,
		"name" : "凤洋将军庙",
		"lng" : 119.362559,
		"lat" : 26.057537
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 418,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30376207436022,
		  26.100530150427961
		]
	  },
	  "properties" : {
		"FID" : 418,
		"name" : "福州广场",
		"lng" : 119.308584,
		"lat" : 26.097432999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 419,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29103044384107,
		  26.088465250414782
		]
	  },
	  "properties" : {
		"FID" : 419,
		"name" : "三坊七巷-冰心故居",
		"lng" : 119.29583,
		"lat" : 26.085355
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 420,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23979464083128,
		  26.2018028403382
		]
	  },
	  "properties" : {
		"FID" : 420,
		"name" : "菩提寺",
		"lng" : 119.244567,
		"lat" : 26.198584
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 421,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29205871763314,
		  26.103383487982438
		]
	  },
	  "properties" : {
		"FID" : 421,
		"name" : "华林寺",
		"lng" : 119.29686100000001,
		"lat" : 26.100265
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 422,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29203988836196,
		  26.088203529527323
		]
	  },
	  "properties" : {
		"FID" : 422,
		"name" : "三坊七巷-王麒故居",
		"lng" : 119.296841,
		"lat" : 26.085094999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 423,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30291507237639,
		  26.080937709337963
		]
	  },
	  "properties" : {
		"FID" : 423,
		"name" : "状元峰",
		"lng" : 119.307734,
		"lat" : 26.077852
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 424,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30096541139815,
		  26.069237303927142
		]
	  },
	  "properties" : {
		"FID" : 424,
		"name" : "茶亭公园-古榕广场",
		"lng" : 119.30578,
		"lat" : 26.066155999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 425,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28938271983256,
		  26.104982586484404
		]
	  },
	  "properties" : {
		"FID" : 425,
		"name" : "苔泉古井",
		"lng" : 119.29418099999999,
		"lat" : 26.101859000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 426,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28017869848763,
		  26.101267697108259
		]
	  },
	  "properties" : {
		"FID" : 426,
		"name" : "左海公园",
		"lng" : 119.284964,
		"lat" : 26.098134000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 427,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29247271131509,
		  26.081472399372462
		]
	  },
	  "properties" : {
		"FID" : 427,
		"name" : "林则徐纪念馆",
		"lng" : 119.297274,
		"lat" : 26.078368999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 428,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28515416930979,
		  26.100785882898887
		]
	  },
	  "properties" : {
		"FID" : 428,
		"name" : "湖边公园",
		"lng" : 119.289946,
		"lat" : 26.097659
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 429,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39359021355372,
		  26.237604515628018
		]
	  },
	  "properties" : {
		"FID" : 429,
		"name" : "汾潭岐胜境",
		"lng" : 119.398545,
		"lat" : 26.234551
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 430,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32585514462662,
		  26.111898262294499
		]
	  },
	  "properties" : {
		"FID" : 430,
		"name" : "双龙寺",
		"lng" : 119.33072,
		"lat" : 26.108834999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 431,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22154039544736,
		  26.098109064742715
		]
	  },
	  "properties" : {
		"FID" : 431,
		"name" : "接官道",
		"lng" : 119.22631699999999,
		"lat" : 26.094964999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 432,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22146315717833,
		  26.100256408800671
		]
	  },
	  "properties" : {
		"FID" : 432,
		"name" : "三相公祖殿",
		"lng" : 119.22624,
		"lat" : 26.097111000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 433,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29361558509584,
		  26.085491272695577
		]
	  },
	  "properties" : {
		"FID" : 433,
		"name" : "福建新四军抗战史暨福州抗战史展览馆",
		"lng" : 119.298419,
		"lat" : 26.082387000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 434,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30249384464416,
		  26.080675272251561
		]
	  },
	  "properties" : {
		"FID" : 434,
		"name" : "福州辛亥革命纪念馆",
		"lng" : 119.307312,
		"lat" : 26.077589
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 435,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29044679847719,
		  26.082404120462378
		]
	  },
	  "properties" : {
		"FID" : 435,
		"name" : "光禄坊公园",
		"lng" : 119.29524499999999,
		"lat" : 26.079297
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 436,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31507426790523,
		  26.095624172343786
		]
	  },
	  "properties" : {
		"FID" : 436,
		"name" : "地藏寺",
		"lng" : 119.319917,
		"lat" : 26.092551
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 437,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25632998087782,
		  26.080917478173873
		]
	  },
	  "properties" : {
		"FID" : 437,
		"name" : "金牛山公园",
		"lng" : 119.261094,
		"lat" : 26.077777000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 438,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32651167484683,
		  26.154068948317409
		]
	  },
	  "properties" : {
		"FID" : 438,
		"name" : "象峰東西境",
		"lng" : 119.33138099999999,
		"lat" : 26.150980000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 439,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29485497288164,
		  26.080174771814065
		]
	  },
	  "properties" : {
		"FID" : 439,
		"name" : "第一山景区",
		"lng" : 119.29966,
		"lat" : 26.077076000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 440,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25617121108903,
		  26.078632026889931
		]
	  },
	  "properties" : {
		"FID" : 440,
		"name" : "西河公园",
		"lng" : 119.260935,
		"lat" : 26.075493000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 441,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.311751939763,
		  26.064877985295112
		]
	  },
	  "properties" : {
		"FID" : 441,
		"name" : "路通古迹",
		"lng" : 119.316586,
		"lat" : 26.061819
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 442,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32130835278569,
		  26.067177434766261
		]
	  },
	  "properties" : {
		"FID" : 442,
		"name" : "福州市博物馆",
		"lng" : 119.326161,
		"lat" : 26.064135
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 443,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29529601679745,
		  26.069957255212074
		]
	  },
	  "properties" : {
		"FID" : 443,
		"name" : "齐天大圣府",
		"lng" : 119.300101,
		"lat" : 26.066866000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 444,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28554774577712,
		  26.152322448335031
		]
	  },
	  "properties" : {
		"FID" : 444,
		"name" : "福州国家森林公园-珍稀植物园",
		"lng" : 119.290344,
		"lat" : 26.149163000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 445,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29847456335972,
		  26.137881412909838
		]
	  },
	  "properties" : {
		"FID" : 445,
		"name" : "凤口境",
		"lng" : 119.30329,
		"lat" : 26.134751000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 446,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25369325974498,
		  26.088660609214909
		]
	  },
	  "properties" : {
		"FID" : 446,
		"name" : "金牛山儿童乐园",
		"lng" : 119.25845700000001,
		"lat" : 26.085514
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 447,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39570634084349,
		  26.253010780157773
		]
	  },
	  "properties" : {
		"FID" : 447,
		"name" : "福州百姓长廊-国石馆",
		"lng" : 119.400662,
		"lat" : 26.249949000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 448,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34648584598467,
		  26.156748047407749
		]
	  },
	  "properties" : {
		"FID" : 448,
		"name" : "兴化山临水宫",
		"lng" : 119.351392,
		"lat" : 26.153694000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 449,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25294224908143,
		  26.331274745844446
		]
	  },
	  "properties" : {
		"FID" : 449,
		"name" : "卧龙谷",
		"lng" : 119.257724,
		"lat" : 26.327988000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 450,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31529654116483,
		  26.099582353700434
		]
	  },
	  "properties" : {
		"FID" : 450,
		"name" : "金鸡山公园-南天照天君宫",
		"lng" : 119.32013999999999,
		"lat" : 26.096506999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 451,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39657519267726,
		  26.244414013513833
		]
	  },
	  "properties" : {
		"FID" : 451,
		"name" : "旋转木马",
		"lng" : 119.40152999999999,
		"lat" : 26.241357000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 452,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36259498149366,
		  26.094131267806592
		]
	  },
	  "properties" : {
		"FID" : 452,
		"name" : "龙溪境",
		"lng" : 119.36752,
		"lat" : 26.091142000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 453,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38486342619876,
		  26.078287790835681
		]
	  },
	  "properties" : {
		"FID" : 453,
		"name" : "白云洞-海音洞",
		"lng" : 119.389805,
		"lat" : 26.075330000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 454,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30748826924059,
		  26.100355357362158
		]
	  },
	  "properties" : {
		"FID" : 454,
		"name" : "温泉公园",
		"lng" : 119.31231699999999,
		"lat" : 26.097265
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 455,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27681167355395,
		  26.075026338791446
		]
	  },
	  "properties" : {
		"FID" : 455,
		"name" : "三和堂",
		"lng" : 119.28159100000001,
		"lat" : 26.071905999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 456,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29009605623712,
		  26.086113105995526
		]
	  },
	  "properties" : {
		"FID" : 456,
		"name" : "三坊七巷-衣锦坊欧阳氏民居",
		"lng" : 119.294894,
		"lat" : 26.083003000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 457,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30146674968299,
		  26.07958133122013
		]
	  },
	  "properties" : {
		"FID" : 457,
		"name" : "福州明代古城墙遗迹",
		"lng" : 119.30628299999999,
		"lat" : 26.076494
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 458,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29554924937264,
		  26.087910778970475
		]
	  },
	  "properties" : {
		"FID" : 458,
		"name" : "基督教花巷堂",
		"lng" : 119.30035599999999,
		"lat" : 26.084807999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 459,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25776390668383,
		  26.10087099752284
		]
	  },
	  "properties" : {
		"FID" : 459,
		"name" : "福州保福太子府1号",
		"lng" : 119.26253,
		"lat" : 26.097718
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 460,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36554824685697,
		  26.08447513391393
		]
	  },
	  "properties" : {
		"FID" : 460,
		"name" : "福州樟林吴氏宗祠",
		"lng" : 119.370476,
		"lat" : 26.081496000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 461,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29025598660006,
		  26.083789326424135
		]
	  },
	  "properties" : {
		"FID" : 461,
		"name" : "何振岱故居",
		"lng" : 119.29505399999999,
		"lat" : 26.080680999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 462,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39576679352628,
		  26.247273632840088
		]
	  },
	  "properties" : {
		"FID" : 462,
		"name" : "恐龙乐园",
		"lng" : 119.400722,
		"lat" : 26.244215000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 463,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29605771207724,
		  26.097142038919849
		]
	  },
	  "properties" : {
		"FID" : 463,
		"name" : "林则徐出生地",
		"lng" : 119.300866,
		"lat" : 26.094034000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 464,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3999040241261,
		  26.247710966836998
		]
	  },
	  "properties" : {
		"FID" : 464,
		"name" : "贵安奇趣家儿童职业体验中心",
		"lng" : 119.404858,
		"lat" : 26.244651999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 465,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39702451883963,
		  26.254673629816843
		]
	  },
	  "properties" : {
		"FID" : 465,
		"name" : "温泉世界",
		"lng" : 119.40197999999999,
		"lat" : 26.251611
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 466,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25553421711686,
		  26.068220345611593
		]
	  },
	  "properties" : {
		"FID" : 466,
		"name" : "闽江公园南园-玉皇大帝庙",
		"lng" : 119.26029699999999,
		"lat" : 26.065087999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 467,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29131079320216,
		  26.078024899793476
		]
	  },
	  "properties" : {
		"FID" : 467,
		"name" : "卧牛石",
		"lng" : 119.29611,
		"lat" : 26.074922000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 468,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28672316951634,
		  26.151076019347599
		]
	  },
	  "properties" : {
		"FID" : 468,
		"name" : "福州国家森林公园-千年古榕",
		"lng" : 119.291521,
		"lat" : 26.147919000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 469,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29731178060641,
		  26.14797474307586
		]
	  },
	  "properties" : {
		"FID" : 469,
		"name" : "斗顶公园-景观湖",
		"lng" : 119.302126,
		"lat" : 26.144836000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 470,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29024335852218,
		  26.079094228727488
		]
	  },
	  "properties" : {
		"FID" : 470,
		"name" : "大士殿",
		"lng" : 119.295041,
		"lat" : 26.075989
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 471,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30144029043736,
		  26.152617668521092
		]
	  },
	  "properties" : {
		"FID" : 471,
		"name" : "闽王纪念广场",
		"lng" : 119.306262,
		"lat" : 26.149483
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 472,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24722721120845,
		  26.088102586342139
		]
	  },
	  "properties" : {
		"FID" : 472,
		"name" : "天主教洪山天主堂",
		"lng" : 119.25199000000001,
		"lat" : 26.084955000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 473,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28446983313175,
		  26.157773336407359
		]
	  },
	  "properties" : {
		"FID" : 473,
		"name" : "福州国家森林公园正心寺",
		"lng" : 119.289265,
		"lat" : 26.154609000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 474,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20806757854285,
		  26.113223514369611
		]
	  },
	  "properties" : {
		"FID" : 474,
		"name" : "绿洲寨公园",
		"lng" : 119.212862,
		"lat" : 26.110084000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 475,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28491335978134,
		  26.142632212171801
		]
	  },
	  "properties" : {
		"FID" : 475,
		"name" : "鸸鹋",
		"lng" : 119.289708,
		"lat" : 26.139478
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 476,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28515356340954,
		  26.095547442303644
		]
	  },
	  "properties" : {
		"FID" : 476,
		"name" : "盆景园",
		"lng" : 119.289945,
		"lat" : 26.092424000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 477,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34354806312321,
		  26.075205336649088
		]
	  },
	  "properties" : {
		"FID" : 477,
		"name" : "阮公祠",
		"lng" : 119.348443,
		"lat" : 26.072199000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 478,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30591016539938,
		  26.100549335819643
		]
	  },
	  "properties" : {
		"FID" : 478,
		"name" : "温泉公园-拱型喷泉",
		"lng" : 119.31073600000001,
		"lat" : 26.097456000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 479,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30705844035214,
		  26.082121105687541
		]
	  },
	  "properties" : {
		"FID" : 479,
		"name" : "三界寺",
		"lng" : 119.311885,
		"lat" : 26.079042000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 480,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29182246556749,
		  26.085064787691799
		]
	  },
	  "properties" : {
		"FID" : 480,
		"name" : "三坊七巷",
		"lng" : 119.296623,
		"lat" : 26.081958
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 481,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32552040501041,
		  26.064201384766267
		]
	  },
	  "properties" : {
		"FID" : 481,
		"name" : "光明港公园-儿童游戏区",
		"lng" : 119.330381,
		"lat" : 26.061169
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 482,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28961832841621,
		  26.092148808019161
		]
	  },
	  "properties" : {
		"FID" : 482,
		"name" : "天主教西门若瑟堂",
		"lng" : 119.294416,
		"lat" : 26.089034000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 483,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25881123894838,
		  26.090037342065148
		]
	  },
	  "properties" : {
		"FID" : 483,
		"name" : "观景台",
		"lng" : 119.263577,
		"lat" : 26.086891999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 484,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29893694693175,
		  26.055831776246155
		]
	  },
	  "properties" : {
		"FID" : 484,
		"name" : "高氏文昌阁",
		"lng" : 119.303747,
		"lat" : 26.052755999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 485,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32891890139639,
		  26.155811450691008
		]
	  },
	  "properties" : {
		"FID" : 485,
		"name" : "莲花府王中王",
		"lng" : 119.333793,
		"lat" : 26.152726000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 486,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29049005333414,
		  26.078127214241441
		]
	  },
	  "properties" : {
		"FID" : 486,
		"name" : "乌山历史风貌区",
		"lng" : 119.295288,
		"lat" : 26.075023000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 487,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30341437624109,
		  26.078289072035858
		]
	  },
	  "properties" : {
		"FID" : 487,
		"name" : "五一广场",
		"lng" : 119.308234,
		"lat" : 26.075206000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 488,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32026389504067,
		  26.126461374688656
		]
	  },
	  "properties" : {
		"FID" : 488,
		"name" : "陈氏宗祠",
		"lng" : 119.325119,
		"lat" : 26.123377999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 489,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28939257987057,
		  26.080024116845468
		]
	  },
	  "properties" : {
		"FID" : 489,
		"name" : "八旗会馆",
		"lng" : 119.294189,
		"lat" : 26.076917000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 490,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39682533634976,
		  26.243352418685134
		]
	  },
	  "properties" : {
		"FID" : 490,
		"name" : "鲁滨逊漂流",
		"lng" : 119.40178,
		"lat" : 26.240296000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 491,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28787170969181,
		  26.09509731283239
		]
	  },
	  "properties" : {
		"FID" : 491,
		"name" : "晨曦广场",
		"lng" : 119.29266699999999,
		"lat" : 26.091978000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 492,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31000935646904,
		  26.103016484586682
		]
	  },
	  "properties" : {
		"FID" : 492,
		"name" : "洋下公园",
		"lng" : 119.314843,
		"lat" : 26.099928999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 493,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28960145874663,
		  26.077438087334457
		]
	  },
	  "properties" : {
		"FID" : 493,
		"name" : "海阔天空",
		"lng" : 119.294398,
		"lat" : 26.074332999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 494,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27669279858225,
		  26.075156560136197
		]
	  },
	  "properties" : {
		"FID" : 494,
		"name" : "神光寺",
		"lng" : 119.28147199999999,
		"lat" : 26.072036000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 495,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24602118879514,
		  26.35470840657354
		]
	  },
	  "properties" : {
		"FID" : 495,
		"name" : "桃源溪风景区",
		"lng" : 119.250804,
		"lat" : 26.351410000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 496,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30401999710953,
		  26.082107539207346
		]
	  },
	  "properties" : {
		"FID" : 496,
		"name" : "玉皇殿",
		"lng" : 119.308841,
		"lat" : 26.079022999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 497,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29427005253524,
		  26.078499594468934
		]
	  },
	  "properties" : {
		"FID" : 497,
		"name" : "胡也频故居",
		"lng" : 119.299074,
		"lat" : 26.075400999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 498,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2893907053883,
		  26.078390033517994
		]
	  },
	  "properties" : {
		"FID" : 498,
		"name" : "兰花谷",
		"lng" : 119.29418699999999,
		"lat" : 26.075284
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 499,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36294727651786,
		  26.058378014417112
		]
	  },
	  "properties" : {
		"FID" : 499,
		"name" : "福州玉封三和殿",
		"lng" : 119.36787,
		"lat" : 26.055413000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 500,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31697824611445,
		  26.100263616078564
		]
	  },
	  "properties" : {
		"FID" : 500,
		"name" : "金鸡山公园览城栈道(鹤林台)",
		"lng" : 119.321825,
		"lat" : 26.097190999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 501,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38419632234579,
		  26.056393512548368
		]
	  },
	  "properties" : {
		"FID" : 501,
		"name" : "石鼓名山达摩洞十八景",
		"lng" : 119.38913599999999,
		"lat" : 26.053450000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 502,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2819599687904,
		  26.1340927024021
		]
	  },
	  "properties" : {
		"FID" : 502,
		"name" : "仙坛正境",
		"lng" : 119.28675,
		"lat" : 26.130939999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 503,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45686490246425,
		  26.091600694358593
		]
	  },
	  "properties" : {
		"FID" : 503,
		"name" : "龙溪境",
		"lng" : 119.461704,
		"lat" : 26.088560999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 504,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45449879921281,
		  26.091597054017932
		]
	  },
	  "properties" : {
		"FID" : 504,
		"name" : "白眉侨批露营公园",
		"lng" : 119.459345,
		"lat" : 26.088563000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 505,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45722126787514,
		  26.087895109680844
		]
	  },
	  "properties" : {
		"FID" : 505,
		"name" : "怀乡亭",
		"lng" : 119.462059,
		"lat" : 26.084857
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 506,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4544639086549,
		  26.088774107644273
		]
	  },
	  "properties" : {
		"FID" : 506,
		"name" : "东岭游击队纪念馆",
		"lng" : 119.45931,
		"lat" : 26.085742
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 507,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.453742702925,
		  26.089840128064814
		]
	  },
	  "properties" : {
		"FID" : 507,
		"name" : "千禧亭",
		"lng" : 119.458591,
		"lat" : 26.086808999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 508,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45379482467129,
		  26.090254522956105
		]
	  },
	  "properties" : {
		"FID" : 508,
		"name" : "南洋厝",
		"lng" : 119.458643,
		"lat" : 26.087223000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 509,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45329637798109,
		  26.09009125983323
		]
	  },
	  "properties" : {
		"FID" : 509,
		"name" : "邱氏宗祠",
		"lng" : 119.458146,
		"lat" : 26.087060999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 510,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45399744992348,
		  26.089861735353757
		]
	  },
	  "properties" : {
		"FID" : 510,
		"name" : "侨兴亭",
		"lng" : 119.458845,
		"lat" : 26.086829999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 511,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.48702798507935,
		  26.058086371534817
		]
	  },
	  "properties" : {
		"FID" : 511,
		"name" : "师公庙",
		"lng" : 119.491761,
		"lat" : 26.054986
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 512,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49677494761123,
		  26.063294039935187
		]
	  },
	  "properties" : {
		"FID" : 512,
		"name" : "西福禅寺",
		"lng" : 119.50147200000001,
		"lat" : 26.060161000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 513,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49310173008645,
		  26.056179242102548
		]
	  },
	  "properties" : {
		"FID" : 513,
		"name" : "祈福寺",
		"lng" : 119.497812,
		"lat" : 26.053062000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 514,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49675440963203,
		  26.069522146291195
		]
	  },
	  "properties" : {
		"FID" : 514,
		"name" : "象山广场",
		"lng" : 119.501452,
		"lat" : 26.066385
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 515,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50882387027039,
		  26.062353231222172
		]
	  },
	  "properties" : {
		"FID" : 515,
		"name" : "亭江炮台",
		"lng" : 119.513476,
		"lat" : 26.059184999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 516,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5013686400769,
		  26.069965259910166
		]
	  },
	  "properties" : {
		"FID" : 516,
		"name" : "西边公园",
		"lng" : 119.506049,
		"lat" : 26.066814000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 517,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50161778150604,
		  26.053572010045922
		]
	  },
	  "properties" : {
		"FID" : 517,
		"name" : "右营公园",
		"lng" : 119.50629600000001,
		"lat" : 26.050431
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 518,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4996436818149,
		  26.049811576251958
		]
	  },
	  "properties" : {
		"FID" : 518,
		"name" : "福州闽安基督教堂",
		"lng" : 119.504329,
		"lat" : 26.046679000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 519,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49570109737638,
		  26.060996276835205
		]
	  },
	  "properties" : {
		"FID" : 519,
		"name" : "西泉禅寺",
		"lng" : 119.50040199999999,
		"lat" : 26.057867999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 520,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49590485224228,
		  26.061102959880301
		]
	  },
	  "properties" : {
		"FID" : 520,
		"name" : "棋盘山风景区",
		"lng" : 119.50060499999999,
		"lat" : 26.057974000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 521,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49489782335684,
		  26.064606286100208
		]
	  },
	  "properties" : {
		"FID" : 521,
		"name" : "月爿坑风景区",
		"lng" : 119.499602,
		"lat" : 26.061478000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 522,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50603360141126,
		  26.088974755803779
		]
	  },
	  "properties" : {
		"FID" : 522,
		"name" : "云岩寺",
		"lng" : 119.510698,
		"lat" : 26.085796999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 523,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50753999618273,
		  26.077842812221146
		]
	  },
	  "properties" : {
		"FID" : 523,
		"name" : "飞泉寺",
		"lng" : 119.512198,
		"lat" : 26.074667999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 524,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4987250411465,
		  26.052568682304269
		]
	  },
	  "properties" : {
		"FID" : 524,
		"name" : "闽镇齐天府圣王祖庙",
		"lng" : 119.50341400000001,
		"lat" : 26.049437000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 525,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50127777212602,
		  26.050047621371913
		]
	  },
	  "properties" : {
		"FID" : 525,
		"name" : "闽安协台衙门",
		"lng" : 119.505957,
		"lat" : 26.04691
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 526,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50419629527309,
		  26.081971675926383
		]
	  },
	  "properties" : {
		"FID" : 526,
		"name" : "张宗祠",
		"lng" : 119.508867,
		"lat" : 26.078804000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 527,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.48864336117933,
		  26.052857666210155
		]
	  },
	  "properties" : {
		"FID" : 527,
		"name" : "报恩寺",
		"lng" : 119.49337,
		"lat" : 26.049755999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 528,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.46101104021544,
		  26.114983269266766
		]
	  },
	  "properties" : {
		"FID" : 528,
		"name" : "乡思亭",
		"lng" : 119.465839,
		"lat" : 26.111917999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 529,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49883041643636,
		  26.052826171374463
		]
	  },
	  "properties" : {
		"FID" : 529,
		"name" : "观音寺",
		"lng" : 119.503519,
		"lat" : 26.049693999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 530,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50629246120477,
		  26.063211366027957
		]
	  },
	  "properties" : {
		"FID" : 530,
		"name" : "南搬天师宫",
		"lng" : 119.510954,
		"lat" : 26.06005
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 531,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50118842372197,
		  26.050246488537464
		]
	  },
	  "properties" : {
		"FID" : 531,
		"name" : "闽安协镇署",
		"lng" : 119.50586800000001,
		"lat" : 26.047108999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 532,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50682322633334,
		  26.06591674335078
		]
	  },
	  "properties" : {
		"FID" : 532,
		"name" : "亭江康庄基督教堂",
		"lng" : 119.511483,
		"lat" : 26.062752
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 533,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50964790014231,
		  26.075905695759587
		]
	  },
	  "properties" : {
		"FID" : 533,
		"name" : "牛项真君堂管理委员会",
		"lng" : 119.514298,
		"lat" : 26.072725999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 534,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50609442434234,
		  26.080878570753473
		]
	  },
	  "properties" : {
		"FID" : 534,
		"name" : "九天府田元帅",
		"lng" : 119.510758,
		"lat" : 26.077705999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 535,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4990698326546,
		  26.045786142856155
		]
	  },
	  "properties" : {
		"FID" : 535,
		"name" : "正心禅寺",
		"lng" : 119.50375699999999,
		"lat" : 26.042657999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 536,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50003409330509,
		  26.050468187101451
		]
	  },
	  "properties" : {
		"FID" : 536,
		"name" : "普庵楼",
		"lng" : 119.504718,
		"lat" : 26.047333999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 537,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40825724764895,
		  26.051072881072049
		]
	  },
	  "properties" : {
		"FID" : 537,
		"name" : "贤龙殿",
		"lng" : 119.413191,
		"lat" : 26.048134000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 538,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40923893670313,
		  26.03996288269893
		]
	  },
	  "properties" : {
		"FID" : 538,
		"name" : "龙泉寺",
		"lng" : 119.414171,
		"lat" : 26.037030999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 539,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4096778010157,
		  26.04691081275811
		]
	  },
	  "properties" : {
		"FID" : 539,
		"name" : "探花府",
		"lng" : 119.41461,
		"lat" : 26.043973999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 540,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51073241218425,
		  26.095746991054959
		]
	  },
	  "properties" : {
		"FID" : 540,
		"name" : "罗汉寺",
		"lng" : 119.51537999999999,
		"lat" : 26.092551
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 541,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.46177532672552,
		  26.023777389420289
		]
	  },
	  "properties" : {
		"FID" : 541,
		"name" : "长磹亭",
		"lng" : 119.466594,
		"lat" : 26.020771
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 542,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40936887515149,
		  26.042287523377567
		]
	  },
	  "properties" : {
		"FID" : 542,
		"name" : "南宫拜石",
		"lng" : 119.41430099999999,
		"lat" : 26.039353999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 543,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5134270962065,
		  26.09744488411523
		]
	  },
	  "properties" : {
		"FID" : 543,
		"name" : "嵩泉寺",
		"lng" : 119.51806500000001,
		"lat" : 26.094239999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 544,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.46338081387961,
		  26.019569661564972
		]
	  },
	  "properties" : {
		"FID" : 544,
		"name" : "和美桥",
		"lng" : 119.468194,
		"lat" : 26.016562
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 545,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.44841930839272,
		  26.000949322478569
		]
	  },
	  "properties" : {
		"FID" : 545,
		"name" : "天马山公园",
		"lng" : 119.453276,
		"lat" : 25.997990000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 546,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.46177209994813,
		  26.026664341505903
		]
	  },
	  "properties" : {
		"FID" : 546,
		"name" : "思乡亭",
		"lng" : 119.46659099999999,
		"lat" : 26.023655999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 547,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51796678890032,
		  26.091738977944697
		]
	  },
	  "properties" : {
		"FID" : 547,
		"name" : "陇西园",
		"lng" : 119.522588,
		"lat" : 26.088525000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 548,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38934501796216,
		  26.057708078627023
		]
	  },
	  "properties" : {
		"FID" : 548,
		"name" : "鼓山风景区",
		"lng" : 119.39428599999999,
		"lat" : 26.054766000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 549,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38935795329176,
		  26.071646406689492
		]
	  },
	  "properties" : {
		"FID" : 549,
		"name" : "鼓岭旅游度假区",
		"lng" : 119.3943,
		"lat" : 26.068695000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 550,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53287956563312,
		  26.044729789523412
		]
	  },
	  "properties" : {
		"FID" : 550,
		"name" : "猴屿洞天岩景区",
		"lng" : 119.537447,
		"lat" : 26.041508
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 551,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.48894740482658,
		  26.02705812796367
		]
	  },
	  "properties" : {
		"FID" : 551,
		"name" : "广济寺",
		"lng" : 119.49367100000001,
		"lat" : 26.023973000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 552,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.46099181387731,
		  25.99732138657923
		]
	  },
	  "properties" : {
		"FID" : 552,
		"name" : "马尾城市中心广场",
		"lng" : 119.465811,
		"lat" : 25.994335
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 553,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41657249094986,
		  26.017686877736502
		]
	  },
	  "properties" : {
		"FID" : 553,
		"name" : "福州快安基督教堂名城中心礼拜堂",
		"lng" : 119.42149499999999,
		"lat" : 26.014765000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 554,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.44421429979434,
		  25.999258435031308
		]
	  },
	  "properties" : {
		"FID" : 554,
		"name" : "天马山生态公园",
		"lng" : 119.449082,
		"lat" : 25.996309
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 555,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.46183306853035,
		  26.003000397530087
		]
	  },
	  "properties" : {
		"FID" : 555,
		"name" : "火车主题公园",
		"lng" : 119.46665,
		"lat" : 26.000008000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 556,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36850547457875,
		  26.092466928088328
		]
	  },
	  "properties" : {
		"FID" : 556,
		"name" : "鳝溪风景区",
		"lng" : 119.373437,
		"lat" : 26.089486000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 557,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41315422737114,
		  26.034234430283693
		]
	  },
	  "properties" : {
		"FID" : 557,
		"name" : "福州快安基督教堂",
		"lng" : 119.418082,
		"lat" : 26.031303999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 558,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39518213591089,
		  26.110803960405388
		]
	  },
	  "properties" : {
		"FID" : 558,
		"name" : "古城墙",
		"lng" : 119.400127,
		"lat" : 26.107828000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 559,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40967198826237,
		  26.110005723379299
		]
	  },
	  "properties" : {
		"FID" : 559,
		"name" : "南洋莊上境",
		"lng" : 119.414609,
		"lat" : 26.107026999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 560,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54951221163427,
		  26.092981230499046
		]
	  },
	  "properties" : {
		"FID" : 560,
		"name" : "琅岐红光湖公园",
		"lng" : 119.554035,
		"lat" : 26.089690999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 561,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54063475956255,
		  26.147306142204258
		]
	  },
	  "properties" : {
		"FID" : 561,
		"name" : "青芝山风景区-青芝寺",
		"lng" : 119.545186,
		"lat" : 26.143999000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 562,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36601863510755,
		  26.151099647669902
		]
	  },
	  "properties" : {
		"FID" : 562,
		"name" : "福州快乐园",
		"lng" : 119.370952,
		"lat" : 26.148078000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 563,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51663543349957,
		  26.059337666640197
		]
	  },
	  "properties" : {
		"FID" : 563,
		"name" : "南岸炮台",
		"lng" : 119.521259,
		"lat" : 26.056149000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 564,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45988186281285,
		  26.003301668851829
		]
	  },
	  "properties" : {
		"FID" : 564,
		"name" : "任氏宗祠",
		"lng" : 119.464705,
		"lat" : 26.000313999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 565,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38043692247571,
		  26.017690698656921
		]
	  },
	  "properties" : {
		"FID" : 565,
		"name" : "三江口生态公园",
		"lng" : 119.385372,
		"lat" : 26.014771
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 566,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50042076742869,
		  26.006732684090576
		]
	  },
	  "properties" : {
		"FID" : 566,
		"name" : "长乐洋屿云门寺",
		"lng" : 119.5051,
		"lat" : 26.003627000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 567,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.44388292522358,
		  25.992991500261056
		]
	  },
	  "properties" : {
		"FID" : 567,
		"name" : "船政格致园",
		"lng" : 119.448751,
		"lat" : 25.990047000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 568,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41399522178401,
		  26.033392470589877
		]
	  },
	  "properties" : {
		"FID" : 568,
		"name" : "君山任氏支祠",
		"lng" : 119.41892199999999,
		"lat" : 26.030462
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 569,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51597241326137,
		  26.000054621018986
		]
	  },
	  "properties" : {
		"FID" : 569,
		"name" : "芦际潭森林公园",
		"lng" : 119.520594,
		"lat" : 25.996908000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 570,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37170888574224,
		  25.994489463985367
		]
	  },
	  "properties" : {
		"FID" : 570,
		"name" : "春伦茶",
		"lng" : 119.376636,
		"lat" : 25.991578000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 571,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.44668713192239,
		  25.994348148504962
		]
	  },
	  "properties" : {
		"FID" : 571,
		"name" : "船政天后宫",
		"lng" : 119.451548,
		"lat" : 25.991396999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 572,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39453761753715,
		  26.037632330026661
		]
	  },
	  "properties" : {
		"FID" : 572,
		"name" : "扣冰古佛寺",
		"lng" : 119.399477,
		"lat" : 26.034704999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 573,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36990866453505,
		  26.05868688453538
		]
	  },
	  "properties" : {
		"FID" : 573,
		"name" : "福建省革命历史纪念馆",
		"lng" : 119.37483899999999,
		"lat" : 26.055730000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 574,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37437376568371,
		  26.032466690233768
		]
	  },
	  "properties" : {
		"FID" : 574,
		"name" : "魁峰境将军庙",
		"lng" : 119.379306,
		"lat" : 26.029532
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 575,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.44964791314607,
		  26.143871871723785
		]
	  },
	  "properties" : {
		"FID" : 575,
		"name" : "福州牛项真君堂",
		"lng" : 119.45451199999999,
		"lat" : 26.140815
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 576,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3911929239588,
		  26.057296239161381
		]
	  },
	  "properties" : {
		"FID" : 576,
		"name" : "迴龙阁",
		"lng" : 119.396134,
		"lat" : 26.054355000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 577,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38270007901571,
		  26.027843101937261
		]
	  },
	  "properties" : {
		"FID" : 577,
		"name" : "魁岐生态公园",
		"lng" : 119.387637,
		"lat" : 26.024918
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 578,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38434860520333,
		  26.078202011056309
		]
	  },
	  "properties" : {
		"FID" : 578,
		"name" : "白云洞-良心寺",
		"lng" : 119.38929,
		"lat" : 26.075244000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 579,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39536360624662,
		  26.091970600624681
		]
	  },
	  "properties" : {
		"FID" : 579,
		"name" : "加德纳纪念馆",
		"lng" : 119.400307,
		"lat" : 26.089006999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 580,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38185238960659,
		  26.015545282715216
		]
	  },
	  "properties" : {
		"FID" : 580,
		"name" : "金沙飞舞",
		"lng" : 119.386788,
		"lat" : 26.012627999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 581,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41797338897449,
		  26.029743314929132
		]
	  },
	  "properties" : {
		"FID" : 581,
		"name" : "快安文武太平王府",
		"lng" : 119.422895,
		"lat" : 26.026812
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 582,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49417767481674,
		  26.00319355464298
		]
	  },
	  "properties" : {
		"FID" : 582,
		"name" : "琴江满族村",
		"lng" : 119.49888,
		"lat" : 26.000108999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 583,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38236644192126,
		  26.077423660055345
		]
	  },
	  "properties" : {
		"FID" : 583,
		"name" : "白云洞-凡圣庵",
		"lng" : 119.38730700000001,
		"lat" : 26.074465
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 584,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39301203169005,
		  26.095699379272268
		]
	  },
	  "properties" : {
		"FID" : 584,
		"name" : "柳杉王公园-白云山庄",
		"lng" : 119.39795599999999,
		"lat" : 26.092732999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 585,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36259498149366,
		  26.094131267806592
		]
	  },
	  "properties" : {
		"FID" : 585,
		"name" : "龙溪境",
		"lng" : 119.36752,
		"lat" : 26.091142000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 586,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41583537811456,
		  26.02030203357868
		]
	  },
	  "properties" : {
		"FID" : 586,
		"name" : "儒江胜境",
		"lng" : 119.420759,
		"lat" : 26.017378999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 587,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38487590316582,
		  26.032640110980385
		]
	  },
	  "properties" : {
		"FID" : 587,
		"name" : "魁岐玉清宫",
		"lng" : 119.389814,
		"lat" : 26.029713000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 588,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38387066231239,
		  26.066589532280606
		]
	  },
	  "properties" : {
		"FID" : 588,
		"name" : "桃源洞",
		"lng" : 119.388811,
		"lat" : 26.063638999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 589,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.48225036714292,
		  26.018562525878327
		]
	  },
	  "properties" : {
		"FID" : 589,
		"name" : "龙海寺",
		"lng" : 119.486998,
		"lat" : 26.015502999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 590,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36554824685697,
		  26.08447513391393
		]
	  },
	  "properties" : {
		"FID" : 590,
		"name" : "福州樟林吴氏宗祠",
		"lng" : 119.370476,
		"lat" : 26.081496000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 591,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38635945690284,
		  26.059123239885796
		]
	  },
	  "properties" : {
		"FID" : 591,
		"name" : "石鼓名山-鼓山观景台",
		"lng" : 119.3913,
		"lat" : 26.056179
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 592,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38867222395386,
		  26.043022426434504
		]
	  },
	  "properties" : {
		"FID" : 592,
		"name" : "石鼓名山-江汉秋阳",
		"lng" : 119.393612,
		"lat" : 26.040089999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 593,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36294727651786,
		  26.058378014417112
		]
	  },
	  "properties" : {
		"FID" : 593,
		"name" : "福州玉封三和殿",
		"lng" : 119.36787,
		"lat" : 26.055413000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 594,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4427783271402,
		  26.003713633603741
		]
	  },
	  "properties" : {
		"FID" : 594,
		"name" : "青龙禅寺",
		"lng" : 119.44765,
		"lat" : 26.000764
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 595,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36670966250408,
		  26.022833298961302
		]
	  },
	  "properties" : {
		"FID" : 595,
		"name" : "濂江书院",
		"lng" : 119.371634,
		"lat" : 26.019897
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 596,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39302703644945,
		  26.056333176806604
		]
	  },
	  "properties" : {
		"FID" : 596,
		"name" : "水云亭",
		"lng" : 119.39796800000001,
		"lat" : 26.053393
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 597,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38483400772547,
		  26.057683033128733
		]
	  },
	  "properties" : {
		"FID" : 597,
		"name" : "十八景名岩",
		"lng" : 119.389774,
		"lat" : 26.054739000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 598,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.48893136611058,
		  26.026776889199883
		]
	  },
	  "properties" : {
		"FID" : 598,
		"name" : "天王殿",
		"lng" : 119.493655,
		"lat" : 26.023692
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 599,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.48267089027217,
		  26.018712861775889
		]
	  },
	  "properties" : {
		"FID" : 599,
		"name" : "玄光寺",
		"lng" : 119.48741699999999,
		"lat" : 26.015651999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 600,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.46358658686238,
		  26.01817224561734
		]
	  },
	  "properties" : {
		"FID" : 600,
		"name" : "沁馨亭",
		"lng" : 119.46839900000001,
		"lat" : 26.015165
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 601,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39238027310351,
		  26.092124151218655
		]
	  },
	  "properties" : {
		"FID" : 601,
		"name" : "鼓岭",
		"lng" : 119.397324,
		"lat" : 26.08916
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 602,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47240464854592,
		  26.013234680375142
		]
	  },
	  "properties" : {
		"FID" : 602,
		"name" : "君竹河公园",
		"lng" : 119.477187,
		"lat" : 26.010207000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 603,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38273573949616,
		  26.05833967337734
		]
	  },
	  "properties" : {
		"FID" : 603,
		"name" : "石鼓名山-降龙洞",
		"lng" : 119.387675,
		"lat" : 26.055394
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 604,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40539732895098,
		  26.034559517600211
		]
	  },
	  "properties" : {
		"FID" : 604,
		"name" : "龙门林氏宗祠",
		"lng" : 119.410332,
		"lat" : 26.031632999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 605,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39204728263806,
		  26.091884066763022
		]
	  },
	  "properties" : {
		"FID" : 605,
		"name" : "宜夏山庄",
		"lng" : 119.396991,
		"lat" : 26.088920000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 606,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36568096404908,
		  26.020593017820673
		]
	  },
	  "properties" : {
		"FID" : 606,
		"name" : "林斯琛故居",
		"lng" : 119.370604,
		"lat" : 26.017657
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 607,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36083069002611,
		  26.008839306429369
		]
	  },
	  "properties" : {
		"FID" : 607,
		"name" : "福州连坂甘泉寺",
		"lng" : 119.365747,
		"lat" : 26.005904999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 608,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51293047954988,
		  26.040570475708883
		]
	  },
	  "properties" : {
		"FID" : 608,
		"name" : "阿弥陀佛",
		"lng" : 119.517566,
		"lat" : 26.037405
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 609,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39029292518047,
		  26.057811841612015
		]
	  },
	  "properties" : {
		"FID" : 609,
		"name" : "罗汉泉",
		"lng" : 119.395234,
		"lat" : 26.054870000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 610,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37677945770812,
		  26.052749257765818
		]
	  },
	  "properties" : {
		"FID" : 610,
		"name" : "洋里平楚庵",
		"lng" : 119.381715,
		"lat" : 26.049803000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 611,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41778711202126,
		  26.01697046843779
		]
	  },
	  "properties" : {
		"FID" : 611,
		"name" : "名城基督徒聚会处",
		"lng" : 119.422708,
		"lat" : 26.014047999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 612,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51252300883641,
		  26.040457226798047
		]
	  },
	  "properties" : {
		"FID" : 612,
		"name" : "南无阿弥陀佛",
		"lng" : 119.51716,
		"lat" : 26.037292999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 613,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39150712504238,
		  26.09391153317436
		]
	  },
	  "properties" : {
		"FID" : 613,
		"name" : "李士甲別墅",
		"lng" : 119.396451,
		"lat" : 26.090945999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 614,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39512642878535,
		  26.001905990648943
		]
	  },
	  "properties" : {
		"FID" : 614,
		"name" : "福州宝胜禅寺",
		"lng" : 119.400063,
		"lat" : 25.999002999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 615,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43824880380527,
		  25.998812846217671
		]
	  },
	  "properties" : {
		"FID" : 615,
		"name" : "天马山休闲公园",
		"lng" : 119.44313099999999,
		"lat" : 25.995875000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 616,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37243455467286,
		  26.056161555453365
		]
	  },
	  "properties" : {
		"FID" : 616,
		"name" : "鼓山风景区摩崖石刻",
		"lng" : 119.37736700000001,
		"lat" : 26.053208999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 617,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36635505588482,
		  26.022730653200895
		]
	  },
	  "properties" : {
		"FID" : 617,
		"name" : "林浦泰山宫",
		"lng" : 119.371279,
		"lat" : 26.019794000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 618,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38278392800288,
		  26.055602805036855
		]
	  },
	  "properties" : {
		"FID" : 618,
		"name" : "观音亭(茶亭)",
		"lng" : 119.38772299999999,
		"lat" : 26.052658999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 619,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51398355063868,
		  26.132181020907275
		]
	  },
	  "properties" : {
		"FID" : 619,
		"name" : "和尚背尼姑",
		"lng" : 119.51862199999999,
		"lat" : 26.128952000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 620,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37242554138631,
		  26.056437750071684
		]
	  },
	  "properties" : {
		"FID" : 620,
		"name" : "鼓山风景区-索道下站",
		"lng" : 119.377358,
		"lat" : 26.053484999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 621,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38690800213331,
		  26.102654880674333
		]
	  },
	  "properties" : {
		"FID" : 621,
		"name" : "闽浙赣五县中心县委游击队联络站旧址",
		"lng" : 119.391852,
		"lat" : 26.099682000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 622,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40514074626543,
		  26.026780152791329
		]
	  },
	  "properties" : {
		"FID" : 622,
		"name" : "倪氏支祠",
		"lng" : 119.41007500000001,
		"lat" : 26.023859000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 623,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38780057574343,
		  26.053412771313919
		]
	  },
	  "properties" : {
		"FID" : 623,
		"name" : "石鼓名山-游泷阁",
		"lng" : 119.392741,
		"lat" : 26.050473
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 624,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39066186431072,
		  26.058330080515201
		]
	  },
	  "properties" : {
		"FID" : 624,
		"name" : "华藏室",
		"lng" : 119.39560299999999,
		"lat" : 26.055388000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 625,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39106689812634,
		  26.057678529759102
		]
	  },
	  "properties" : {
		"FID" : 625,
		"name" : "南无观世音菩萨",
		"lng" : 119.39600799999999,
		"lat" : 26.054736999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 626,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37302435730552,
		  26.012786611643836
		]
	  },
	  "properties" : {
		"FID" : 626,
		"name" : "泗洲文佛",
		"lng" : 119.377954,
		"lat" : 26.009864
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 627,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45900691389801,
		  26.006167442387078
		]
	  },
	  "properties" : {
		"FID" : 627,
		"name" : "圆通寺",
		"lng" : 119.46383299999999,
		"lat" : 26.00318
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 628,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52000944216493,
		  26.05832038241136
		]
	  },
	  "properties" : {
		"FID" : 628,
		"name" : "象屿陈永洽公园",
		"lng" : 119.524621,
		"lat" : 26.055122999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 629,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3774704823072,
		  26.033253517856412
		]
	  },
	  "properties" : {
		"FID" : 629,
		"name" : "魁岐溪边公园",
		"lng" : 119.38240500000001,
		"lat" : 26.030321000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 630,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50940131827983,
		  26.030759605567045
		]
	  },
	  "properties" : {
		"FID" : 630,
		"name" : "郑振铎公园",
		"lng" : 119.514049,
		"lat" : 26.027611
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 631,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38406150186516,
		  26.054670429360872
		]
	  },
	  "properties" : {
		"FID" : 631,
		"name" : "晚乐园",
		"lng" : 119.38900099999999,
		"lat" : 26.051728000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 632,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49891046230807,
		  26.015653236576185
		]
	  },
	  "properties" : {
		"FID" : 632,
		"name" : "南无阿弥陀佛",
		"lng" : 119.503596,
		"lat" : 26.012546
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 633,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38517599449048,
		  26.056437017310408
		]
	  },
	  "properties" : {
		"FID" : 633,
		"name" : "罗汉台",
		"lng" : 119.39011600000001,
		"lat" : 26.053494000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 634,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38754651274455,
		  26.054877861801799
		]
	  },
	  "properties" : {
		"FID" : 634,
		"name" : "石磴古道",
		"lng" : 119.392487,
		"lat" : 26.051936999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 635,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51392035957078,
		  26.036526577745633
		]
	  },
	  "properties" : {
		"FID" : 635,
		"name" : "白门庙",
		"lng" : 119.518552,
		"lat" : 26.033360999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 636,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47798975870059,
		  26.155252198674905
		]
	  },
	  "properties" : {
		"FID" : 636,
		"name" : "梅洋文化公园",
		"lng" : 119.48276300000001,
		"lat" : 26.152114999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 637,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37554422695544,
		  26.054133257416492
		]
	  },
	  "properties" : {
		"FID" : 637,
		"name" : "鼓山风景名胜区-凉亭",
		"lng" : 119.38047899999999,
		"lat" : 26.051185
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 638,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39572123041202,
		  26.110877964269129
		]
	  },
	  "properties" : {
		"FID" : 638,
		"name" : "牛头涯",
		"lng" : 119.400666,
		"lat" : 26.107901999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 639,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.46596881848289,
		  26.159338374895963
		]
	  },
	  "properties" : {
		"FID" : 639,
		"name" : "张圣真君堂",
		"lng" : 119.47078399999999,
		"lat" : 26.156231999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 640,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39230914202874,
		  26.093810278030283
		]
	  },
	  "properties" : {
		"FID" : 640,
		"name" : "鼓岭麦先生厝",
		"lng" : 119.39725300000001,
		"lat" : 26.090845000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 641,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39297298282125,
		  26.056990628782547
		]
	  },
	  "properties" : {
		"FID" : 641,
		"name" : "石鼓名山-无书石门",
		"lng" : 119.397914,
		"lat" : 26.05405
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 642,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43726462105678,
		  25.997954529910242
		]
	  },
	  "properties" : {
		"FID" : 642,
		"name" : "马江渡广场",
		"lng" : 119.442149,
		"lat" : 25.995018999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 643,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38747148215754,
		  26.055475295017587
		]
	  },
	  "properties" : {
		"FID" : 643,
		"name" : "桃岩洞",
		"lng" : 119.39241199999999,
		"lat" : 26.052534000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 644,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39408545119871,
		  26.039049348228666
		]
	  },
	  "properties" : {
		"FID" : 644,
		"name" : "天镜岩",
		"lng" : 119.39902499999999,
		"lat" : 26.036121000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 645,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38381878798154,
		  26.078299372276433
		]
	  },
	  "properties" : {
		"FID" : 645,
		"name" : "三天门",
		"lng" : 119.38876,
		"lat" : 26.075341000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 646,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45438033398864,
		  26.000084136735644
		]
	  },
	  "properties" : {
		"FID" : 646,
		"name" : "琅山董氏宗祠",
		"lng" : 119.45922,
		"lat" : 25.997112000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 647,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39073384481097,
		  26.058541201656158
		]
	  },
	  "properties" : {
		"FID" : 647,
		"name" : "鼓山涌泉寺-伽蓝殿",
		"lng" : 119.395675,
		"lat" : 26.055599000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 648,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38127746423913,
		  26.057505049342069
		]
	  },
	  "properties" : {
		"FID" : 648,
		"name" : "石鼓名山-印空亭",
		"lng" : 119.386216,
		"lat" : 26.054559000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 649,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36257097019482,
		  26.094665651294228
		]
	  },
	  "properties" : {
		"FID" : 649,
		"name" : "延陵吴氏宗祠",
		"lng" : 119.367496,
		"lat" : 26.091676
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 650,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37322524646939,
		  26.012042909756545
		]
	  },
	  "properties" : {
		"FID" : 650,
		"name" : "财神殿",
		"lng" : 119.37815500000001,
		"lat" : 26.009121
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 651,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36603669810039,
		  26.09764122673722
		]
	  },
	  "properties" : {
		"FID" : 651,
		"name" : "鼓岭古登山道",
		"lng" : 119.370966,
		"lat" : 26.094653999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 652,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39078683819574,
		  26.058597224230276
		]
	  },
	  "properties" : {
		"FID" : 652,
		"name" : "念佛堂",
		"lng" : 119.39572800000001,
		"lat" : 26.055655000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 653,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39022087188792,
		  26.058575376341441
		]
	  },
	  "properties" : {
		"FID" : 653,
		"name" : "学戒堂",
		"lng" : 119.395162,
		"lat" : 26.055633
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 654,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41570720456752,
		  26.020531083565761
		]
	  },
	  "properties" : {
		"FID" : 654,
		"name" : "倪氏宗祠",
		"lng" : 119.420631,
		"lat" : 26.017607999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 655,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39024786566064,
		  26.058632406370712
		]
	  },
	  "properties" : {
		"FID" : 655,
		"name" : "寿昌堂",
		"lng" : 119.395189,
		"lat" : 26.055689999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 656,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39016686399728,
		  26.058729496441334
		]
	  },
	  "properties" : {
		"FID" : 656,
		"name" : "上客堂",
		"lng" : 119.39510799999999,
		"lat" : 26.055786999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 657,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37314445825976,
		  26.023279628072814
		]
	  },
	  "properties" : {
		"FID" : 657,
		"name" : "南江滨生态公园福悦潮场园区",
		"lng" : 119.378075,
		"lat" : 26.020350000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 658,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53514935827582,
		  26.063085607424846
		]
	  },
	  "properties" : {
		"FID" : 658,
		"name" : "猴屿张家戚继光公园",
		"lng" : 119.539711,
		"lat" : 26.059846
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 659,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39036384570687,
		  26.058793479365754
		]
	  },
	  "properties" : {
		"FID" : 659,
		"name" : "法堂",
		"lng" : 119.39530499999999,
		"lat" : 26.055851000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 660,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38738727824757,
		  26.097681409735113
		]
	  },
	  "properties" : {
		"FID" : 660,
		"name" : "鼓岭下乖凉亭",
		"lng" : 119.392331,
		"lat" : 26.094712000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 661,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36300491669425,
		  26.022772879435252
		]
	  },
	  "properties" : {
		"FID" : 661,
		"name" : "龙津庵",
		"lng" : 119.367925,
		"lat" : 26.019832000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 662,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50673664472887,
		  26.028746421788387
		]
	  },
	  "properties" : {
		"FID" : 662,
		"name" : "太平港帅营",
		"lng" : 119.511394,
		"lat" : 26.025607000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 663,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38967025091313,
		  26.054207616223497
		]
	  },
	  "properties" : {
		"FID" : 663,
		"name" : "石鼓名山-柗风阁",
		"lng" : 119.394611,
		"lat" : 26.051268
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 664,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52582047691689,
		  26.057751647589463
		]
	  },
	  "properties" : {
		"FID" : 664,
		"name" : "猴屿锦福禅寺",
		"lng" : 119.530412,
		"lat" : 26.054538999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 665,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38656165019658,
		  26.055929000600017
		]
	  },
	  "properties" : {
		"FID" : 665,
		"name" : "更衣亭",
		"lng" : 119.391502,
		"lat" : 26.052987000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 666,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37365746070468,
		  26.070201767168641
		]
	  },
	  "properties" : {
		"FID" : 666,
		"name" : "华严寺",
		"lng" : 119.378592,
		"lat" : 26.067240999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 667,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3902648601468,
		  26.058689439477362
		]
	  },
	  "properties" : {
		"FID" : 667,
		"name" : "鼓山涌泉寺-祖师殿",
		"lng" : 119.395206,
		"lat" : 26.055747
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 668,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37963941109963,
		  26.056310397622049
		]
	  },
	  "properties" : {
		"FID" : 668,
		"name" : "石鼓名山-半山亭",
		"lng" : 119.38457699999999,
		"lat" : 26.053363999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 669,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38462606115203,
		  26.057880276566156
		]
	  },
	  "properties" : {
		"FID" : 669,
		"name" : "石鼓名山-达摩洞",
		"lng" : 119.389566,
		"lat" : 26.054936000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 670,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60346034749435,
		  26.106748298592244
		]
	  },
	  "properties" : {
		"FID" : 670,
		"name" : "九天应元府",
		"lng" : 119.607911,
		"lat" : 26.103408999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 671,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60348780316906,
		  26.114299202578614
		]
	  },
	  "properties" : {
		"FID" : 671,
		"name" : "驸马陵",
		"lng" : 119.607939,
		"lat" : 26.110955000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 672,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61414663420345,
		  26.095875248279217
		]
	  },
	  "properties" : {
		"FID" : 672,
		"name" : "聚祥亭",
		"lng" : 119.61859800000001,
		"lat" : 26.092549999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 673,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60346979419563,
		  26.114401276683765
		]
	  },
	  "properties" : {
		"FID" : 673,
		"name" : "龙台驸马墓",
		"lng" : 119.607921,
		"lat" : 26.111056999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 674,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61895047712848,
		  26.095545514205899
		]
	  },
	  "properties" : {
		"FID" : 674,
		"name" : "天安胜景",
		"lng" : 119.62340399999999,
		"lat" : 26.092224999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 675,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61846275967093,
		  26.095252817511934
		]
	  },
	  "properties" : {
		"FID" : 675,
		"name" : "天安寺",
		"lng" : 119.622916,
		"lat" : 26.091932
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 676,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5979301601264,
		  26.120692119784888
		]
	  },
	  "properties" : {
		"FID" : 676,
		"name" : "福州南山寺",
		"lng" : 119.602383,
		"lat" : 26.117342000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 677,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61068984455649,
		  26.093081135428822
		]
	  },
	  "properties" : {
		"FID" : 677,
		"name" : "荣光村扬帆广场",
		"lng" : 119.61514,
		"lat" : 26.089755
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 678,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61798255429916,
		  26.115314406768896
		]
	  },
	  "properties" : {
		"FID" : 678,
		"name" : "关帝庙",
		"lng" : 119.62243700000001,
		"lat" : 26.111979999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 679,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63030403649429,
		  26.109680040392462
		]
	  },
	  "properties" : {
		"FID" : 679,
		"name" : "红蟳公社",
		"lng" : 119.634767,
		"lat" : 26.106363999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 680,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61534459613752,
		  26.090039353515522
		]
	  },
	  "properties" : {
		"FID" : 680,
		"name" : "白云山风景区",
		"lng" : 119.61979599999999,
		"lat" : 26.086718999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 681,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59831824623241,
		  26.121271412157462
		]
	  },
	  "properties" : {
		"FID" : 681,
		"name" : "梵音寺",
		"lng" : 119.602771,
		"lat" : 26.117920999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 682,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58283122696048,
		  26.099074095537851
		]
	  },
	  "properties" : {
		"FID" : 682,
		"name" : "天竺寺",
		"lng" : 119.587293,
		"lat" : 26.095739999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 683,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59789113505222,
		  26.120855232990912
		]
	  },
	  "properties" : {
		"FID" : 683,
		"name" : "念佛堂",
		"lng" : 119.602344,
		"lat" : 26.117505000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 684,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58760238628324,
		  26.089894759027001
		]
	  },
	  "properties" : {
		"FID" : 684,
		"name" : "基督徒吴庄聚会所",
		"lng" : 119.59205900000001,
		"lat" : 26.086565
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 685,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63492792612831,
		  26.117055161464929
		]
	  },
	  "properties" : {
		"FID" : 685,
		"name" : "壶江妈祖广场",
		"lng" : 119.639396,
		"lat" : 26.113741000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 686,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59708833429494,
		  26.127928935000707
		]
	  },
	  "properties" : {
		"FID" : 686,
		"name" : "翁氏宗祠(凤窝)",
		"lng" : 119.60154199999999,
		"lat" : 26.124573999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 687,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5972044591131,
		  26.126807194940742
		]
	  },
	  "properties" : {
		"FID" : 687,
		"name" : "华严寺",
		"lng" : 119.601658,
		"lat" : 26.123453000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 688,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5971694326295,
		  26.12699231985874
		]
	  },
	  "properties" : {
		"FID" : 688,
		"name" : "观音堂",
		"lng" : 119.601623,
		"lat" : 26.123638
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 689,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63398685222464,
		  26.117780033213549
		]
	  },
	  "properties" : {
		"FID" : 689,
		"name" : "壶江牌坊",
		"lng" : 119.638454,
		"lat" : 26.114464000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 690,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63309470645547,
		  26.11849180255189
		]
	  },
	  "properties" : {
		"FID" : 690,
		"name" : "海曲园",
		"lng" : 119.63756100000001,
		"lat" : 26.115174
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 691,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63501884081822,
		  26.11691093139482
		]
	  },
	  "properties" : {
		"FID" : 691,
		"name" : "先贤堂",
		"lng" : 119.639487,
		"lat" : 26.113596999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 692,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63569914158396,
		  26.116575685217871
		]
	  },
	  "properties" : {
		"FID" : 692,
		"name" : "灵椿庵",
		"lng" : 119.640168,
		"lat" : 26.113263
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 693,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63529555044104,
		  26.116876491911295
		]
	  },
	  "properties" : {
		"FID" : 693,
		"name" : "壶江天妃宫",
		"lng" : 119.639764,
		"lat" : 26.113562999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 694,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63334334949506,
		  26.119959388697112
		]
	  },
	  "properties" : {
		"FID" : 694,
		"name" : "慈心堂",
		"lng" : 119.63781,
		"lat" : 26.116641000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 695,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63563616752742,
		  26.117147151110778
		]
	  },
	  "properties" : {
		"FID" : 695,
		"name" : "登龙境",
		"lng" : 119.64010500000001,
		"lat" : 26.113834000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 696,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63564216655914,
		  26.117072093386845
		]
	  },
	  "properties" : {
		"FID" : 696,
		"name" : "观音阁",
		"lng" : 119.640111,
		"lat" : 26.113759000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 697,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63618760800875,
		  26.116667999260983
		]
	  },
	  "properties" : {
		"FID" : 697,
		"name" : "观日台",
		"lng" : 119.640657,
		"lat" : 26.113356
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 698,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63403349395739,
		  26.122049723154095
		]
	  },
	  "properties" : {
		"FID" : 698,
		"name" : "明心寺",
		"lng" : 119.63850100000001,
		"lat" : 26.118731
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 699,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60375452745686,
		  26.07695552405761
		]
	  },
	  "properties" : {
		"FID" : 699,
		"name" : "千佛寺",
		"lng" : 119.608203,
		"lat" : 26.073636
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 700,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54951221163427,
		  26.092981230499046
		]
	  },
	  "properties" : {
		"FID" : 700,
		"name" : "琅岐红光湖公园",
		"lng" : 119.554035,
		"lat" : 26.089690999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 701,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63605877794411,
		  26.116249925615964
		]
	  },
	  "properties" : {
		"FID" : 701,
		"name" : "清胜禅寺",
		"lng" : 119.640528,
		"lat" : 26.112938
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 702,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57608004388176,
		  26.098234379582571
		]
	  },
	  "properties" : {
		"FID" : 702,
		"name" : "清福院",
		"lng" : 119.58055,
		"lat" : 26.094905000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 703,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60559285689996,
		  26.07329819796961
		]
	  },
	  "properties" : {
		"FID" : 703,
		"name" : "妈祖河公园",
		"lng" : 119.610041,
		"lat" : 26.069982
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 704,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57592727262367,
		  26.105954319322098
		]
	  },
	  "properties" : {
		"FID" : 704,
		"name" : "南山公园",
		"lng" : 119.580398,
		"lat" : 26.102620000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 705,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63746713449179,
		  26.062498273937148
		]
	  },
	  "properties" : {
		"FID" : 705,
		"name" : "琅岐沙滩",
		"lng" : 119.64193400000001,
		"lat" : 26.059224
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 706,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59414518268061,
		  26.139492622160802
		]
	  },
	  "properties" : {
		"FID" : 706,
		"name" : "长门炮台",
		"lng" : 119.598601,
		"lat" : 26.136130000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 707,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63288661082512,
		  26.122672805028319
		]
	  },
	  "properties" : {
		"FID" : 707,
		"name" : "粼川亭",
		"lng" : 119.637353,
		"lat" : 26.119351999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 708,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56444043046642,
		  26.143194460623871
		]
	  },
	  "properties" : {
		"FID" : 708,
		"name" : "报恩寺",
		"lng" : 119.568933,
		"lat" : 26.139848000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 709,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57230413422346,
		  26.089108146107254
		]
	  },
	  "properties" : {
		"FID" : 709,
		"name" : "鳌山公园",
		"lng" : 119.576779,
		"lat" : 26.085788000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 710,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57842387080095,
		  26.088361551352214
		]
	  },
	  "properties" : {
		"FID" : 710,
		"name" : "正谊堂",
		"lng" : 119.58289000000001,
		"lat" : 26.085037
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 711,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54063475956255,
		  26.147306142204258
		]
	  },
	  "properties" : {
		"FID" : 711,
		"name" : "青芝山风景区-青芝寺",
		"lng" : 119.545186,
		"lat" : 26.143999000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 712,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57504285462748,
		  26.09447008256388
		]
	  },
	  "properties" : {
		"FID" : 712,
		"name" : "西兴寺",
		"lng" : 119.579514,
		"lat" : 26.091144
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 713,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63796233014213,
		  26.120982032329145
		]
	  },
	  "properties" : {
		"FID" : 713,
		"name" : "连江壶江紫竹寺",
		"lng" : 119.64243399999999,
		"lat" : 26.11767
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 714,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55751444191623,
		  26.136089059513996
		]
	  },
	  "properties" : {
		"FID" : 714,
		"name" : "蓉山公园",
		"lng" : 119.562021,
		"lat" : 26.132757000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 715,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57691789949909,
		  26.088392521920404
		]
	  },
	  "properties" : {
		"FID" : 715,
		"name" : "董文驹公故居",
		"lng" : 119.58138599999999,
		"lat" : 26.085069000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 716,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57196948581475,
		  26.145953617170154
		]
	  },
	  "properties" : {
		"FID" : 716,
		"name" : "大雄宝殿",
		"lng" : 119.576449,
		"lat" : 26.142596999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 717,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56949880597608,
		  26.140784858490065
		]
	  },
	  "properties" : {
		"FID" : 717,
		"name" : "龙山公园",
		"lng" : 119.573982,
		"lat" : 26.137433999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 718,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63027017888579,
		  26.080588948149373
		]
	  },
	  "properties" : {
		"FID" : 718,
		"name" : "云龙妈祖公园",
		"lng" : 119.634731,
		"lat" : 26.077292
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 719,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57722136688054,
		  26.0875391774231
		]
	  },
	  "properties" : {
		"FID" : 719,
		"name" : "董公世舜祖居",
		"lng" : 119.581689,
		"lat" : 26.084216000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 720,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55717533499946,
		  26.140786512206663
		]
	  },
	  "properties" : {
		"FID" : 720,
		"name" : "侨乡公园",
		"lng" : 119.561683,
		"lat" : 26.137452
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 721,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62691498351063,
		  26.151110078680201
		]
	  },
	  "properties" : {
		"FID" : 721,
		"name" : "塘下公园",
		"lng" : 119.631378,
		"lat" : 26.147763000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 722,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63293667506363,
		  26.066001451070051
		]
	  },
	  "properties" : {
		"FID" : 722,
		"name" : "欧阳氏宗祠",
		"lng" : 119.637399,
		"lat" : 26.062718
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 723,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63162203438074,
		  26.078810877328369
		]
	  },
	  "properties" : {
		"FID" : 723,
		"name" : "高安境真武庙",
		"lng" : 119.636084,
		"lat" : 26.075517000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 724,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57411575647436,
		  26.090985010188945
		]
	  },
	  "properties" : {
		"FID" : 724,
		"name" : "琅岐基督教堂",
		"lng" : 119.578588,
		"lat" : 26.087662000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 725,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57371410537662,
		  26.091719147042767
		]
	  },
	  "properties" : {
		"FID" : 725,
		"name" : "嘉登泰山庙",
		"lng" : 119.578187,
		"lat" : 26.088395999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 726,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57090120006977,
		  26.084832959111086
		]
	  },
	  "properties" : {
		"FID" : 726,
		"name" : "泗洲文佛寺",
		"lng" : 119.575378,
		"lat" : 26.081517000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 727,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55775452253019,
		  26.1561310894046
		]
	  },
	  "properties" : {
		"FID" : 727,
		"name" : "兰若禅寺",
		"lng" : 119.562262,
		"lat" : 26.152785999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 728,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63473467970866,
		  26.081937417336455
		]
	  },
	  "properties" : {
		"FID" : 728,
		"name" : "云龙叶氏宗祠",
		"lng" : 119.6392,
		"lat" : 26.078645999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 729,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5718124537274,
		  26.156739241064045
		]
	  },
	  "properties" : {
		"FID" : 729,
		"name" : "连江琯头象龙寺",
		"lng" : 119.57629300000001,
		"lat" : 26.153376000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 730,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56528288956399,
		  26.090230221944463
		]
	  },
	  "properties" : {
		"FID" : 730,
		"name" : "过透公园",
		"lng" : 119.56977000000001,
		"lat" : 26.086917
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 731,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57137176799193,
		  26.087527207941033
		]
	  },
	  "properties" : {
		"FID" : 731,
		"name" : "昭烈王庙",
		"lng" : 119.57584799999999,
		"lat" : 26.084209000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 732,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56626609840109,
		  26.085181085687669
		]
	  },
	  "properties" : {
		"FID" : 732,
		"name" : "光明村垃圾分类亭",
		"lng" : 119.570751,
		"lat" : 26.081869999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 733,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57812756659875,
		  26.087331671798399
		]
	  },
	  "properties" : {
		"FID" : 733,
		"name" : "牛屿山公园",
		"lng" : 119.582594,
		"lat" : 26.084008000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 734,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57129522131649,
		  26.093369990518223
		]
	  },
	  "properties" : {
		"FID" : 734,
		"name" : "凤山禅寺",
		"lng" : 119.575772,
		"lat" : 26.090047999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 735,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5778811897794,
		  26.088142039634054
		]
	  },
	  "properties" : {
		"FID" : 735,
		"name" : "琅山朱氏宗祠",
		"lng" : 119.582348,
		"lat" : 26.084817999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 736,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57245737680077,
		  26.089064260186596
		]
	  },
	  "properties" : {
		"FID" : 736,
		"name" : "江氏宗祠",
		"lng" : 119.576932,
		"lat" : 26.085743999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 737,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56863344184131,
		  26.139067833345731
		]
	  },
	  "properties" : {
		"FID" : 737,
		"name" : "佛地寺",
		"lng" : 119.57311799999999,
		"lat" : 26.135719000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 738,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57175914284792,
		  26.146078494851807
		]
	  },
	  "properties" : {
		"FID" : 738,
		"name" : "保安寺",
		"lng" : 119.576239,
		"lat" : 26.142721999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 739,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57153861713012,
		  26.134688050519994
		]
	  },
	  "properties" : {
		"FID" : 739,
		"name" : "门边村龙门公园",
		"lng" : 119.576018,
		"lat" : 26.131339000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 740,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5712203029576,
		  26.090572071314821
		]
	  },
	  "properties" : {
		"FID" : 740,
		"name" : "陈氏宗祠",
		"lng" : 119.57569700000001,
		"lat" : 26.087251999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 741,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56670133446244,
		  26.134330610446444
		]
	  },
	  "properties" : {
		"FID" : 741,
		"name" : "门边村江滨公园",
		"lng" : 119.571189,
		"lat" : 26.130987000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 742,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5901820065892,
		  26.136210341106825
		]
	  },
	  "properties" : {
		"FID" : 742,
		"name" : "长门文体公园",
		"lng" : 119.59464,
		"lat" : 26.132850000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 743,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55818679681528,
		  26.083058571205601
		]
	  },
	  "properties" : {
		"FID" : 743,
		"name" : "琅岐香海基督徒聚会所",
		"lng" : 119.56268799999999,
		"lat" : 26.07976
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 744,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55587742625195,
		  26.139871839450624
		]
	  },
	  "properties" : {
		"FID" : 744,
		"name" : "基督教福音堂",
		"lng" : 119.560388,
		"lat" : 26.13654
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 745,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5785421962706,
		  26.085938026242239
		]
	  },
	  "properties" : {
		"FID" : 745,
		"name" : "仰恩亭",
		"lng" : 119.58300800000001,
		"lat" : 26.082615000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 746,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56819120214813,
		  26.090336729459118
		]
	  },
	  "properties" : {
		"FID" : 746,
		"name" : "陈氏支祠",
		"lng" : 119.57267299999999,
		"lat" : 26.087019999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 747,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57349054885022,
		  26.067136616698992
		]
	  },
	  "properties" : {
		"FID" : 747,
		"name" : "绿丰农业观光园",
		"lng" : 119.577962,
		"lat" : 26.063829999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 748,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63286658979438,
		  26.068140983182325
		]
	  },
	  "properties" : {
		"FID" : 748,
		"name" : "五福天仙府",
		"lng" : 119.63732899999999,
		"lat" : 26.064855999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 749,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62431946385998,
		  26.144755301285961
		]
	  },
	  "properties" : {
		"FID" : 749,
		"name" : "郑和井公园",
		"lng" : 119.62878000000001,
		"lat" : 26.141408999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 750,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6127918436551,
		  26.154407001553651
		]
	  },
	  "properties" : {
		"FID" : 750,
		"name" : "蓬岐村休闲园",
		"lng" : 119.61724700000001,
		"lat" : 26.151043000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 751,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63446649219787,
		  26.15716037223623
		]
	  },
	  "properties" : {
		"FID" : 751,
		"name" : "龙坞胜境",
		"lng" : 119.638937,
		"lat" : 26.15382
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 752,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56745058958761,
		  26.080612449244583
		]
	  },
	  "properties" : {
		"FID" : 752,
		"name" : "上琦境天元庙",
		"lng" : 119.571933,
		"lat" : 26.077303000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 753,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59221105719509,
		  26.140051969921387
		]
	  },
	  "properties" : {
		"FID" : 753,
		"name" : "张圣真君堂",
		"lng" : 119.59666799999999,
		"lat" : 26.136689000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 754,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63223484667589,
		  26.155797784193854
		]
	  },
	  "properties" : {
		"FID" : 754,
		"name" : "龙沙村牌坊",
		"lng" : 119.636703,
		"lat" : 26.152455
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 755,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55485252488307,
		  26.091744942214831
		]
	  },
	  "properties" : {
		"FID" : 755,
		"name" : "印象广场",
		"lng" : 119.55936199999999,
		"lat" : 26.088446000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 756,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6127918436551,
		  26.154407001553651
		]
	  },
	  "properties" : {
		"FID" : 756,
		"name" : "蓬岐村休闲园",
		"lng" : 119.61724700000001,
		"lat" : 26.151043000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 757,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66119311954,
		  26.138538154376288
		]
	  },
	  "properties" : {
		"FID" : 757,
		"name" : "川石公园",
		"lng" : 119.66569699999999,
		"lat" : 26.135255999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 758,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54258673174,
		  26.142754499103955
		]
	  },
	  "properties" : {
		"FID" : 758,
		"name" : "青芝山风景区-梵音禅寺",
		"lng" : 119.547132,
		"lat" : 26.139446
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 759,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54169536608475,
		  26.112714291415767
		]
	  },
	  "properties" : {
		"FID" : 759,
		"name" : "道祥公园",
		"lng" : 119.54624099999999,
		"lat" : 26.109427
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 760,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63677563499554,
		  26.066152795323941
		]
	  },
	  "properties" : {
		"FID" : 760,
		"name" : "琅岐临水宫",
		"lng" : 119.64124200000001,
		"lat" : 26.062874999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 761,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55205980373319,
		  26.132348499934505
		]
	  },
	  "properties" : {
		"FID" : 761,
		"name" : "林氏宗祠",
		"lng" : 119.556579,
		"lat" : 26.129028000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 762,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5359044699117,
		  26.10726464646093
		]
	  },
	  "properties" : {
		"FID" : 762,
		"name" : "光德亭",
		"lng" : 119.54046700000001,
		"lat" : 26.103994
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 763,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53712605721906,
		  26.109390884614733
		]
	  },
	  "properties" : {
		"FID" : 763,
		"name" : "东岐三清宫",
		"lng" : 119.541685,
		"lat" : 26.106116
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 764,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63593246375602,
		  26.067377909978468
		]
	  },
	  "properties" : {
		"FID" : 764,
		"name" : "齐天府",
		"lng" : 119.640398,
		"lat" : 26.064098000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 765,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59122643808624,
		  26.140033891411584
		]
	  },
	  "properties" : {
		"FID" : 765,
		"name" : "知府庙",
		"lng" : 119.59568400000001,
		"lat" : 26.136671
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 766,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63582856287978,
		  26.0675531856002
		]
	  },
	  "properties" : {
		"FID" : 766,
		"name" : "凤岩寺",
		"lng" : 119.640294,
		"lat" : 26.064273
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 767,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66366869610377,
		  26.135833721807863
		]
	  },
	  "properties" : {
		"FID" : 767,
		"name" : "基督教川石堂",
		"lng" : 119.668176,
		"lat" : 26.132558
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 768,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63203522948187,
		  26.153216454366021
		]
	  },
	  "properties" : {
		"FID" : 768,
		"name" : "锁风隘",
		"lng" : 119.636503,
		"lat" : 26.149875000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 769,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63427571959872,
		  26.156757404630977
		]
	  },
	  "properties" : {
		"FID" : 769,
		"name" : "龙沙海滨公园",
		"lng" : 119.638746,
		"lat" : 26.153417000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 770,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57346691701834,
		  26.144363987903873
		]
	  },
	  "properties" : {
		"FID" : 770,
		"name" : "怡心亭",
		"lng" : 119.577944,
		"lat" : 26.141006999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 771,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59137267396676,
		  26.138090668978517
		]
	  },
	  "properties" : {
		"FID" : 771,
		"name" : "桃源胜境",
		"lng" : 119.59583000000001,
		"lat" : 26.134729
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 772,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56230177526997,
		  26.135046443982358
		]
	  },
	  "properties" : {
		"FID" : 772,
		"name" : "玉楼寺",
		"lng" : 119.56679800000001,
		"lat" : 26.131708
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 773,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5635161826327,
		  26.094132529237555
		]
	  },
	  "properties" : {
		"FID" : 773,
		"name" : "寨上境十八位将军庙",
		"lng" : 119.56800699999999,
		"lat" : 26.090819
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 774,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56686226525144,
		  26.139334988117639
		]
	  },
	  "properties" : {
		"FID" : 774,
		"name" : "揽风台",
		"lng" : 119.57135,
		"lat" : 26.135988000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 775,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62315489699819,
		  26.150257148217442
		]
	  },
	  "properties" : {
		"FID" : 775,
		"name" : "元华乐园",
		"lng" : 119.62761500000001,
		"lat" : 26.146906000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 776,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66209598778116,
		  26.135984813973305
		]
	  },
	  "properties" : {
		"FID" : 776,
		"name" : "陈氏宗祠",
		"lng" : 119.666601,
		"lat" : 26.132705999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 777,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.664346424225,
		  26.139632845101907
		]
	  },
	  "properties" : {
		"FID" : 777,
		"name" : "五虎礁海湾沙滩",
		"lng" : 119.66885499999999,
		"lat" : 26.136355999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 778,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62927921909053,
		  26.147510699575673
		]
	  },
	  "properties" : {
		"FID" : 778,
		"name" : "天后宫",
		"lng" : 119.63374399999999,
		"lat" : 26.144169000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 779,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66082469907697,
		  26.137956483404565
		]
	  },
	  "properties" : {
		"FID" : 779,
		"name" : "川石牌坊",
		"lng" : 119.665328,
		"lat" : 26.134674
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 780,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56157316855206,
		  26.136588416138341
		]
	  },
	  "properties" : {
		"FID" : 780,
		"name" : "金牛山广场B",
		"lng" : 119.56607099999999,
		"lat" : 26.13325
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 781,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5379356315504,
		  26.10773166631899
		]
	  },
	  "properties" : {
		"FID" : 781,
		"name" : "东岐码头旧址",
		"lng" : 119.542492,
		"lat" : 26.104455999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 782,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54408593206574,
		  26.129553247547332
		]
	  },
	  "properties" : {
		"FID" : 782,
		"name" : "桂玉公园",
		"lng" : 119.548626,
		"lat" : 26.126249999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 783,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66147181965103,
		  26.137077696267301
		]
	  },
	  "properties" : {
		"FID" : 783,
		"name" : "白马宫",
		"lng" : 119.665976,
		"lat" : 26.133797000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 784,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54167525153582,
		  26.113488751229582
		]
	  },
	  "properties" : {
		"FID" : 784,
		"name" : "林氏宗祠",
		"lng" : 119.546221,
		"lat" : 26.110201
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 785,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66550009300548,
		  26.134678487657244
		]
	  },
	  "properties" : {
		"FID" : 785,
		"name" : "佑天宫",
		"lng" : 119.67001,
		"lat" : 26.131406999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 786,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5444117985576,
		  26.13014730567404
		]
	  },
	  "properties" : {
		"FID" : 786,
		"name" : "煦光亭",
		"lng" : 119.548951,
		"lat" : 26.126843000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 787,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66729625525338,
		  26.137418798418587
		]
	  },
	  "properties" : {
		"FID" : 787,
		"name" : "望云亭",
		"lng" : 119.671809,
		"lat" : 26.134149000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 788,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54165829120667,
		  26.057387583812343
		]
	  },
	  "properties" : {
		"FID" : 788,
		"name" : "猴屿网红绿皮火车",
		"lng" : 119.5462,
		"lat" : 26.054137000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 789,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66451551001191,
		  26.135066616484593
		]
	  },
	  "properties" : {
		"FID" : 789,
		"name" : "金山宝",
		"lng" : 119.66902399999999,
		"lat" : 26.131792999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 790,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54186674789361,
		  26.141654254914574
		]
	  },
	  "properties" : {
		"FID" : 790,
		"name" : "青芝山风景区-孟溪胜境",
		"lng" : 119.546414,
		"lat" : 26.138348000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 791,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54149581649581,
		  26.057461280654074
		]
	  },
	  "properties" : {
		"FID" : 791,
		"name" : "红安河绿皮火车",
		"lng" : 119.546038,
		"lat" : 26.054210999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 792,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5392765646001,
		  26.053993043673824
		]
	  },
	  "properties" : {
		"FID" : 792,
		"name" : "猴屿屏山寺",
		"lng" : 119.543825,
		"lat" : 26.050750000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 793,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53337832540663,
		  26.110730867835294
		]
	  },
	  "properties" : {
		"FID" : 793,
		"name" : "福州市护国寺(泰山宫)",
		"lng" : 119.537949,
		"lat" : 26.107464
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 794,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54030087778077,
		  26.132295869310369
		]
	  },
	  "properties" : {
		"FID" : 794,
		"name" : "崇文公园",
		"lng" : 119.54485200000001,
		"lat" : 26.128999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 795,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53762685898936,
		  26.132910228337938
		]
	  },
	  "properties" : {
		"FID" : 795,
		"name" : "净光禅寺",
		"lng" : 119.542186,
		"lat" : 26.129619000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 796,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53583625144503,
		  26.107374557648356
		]
	  },
	  "properties" : {
		"FID" : 796,
		"name" : "光德亭门头道",
		"lng" : 119.54039899999999,
		"lat" : 26.104104
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 797,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53324463730777,
		  26.128021726107814
		]
	  },
	  "properties" : {
		"FID" : 797,
		"name" : "灵峰禅寺",
		"lng" : 119.537817,
		"lat" : 26.124744
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 798,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53425892070982,
		  26.058407341598627
		]
	  },
	  "properties" : {
		"FID" : 798,
		"name" : "猴屿长寿庵",
		"lng" : 119.53882299999999,
		"lat" : 26.055173
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 799,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53514935827582,
		  26.063085607424846
		]
	  },
	  "properties" : {
		"FID" : 799,
		"name" : "猴屿张家戚继光公园",
		"lng" : 119.539711,
		"lat" : 26.059846
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 800,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5376934054121,
		  26.059684271078968
		]
	  },
	  "properties" : {
		"FID" : 800,
		"name" : "猴屿侯封境",
		"lng" : 119.542247,
		"lat" : 26.056441
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 801,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53697083286687,
		  26.133359000082102
		]
	  },
	  "properties" : {
		"FID" : 801,
		"name" : "留云寺",
		"lng" : 119.541532,
		"lat" : 26.130068999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 802,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53339720148217,
		  26.058495319895599
		]
	  },
	  "properties" : {
		"FID" : 802,
		"name" : "猴屿张香俤公园",
		"lng" : 119.537964,
		"lat" : 26.055263
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 803,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53963525473631,
		  26.059111287439105
		]
	  },
	  "properties" : {
		"FID" : 803,
		"name" : "红安亭",
		"lng" : 119.544183,
		"lat" : 26.055864
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 804,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52582047691689,
		  26.057751647589463
		]
	  },
	  "properties" : {
		"FID" : 804,
		"name" : "猴屿锦福禅寺",
		"lng" : 119.530412,
		"lat" : 26.054538999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 805,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53724486158032,
		  26.062210932432251
		]
	  },
	  "properties" : {
		"FID" : 805,
		"name" : "猴屿元帅府",
		"lng" : 119.54179999999999,
		"lat" : 26.058966999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 806,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53304109602551,
		  26.058190248830901
		]
	  },
	  "properties" : {
		"FID" : 806,
		"name" : "张香俤怀乡亭",
		"lng" : 119.537609,
		"lat" : 26.054959
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 807,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53819305361665,
		  26.057741110188712
		]
	  },
	  "properties" : {
		"FID" : 807,
		"name" : "一代廉吏郑丙",
		"lng" : 119.542745,
		"lat" : 26.054497999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 808,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53322867897543,
		  26.058348812050831
		]
	  },
	  "properties" : {
		"FID" : 808,
		"name" : "猴屿怀乡亭",
		"lng" : 119.537796,
		"lat" : 26.055116999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 809,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53675254795377,
		  26.059655076119391
		]
	  },
	  "properties" : {
		"FID" : 809,
		"name" : "凤岭雅集",
		"lng" : 119.541309,
		"lat" : 26.056414
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 810,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52941422202454,
		  26.142546473864176
		]
	  },
	  "properties" : {
		"FID" : 810,
		"name" : "龙华禅寺",
		"lng" : 119.53400000000001,
		"lat" : 26.139268999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 811,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53394971709326,
		  26.061597738624787
		]
	  },
	  "properties" : {
		"FID" : 811,
		"name" : "猴屿张氏宗祠纪念馆",
		"lng" : 119.538515,
		"lat" : 26.058361999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 812,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.619746577021,
		  26.088019724020992
		]
	  },
	  "properties" : {
		"FID" : 812,
		"name" : "琅岐白云寺",
		"lng" : 119.6242,
		"lat" : 26.084705
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 813,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54087821318394,
		  26.150826893986675
		]
	  },
	  "properties" : {
		"FID" : 813,
		"name" : "青芝山风景区",
		"lng" : 119.545429,
		"lat" : 26.147517000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 814,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5618867363373,
		  26.082570677068308
		]
	  },
	  "properties" : {
		"FID" : 814,
		"name" : "琅岐真武殿(装修中)",
		"lng" : 119.56638,
		"lat" : 26.079267000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 815,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32040195081971,
		  26.042849811968839
		]
	  },
	  "properties" : {
		"FID" : 815,
		"name" : "福州蔡襄纪念馆",
		"lng" : 119.32525099999999,
		"lat" : 26.039822000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 816,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32131925441119,
		  26.041732303674053
		]
	  },
	  "properties" : {
		"FID" : 816,
		"name" : "仙居亭",
		"lng" : 119.32617,
		"lat" : 26.038706999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 817,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32039798541808,
		  26.042493578914861
		]
	  },
	  "properties" : {
		"FID" : 817,
		"name" : "五代通明井",
		"lng" : 119.325247,
		"lat" : 26.039466000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 818,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32039995401495,
		  26.042858821869356
		]
	  },
	  "properties" : {
		"FID" : 818,
		"name" : "蔡忠惠公祠",
		"lng" : 119.325249,
		"lat" : 26.039831
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 819,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32013442019422,
		  26.043509768710837
		]
	  },
	  "properties" : {
		"FID" : 819,
		"name" : "福州南台藤山开闽王祠",
		"lng" : 119.324983,
		"lat" : 26.040481
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 820,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3214509743343,
		  26.042054269321252
		]
	  },
	  "properties" : {
		"FID" : 820,
		"name" : "娘娘母王",
		"lng" : 119.326302,
		"lat" : 26.039028999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 821,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32166856048921,
		  26.041939775816079
		]
	  },
	  "properties" : {
		"FID" : 821,
		"name" : "府霞裴仙师",
		"lng" : 119.32652,
		"lat" : 26.038914999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 822,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32163159062041,
		  26.042491219075057
		]
	  },
	  "properties" : {
		"FID" : 822,
		"name" : "南天照天君接龙亭分殿",
		"lng" : 119.326483,
		"lat" : 26.039466000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 823,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31972244364633,
		  26.040541549887987
		]
	  },
	  "properties" : {
		"FID" : 823,
		"name" : "哈利路亚",
		"lng" : 119.32456999999999,
		"lat" : 26.037514000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 824,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32007126916805,
		  26.047132334073655
		]
	  },
	  "properties" : {
		"FID" : 824,
		"name" : "陈靖姑故居",
		"lng" : 119.32492000000001,
		"lat" : 26.044101000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 825,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31683380075728,
		  26.04366115638754
		]
	  },
	  "properties" : {
		"FID" : 825,
		"name" : "观音堂",
		"lng" : 119.321676,
		"lat" : 26.040626
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 826,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31772592766579,
		  26.045631792003348
		]
	  },
	  "properties" : {
		"FID" : 826,
		"name" : "基督教小岭堂",
		"lng" : 119.32257,
		"lat" : 26.042597000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 827,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32225866293375,
		  26.038653425331411
		]
	  },
	  "properties" : {
		"FID" : 827,
		"name" : "种福寺",
		"lng" : 119.327111,
		"lat" : 26.035632
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 828,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32035073281023,
		  26.047052746611332
		]
	  },
	  "properties" : {
		"FID" : 828,
		"name" : "临水夫人故居",
		"lng" : 119.3252,
		"lat" : 26.044021999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 829,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31552841251703,
		  26.042401778003878
		]
	  },
	  "properties" : {
		"FID" : 829,
		"name" : "创佳壹号体育公园",
		"lng" : 119.320368,
		"lat" : 26.039365
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 830,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31968995386708,
		  26.047862554499179
		]
	  },
	  "properties" : {
		"FID" : 830,
		"name" : "许真君祖殿",
		"lng" : 119.324538,
		"lat" : 26.044830000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 831,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32035672088628,
		  26.047056737863794
		]
	  },
	  "properties" : {
		"FID" : 831,
		"name" : "居故母圣天顺",
		"lng" : 119.32520599999999,
		"lat" : 26.044025999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 832,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31413490482824,
		  26.044842053479226
		]
	  },
	  "properties" : {
		"FID" : 832,
		"name" : "山藤真人宫",
		"lng" : 119.318972,
		"lat" : 26.041801
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 833,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32059417760877,
		  26.048147019367715
		]
	  },
	  "properties" : {
		"FID" : 833,
		"name" : "庙祖师仙三白裴黑档大",
		"lng" : 119.325444,
		"lat" : 26.045116
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 834,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31397124466686,
		  26.044493125669522
		]
	  },
	  "properties" : {
		"FID" : 834,
		"name" : "无逸山荘",
		"lng" : 119.318808,
		"lat" : 26.041452
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 835,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31667944514135,
		  26.039070346831949
		]
	  },
	  "properties" : {
		"FID" : 835,
		"name" : "福州道教腾山汉潘府龙兴堂总堂",
		"lng" : 119.321521,
		"lat" : 26.036038000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 836,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31960699512426,
		  26.036202835451117
		]
	  },
	  "properties" : {
		"FID" : 836,
		"name" : "三圣王庙",
		"lng" : 119.324454,
		"lat" : 26.033177999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 837,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32696193341914,
		  26.04681794609273
		]
	  },
	  "properties" : {
		"FID" : 837,
		"name" : "民族英雄陈文龙纪念馆",
		"lng" : 119.331824,
		"lat" : 26.043800000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 838,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32057397146137,
		  26.051395246560986
		]
	  },
	  "properties" : {
		"FID" : 838,
		"name" : "泛船浦神父楼",
		"lng" : 119.325424,
		"lat" : 26.048362000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 839,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31662377344117,
		  26.049396423687952
		]
	  },
	  "properties" : {
		"FID" : 839,
		"name" : "共和茶港1号",
		"lng" : 119.321466,
		"lat" : 26.046357
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 840,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32406730428355,
		  26.049879542963726
		]
	  },
	  "properties" : {
		"FID" : 840,
		"name" : "汉闽越王庙",
		"lng" : 119.328924,
		"lat" : 26.046854
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 841,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32695794104836,
		  26.046818954391551
		]
	  },
	  "properties" : {
		"FID" : 841,
		"name" : "中墩尚书庙",
		"lng" : 119.33181999999999,
		"lat" : 26.043800999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 842,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31369145549186,
		  26.048799556252099
		]
	  },
	  "properties" : {
		"FID" : 842,
		"name" : "塔亭临水陈太后祖庙",
		"lng" : 119.318528,
		"lat" : 26.045755
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 843,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31121262755288,
		  26.042788129296479
		]
	  },
	  "properties" : {
		"FID" : 843,
		"name" : "云应正境",
		"lng" : 119.31604400000001,
		"lat" : 26.039743000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 844,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32687809659434,
		  26.046800094048653
		]
	  },
	  "properties" : {
		"FID" : 844,
		"name" : "宋忠肃公祠",
		"lng" : 119.33174,
		"lat" : 26.043782
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 845,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32415014566546,
		  26.049852366139596
		]
	  },
	  "properties" : {
		"FID" : 845,
		"name" : "探花府积寿堂",
		"lng" : 119.329007,
		"lat" : 26.046827
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 846,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3238149152515,
		  26.035042003297303
		]
	  },
	  "properties" : {
		"FID" : 846,
		"name" : "东升奋斗广场",
		"lng" : 119.32867,
		"lat" : 26.032025999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 847,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3133073595808,
		  26.046548759141199
		]
	  },
	  "properties" : {
		"FID" : 847,
		"name" : "陈之麟先生的故居(不对外开放)",
		"lng" : 119.31814300000001,
		"lat" : 26.043505
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 848,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31068977680528,
		  26.040655657832616
		]
	  },
	  "properties" : {
		"FID" : 848,
		"name" : "王爷礼堂",
		"lng" : 119.31552000000001,
		"lat" : 26.037610999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 849,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31976653972572,
		  26.051378777602171
		]
	  },
	  "properties" : {
		"FID" : 849,
		"name" : "泛船浦牧灵中心",
		"lng" : 119.32461499999999,
		"lat" : 26.048344
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 850,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31387710163467,
		  26.048780194497176
		]
	  },
	  "properties" : {
		"FID" : 850,
		"name" : "敕封顺懿宫",
		"lng" : 119.318714,
		"lat" : 26.045736000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 851,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31349785465866,
		  26.035152699537733
		]
	  },
	  "properties" : {
		"FID" : 851,
		"name" : "伽蓝庙",
		"lng" : 119.318333,
		"lat" : 26.032117
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 852,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31032841136155,
		  26.041281749481673
		]
	  },
	  "properties" : {
		"FID" : 852,
		"name" : "林森公馆",
		"lng" : 119.315158,
		"lat" : 26.038236000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 853,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32387465125861,
		  26.050233149839549
		]
	  },
	  "properties" : {
		"FID" : 853,
		"name" : "港头娘奶祖殿",
		"lng" : 119.328731,
		"lat" : 26.047207
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 854,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31243888357308,
		  26.048304568323328
		]
	  },
	  "properties" : {
		"FID" : 854,
		"name" : "独立厅",
		"lng" : 119.317273,
		"lat" : 26.045258
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 855,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32001336963577,
		  26.034045599075132
		]
	  },
	  "properties" : {
		"FID" : 855,
		"name" : "山藤汉藩府下井同心堂",
		"lng" : 119.324861,
		"lat" : 26.031023000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 856,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33104960943886,
		  26.039985565234065
		]
	  },
	  "properties" : {
		"FID" : 856,
		"name" : "南湖祖殿",
		"lng" : 119.335919,
		"lat" : 26.03698
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 857,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30541640181323,
		  26.043038878452492
		]
	  },
	  "properties" : {
		"FID" : 857,
		"name" : "可园",
		"lng" : 119.310237,
		"lat" : 26.039982999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 858,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30720169433165,
		  26.048689474924085
		]
	  },
	  "properties" : {
		"FID" : 858,
		"name" : "仓前公园",
		"lng" : 119.312026,
		"lat" : 26.045632999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 859,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30728361124808,
		  26.047779713015895
		]
	  },
	  "properties" : {
		"FID" : 859,
		"name" : "福州天安基督教堂",
		"lng" : 119.31210799999999,
		"lat" : 26.044723999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 860,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32299530667673,
		  26.050909288073179
		]
	  },
	  "properties" : {
		"FID" : 860,
		"name" : "临江晏公祖庙",
		"lng" : 119.32785,
		"lat" : 26.047881
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 861,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31374324907542,
		  26.050222417794959
		]
	  },
	  "properties" : {
		"FID" : 861,
		"name" : "福州市清凉寺",
		"lng" : 119.31858,
		"lat" : 26.047177000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 862,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31075863952368,
		  26.04075159514554
		]
	  },
	  "properties" : {
		"FID" : 862,
		"name" : "圣王庙",
		"lng" : 119.315589,
		"lat" : 26.037707000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 863,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31069621023451,
		  26.048013613341936
		]
	  },
	  "properties" : {
		"FID" : 863,
		"name" : "烟台山公园",
		"lng" : 119.315527,
		"lat" : 26.044964
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 864,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32040268952856,
		  26.033047179160924
		]
	  },
	  "properties" : {
		"FID" : 864,
		"name" : "藤山古迹齐天府",
		"lng" : 119.32525099999999,
		"lat" : 26.030025999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 865,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32034480525662,
		  26.033002259310841
		]
	  },
	  "properties" : {
		"FID" : 865,
		"name" : "古迹圣王垱",
		"lng" : 119.325193,
		"lat" : 26.029980999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 866,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30721717846359,
		  26.041878850396891
		]
	  },
	  "properties" : {
		"FID" : 866,
		"name" : "福州马厂街基督教堂",
		"lng" : 119.31204099999999,
		"lat" : 26.038827000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 867,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31003599948731,
		  26.054056903669839
		]
	  },
	  "properties" : {
		"FID" : 867,
		"name" : "闽江夜游",
		"lng" : 119.31486599999999,
		"lat" : 26.051002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 868,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.311751939763,
		  26.064877985295112
		]
	  },
	  "properties" : {
		"FID" : 868,
		"name" : "路通古迹",
		"lng" : 119.316586,
		"lat" : 26.061819
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 869,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33176715663049,
		  26.041159004142969
		]
	  },
	  "properties" : {
		"FID" : 869,
		"name" : "高湖吴氏宗祠",
		"lng" : 119.33663799999999,
		"lat" : 26.038153999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 870,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30876377223144,
		  26.048922785474236
		]
	  },
	  "properties" : {
		"FID" : 870,
		"name" : "安澜会馆",
		"lng" : 119.313591,
		"lat" : 26.045869
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 871,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30285379907167,
		  26.046166529268735
		]
	  },
	  "properties" : {
		"FID" : 871,
		"name" : "万寿头陀寺",
		"lng" : 119.30767,
		"lat" : 26.043104
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 872,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30793539144038,
		  26.047922624448358
		]
	  },
	  "properties" : {
		"FID" : 872,
		"name" : "陈子珍故居",
		"lng" : 119.31276099999999,
		"lat" : 26.044868000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 873,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32552040501041,
		  26.064201384766267
		]
	  },
	  "properties" : {
		"FID" : 873,
		"name" : "光明港公园-儿童游戏区",
		"lng" : 119.330381,
		"lat" : 26.061169
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 874,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29474610338049,
		  26.040871589190346
		]
	  },
	  "properties" : {
		"FID" : 874,
		"name" : "福州市上渡基督教堂",
		"lng" : 119.299548,
		"lat" : 26.037799
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 875,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29981729400437,
		  26.044277500411187
		]
	  },
	  "properties" : {
		"FID" : 875,
		"name" : "望北台真武庙",
		"lng" : 119.30462799999999,
		"lat" : 26.041211000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 876,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32152922617576,
		  26.023463524989715
		]
	  },
	  "properties" : {
		"FID" : 876,
		"name" : "王氏宗祠",
		"lng" : 119.326379,
		"lat" : 26.020451000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 877,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30238891885176,
		  26.042307736913646
		]
	  },
	  "properties" : {
		"FID" : 877,
		"name" : "华南女子文理学院旧址",
		"lng" : 119.307204,
		"lat" : 26.039247
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 878,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31997843303371,
		  26.034103705140005
		]
	  },
	  "properties" : {
		"FID" : 878,
		"name" : "泗洲文佛堂",
		"lng" : 119.324826,
		"lat" : 26.031081
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 879,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33596181549942,
		  26.034147422819235
		]
	  },
	  "properties" : {
		"FID" : 879,
		"name" : "静益寺",
		"lng" : 119.34084,
		"lat" : 26.031154999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 880,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30519112827808,
		  26.052135415423962
		]
	  },
	  "properties" : {
		"FID" : 880,
		"name" : "青年广场",
		"lng" : 119.310012,
		"lat" : 26.049073
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 881,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32764830426184,
		  26.064069233605178
		]
	  },
	  "properties" : {
		"FID" : 881,
		"name" : "光明港公园-西区",
		"lng" : 119.33251300000001,
		"lat" : 26.061040999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 882,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30776184819895,
		  26.046138737248821
		]
	  },
	  "properties" : {
		"FID" : 882,
		"name" : "法国领事馆旧址",
		"lng" : 119.31258699999999,
		"lat" : 26.043085000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 883,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30862517360268,
		  26.047030763511572
		]
	  },
	  "properties" : {
		"FID" : 883,
		"name" : "闽海关税务司官邸",
		"lng" : 119.313452,
		"lat" : 26.043977999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 884,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30656355628618,
		  26.039603494872026
		]
	  },
	  "properties" : {
		"FID" : 884,
		"name" : "施埔基督教堂",
		"lng" : 119.311386,
		"lat" : 26.036552
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 885,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32172137137805,
		  26.069548229410003
		]
	  },
	  "properties" : {
		"FID" : 885,
		"name" : "瑞云寺",
		"lng" : 119.32657500000001,
		"lat" : 26.066504999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 886,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34038360309333,
		  26.062532485206276
		]
	  },
	  "properties" : {
		"FID" : 886,
		"name" : "亚峰公园",
		"lng" : 119.34527199999999,
		"lat" : 26.059529000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 887,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29416917463898,
		  26.039109319511628
		]
	  },
	  "properties" : {
		"FID" : 887,
		"name" : "天主堂",
		"lng" : 119.29897,
		"lat" : 26.036037
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 888,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33056791876142,
		  26.048026905338268
		]
	  },
	  "properties" : {
		"FID" : 888,
		"name" : "仙佛寺",
		"lng" : 119.335437,
		"lat" : 26.045014999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 889,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30751209050796,
		  26.035792198503238
		]
	  },
	  "properties" : {
		"FID" : 889,
		"name" : "施埔将军庙",
		"lng" : 119.312336,
		"lat" : 26.032744999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 890,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32954286712464,
		  26.048174948007329
		]
	  },
	  "properties" : {
		"FID" : 890,
		"name" : "真武廟",
		"lng" : 119.33441000000001,
		"lat" : 26.045161
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 891,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3099906021951,
		  26.047192363675226
		]
	  },
	  "properties" : {
		"FID" : 891,
		"name" : "文园",
		"lng" : 119.31482,
		"lat" : 26.044142000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 892,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29779751663665,
		  26.034238111892499
		]
	  },
	  "properties" : {
		"FID" : 892,
		"name" : "白泉庵",
		"lng" : 119.302604,
		"lat" : 26.031175000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 893,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29353720192228,
		  26.05233524601627
		]
	  },
	  "properties" : {
		"FID" : 893,
		"name" : "洪武亭",
		"lng" : 119.298338,
		"lat" : 26.049253
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 894,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30647211630985,
		  26.047685117180418
		]
	  },
	  "properties" : {
		"FID" : 894,
		"name" : "仓前橄榄五郑宅",
		"lng" : 119.311295,
		"lat" : 26.044627999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 895,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30338162225351,
		  26.049233670464613
		]
	  },
	  "properties" : {
		"FID" : 895,
		"name" : "霞江清泉庵",
		"lng" : 119.308199,
		"lat" : 26.04617
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 896,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31036386394308,
		  26.060927913470795
		]
	  },
	  "properties" : {
		"FID" : 896,
		"name" : "吴颜庙",
		"lng" : 119.315195,
		"lat" : 26.057869
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 897,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3311917271494,
		  26.048066752784383
		]
	  },
	  "properties" : {
		"FID" : 897,
		"name" : "美墩祖庙",
		"lng" : 119.336062,
		"lat" : 26.045055999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 898,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29958784758493,
		  26.055509458180129
		]
	  },
	  "properties" : {
		"FID" : 898,
		"name" : "上下杭历史文化街区",
		"lng" : 119.304399,
		"lat" : 26.052434999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 899,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32130835278569,
		  26.067177434766261
		]
	  },
	  "properties" : {
		"FID" : 899,
		"name" : "福州市博物馆",
		"lng" : 119.326161,
		"lat" : 26.064135
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 900,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31139824160019,
		  26.056511030906645
		]
	  },
	  "properties" : {
		"FID" : 900,
		"name" : "古街购物广场(台江店)",
		"lng" : 119.316231,
		"lat" : 26.053457000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 901,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30854520865034,
		  26.048546932146827
		]
	  },
	  "properties" : {
		"FID" : 901,
		"name" : "崇圣庵巷2号",
		"lng" : 119.313372,
		"lat" : 26.045493
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 902,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.307081613462,
		  26.039430441079414
		]
	  },
	  "properties" : {
		"FID" : 902,
		"name" : "真学广场",
		"lng" : 119.311905,
		"lat" : 26.036380000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 903,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31024916725121,
		  26.019947434240034
		]
	  },
	  "properties" : {
		"FID" : 903,
		"name" : "普照寺",
		"lng" : 119.315077,
		"lat" : 26.016915999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 904,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3155853333885,
		  26.055252331645494
		]
	  },
	  "properties" : {
		"FID" : 904,
		"name" : "台江区江滨公园-滨江旅游休闲广场",
		"lng" : 119.320426,
		"lat" : 26.052206999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 905,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33077652430472,
		  26.04798248072013
		]
	  },
	  "properties" : {
		"FID" : 905,
		"name" : "紫霞府白仙师庙",
		"lng" : 119.335646,
		"lat" : 26.044971
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 906,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30616101194953,
		  26.043385776343086
		]
	  },
	  "properties" : {
		"FID" : 906,
		"name" : "忠庐",
		"lng" : 119.31098299999999,
		"lat" : 26.040330999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 907,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29445191171604,
		  26.049815096160934
		]
	  },
	  "properties" : {
		"FID" : 907,
		"name" : "闽江公园北园-闽水园",
		"lng" : 119.299254,
		"lat" : 26.046735999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 908,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30564098348593,
		  26.043142546185514
		]
	  },
	  "properties" : {
		"FID" : 908,
		"name" : "梦园",
		"lng" : 119.310462,
		"lat" : 26.040087
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 909,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33870030080377,
		  26.027418836959153
		]
	  },
	  "properties" : {
		"FID" : 909,
		"name" : "后山临水宫",
		"lng" : 119.343583,
		"lat" : 26.024436000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 910,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30581045499687,
		  26.032753213638632
		]
	  },
	  "properties" : {
		"FID" : 910,
		"name" : "万安学生街休闲广场",
		"lng" : 119.310631,
		"lat" : 26.029705
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 911,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30686876116683,
		  26.042691030092847
		]
	  },
	  "properties" : {
		"FID" : 911,
		"name" : "亦庐",
		"lng" : 119.31169199999999,
		"lat" : 26.039638
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 912,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30778379734619,
		  26.046272787743572
		]
	  },
	  "properties" : {
		"FID" : 912,
		"name" : "保罗·克洛代尔故居",
		"lng" : 119.31260899999999,
		"lat" : 26.043219000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 913,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31127790084984,
		  26.050790405807327
		]
	  },
	  "properties" : {
		"FID" : 913,
		"name" : "舍人庙",
		"lng" : 119.31610999999999,
		"lat" : 26.047740000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 914,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3324050649798,
		  26.039611757192652
		]
	  },
	  "properties" : {
		"FID" : 914,
		"name" : "菱湖小学旧址",
		"lng" : 119.337277,
		"lat" : 26.036608999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 915,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31488726172553,
		  26.060741335993544
		]
	  },
	  "properties" : {
		"FID" : 915,
		"name" : "光明城基督徒聚会处",
		"lng" : 119.319727,
		"lat" : 26.057690999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 916,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30043227458677,
		  26.056888945281813
		]
	  },
	  "properties" : {
		"FID" : 916,
		"name" : "福州商会八角亭",
		"lng" : 119.305245,
		"lat" : 26.053815
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 917,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31065780677525,
		  26.054328937368172
		]
	  },
	  "properties" : {
		"FID" : 917,
		"name" : "海丝广场",
		"lng" : 119.315489,
		"lat" : 26.051275
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 918,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31034043784666,
		  26.040629286266899
		]
	  },
	  "properties" : {
		"FID" : 918,
		"name" : "道教程埔头圣王庙管理委员会",
		"lng" : 119.31516999999999,
		"lat" : 26.037583999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 919,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30126056079054,
		  26.060348843838216
		]
	  },
	  "properties" : {
		"FID" : 919,
		"name" : "铺前基督教堂",
		"lng" : 119.30607500000001,
		"lat" : 26.057274
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 920,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30639626680656,
		  26.060820088492452
		]
	  },
	  "properties" : {
		"FID" : 920,
		"name" : "达道太保庙",
		"lng" : 119.31122000000001,
		"lat" : 26.057753999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 921,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30442060062261,
		  26.051184147417182
		]
	  },
	  "properties" : {
		"FID" : 921,
		"name" : "青年桥",
		"lng" : 119.30924,
		"lat" : 26.048120999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 922,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29813500801271,
		  26.046678958808222
		]
	  },
	  "properties" : {
		"FID" : 922,
		"name" : "爱情岛",
		"lng" : 119.302943,
		"lat" : 26.043607999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 923,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30637494971054,
		  26.038988419124305
		]
	  },
	  "properties" : {
		"FID" : 923,
		"name" : "师大社区文化活动广场",
		"lng" : 119.31119700000001,
		"lat" : 26.035937000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 924,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33964965554779,
		  26.026476476185106
		]
	  },
	  "properties" : {
		"FID" : 924,
		"name" : "真君庙",
		"lng" : 119.344534,
		"lat" : 26.023496000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 925,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30261845778661,
		  26.056291759764864
		]
	  },
	  "properties" : {
		"FID" : 925,
		"name" : "福州万寿尚书庙(陈文龙故邸)",
		"lng" : 119.307435,
		"lat" : 26.053222000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 926,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33343000999102,
		  26.041207912685397
		]
	  },
	  "properties" : {
		"FID" : 926,
		"name" : "高湖南天主宰王爷庙",
		"lng" : 119.33830399999999,
		"lat" : 26.038205999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 927,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31223905943862,
		  26.051015768211606
		]
	  },
	  "properties" : {
		"FID" : 927,
		"name" : "梅岭观海小广场",
		"lng" : 119.31707299999999,
		"lat" : 26.047967
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 928,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33276138261677,
		  26.039728166306698
		]
	  },
	  "properties" : {
		"FID" : 928,
		"name" : "高湖郑氏祠堂",
		"lng" : 119.33763399999999,
		"lat" : 26.036726000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 929,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32141843505431,
		  26.023545792737046
		]
	  },
	  "properties" : {
		"FID" : 929,
		"name" : "闽王纪念堂",
		"lng" : 119.326268,
		"lat" : 26.020533
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 930,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32029886290763,
		  26.033419629818983
		]
	  },
	  "properties" : {
		"FID" : 930,
		"name" : "鳌头巷尾观音亭",
		"lng" : 119.325147,
		"lat" : 26.030398000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 931,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30450751723784,
		  26.050198328999382
		]
	  },
	  "properties" : {
		"FID" : 931,
		"name" : "苍霞公园",
		"lng" : 119.309327,
		"lat" : 26.047135999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 932,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30300977624233,
		  26.056051913082655
		]
	  },
	  "properties" : {
		"FID" : 932,
		"name" : "三捷河广场",
		"lng" : 119.307827,
		"lat" : 26.052983000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 933,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31441742275081,
		  26.05730891734483
		]
	  },
	  "properties" : {
		"FID" : 933,
		"name" : "基督徒古街聚会处",
		"lng" : 119.319256,
		"lat" : 26.054259999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 934,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30419236408693,
		  26.059817356225608
		]
	  },
	  "properties" : {
		"FID" : 934,
		"name" : "华兴广场",
		"lng" : 119.309012,
		"lat" : 26.056747999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 935,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32087196495246,
		  26.030579610112589
		]
	  },
	  "properties" : {
		"FID" : 935,
		"name" : "绿野寺",
		"lng" : 119.325721,
		"lat" : 26.027560999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 936,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33843750226734,
		  26.044254711246371
		]
	  },
	  "properties" : {
		"FID" : 936,
		"name" : "江锦泰山青府",
		"lng" : 119.343321,
		"lat" : 26.041260000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 937,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30193492607782,
		  26.052938696285203
		]
	  },
	  "properties" : {
		"FID" : 937,
		"name" : "黄培松故居",
		"lng" : 119.30674999999999,
		"lat" : 26.049869999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 938,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30226825014478,
		  26.04075790003257
		]
	  },
	  "properties" : {
		"FID" : 938,
		"name" : "人口文化广场",
		"lng" : 119.30708300000001,
		"lat" : 26.037697999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 939,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31294075294284,
		  26.050614186341498
		]
	  },
	  "properties" : {
		"FID" : 939,
		"name" : "花生里广场",
		"lng" : 119.31777599999999,
		"lat" : 26.047567000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 940,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29621747418612,
		  26.043556020518881
		]
	  },
	  "properties" : {
		"FID" : 940,
		"name" : "仓山区教育公园",
		"lng" : 119.301022,
		"lat" : 26.040483999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 941,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33303709068907,
		  26.063113393000108
		]
	  },
	  "properties" : {
		"FID" : 941,
		"name" : "台江体育公园",
		"lng" : 119.337912,
		"lat" : 26.060096000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 942,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33040600197205,
		  26.064214090139256
		]
	  },
	  "properties" : {
		"FID" : 942,
		"name" : "光明港公园",
		"lng" : 119.33527599999999,
		"lat" : 26.061191000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 943,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33724699322792,
		  26.053294982169106
		]
	  },
	  "properties" : {
		"FID" : 943,
		"name" : "坑涧幽谷",
		"lng" : 119.342129,
		"lat" : 26.050291999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 944,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29424219056008,
		  26.050640987192757
		]
	  },
	  "properties" : {
		"FID" : 944,
		"name" : "观音阁(帮洲里)",
		"lng" : 119.29904399999999,
		"lat" : 26.047561000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 945,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33034455357075,
		  26.018838560350055
		]
	  },
	  "properties" : {
		"FID" : 945,
		"name" : "郭梦良故居",
		"lng" : 119.335211,
		"lat" : 26.015846
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 946,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2993217201265,
		  26.050026219000031
		]
	  },
	  "properties" : {
		"FID" : 946,
		"name" : "白龙庵",
		"lng" : 119.304132,
		"lat" : 26.046955000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 947,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3137855681519,
		  26.031652788537748
		]
	  },
	  "properties" : {
		"FID" : 947,
		"name" : "万升基督教聚会点",
		"lng" : 119.31862099999999,
		"lat" : 26.02862
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 948,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33356898667672,
		  26.038063526466594
		]
	  },
	  "properties" : {
		"FID" : 948,
		"name" : "玉封镇守南天门陈氏九位仙公",
		"lng" : 119.338443,
		"lat" : 26.035063999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 949,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29941049705153,
		  26.037646709573007
		]
	  },
	  "properties" : {
		"FID" : 949,
		"name" : "长兴禅寺",
		"lng" : 119.30422,
		"lat" : 26.034583999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 950,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30374548864664,
		  26.029009352775873
		]
	  },
	  "properties" : {
		"FID" : 950,
		"name" : "张氏宗祠",
		"lng" : 119.30856199999999,
		"lat" : 26.025960000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 951,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34423902727747,
		  26.046798083028914
		]
	  },
	  "properties" : {
		"FID" : 951,
		"name" : "花田荷塘区",
		"lng" : 119.34913299999999,
		"lat" : 26.043811999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 952,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30137685241476,
		  26.053746206914951
		]
	  },
	  "properties" : {
		"FID" : 952,
		"name" : "法师亭",
		"lng" : 119.306191,
		"lat" : 26.050675999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 953,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32680893265872,
		  26.06394775334136
		]
	  },
	  "properties" : {
		"FID" : 953,
		"name" : "光明港公园(西区)-光明阁",
		"lng" : 119.331672,
		"lat" : 26.060918000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 954,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30500118426728,
		  26.029409395229667
		]
	  },
	  "properties" : {
		"FID" : 954,
		"name" : "大王庙",
		"lng" : 119.30982,
		"lat" : 26.026361999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 955,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31771928688974,
		  26.067531518634478
		]
	  },
	  "properties" : {
		"FID" : 955,
		"name" : "老象园集市",
		"lng" : 119.322565,
		"lat" : 26.064482000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 956,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34782858346708,
		  26.038920630319641
		]
	  },
	  "properties" : {
		"FID" : 956,
		"name" : "福慧寺",
		"lng" : 119.352728,
		"lat" : 26.035945999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 957,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29992819342093,
		  26.056354447252509
		]
	  },
	  "properties" : {
		"FID" : 957,
		"name" : "社区故事馆",
		"lng" : 119.30474,
		"lat" : 26.053280000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 958,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31059944476318,
		  26.020772347140866
		]
	  },
	  "properties" : {
		"FID" : 958,
		"name" : "泰山府",
		"lng" : 119.315428,
		"lat" : 26.017741000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 959,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32698767553337,
		  26.062785633647593
		]
	  },
	  "properties" : {
		"FID" : 959,
		"name" : "天仙府海潮寺",
		"lng" : 119.331851,
		"lat" : 26.059757000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 960,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32704345185735,
		  26.024655789696748
		]
	  },
	  "properties" : {
		"FID" : 960,
		"name" : "李钟广故居",
		"lng" : 119.33190399999999,
		"lat" : 26.021653000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 961,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33833734789344,
		  26.0486948890664
		]
	  },
	  "properties" : {
		"FID" : 961,
		"name" : "环卫新兵",
		"lng" : 119.343221,
		"lat" : 26.045697000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 962,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31324836475491,
		  26.034709867525226
		]
	  },
	  "properties" : {
		"FID" : 962,
		"name" : "云山江氏宗祠",
		"lng" : 119.318083,
		"lat" : 26.031673999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 963,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29485195288481,
		  26.053889198363585
		]
	  },
	  "properties" : {
		"FID" : 963,
		"name" : "古迹圣王亭玉封齐天府",
		"lng" : 119.299655,
		"lat" : 26.050808
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 964,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33991548574103,
		  26.061964947669399
		]
	  },
	  "properties" : {
		"FID" : 964,
		"name" : "鳌峰洲广应白马王庙",
		"lng" : 119.344803,
		"lat" : 26.058961
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 965,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33934255802376,
		  26.048256766909422
		]
	  },
	  "properties" : {
		"FID" : 965,
		"name" : "守望相助",
		"lng" : 119.344228,
		"lat" : 26.045261
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 966,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33576044532263,
		  26.043961432187871
		]
	  },
	  "properties" : {
		"FID" : 966,
		"name" : "锦江境雁头六仙师庙",
		"lng" : 119.340639,
		"lat" : 26.040962
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 967,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33439333686239,
		  26.039426908633281
		]
	  },
	  "properties" : {
		"FID" : 967,
		"name" : "永春亭",
		"lng" : 119.339269,
		"lat" : 26.036428000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 968,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31136769777791,
		  26.064490440477226
		]
	  },
	  "properties" : {
		"FID" : 968,
		"name" : "路通桥",
		"lng" : 119.31620100000001,
		"lat" : 26.061430999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 969,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33167588919594,
		  26.020554210353126
		]
	  },
	  "properties" : {
		"FID" : 969,
		"name" : "圣王宫",
		"lng" : 119.336545,
		"lat" : 26.017562999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 970,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28873264526905,
		  26.052349575201099
		]
	  },
	  "properties" : {
		"FID" : 970,
		"name" : "闽江公园北园-闽风园",
		"lng" : 119.293526,
		"lat" : 26.04926
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 971,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29559955146054,
		  26.056177530536996
		]
	  },
	  "properties" : {
		"FID" : 971,
		"name" : "复初古迹",
		"lng" : 119.300404,
		"lat" : 26.053096
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 972,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30481692043719,
		  26.050663091583925
		]
	  },
	  "properties" : {
		"FID" : 972,
		"name" : "苍霞公园-严复塑像",
		"lng" : 119.309637,
		"lat" : 26.047601
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 973,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33460015636123,
		  26.036702680349684
		]
	  },
	  "properties" : {
		"FID" : 973,
		"name" : "祠支氏郑湖南",
		"lng" : 119.339476,
		"lat" : 26.033705999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 974,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30120231936247,
		  26.03832710514607
		]
	  },
	  "properties" : {
		"FID" : 974,
		"name" : "长安山公园",
		"lng" : 119.306015,
		"lat" : 26.035267000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 975,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30543181640218,
		  26.037154872848877
		]
	  },
	  "properties" : {
		"FID" : 975,
		"name" : "放飞梦想",
		"lng" : 119.31025200000001,
		"lat" : 26.034103000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 976,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34069016372075,
		  26.047925114553973
		]
	  },
	  "properties" : {
		"FID" : 976,
		"name" : "升之舞",
		"lng" : 119.345578,
		"lat" : 26.044931999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 977,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29734672005446,
		  26.04169290395664
		]
	  },
	  "properties" : {
		"FID" : 977,
		"name" : "闽王庙",
		"lng" : 119.302153,
		"lat" : 26.038623999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 978,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31132736005208,
		  26.056721303908176
		]
	  },
	  "properties" : {
		"FID" : 978,
		"name" : "三楼大妈广场",
		"lng" : 119.31616,
		"lat" : 26.053667000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 979,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31360026582132,
		  26.066881870720319
		]
	  },
	  "properties" : {
		"FID" : 979,
		"name" : "河口万寿桥",
		"lng" : 119.318438,
		"lat" : 26.063825000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 980,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30066987913635,
		  26.03001339084804
		]
	  },
	  "properties" : {
		"FID" : 980,
		"name" : "吴氏宗祠",
		"lng" : 119.305481,
		"lat" : 26.026958
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 981,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33491554196749,
		  26.037038320482683
		]
	  },
	  "properties" : {
		"FID" : 981,
		"name" : "龙翔亭",
		"lng" : 119.339792,
		"lat" : 26.034041999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 982,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33454126456157,
		  26.036727807064462
		]
	  },
	  "properties" : {
		"FID" : 982,
		"name" : "南湖郑氏支祠",
		"lng" : 119.339417,
		"lat" : 26.033731
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 983,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31349045543936,
		  26.067152257626155
		]
	  },
	  "properties" : {
		"FID" : 983,
		"name" : "万寿总堂",
		"lng" : 119.31832799999999,
		"lat" : 26.064094999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 984,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30287318593656,
		  26.040561710064331
		]
	  },
	  "properties" : {
		"FID" : 984,
		"name" : "疯象乐园(仓山区315店)",
		"lng" : 119.307689,
		"lat" : 26.037503000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 985,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30802638983941,
		  26.058972893437229
		]
	  },
	  "properties" : {
		"FID" : 985,
		"name" : "屏山镇海楼三位仙姑同心堂大殿",
		"lng" : 119.312853,
		"lat" : 26.055910999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 986,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29987522393485,
		  26.04387112740304
		]
	  },
	  "properties" : {
		"FID" : 986,
		"name" : "五显殿华光大帝",
		"lng" : 119.304686,
		"lat" : 26.040804999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 987,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31411241440395,
		  26.025388925538085
		]
	  },
	  "properties" : {
		"FID" : 987,
		"name" : "金陵陈氏宗祠",
		"lng" : 119.31894800000001,
		"lat" : 26.022361
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 988,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33102116156354,
		  26.020188197588435
		]
	  },
	  "properties" : {
		"FID" : 988,
		"name" : "郭宅村玉湖郭氏祠堂",
		"lng" : 119.33588899999999,
		"lat" : 26.017195999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 989,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3047650215447,
		  26.050573123416914
		]
	  },
	  "properties" : {
		"FID" : 989,
		"name" : "苍霞宝鼎境庙",
		"lng" : 119.309585,
		"lat" : 26.047511
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 990,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31382572846888,
		  26.055031499591568
		]
	  },
	  "properties" : {
		"FID" : 990,
		"name" : "福州市防洪堤纪念碑",
		"lng" : 119.318663,
		"lat" : 26.051983
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 991,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3248797058544,
		  26.023727293497153
		]
	  },
	  "properties" : {
		"FID" : 991,
		"name" : "文昌宫",
		"lng" : 119.329736,
		"lat" : 26.020721000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 992,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32553794797266,
		  26.069792090297732
		]
	  },
	  "properties" : {
		"FID" : 992,
		"name" : "王庄南湖公园",
		"lng" : 119.330399,
		"lat" : 26.066756000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 993,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30917136059584,
		  26.030985911881888
		]
	  },
	  "properties" : {
		"FID" : 993,
		"name" : "福建警察学院后花园",
		"lng" : 119.313998,
		"lat" : 26.027944999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 994,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3040351007437,
		  26.053807596743891
		]
	  },
	  "properties" : {
		"FID" : 994,
		"name" : "南方日报社",
		"lng" : 119.308854,
		"lat" : 26.050742
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 995,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30332870998402,
		  26.049330829069515
		]
	  },
	  "properties" : {
		"FID" : 995,
		"name" : "清泉庵诸神宫",
		"lng" : 119.30814599999999,
		"lat" : 26.046267
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 996,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31169643754029,
		  26.059674600778202
		]
	  },
	  "properties" : {
		"FID" : 996,
		"name" : "玉封圣王府",
		"lng" : 119.31653,
		"lat" : 26.056619000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 997,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30355733882037,
		  26.035507087899294
		]
	  },
	  "properties" : {
		"FID" : 997,
		"name" : "仙湖祖境",
		"lng" : 119.308374,
		"lat" : 26.032453
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 998,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34037072929848,
		  26.047994735012118
		]
	  },
	  "properties" : {
		"FID" : 998,
		"name" : "新美人鱼",
		"lng" : 119.345258,
		"lat" : 26.045000999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 999,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32103217298595,
		  26.023703638477539
		]
	  },
	  "properties" : {
		"FID" : 999,
		"name" : "友月亭",
		"lng" : 119.325881,
		"lat" : 26.020689999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1000,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32364420642428,
		  26.0223327102116
		]
	  },
	  "properties" : {
		"FID" : 1000,
		"name" : "金秋亭",
		"lng" : 119.328498,
		"lat" : 26.019324999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1001,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30270130837717,
		  26.056311628185707
		]
	  },
	  "properties" : {
		"FID" : 1001,
		"name" : "万寿尚书祖庙",
		"lng" : 119.307518,
		"lat" : 26.053242000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1002,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30826475981189,
		  26.061445117245526
		]
	  },
	  "properties" : {
		"FID" : 1002,
		"name" : "署督裴真人紫霞府",
		"lng" : 119.313092,
		"lat" : 26.058382000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1003,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32483180484471,
		  26.023645329460244
		]
	  },
	  "properties" : {
		"FID" : 1003,
		"name" : "慈济寺",
		"lng" : 119.329688,
		"lat" : 26.020638999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1004,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30308715223791,
		  26.049212173707186
		]
	  },
	  "properties" : {
		"FID" : 1004,
		"name" : "封玉齐天府",
		"lng" : 119.30790399999999,
		"lat" : 26.046147999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1005,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31484480068752,
		  26.067930230164304
		]
	  },
	  "properties" : {
		"FID" : 1005,
		"name" : "打铁港公园",
		"lng" : 119.31968500000001,
		"lat" : 26.064875000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1006,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31018135716356,
		  26.01912099778302
		]
	  },
	  "properties" : {
		"FID" : 1006,
		"name" : "佛仙寺",
		"lng" : 119.315009,
		"lat" : 26.016089999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1007,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33007868925525,
		  26.023759407225764
		]
	  },
	  "properties" : {
		"FID" : 1007,
		"name" : "仓山区尤宅",
		"lng" : 119.334945,
		"lat" : 26.020762999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1008,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50293251706758,
		  25.810936162705829
		]
	  },
	  "properties" : {
		"FID" : 1008,
		"name" : "南溪玄天上帝庙",
		"lng" : 119.507588,
		"lat" : 25.807953000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1009,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53805183019762,
		  25.834559124901983
		]
	  },
	  "properties" : {
		"FID" : 1009,
		"name" : "五百罗汉群",
		"lng" : 119.54258799999999,
		"lat" : 25.831465999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1010,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53549877222498,
		  25.838342598744749
		]
	  },
	  "properties" : {
		"FID" : 1010,
		"name" : "当阳寺",
		"lng" : 119.540043,
		"lat" : 25.835253000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1011,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53801564308981,
		  25.835641732079186
		]
	  },
	  "properties" : {
		"FID" : 1011,
		"name" : "复兴门",
		"lng" : 119.542552,
		"lat" : 25.832547999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1012,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54627763209091,
		  25.830874468170201
		]
	  },
	  "properties" : {
		"FID" : 1012,
		"name" : "炳年公园",
		"lng" : 119.55079000000001,
		"lat" : 25.827766
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1013,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53667455385295,
		  25.835991858603407
		]
	  },
	  "properties" : {
		"FID" : 1013,
		"name" : "主兰公园",
		"lng" : 119.54121499999999,
		"lat" : 25.832901
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1014,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53907281163885,
		  25.835537066377785
		]
	  },
	  "properties" : {
		"FID" : 1014,
		"name" : "欢喜佛",
		"lng" : 119.543606,
		"lat" : 25.832440999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1015,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53924229624174,
		  25.835794612187001
		]
	  },
	  "properties" : {
		"FID" : 1015,
		"name" : "朝元观三台庵",
		"lng" : 119.543775,
		"lat" : 25.832698000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1016,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53919591842033,
		  25.839117630113986
		]
	  },
	  "properties" : {
		"FID" : 1016,
		"name" : "信发亭",
		"lng" : 119.543729,
		"lat" : 25.836019
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1017,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53776973157396,
		  25.838003676088292
		]
	  },
	  "properties" : {
		"FID" : 1017,
		"name" : "钓鳌亭",
		"lng" : 119.54230699999999,
		"lat" : 25.834909
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1018,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53944178773374,
		  25.837171939011991
		]
	  },
	  "properties" : {
		"FID" : 1018,
		"name" : "紫阳阁",
		"lng" : 119.54397400000001,
		"lat" : 25.834074000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1019,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54040741561954,
		  25.840126978165266
		]
	  },
	  "properties" : {
		"FID" : 1019,
		"name" : "潘氏宗祠",
		"lng" : 119.544937,
		"lat" : 25.837025000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1020,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51430455109072,
		  25.847892849572229
		]
	  },
	  "properties" : {
		"FID" : 1020,
		"name" : "竹田岩",
		"lng" : 119.51892100000001,
		"lat" : 25.844853000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1021,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54125589490914,
		  25.839994757181994
		]
	  },
	  "properties" : {
		"FID" : 1021,
		"name" : "御史府第",
		"lng" : 119.545783,
		"lat" : 25.836891000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1022,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54085755899004,
		  25.842480478020587
		]
	  },
	  "properties" : {
		"FID" : 1022,
		"name" : "玄壇亭",
		"lng" : 119.54538599999999,
		"lat" : 25.839376000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1023,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49933449542938,
		  25.791950718508534
		]
	  },
	  "properties" : {
		"FID" : 1023,
		"name" : "大姆山草场",
		"lng" : 119.504002,
		"lat" : 25.788989999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1024,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54101517328232,
		  25.840320439376722
		]
	  },
	  "properties" : {
		"FID" : 1024,
		"name" : "观音佛",
		"lng" : 119.545543,
		"lat" : 25.837216999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1025,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55645771921397,
		  25.822577701801066
		]
	  },
	  "properties" : {
		"FID" : 1025,
		"name" : "江田镇石门村法源寺",
		"lng" : 119.56094400000001,
		"lat" : 25.819455999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1026,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54224467843984,
		  25.840855449632393
		]
	  },
	  "properties" : {
		"FID" : 1026,
		"name" : "通天府",
		"lng" : 119.546769,
		"lat" : 25.837748999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1027,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54338705703391,
		  25.838985685379704
		]
	  },
	  "properties" : {
		"FID" : 1027,
		"name" : "溪山村营田陈氏宗祠",
		"lng" : 119.54790800000001,
		"lat" : 25.835878000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1028,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54392209237608,
		  25.845456959120582
		]
	  },
	  "properties" : {
		"FID" : 1028,
		"name" : "基督教三溪堂",
		"lng" : 119.54844199999999,
		"lat" : 25.842344000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1029,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50508870586648,
		  25.849448998543537
		]
	  },
	  "properties" : {
		"FID" : 1029,
		"name" : "仙山陈氏宗祠",
		"lng" : 119.509739,
		"lat" : 25.846435
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1030,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5137976382515,
		  25.849065156597874
		]
	  },
	  "properties" : {
		"FID" : 1030,
		"name" : "西兴寺",
		"lng" : 119.518416,
		"lat" : 25.846025999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1031,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54336796398613,
		  25.839528992623116
		]
	  },
	  "properties" : {
		"FID" : 1031,
		"name" : "溪山村营田陈氏志响祖厅",
		"lng" : 119.547889,
		"lat" : 25.836421000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1032,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55623821540834,
		  25.822577345901571
		]
	  },
	  "properties" : {
		"FID" : 1032,
		"name" : "地藏殿",
		"lng" : 119.56072500000001,
		"lat" : 25.819455999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1033,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5217735051895,
		  25.854066677706776
		]
	  },
	  "properties" : {
		"FID" : 1033,
		"name" : "南阳陈氏宗祠",
		"lng" : 119.526364,
		"lat" : 25.851002000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1034,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4822860707223,
		  25.821855389363645
		]
	  },
	  "properties" : {
		"FID" : 1034,
		"name" : "保谷禅寺",
		"lng" : 119.487019,
		"lat" : 25.818926999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1035,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53058509457924,
		  25.853778552915628
		]
	  },
	  "properties" : {
		"FID" : 1035,
		"name" : "感恩郑氏坊",
		"lng" : 119.535146,
		"lat" : 25.850691000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1036,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51631650656896,
		  25.851415834398505
		]
	  },
	  "properties" : {
		"FID" : 1036,
		"name" : "泰华祖厅",
		"lng" : 119.520926,
		"lat" : 25.848368000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1037,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53039340886058,
		  25.85466364523446
		]
	  },
	  "properties" : {
		"FID" : 1037,
		"name" : "感恩郑氏怡心亭",
		"lng" : 119.534955,
		"lat" : 25.851576000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1038,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53511237647263,
		  25.854905343810234
		]
	  },
	  "properties" : {
		"FID" : 1038,
		"name" : "感恩娘宫裡",
		"lng" : 119.539659,
		"lat" : 25.851806
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1039,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50855505151179,
		  25.855648223659831
		]
	  },
	  "properties" : {
		"FID" : 1039,
		"name" : "玉溪陈氏宗祠",
		"lng" : 119.513193,
		"lat" : 25.852620000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1040,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53487056372028,
		  25.855753317754321
		]
	  },
	  "properties" : {
		"FID" : 1040,
		"name" : "龍福廟",
		"lng" : 119.539418,
		"lat" : 25.852654000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1041,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57006447900693,
		  25.812085237009406
		]
	  },
	  "properties" : {
		"FID" : 1041,
		"name" : "九龙山景区",
		"lng" : 119.574523,
		"lat" : 25.808952000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1042,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50641295988322,
		  25.858305649999874
		]
	  },
	  "properties" : {
		"FID" : 1042,
		"name" : "长乐新峰禅寺",
		"lng" : 119.511059,
		"lat" : 25.855281999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1043,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54683351717001,
		  25.853256928409728
		]
	  },
	  "properties" : {
		"FID" : 1043,
		"name" : "八贤刘氏支祠",
		"lng" : 119.551346,
		"lat" : 25.850133
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1044,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4809184757258,
		  25.857427152930686
		]
	  },
	  "properties" : {
		"FID" : 1044,
		"name" : "罗联乡顶头临水行宫",
		"lng" : 119.485659,
		"lat" : 25.854479999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1045,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5775497460394,
		  25.824579590539656
		]
	  },
	  "properties" : {
		"FID" : 1045,
		"name" : "江田广场",
		"lng" : 119.581998,
		"lat" : 25.821432000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1046,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54813202894603,
		  25.852501989148614
		]
	  },
	  "properties" : {
		"FID" : 1046,
		"name" : "佑民亭",
		"lng" : 119.55264099999999,
		"lat" : 25.849375999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1047,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60516277926459,
		  25.810384194483387
		]
	  },
	  "properties" : {
		"FID" : 1047,
		"name" : "下沙公园",
		"lng" : 119.60959200000001,
		"lat" : 25.807243
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1048,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58131928090455,
		  25.811549757801789
		]
	  },
	  "properties" : {
		"FID" : 1048,
		"name" : "灵峰寺",
		"lng" : 119.585762,
		"lat" : 25.808408
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1049,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5326693184915,
		  25.860196883894638
		]
	  },
	  "properties" : {
		"FID" : 1049,
		"name" : "荣阳郑氏宗祠",
		"lng" : 119.53722399999999,
		"lat" : 25.857099999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1050,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53811630504846,
		  25.858322565207935
		]
	  },
	  "properties" : {
		"FID" : 1050,
		"name" : "普光寺",
		"lng" : 119.542654,
		"lat" : 25.855214
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1051,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53329735015983,
		  25.859628046122278
		]
	  },
	  "properties" : {
		"FID" : 1051,
		"name" : "其孝公祖厅",
		"lng" : 119.53785000000001,
		"lat" : 25.856529999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1052,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.48103994246205,
		  25.857067273585251
		]
	  },
	  "properties" : {
		"FID" : 1052,
		"name" : "临水宫",
		"lng" : 119.48578000000001,
		"lat" : 25.854120000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1053,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53261914897278,
		  25.860334850784771
		]
	  },
	  "properties" : {
		"FID" : 1053,
		"name" : "金雞山",
		"lng" : 119.53717399999999,
		"lat" : 25.857237999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1054,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55826657206421,
		  25.769950359860367
		]
	  },
	  "properties" : {
		"FID" : 1054,
		"name" : "中共福建省委旧址",
		"lng" : 119.56274500000001,
		"lat" : 25.766857999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1055,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57459995776587,
		  25.820530770376848
		]
	  },
	  "properties" : {
		"FID" : 1055,
		"name" : "江田阜房陈伯康纪念堂理事会",
		"lng" : 119.579052,
		"lat" : 25.817388000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1056,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5811628012716,
		  25.815768305644728
		]
	  },
	  "properties" : {
		"FID" : 1056,
		"name" : "江田古杭天雄公功德苑",
		"lng" : 119.585606,
		"lat" : 25.812624
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1057,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56870856893603,
		  25.764695063981492
		]
	  },
	  "properties" : {
		"FID" : 1057,
		"name" : "风洞山风景区",
		"lng" : 119.573166,
		"lat" : 25.761592
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1058,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57468106746848,
		  25.820642908497824
		]
	  },
	  "properties" : {
		"FID" : 1058,
		"name" : "陈伯康纪念堂",
		"lng" : 119.579133,
		"lat" : 25.817499999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1059,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64377709609751,
		  25.918279195036494
		]
	  },
	  "properties" : {
		"FID" : 1059,
		"name" : "显应宫",
		"lng" : 119.648241,
		"lat" : 25.915113000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1060,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53761799981284,
		  25.883231752062233
		]
	  },
	  "properties" : {
		"FID" : 1060,
		"name" : "西亭石氏支祠",
		"lng" : 119.542159,
		"lat" : 25.880108
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1061,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5396238641771,
		  25.885026489116548
		]
	  },
	  "properties" : {
		"FID" : 1061,
		"name" : "河阳石氏宗祠",
		"lng" : 119.54415899999999,
		"lat" : 25.881896999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1062,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54368100407899,
		  25.920305847775733
		]
	  },
	  "properties" : {
		"FID" : 1062,
		"name" : "龙泉禅寺",
		"lng" : 119.548207,
		"lat" : 25.917144
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1063,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45461682027724,
		  25.695024271009569
		]
	  },
	  "properties" : {
		"FID" : 1063,
		"name" : "龙江古石桥",
		"lng" : 119.459433,
		"lat" : 25.692243999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1064,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57274610740102,
		  25.821550785236056
		]
	  },
	  "properties" : {
		"FID" : 1064,
		"name" : "双桂亭",
		"lng" : 119.577201,
		"lat" : 25.818408999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1065,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50788402041181,
		  25.863331252917877
		]
	  },
	  "properties" : {
		"FID" : 1065,
		"name" : "林氏宗祠(感蕉线)",
		"lng" : 119.512525,
		"lat" : 25.860299999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1066,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52719207367862,
		  25.879510717421631
		]
	  },
	  "properties" : {
		"FID" : 1066,
		"name" : "竹林寺",
		"lng" : 119.531766,
		"lat" : 25.876415000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1067,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5358935576494,
		  25.858127282513713
		]
	  },
	  "properties" : {
		"FID" : 1067,
		"name" : "宗头公祖厅",
		"lng" : 119.54043799999999,
		"lat" : 25.855024
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1068,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62645084465065,
		  25.937233929742064
		]
	  },
	  "properties" : {
		"FID" : 1068,
		"name" : "龙角峰寺",
		"lng" : 119.630898,
		"lat" : 25.934028999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1069,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38794822603383,
		  25.741123400332633
		]
	  },
	  "properties" : {
		"FID" : 1069,
		"name" : "玉屏山公园",
		"lng" : 119.392865,
		"lat" : 25.738386999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1070,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53869281601131,
		  25.861305817691445
		]
	  },
	  "properties" : {
		"FID" : 1070,
		"name" : "齐天大圣宫",
		"lng" : 119.543229,
		"lat" : 25.858194000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1071,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53703490800535,
		  25.86008822407608
		]
	  },
	  "properties" : {
		"FID" : 1071,
		"name" : "通天府",
		"lng" : 119.54157600000001,
		"lat" : 25.856981000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1072,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45911113028686,
		  25.712732596022498
		]
	  },
	  "properties" : {
		"FID" : 1072,
		"name" : "弥勒造像",
		"lng" : 119.463915,
		"lat" : 25.709931999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1073,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53685645521624,
		  25.858838997378939
		]
	  },
	  "properties" : {
		"FID" : 1073,
		"name" : "曾承仁住宅",
		"lng" : 119.541398,
		"lat" : 25.855733000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1074,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55616086204459,
		  25.866681547162031
		]
	  },
	  "properties" : {
		"FID" : 1074,
		"name" : "齐天府",
		"lng" : 119.56065099999999,
		"lat" : 25.863531999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1075,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50547198642774,
		  25.86501524086006
		]
	  },
	  "properties" : {
		"FID" : 1075,
		"name" : "长乐云谷寺",
		"lng" : 119.510122,
		"lat" : 25.861989999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1076,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50322510682587,
		  25.940462920339382
		]
	  },
	  "properties" : {
		"FID" : 1076,
		"name" : "长乐鸟语林",
		"lng" : 119.50788900000001,
		"lat" : 25.937394000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1077,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53793063001436,
		  25.85993218695701
		]
	  },
	  "properties" : {
		"FID" : 1077,
		"name" : "昂本公故居",
		"lng" : 119.542469,
		"lat" : 25.856822999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1078,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53808071655368,
		  25.864975817710228
		]
	  },
	  "properties" : {
		"FID" : 1078,
		"name" : "普明寺",
		"lng" : 119.542619,
		"lat" : 25.861863
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1079,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54670199120396,
		  25.855641211253477
		]
	  },
	  "properties" : {
		"FID" : 1079,
		"name" : "仁寿宫",
		"lng" : 119.551215,
		"lat" : 25.852516000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1080,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56933370315035,
		  25.87533203396044
		]
	  },
	  "properties" : {
		"FID" : 1080,
		"name" : "崇化寺",
		"lng" : 119.573798,
		"lat" : 25.872159
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1081,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56835744477799,
		  25.827616153981126
		]
	  },
	  "properties" : {
		"FID" : 1081,
		"name" : "吊隔顶墙",
		"lng" : 119.57281999999999,
		"lat" : 25.824475
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1082,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59803763033106,
		  25.725295556230375
		]
	  },
	  "properties" : {
		"FID" : 1082,
		"name" : "东林寺",
		"lng" : 119.602462,
		"lat" : 25.722201999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1083,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53275658059006,
		  25.860406233711689
		]
	  },
	  "properties" : {
		"FID" : 1083,
		"name" : "高侯爷神庙",
		"lng" : 119.537311,
		"lat" : 25.857309000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1084,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53821853806578,
		  25.859345463521702
		]
	  },
	  "properties" : {
		"FID" : 1084,
		"name" : "三德游氏宗祠",
		"lng" : 119.542756,
		"lat" : 25.856235999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1085,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53813123062774,
		  25.859970670858306
		]
	  },
	  "properties" : {
		"FID" : 1085,
		"name" : "豫章曾氏宗祠",
		"lng" : 119.542669,
		"lat" : 25.856860999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1086,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50989954298349,
		  25.861683075358865
		]
	  },
	  "properties" : {
		"FID" : 1086,
		"name" : "开闽王氏宗祠",
		"lng" : 119.514533,
		"lat" : 25.858647000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1087,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54573055452005,
		  25.908253982036499
		]
	  },
	  "properties" : {
		"FID" : 1087,
		"name" : "万寿庵",
		"lng" : 119.55025000000001,
		"lat" : 25.905096
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1088,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57339028534538,
		  25.818842666676947
		]
	  },
	  "properties" : {
		"FID" : 1088,
		"name" : "先贤祠",
		"lng" : 119.577844,
		"lat" : 25.815702000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1089,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.46886412136016,
		  25.884109569404355
		]
	  },
	  "properties" : {
		"FID" : 1089,
		"name" : "长乐区秀凤将军公园",
		"lng" : 119.47364899999999,
		"lat" : 25.881178999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1090,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53823841305237,
		  25.861897169746793
		]
	  },
	  "properties" : {
		"FID" : 1090,
		"name" : "臨水宫",
		"lng" : 119.542776,
		"lat" : 25.858785999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1091,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54909923205388,
		  25.857059800539229
		]
	  },
	  "properties" : {
		"FID" : 1091,
		"name" : "青云亭",
		"lng" : 119.553606,
		"lat" : 25.853929000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1092,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62023937607736,
		  25.767555244261104
		]
	  },
	  "properties" : {
		"FID" : 1092,
		"name" : "横山立云寺",
		"lng" : 119.62466999999999,
		"lat" : 25.764451999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1093,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52872270987977,
		  25.899248752365136
		]
	  },
	  "properties" : {
		"FID" : 1093,
		"name" : "观音古寺",
		"lng" : 119.533293,
		"lat" : 25.896135999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1094,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5491252973864,
		  25.857092871599015
		]
	  },
	  "properties" : {
		"FID" : 1094,
		"name" : "海云寺",
		"lng" : 119.55363199999999,
		"lat" : 25.853961999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1095,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60860705645699,
		  25.915108286638056
		]
	  },
	  "properties" : {
		"FID" : 1095,
		"name" : "柯尚迁公园",
		"lng" : 119.613044,
		"lat" : 25.911901
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1096,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.48431464229161,
		  25.778967974398576
		]
	  },
	  "properties" : {
		"FID" : 1096,
		"name" : "大觉庵",
		"lng" : 119.489037,
		"lat" : 25.776060000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1097,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51930992221787,
		  25.949911795314943
		]
	  },
	  "properties" : {
		"FID" : 1097,
		"name" : "南山公园",
		"lng" : 119.523916,
		"lat" : 25.94679
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1098,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.556688640351,
		  25.858792258226075
		]
	  },
	  "properties" : {
		"FID" : 1098,
		"name" : "林氏西房祖厅",
		"lng" : 119.561177,
		"lat" : 25.855647000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1099,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53852230262629,
		  25.861358465071241
		]
	  },
	  "properties" : {
		"FID" : 1099,
		"name" : "地藏殿",
		"lng" : 119.543059,
		"lat" : 25.858246999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1100,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5411886341094,
		  25.882396208813763
		]
	  },
	  "properties" : {
		"FID" : 1100,
		"name" : "新宁公园",
		"lng" : 119.54571900000001,
		"lat" : 25.879265
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1101,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54050696936265,
		  25.89179493832285
		]
	  },
	  "properties" : {
		"FID" : 1101,
		"name" : "董奉山风景区",
		"lng" : 119.54504,
		"lat" : 25.888659000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1102,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53405332417672,
		  25.879024579267789
		]
	  },
	  "properties" : {
		"FID" : 1102,
		"name" : "高楼陈氏宗祠",
		"lng" : 119.538605,
		"lat" : 25.875912
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1103,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54021006796162,
		  25.892235574328399
		]
	  },
	  "properties" : {
		"FID" : 1103,
		"name" : "董奉草堂",
		"lng" : 119.54474399999999,
		"lat" : 25.889099999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1104,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54050696936265,
		  25.89179493832285
		]
	  },
	  "properties" : {
		"FID" : 1104,
		"name" : "董奉山风景区",
		"lng" : 119.54504,
		"lat" : 25.888659000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1105,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53405332417672,
		  25.879024579267789
		]
	  },
	  "properties" : {
		"FID" : 1105,
		"name" : "高楼陈氏宗祠",
		"lng" : 119.538605,
		"lat" : 25.875912
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1106,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52872270987977,
		  25.899248752365136
		]
	  },
	  "properties" : {
		"FID" : 1106,
		"name" : "观音古寺",
		"lng" : 119.533293,
		"lat" : 25.896135999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1107,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54021006796162,
		  25.892235574328399
		]
	  },
	  "properties" : {
		"FID" : 1107,
		"name" : "董奉草堂",
		"lng" : 119.54474399999999,
		"lat" : 25.889099999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1108,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6259871395316,
		  25.938259208420476
		]
	  },
	  "properties" : {
		"FID" : 1108,
		"name" : "龙角峰公园",
		"lng" : 119.63043399999999,
		"lat" : 25.935053
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1109,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55901676069196,
		  25.859787534412931
		]
	  },
	  "properties" : {
		"FID" : 1109,
		"name" : "金沙寺",
		"lng" : 119.5635,
		"lat" : 25.856638
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1110,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5411886341094,
		  25.882396208813763
		]
	  },
	  "properties" : {
		"FID" : 1110,
		"name" : "新宁公园",
		"lng" : 119.54571900000001,
		"lat" : 25.879265
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1111,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4125897778562,
		  25.767885185318832
		]
	  },
	  "properties" : {
		"FID" : 1111,
		"name" : "激情广场",
		"lng" : 119.41749799999999,
		"lat" : 25.765129999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1112,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4564695600785,
		  25.920329890979769
		]
	  },
	  "properties" : {
		"FID" : 1112,
		"name" : "康山寺紫清宫",
		"lng" : 119.461297,
		"lat" : 25.917407000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1113,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.48096365538028,
		  25.857211144428494
		]
	  },
	  "properties" : {
		"FID" : 1113,
		"name" : "临水亭",
		"lng" : 119.485704,
		"lat" : 25.854264000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1114,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5826475437093,
		  25.8142661212052
		]
	  },
	  "properties" : {
		"FID" : 1114,
		"name" : "怀德亭",
		"lng" : 119.58708900000001,
		"lat" : 25.811122000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1115,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38817644901542,
		  25.724370906872259
		]
	  },
	  "properties" : {
		"FID" : 1115,
		"name" : "龙山寺",
		"lng" : 119.393092,
		"lat" : 25.721644000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1116,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53049130884297,
		  25.722241858619746
		]
	  },
	  "properties" : {
		"FID" : 1116,
		"name" : "魁岩生态公园",
		"lng" : 119.535043,
		"lat" : 25.719234
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1117,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53348370864218,
		  25.876592600434229
		]
	  },
	  "properties" : {
		"FID" : 1117,
		"name" : "万鼎公园",
		"lng" : 119.538037,
		"lat" : 25.873483
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1118,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53604230480522,
		  25.867936028114599
		]
	  },
	  "properties" : {
		"FID" : 1118,
		"name" : "玉沙閣",
		"lng" : 119.540587,
		"lat" : 25.864826000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1119,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5824403335111,
		  25.814104921286489
		]
	  },
	  "properties" : {
		"FID" : 1119,
		"name" : "观音阁",
		"lng" : 119.586882,
		"lat" : 25.810960999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1120,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45842610101997,
		  25.83248893021057
		]
	  },
	  "properties" : {
		"FID" : 1120,
		"name" : "长乐罗联东林双涧禅寺",
		"lng" : 119.463241,
		"lat" : 25.829619000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1121,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4120031459769,
		  25.794733943094862
		]
	  },
	  "properties" : {
		"FID" : 1121,
		"name" : "德胜公园",
		"lng" : 119.41691400000001,
		"lat" : 25.791962999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1122,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54305833072011,
		  25.905348495232378
		]
	  },
	  "properties" : {
		"FID" : 1122,
		"name" : "百福公园",
		"lng" : 119.547585,
		"lat" : 25.902197999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1123,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.48840809264094,
		  25.760362100786459
		]
	  },
	  "properties" : {
		"FID" : 1123,
		"name" : "风动石公园",
		"lng" : 119.49311400000001,
		"lat" : 25.757453000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1124,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.46098743243533,
		  25.908657208768155
		]
	  },
	  "properties" : {
		"FID" : 1124,
		"name" : "长乐琅峰泗洲文佛寺(雪峰下院)",
		"lng" : 119.4658,
		"lat" : 25.905730999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1125,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45572455241069,
		  25.943880030608494
		]
	  },
	  "properties" : {
		"FID" : 1125,
		"name" : "广明禅寺",
		"lng" : 119.460556,
		"lat" : 25.940943000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1126,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39008657330361,
		  25.918018028960816
		]
	  },
	  "properties" : {
		"FID" : 1126,
		"name" : "临水宫",
		"lng" : 119.395017,
		"lat" : 25.915171000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1127,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49816641584623,
		  25.937859038242234
		]
	  },
	  "properties" : {
		"FID" : 1127,
		"name" : "廉园",
		"lng" : 119.502849,
		"lat" : 25.934806999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1128,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60639839349656,
		  25.92697659609961
		]
	  },
	  "properties" : {
		"FID" : 1128,
		"name" : "真武庙",
		"lng" : 119.61083600000001,
		"lat" : 25.923760000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1129,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53125149979446,
		  25.905411247396387
		]
	  },
	  "properties" : {
		"FID" : 1129,
		"name" : "贡果公园",
		"lng" : 119.535814,
		"lat" : 25.902287999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1130,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40285318860163,
		  25.698314647573618
		]
	  },
	  "properties" : {
		"FID" : 1130,
		"name" : "天主堂",
		"lng" : 119.407764,
		"lat" : 25.695602999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1131,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65036103252284,
		  25.938364238196634
		]
	  },
	  "properties" : {
		"FID" : 1131,
		"name" : "长乐鹏谢村仙景山玄帝庙",
		"lng" : 119.65483500000001,
		"lat" : 25.935196000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1132,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38854057683844,
		  25.708626164838222
		]
	  },
	  "properties" : {
		"FID" : 1132,
		"name" : "东湖境五显庙",
		"lng" : 119.393455,
		"lat" : 25.705908000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1133,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.42871563886436,
		  25.89648240337015
		]
	  },
	  "properties" : {
		"FID" : 1133,
		"name" : "宝林寺",
		"lng" : 119.43361,
		"lat" : 25.893629000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1134,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57433873985542,
		  25.929580035318729
		]
	  },
	  "properties" : {
		"FID" : 1134,
		"name" : "关爱女孩公园",
		"lng" : 119.578799,
		"lat" : 25.926366000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1135,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5564200157542,
		  25.85893491797184
		]
	  },
	  "properties" : {
		"FID" : 1135,
		"name" : "仙桥游氏支祠",
		"lng" : 119.560909,
		"lat" : 25.855789999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1136,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.42369458894586,
		  25.728035608221735
		]
	  },
	  "properties" : {
		"FID" : 1136,
		"name" : "真人庙",
		"lng" : 119.428585,
		"lat" : 25.725293000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1137,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53623494057177,
		  25.881128151140299
		]
	  },
	  "properties" : {
		"FID" : 1137,
		"name" : "新宅林氏宗祠",
		"lng" : 119.54078,
		"lat" : 25.878008999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1138,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.46806457045736,
		  25.855206463950207
		]
	  },
	  "properties" : {
		"FID" : 1138,
		"name" : "罗联基督教崇尚堂",
		"lng" : 119.47284999999999,
		"lat" : 25.852297
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1139,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59182766947204,
		  25.795049717462078
		]
	  },
	  "properties" : {
		"FID" : 1139,
		"name" : "华光寺",
		"lng" : 119.59626,
		"lat" : 25.791914999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1140,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64236152969555,
		  25.908829231501983
		]
	  },
	  "properties" : {
		"FID" : 1140,
		"name" : "海岸长城",
		"lng" : 119.646823,
		"lat" : 25.905667000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1141,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45912154326138,
		  25.748004341699037
		]
	  },
	  "properties" : {
		"FID" : 1141,
		"name" : "瑞岩塔",
		"lng" : 119.463928,
		"lat" : 25.745183999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1142,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61610470552385,
		  25.945643019471532
		]
	  },
	  "properties" : {
		"FID" : 1142,
		"name" : "文京寺",
		"lng" : 119.620546,
		"lat" : 25.942421
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1143,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.46103582165446,
		  25.690413548922102
		]
	  },
	  "properties" : {
		"FID" : 1143,
		"name" : "海口基督堂",
		"lng" : 119.46583200000001,
		"lat" : 25.687619999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1144,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4494934991375,
		  25.877960603253872
		]
	  },
	  "properties" : {
		"FID" : 1144,
		"name" : "中共长乐第一支部旧址",
		"lng" : 119.45433800000001,
		"lat" : 25.875081999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1145,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47756749054838,
		  25.937411676426308
		]
	  },
	  "properties" : {
		"FID" : 1145,
		"name" : "富阳文化广场",
		"lng" : 119.482326,
		"lat" : 25.934421
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1146,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54992149212816,
		  25.952048728918321
		]
	  },
	  "properties" : {
		"FID" : 1146,
		"name" : "义姑祠",
		"lng" : 119.554433,
		"lat" : 25.948853
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1147,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45919752526983,
		  25.711027886519318
		]
	  },
	  "properties" : {
		"FID" : 1147,
		"name" : "福清市瑞岩山景区",
		"lng" : 119.464001,
		"lat" : 25.708227999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1148,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41571286461053,
		  25.800416167880648
		]
	  },
	  "properties" : {
		"FID" : 1148,
		"name" : "德福公园",
		"lng" : 119.42062,
		"lat" : 25.797639
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1149,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58948392689906,
		  25.811082332545642
		]
	  },
	  "properties" : {
		"FID" : 1149,
		"name" : "佛妈祖亭",
		"lng" : 119.593919,
		"lat" : 25.807938
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1150,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47012286874262,
		  25.931623821948524
		]
	  },
	  "properties" : {
		"FID" : 1150,
		"name" : "九龙林氏支祠",
		"lng" : 119.474907,
		"lat" : 25.928657999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1151,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5633856371649,
		  25.86276967800972
		]
	  },
	  "properties" : {
		"FID" : 1151,
		"name" : "方济沙威堂",
		"lng" : 119.56786,
		"lat" : 25.859611999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1152,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59257029363842,
		  25.722690592150631
		]
	  },
	  "properties" : {
		"FID" : 1152,
		"name" : "榕岭境大王宫",
		"lng" : 119.596997,
		"lat" : 25.719598000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1153,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49288083372218,
		  25.935453550937794
		]
	  },
	  "properties" : {
		"FID" : 1153,
		"name" : "长乐人民公园",
		"lng" : 119.49758300000001,
		"lat" : 25.932418999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1154,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45896062486963,
		  25.713248503027099
		]
	  },
	  "properties" : {
		"FID" : 1154,
		"name" : "瑞岩寺",
		"lng" : 119.463765,
		"lat" : 25.710448
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1155,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40964939482619,
		  25.761358535187416
		]
	  },
	  "properties" : {
		"FID" : 1155,
		"name" : "洪春松涛园",
		"lng" : 119.41455999999999,
		"lat" : 25.758609
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1156,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53419035963208,
		  25.718505898770648
		]
	  },
	  "properties" : {
		"FID" : 1156,
		"name" : "东亭祠堂",
		"lng" : 119.53873,
		"lat" : 25.715491
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1157,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43882697845997,
		  25.681272195147908
		]
	  },
	  "properties" : {
		"FID" : 1157,
		"name" : "福清市海口镇东埔基督教堂",
		"lng" : 119.443684,
		"lat" : 25.678532000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1158,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59989626301376,
		  25.877654418284404
		]
	  },
	  "properties" : {
		"FID" : 1158,
		"name" : "福州东湖海洋温泉度假村水乐园",
		"lng" : 119.604331,
		"lat" : 25.874468
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1159,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64069811238454,
		  25.914678897676001
		]
	  },
	  "properties" : {
		"FID" : 1159,
		"name" : "天主堂",
		"lng" : 119.645158,
		"lat" : 25.91151
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1160,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59201338499624,
		  25.800632151529953
		]
	  },
	  "properties" : {
		"FID" : 1160,
		"name" : "彦佃公祖厅",
		"lng" : 119.596446,
		"lat" : 25.797494
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1161,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54302592429616,
		  25.882054939573614
		]
	  },
	  "properties" : {
		"FID" : 1161,
		"name" : "法治广场",
		"lng" : 119.547551,
		"lat" : 25.878920000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1162,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55850984572569,
		  25.870963061348895
		]
	  },
	  "properties" : {
		"FID" : 1162,
		"name" : "天仙府",
		"lng" : 119.562995,
		"lat" : 25.867806999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1163,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61339484648776,
		  25.916452675122038
		]
	  },
	  "properties" : {
		"FID" : 1163,
		"name" : "天主堂",
		"lng" : 119.617833,
		"lat" : 25.913247999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1164,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53465711994707,
		  25.880302871352136
		]
	  },
	  "properties" : {
		"FID" : 1164,
		"name" : "高楼江夏黄氏宗祠",
		"lng" : 119.539207,
		"lat" : 25.877188
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1165,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59438888587357,
		  25.798241693321447
		]
	  },
	  "properties" : {
		"FID" : 1165,
		"name" : "朝厚廳",
		"lng" : 119.59882,
		"lat" : 25.795105
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1166,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51076684780271,
		  25.736411900311488
		]
	  },
	  "properties" : {
		"FID" : 1166,
		"name" : "龙卧禅寺",
		"lng" : 119.515388,
		"lat" : 25.733450000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1167,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53127218498408,
		  25.88312147344854
		]
	  },
	  "properties" : {
		"FID" : 1167,
		"name" : "貝石山白馬王",
		"lng" : 119.535833,
		"lat" : 25.880013000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1168,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53765913162957,
		  25.883127777934902
		]
	  },
	  "properties" : {
		"FID" : 1168,
		"name" : "祠支氏石亭西",
		"lng" : 119.54219999999999,
		"lat" : 25.880004
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1169,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53381752523835,
		  25.87982954127083
		]
	  },
	  "properties" : {
		"FID" : 1169,
		"name" : "黄氏文本公祖居",
		"lng" : 119.53837,
		"lat" : 25.876716999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1170,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43692675063947,
		  25.773404026389304
		]
	  },
	  "properties" : {
		"FID" : 1170,
		"name" : "福清市漈头革命历史纪念馆",
		"lng" : 119.441795,
		"lat" : 25.770616
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1171,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59437351217498,
		  25.873094341606528
		]
	  },
	  "properties" : {
		"FID" : 1171,
		"name" : "滨海新城体育公园",
		"lng" : 119.59881,
		"lat" : 25.869910000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1172,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57263587428005,
		  25.864211039931725
		]
	  },
	  "properties" : {
		"FID" : 1172,
		"name" : "长乐东山观音寺",
		"lng" : 119.577094,
		"lat" : 25.861042000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1173,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59280152247018,
		  25.763361767807435
		]
	  },
	  "properties" : {
		"FID" : 1173,
		"name" : "长乐松下首祉御国宫",
		"lng" : 119.59723099999999,
		"lat" : 25.760245999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1174,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40797221356743,
		  25.704752907280266
		]
	  },
	  "properties" : {
		"FID" : 1174,
		"name" : "周氏祠堂",
		"lng" : 119.41288,
		"lat" : 25.702036
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1175,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57344367241632,
		  25.939787164013897
		]
	  },
	  "properties" : {
		"FID" : 1175,
		"name" : "天主堂",
		"lng" : 119.577906,
		"lat" : 25.936567
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1176,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49547756896476,
		  25.730807357460225
		]
	  },
	  "properties" : {
		"FID" : 1176,
		"name" : "陈氏裳中公祠",
		"lng" : 119.50015500000001,
		"lat" : 25.727893999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1177,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43497072182348,
		  25.729757516600923
		]
	  },
	  "properties" : {
		"FID" : 1177,
		"name" : "英武宫",
		"lng" : 119.43984,
		"lat" : 25.726997999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1178,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47040468160733,
		  25.704476777351008
		]
	  },
	  "properties" : {
		"FID" : 1178,
		"name" : "海岳锺灵",
		"lng" : 119.475171,
		"lat" : 25.701650999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1179,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52966157513782,
		  25.943443895720481
		]
	  },
	  "properties" : {
		"FID" : 1179,
		"name" : "卢江公园",
		"lng" : 119.534232,
		"lat" : 25.940299
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1180,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55173084337112,
		  25.927526439781804
		]
	  },
	  "properties" : {
		"FID" : 1180,
		"name" : "鹤上湖尾宋塔",
		"lng" : 119.556236,
		"lat" : 25.924344000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1181,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58479285657552,
		  25.909864173004923
		]
	  },
	  "properties" : {
		"FID" : 1181,
		"name" : "壶井天主教堂",
		"lng" : 119.58923900000001,
		"lat" : 25.906656999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1182,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.46349499780516,
		  25.9150759475413
		]
	  },
	  "properties" : {
		"FID" : 1182,
		"name" : "炳英公园",
		"lng" : 119.4683,
		"lat" : 25.912139
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1183,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59747847935597,
		  25.766668338258391
		]
	  },
	  "properties" : {
		"FID" : 1183,
		"name" : "必举公祖厅",
		"lng" : 119.601906,
		"lat" : 25.763551
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1184,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59852783032876,
		  25.766692138285674
		]
	  },
	  "properties" : {
		"FID" : 1184,
		"name" : "首航公园",
		"lng" : 119.60295499999999,
		"lat" : 25.763574999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1185,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40419302389873,
		  25.724288075713776
		]
	  },
	  "properties" : {
		"FID" : 1185,
		"name" : "龙溪境",
		"lng" : 119.409105,
		"lat" : 25.721561999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1186,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54080543418878,
		  25.952592522063963
		]
	  },
	  "properties" : {
		"FID" : 1186,
		"name" : "通天府",
		"lng" : 119.54534200000001,
		"lat" : 25.949414999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1187,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.44674754439322,
		  25.884537069915432
		]
	  },
	  "properties" : {
		"FID" : 1187,
		"name" : "大溪林氏祠堂",
		"lng" : 119.4516,
		"lat" : 25.88166
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1188,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.44656391444526,
		  25.766171143331807
		]
	  },
	  "properties" : {
		"FID" : 1188,
		"name" : "福清妙音寺",
		"lng" : 119.451408,
		"lat" : 25.763369000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1189,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39198274840568,
		  25.729754708828594
		]
	  },
	  "properties" : {
		"FID" : 1189,
		"name" : "龙山公园",
		"lng" : 119.396899,
		"lat" : 25.727025999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1190,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51892235531135,
		  25.95268960891535
		]
	  },
	  "properties" : {
		"FID" : 1190,
		"name" : "南山体育公园",
		"lng" : 119.52352999999999,
		"lat" : 25.949566999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1191,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51538095432245,
		  25.703007812381973
		]
	  },
	  "properties" : {
		"FID" : 1191,
		"name" : "陈氏祠堂",
		"lng" : 119.519983,
		"lat" : 25.700050999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1192,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41958384456211,
		  25.947339752269436
		]
	  },
	  "properties" : {
		"FID" : 1192,
		"name" : "下洋自爱公园",
		"lng" : 119.424497,
		"lat" : 25.944462999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1193,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55216467943538,
		  25.903182864534315
		]
	  },
	  "properties" : {
		"FID" : 1193,
		"name" : "蒋氏祖厅",
		"lng" : 119.556667,
		"lat" : 25.900016000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1194,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58751649866613,
		  25.879226664585794
		]
	  },
	  "properties" : {
		"FID" : 1194,
		"name" : "河谷风洞",
		"lng" : 119.59195800000001,
		"lat" : 25.876038999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1195,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47945070713388,
		  25.728325405709594
		]
	  },
	  "properties" : {
		"FID" : 1195,
		"name" : "龙岩寺",
		"lng" : 119.48418700000001,
		"lat" : 25.725460999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1196,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58863371878786,
		  25.87473996972378
		]
	  },
	  "properties" : {
		"FID" : 1196,
		"name" : "东湖游艇会",
		"lng" : 119.593074,
		"lat" : 25.871555000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1197,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41166292965336,
		  25.700015436651682
		]
	  },
	  "properties" : {
		"FID" : 1197,
		"name" : "钟山寺",
		"lng" : 119.416567,
		"lat" : 25.697299000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1198,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47382226255392,
		  25.694109797175138
		]
	  },
	  "properties" : {
		"FID" : 1198,
		"name" : "九使庙",
		"lng" : 119.478576,
		"lat" : 25.691279999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1199,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58332747514605,
		  25.908751826091297
		]
	  },
	  "properties" : {
		"FID" : 1199,
		"name" : "狮岩寺",
		"lng" : 119.58777499999999,
		"lat" : 25.905546000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1200,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52555539253905,
		  25.923373712872429
		]
	  },
	  "properties" : {
		"FID" : 1200,
		"name" : "环山陈氏祖厅",
		"lng" : 119.53013799999999,
		"lat" : 25.920252999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1201,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62691316285375,
		  25.899874225733054
		]
	  },
	  "properties" : {
		"FID" : 1201,
		"name" : "望海楼沙滩",
		"lng" : 119.63135800000001,
		"lat" : 25.896695000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1202,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47967992381179,
		  25.939423138963281
		]
	  },
	  "properties" : {
		"FID" : 1202,
		"name" : "江南赵氏宗祠",
		"lng" : 119.484431,
		"lat" : 25.936425
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1203,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47722306411488,
		  25.940066486649563
		]
	  },
	  "properties" : {
		"FID" : 1203,
		"name" : "长乐黄氏宗祠",
		"lng" : 119.481983,
		"lat" : 25.937075
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1204,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67698203603776,
		  26.016933542461171
		]
	  },
	  "properties" : {
		"FID" : 1204,
		"name" : "将军山公园",
		"lng" : 119.6815,
		"lat" : 26.013762
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1205,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.70476669715414,
		  25.970138034976113
		]
	  },
	  "properties" : {
		"FID" : 1205,
		"name" : "大王宫",
		"lng" : 119.70931400000001,
		"lat" : 25.967044999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1206,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.69966082741135,
		  25.964341532482042
		]
	  },
	  "properties" : {
		"FID" : 1206,
		"name" : "大鹤省级森林公园",
		"lng" : 119.70420300000001,
		"lat" : 25.961245000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1207,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.70007665357834,
		  25.988461334263697
		]
	  },
	  "properties" : {
		"FID" : 1207,
		"name" : "石壁基督教堂",
		"lng" : 119.704621,
		"lat" : 25.985348999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1208,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.70761584764851,
		  25.977787384986243
		]
	  },
	  "properties" : {
		"FID" : 1208,
		"name" : "文武太平王庙",
		"lng" : 119.712166,
		"lat" : 25.974692999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1209,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.68699214470962,
		  26.021701500800649
		]
	  },
	  "properties" : {
		"FID" : 1209,
		"name" : "三田都元帅府",
		"lng" : 119.691524,
		"lat" : 26.018545
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1210,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.68471117452602,
		  26.020734904598996
		]
	  },
	  "properties" : {
		"FID" : 1210,
		"name" : "蔡仙府",
		"lng" : 119.68924,
		"lat" : 26.017575000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1211,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.70083304141481,
		  25.986780052863224
		]
	  },
	  "properties" : {
		"FID" : 1211,
		"name" : "大王宫",
		"lng" : 119.705378,
		"lat" : 25.98367
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1212,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.69899964463694,
		  25.989588742687793
		]
	  },
	  "properties" : {
		"FID" : 1212,
		"name" : "董道溉公祖厅",
		"lng" : 119.703543,
		"lat" : 25.986474000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1213,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67804731914019,
		  26.019889556463749
		]
	  },
	  "properties" : {
		"FID" : 1213,
		"name" : "梅花古城",
		"lng" : 119.68256700000001,
		"lat" : 26.016718000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1214,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67423535243725,
		  25.997750666422469
		]
	  },
	  "properties" : {
		"FID" : 1214,
		"name" : "棋山禅寺",
		"lng" : 119.678748,
		"lat" : 25.994586999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1215,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67921183463929,
		  26.017931056347688
		]
	  },
	  "properties" : {
		"FID" : 1215,
		"name" : "梅花镇彭家大院(彭家十策堂大院)",
		"lng" : 119.683733,
		"lat" : 26.014762999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1216,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67811002052117,
		  26.009073084879571
		]
	  },
	  "properties" : {
		"FID" : 1216,
		"name" : "九位仙君殿",
		"lng" : 119.68262900000001,
		"lat" : 26.005908999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1217,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6772833879173,
		  26.019980047343402
		]
	  },
	  "properties" : {
		"FID" : 1217,
		"name" : "梅花镇林位宫",
		"lng" : 119.681802,
		"lat" : 26.016807
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1218,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67312257090055,
		  26.016747706881425
		]
	  },
	  "properties" : {
		"FID" : 1218,
		"name" : "塔礁公园",
		"lng" : 119.677635,
		"lat" : 26.013569
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1219,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67735777077412,
		  26.013295364430551
		]
	  },
	  "properties" : {
		"FID" : 1219,
		"name" : "长乐梅花真耶稣教会",
		"lng" : 119.681876,
		"lat" : 26.010127000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1220,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67473808633625,
		  26.0189321287348
		]
	  },
	  "properties" : {
		"FID" : 1220,
		"name" : "天后宫",
		"lng" : 119.679253,
		"lat" : 26.015754999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1221,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67856146231465,
		  26.021758866706129
		]
	  },
	  "properties" : {
		"FID" : 1221,
		"name" : "西施弄",
		"lng" : 119.683082,
		"lat" : 26.018587
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1222,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.69404034104934,
		  25.957136524343813
		]
	  },
	  "properties" : {
		"FID" : 1222,
		"name" : "长乐区象鼻澳海滩",
		"lng" : 119.698576,
		"lat" : 25.954035999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1223,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67776873162011,
		  26.019601881772356
		]
	  },
	  "properties" : {
		"FID" : 1223,
		"name" : "梅花许孝位故居",
		"lng" : 119.682288,
		"lat" : 26.01643
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1224,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67804532201654,
		  26.019888559517216
		]
	  },
	  "properties" : {
		"FID" : 1224,
		"name" : "梅椅古城酡花烦",
		"lng" : 119.682565,
		"lat" : 26.016717
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1225,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67803134375691,
		  26.019859565934965
		]
	  },
	  "properties" : {
		"FID" : 1225,
		"name" : "梅花古城东城门",
		"lng" : 119.682551,
		"lat" : 26.016687999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1226,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.68387396960489,
		  25.970216012006446
		]
	  },
	  "properties" : {
		"FID" : 1226,
		"name" : "玉封通天府白马忠懿王",
		"lng" : 119.68839800000001,
		"lat" : 25.967089000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1227,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67197579445182,
		  25.995302290579129
		]
	  },
	  "properties" : {
		"FID" : 1227,
		"name" : "长乐区陇西前董纪念堂",
		"lng" : 119.676485,
		"lat" : 25.992135999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1228,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67130323839434,
		  25.988891203221314
		]
	  },
	  "properties" : {
		"FID" : 1228,
		"name" : "鹤峰洞",
		"lng" : 119.675811,
		"lat" : 25.985728000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1229,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66278917874055,
		  25.996027330995407
		]
	  },
	  "properties" : {
		"FID" : 1229,
		"name" : "观音岩寺",
		"lng" : 119.66728500000001,
		"lat" : 25.992843000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1230,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6904932429491,
		  25.960676872671129
		]
	  },
	  "properties" : {
		"FID" : 1230,
		"name" : "沙帽洞",
		"lng" : 119.695025,
		"lat" : 25.957567999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1231,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67367209323044,
		  25.998707385948205
		]
	  },
	  "properties" : {
		"FID" : 1231,
		"name" : "念佛堂",
		"lng" : 119.678184,
		"lat" : 25.995542
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1232,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66317780987185,
		  25.99328372108052
		]
	  },
	  "properties" : {
		"FID" : 1232,
		"name" : "下屿头祖厅",
		"lng" : 119.66767400000001,
		"lat" : 25.990102
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1233,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66186667748235,
		  25.980191293946085
		]
	  },
	  "properties" : {
		"FID" : 1233,
		"name" : "江七府",
		"lng" : 119.66636,
		"lat" : 25.977015999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1234,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65980866984506,
		  25.980207206119516
		]
	  },
	  "properties" : {
		"FID" : 1234,
		"name" : "仙富村基督教堂",
		"lng" : 119.664299,
		"lat" : 25.977028000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1235,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66911135024232,
		  25.990061185851516
		]
	  },
	  "properties" : {
		"FID" : 1235,
		"name" : "宝莲堂",
		"lng" : 119.673616,
		"lat" : 25.986892999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1236,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6686307622611,
		  25.994058828968992
		]
	  },
	  "properties" : {
		"FID" : 1236,
		"name" : "既济堂",
		"lng" : 119.673135,
		"lat" : 25.990887000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1237,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65723716033148,
		  25.983192078519174
		]
	  },
	  "properties" : {
		"FID" : 1237,
		"name" : "文化活动广场",
		"lng" : 119.66172400000001,
		"lat" : 25.980005999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1238,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.652029950097,
		  25.990723831927845
		]
	  },
	  "properties" : {
		"FID" : 1238,
		"name" : "忠华公园",
		"lng" : 119.65651,
		"lat" : 25.987522999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1239,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65066051106109,
		  25.967539514728863
		]
	  },
	  "properties" : {
		"FID" : 1239,
		"name" : "长乐仙宅鸿庆寺",
		"lng" : 119.655137,
		"lat" : 25.964352000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1240,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61460008047585,
		  26.032097192557284
		]
	  },
	  "properties" : {
		"FID" : 1240,
		"name" : "闽江河口国家湿地公园",
		"lng" : 119.61904699999999,
		"lat" : 26.028815000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1241,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58594630789739,
		  26.04345323379356
		]
	  },
	  "properties" : {
		"FID" : 1241,
		"name" : "鳌峰岩寺",
		"lng" : 119.590401,
		"lat" : 26.040154999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1242,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64343046561693,
		  26.002045661558693
		]
	  },
	  "properties" : {
		"FID" : 1242,
		"name" : "长乐文岭白姑仙娘宫",
		"lng" : 119.64790000000001,
		"lat" : 25.998822000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1243,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59480507708324,
		  25.993323319027471
		]
	  },
	  "properties" : {
		"FID" : 1243,
		"name" : "西湖公园",
		"lng" : 119.59925,
		"lat" : 25.990058000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1244,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66242289001157,
		  25.993608380044499
		]
	  },
	  "properties" : {
		"FID" : 1244,
		"name" : "鳌峰楼前董村祠堂",
		"lng" : 119.666918,
		"lat" : 25.990424999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1245,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64982441773827,
		  25.98448256000939
		]
	  },
	  "properties" : {
		"FID" : 1245,
		"name" : "九天府",
		"lng" : 119.654301,
		"lat" : 25.981282
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1246,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58761248707731,
		  25.991685544280344
		]
	  },
	  "properties" : {
		"FID" : 1246,
		"name" : "灵山廣义寺",
		"lng" : 119.592062,
		"lat" : 25.988422
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1247,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5746566467039,
		  26.04818088685936
		]
	  },
	  "properties" : {
		"FID" : 1247,
		"name" : "普陀寺",
		"lng" : 119.579125,
		"lat" : 26.044886000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1248,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60229152454457,
		  26.033287791093702
		]
	  },
	  "properties" : {
		"FID" : 1248,
		"name" : "鳖潭公园",
		"lng" : 119.606737,
		"lat" : 26.029997000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1249,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66244585457115,
		  25.993634354040129
		]
	  },
	  "properties" : {
		"FID" : 1249,
		"name" : "福峰殿白马尊王(前董村)",
		"lng" : 119.66694099999999,
		"lat" : 25.990451
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1250,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62225962329197,
		  25.969065592556078
		]
	  },
	  "properties" : {
		"FID" : 1250,
		"name" : "六林观音寺",
		"lng" : 119.626706,
		"lat" : 25.965834000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1251,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63488204655302,
		  25.978126020734912
		]
	  },
	  "properties" : {
		"FID" : 1251,
		"name" : "长乐金峰胪峰圣林禅寺",
		"lng" : 119.63934,
		"lat" : 25.974905
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1252,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61788826530972,
		  25.981715857846982
		]
	  },
	  "properties" : {
		"FID" : 1252,
		"name" : "集仙公园",
		"lng" : 119.622333,
		"lat" : 25.978470999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1253,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64982541638814,
		  25.984482558219845
		]
	  },
	  "properties" : {
		"FID" : 1253,
		"name" : "封玉蟒天神王",
		"lng" : 119.654302,
		"lat" : 25.981282
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1254,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65767771622573,
		  25.980605490245736
		]
	  },
	  "properties" : {
		"FID" : 1254,
		"name" : "圣水寺",
		"lng" : 119.662165,
		"lat" : 25.977422000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1255,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63362866684602,
		  25.987453238703988
		]
	  },
	  "properties" : {
		"FID" : 1255,
		"name" : "佛塔寺",
		"lng" : 119.638086,
		"lat" : 25.984224000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1256,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66148717497951,
		  25.994716914328457
		]
	  },
	  "properties" : {
		"FID" : 1256,
		"name" : "龍山洞",
		"lng" : 119.665981,
		"lat" : 25.991530999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1257,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59235997398771,
		  26.045685910480465
		]
	  },
	  "properties" : {
		"FID" : 1257,
		"name" : "福泽公园",
		"lng" : 119.59681,
		"lat" : 26.042384999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1258,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63815504326782,
		  26.011719866991399
		]
	  },
	  "properties" : {
		"FID" : 1258,
		"name" : "阜山民俗文化广场",
		"lng" : 119.642619,
		"lat" : 26.008481
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1259,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63954202479438,
		  26.003806270607051
		]
	  },
	  "properties" : {
		"FID" : 1259,
		"name" : "龙华禅寺",
		"lng" : 119.644007,
		"lat" : 26.000575000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1260,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64007706308836,
		  26.008443564026823
		]
	  },
	  "properties" : {
		"FID" : 1260,
		"name" : "天后宫",
		"lng" : 119.644543,
		"lat" : 26.005210000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1261,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65136610621816,
		  26.001168153361778
		]
	  },
	  "properties" : {
		"FID" : 1261,
		"name" : "鲤山寺",
		"lng" : 119.655846,
		"lat" : 25.997959000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1262,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58576792730226,
		  25.963289654074732
		]
	  },
	  "properties" : {
		"FID" : 1262,
		"name" : "真元观",
		"lng" : 119.590217,
		"lat" : 25.960045999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1263,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60219902630531,
		  26.040004371375566
		]
	  },
	  "properties" : {
		"FID" : 1263,
		"name" : "广聚寺",
		"lng" : 119.606645,
		"lat" : 26.036708999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1264,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57057607176191,
		  26.010112311281222
		]
	  },
	  "properties" : {
		"FID" : 1264,
		"name" : "晦翁岩",
		"lng" : 119.575048,
		"lat" : 26.006847
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1265,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5847726677805,
		  25.981678828750319
		]
	  },
	  "properties" : {
		"FID" : 1265,
		"name" : "长乐西石岩禅寺",
		"lng" : 119.589224,
		"lat" : 25.978422999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1266,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65386682254174,
		  25.957243668097394
		]
	  },
	  "properties" : {
		"FID" : 1266,
		"name" : "龙峰显赫宫",
		"lng" : 119.65834700000001,
		"lat" : 25.954069
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1267,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61175075110179,
		  25.966216681210952
		]
	  },
	  "properties" : {
		"FID" : 1267,
		"name" : "华阳东境",
		"lng" : 119.616192,
		"lat" : 25.962976999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1268,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66050053365194,
		  25.995782511688134
		]
	  },
	  "properties" : {
		"FID" : 1268,
		"name" : "祖焕公祖厅",
		"lng" : 119.664993,
		"lat" : 25.992594
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1269,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65793845038232,
		  25.965333598474675
		]
	  },
	  "properties" : {
		"FID" : 1269,
		"name" : "圣阳刘氏宗祠",
		"lng" : 119.662425,
		"lat" : 25.962160999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1270,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60027108469812,
		  25.978708347479291
		]
	  },
	  "properties" : {
		"FID" : 1270,
		"name" : "张氏宗祠",
		"lng" : 119.604713,
		"lat" : 25.975453999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1271,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6188263078335,
		  26.015893195412715
		]
	  },
	  "properties" : {
		"FID" : 1271,
		"name" : "三聖堂",
		"lng" : 119.62327399999999,
		"lat" : 26.012626000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1272,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64315901963748,
		  25.985253676241378
		]
	  },
	  "properties" : {
		"FID" : 1272,
		"name" : "灵瑞寺",
		"lng" : 119.647627,
		"lat" : 25.982040999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1273,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64870394012047,
		  25.970461003688868
		]
	  },
	  "properties" : {
		"FID" : 1273,
		"name" : "占忠公祖厅",
		"lng" : 119.653178,
		"lat" : 25.967268000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1274,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56064676729889,
		  26.046548806348198
		]
	  },
	  "properties" : {
		"FID" : 1274,
		"name" : "蒲竺寺",
		"lng" : 119.56514,
		"lat" : 26.043271000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1275,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61368952882644,
		  25.975018125539656
		]
	  },
	  "properties" : {
		"FID" : 1275,
		"name" : "金峰广场",
		"lng" : 119.618132,
		"lat" : 25.971774
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1276,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56804667634233,
		  26.038833101586725
		]
	  },
	  "properties" : {
		"FID" : 1276,
		"name" : "福建省长乐区潭头镇德成岩禅寺",
		"lng" : 119.572525,
		"lat" : 26.035551000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1277,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62839728814525,
		  26.019365284065429
		]
	  },
	  "properties" : {
		"FID" : 1277,
		"name" : "克凤村海安公园",
		"lng" : 119.632852,
		"lat" : 26.016107000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1278,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62673514433665,
		  25.985315261986873
		]
	  },
	  "properties" : {
		"FID" : 1278,
		"name" : "金峰基督教堂",
		"lng" : 119.631186,
		"lat" : 25.982078000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1279,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58488465886333,
		  26.038735675013061
		]
	  },
	  "properties" : {
		"FID" : 1279,
		"name" : "长乐潭头文溪双峰寺",
		"lng" : 119.58934000000001,
		"lat" : 26.035440999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1280,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61942600519056,
		  25.973962013552992
		]
	  },
	  "properties" : {
		"FID" : 1280,
		"name" : "金峯林氏宗祠",
		"lng" : 119.62387099999999,
		"lat" : 25.970724000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1281,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64186312647956,
		  25.991918381602407
		]
	  },
	  "properties" : {
		"FID" : 1281,
		"name" : "吴岩村齐天府",
		"lng" : 119.64633000000001,
		"lat" : 25.988699
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1282,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64017355088876,
		  26.000143756039524
		]
	  },
	  "properties" : {
		"FID" : 1282,
		"name" : "潮山姚氏宗祠",
		"lng" : 119.644639,
		"lat" : 25.996915999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1283,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51224970048966,
		  25.963002726482607
		]
	  },
	  "properties" : {
		"FID" : 1283,
		"name" : "河滨公园",
		"lng" : 119.516882,
		"lat" : 25.959892
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1284,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57156203443559,
		  26.00510888254512
		]
	  },
	  "properties" : {
		"FID" : 1284,
		"name" : "法王寺",
		"lng" : 119.576032,
		"lat" : 26.001846
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1285,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56936804564145,
		  26.010129065618319
		]
	  },
	  "properties" : {
		"FID" : 1285,
		"name" : "长乐区二刘村龙峰寺",
		"lng" : 119.573842,
		"lat" : 26.006865000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1286,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60663839959429,
		  25.954529126107939
		]
	  },
	  "properties" : {
		"FID" : 1286,
		"name" : "欧阳陈氏宗祠",
		"lng" : 119.61107800000001,
		"lat" : 25.951294000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1287,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55569734608132,
		  25.955958552327669
		]
	  },
	  "properties" : {
		"FID" : 1287,
		"name" : "九头马古民居",
		"lng" : 119.56019499999999,
		"lat" : 25.952750000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1288,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64256032922486,
		  25.991175715799304
		]
	  },
	  "properties" : {
		"FID" : 1288,
		"name" : "登云程氏宗祠",
		"lng" : 119.64702800000001,
		"lat" : 25.987957999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1289,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59407858860874,
		  25.995046530521737
		]
	  },
	  "properties" : {
		"FID" : 1289,
		"name" : "陈氏义房祖堂",
		"lng" : 119.598524,
		"lat" : 25.991779999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1290,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59810354893371,
		  26.046986298528523
		]
	  },
	  "properties" : {
		"FID" : 1290,
		"name" : "福星渔家公园",
		"lng" : 119.60255100000001,
		"lat" : 26.043685
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1291,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61083735360279,
		  25.988707688392651
		]
	  },
	  "properties" : {
		"FID" : 1291,
		"name" : "凤井庵",
		"lng" : 119.61528,
		"lat" : 25.985451999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1292,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59169022633377,
		  25.99490038939588
		]
	  },
	  "properties" : {
		"FID" : 1292,
		"name" : "岭南罗岳元帅府",
		"lng" : 119.596137,
		"lat" : 25.991634000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1293,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61456956383959,
		  25.956272614648661
		]
	  },
	  "properties" : {
		"FID" : 1293,
		"name" : "长乐区濠溪刘氏宗祠",
		"lng" : 119.619011,
		"lat" : 25.953042
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1294,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59141044256116,
		  25.989424635427266
		]
	  },
	  "properties" : {
		"FID" : 1294,
		"name" : "鲎峰寺",
		"lng" : 119.595857,
		"lat" : 25.986162
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1295,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62634898883306,
		  26.019440989399254
		]
	  },
	  "properties" : {
		"FID" : 1295,
		"name" : "英武庙",
		"lng" : 119.630802,
		"lat" : 26.016179999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1296,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6208312726916,
		  26.014228948646874
		]
	  },
	  "properties" : {
		"FID" : 1296,
		"name" : "厚福文昌阁",
		"lng" : 119.62528,
		"lat" : 26.010964999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1297,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6208312726916,
		  26.014228948646874
		]
	  },
	  "properties" : {
		"FID" : 1297,
		"name" : "厚福文昌阁",
		"lng" : 119.62528,
		"lat" : 26.010964999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1298,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62714931683436,
		  25.992072336290079
		]
	  },
	  "properties" : {
		"FID" : 1298,
		"name" : "沙合禅寺",
		"lng" : 119.631601,
		"lat" : 25.988831000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1299,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62419895399711,
		  25.973491343312883
		]
	  },
	  "properties" : {
		"FID" : 1299,
		"name" : "石竹山九们仙君",
		"lng" : 119.628647,
		"lat" : 25.970258999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1300,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63800280965783,
		  25.975883693053902
		]
	  },
	  "properties" : {
		"FID" : 1300,
		"name" : "法云禅寺",
		"lng" : 119.642464,
		"lat" : 25.972669
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1301,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62463904666861,
		  25.981568316959219
		]
	  },
	  "properties" : {
		"FID" : 1301,
		"name" : "甘墩街广场",
		"lng" : 119.629088,
		"lat" : 25.978331000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1302,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51938289037602,
		  25.967538991617857
		]
	  },
	  "properties" : {
		"FID" : 1302,
		"name" : "城隍庙",
		"lng" : 119.52399,
		"lat" : 25.964404999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1303,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6064548998513,
		  25.98933493376876
		]
	  },
	  "properties" : {
		"FID" : 1303,
		"name" : "沟沙玄天府",
		"lng" : 119.61089699999999,
		"lat" : 25.986076000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1304,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61876297329452,
		  25.97945043636868
		]
	  },
	  "properties" : {
		"FID" : 1304,
		"name" : "金峰太子殿",
		"lng" : 119.62320800000001,
		"lat" : 25.976208
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1305,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58420780863204,
		  25.958185605794153
		]
	  },
	  "properties" : {
		"FID" : 1305,
		"name" : "洞湖观音寺",
		"lng" : 119.588658,
		"lat" : 25.954946
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1306,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62832310931675,
		  25.981232414449519
		]
	  },
	  "properties" : {
		"FID" : 1306,
		"name" : "天主堂",
		"lng" : 119.632775,
		"lat" : 25.978000000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1307,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59653374002208,
		  25.994773127075199
		]
	  },
	  "properties" : {
		"FID" : 1307,
		"name" : "岭南商昭厅德福堂",
		"lng" : 119.600978,
		"lat" : 25.991506999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1308,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.593369397163,
		  25.964678848876694
		]
	  },
	  "properties" : {
		"FID" : 1308,
		"name" : "蓝田上陈马山坡壋支祠",
		"lng" : 119.597813,
		"lat" : 25.961433
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1309,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60574409709612,
		  26.042287299662959
		]
	  },
	  "properties" : {
		"FID" : 1309,
		"name" : "天妃庙",
		"lng" : 119.61019,
		"lat" : 26.038992
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1310,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59686890980521,
		  25.99425872656321
		]
	  },
	  "properties" : {
		"FID" : 1310,
		"name" : "岭南陈氏宗祠",
		"lng" : 119.601313,
		"lat" : 25.990993
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1311,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5999127161528,
		  26.038077833268083
		]
	  },
	  "properties" : {
		"FID" : 1311,
		"name" : "妈祖古庙",
		"lng" : 119.604359,
		"lat" : 26.034783000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1312,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60418606068271,
		  25.986870411571864
		]
	  },
	  "properties" : {
		"FID" : 1312,
		"name" : "塔前前厝祖庙",
		"lng" : 119.608628,
		"lat" : 25.983612000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1313,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60514838137618,
		  25.996770694199437
		]
	  },
	  "properties" : {
		"FID" : 1313,
		"name" : "林氏大宗祠堂",
		"lng" : 119.60959099999999,
		"lat" : 25.993506
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1314,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60304145954055,
		  26.035477972843108
		]
	  },
	  "properties" : {
		"FID" : 1314,
		"name" : "真耶稣教会",
		"lng" : 119.60748700000001,
		"lat" : 26.032185999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1315,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61488509418123,
		  26.016550390890981
		]
	  },
	  "properties" : {
		"FID" : 1315,
		"name" : "基督教厚福堂",
		"lng" : 119.619331,
		"lat" : 26.013279000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1316,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59306512563862,
		  25.993844724338338
		]
	  },
	  "properties" : {
		"FID" : 1316,
		"name" : "仙君寺",
		"lng" : 119.597511,
		"lat" : 25.990579
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1317,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63802579315228,
		  25.975753568199771
		]
	  },
	  "properties" : {
		"FID" : 1317,
		"name" : "合兴堂",
		"lng" : 119.642487,
		"lat" : 25.972539000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1318,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61662224926117,
		  26.018067838277517
		]
	  },
	  "properties" : {
		"FID" : 1318,
		"name" : "显圣堂",
		"lng" : 119.62106900000001,
		"lat" : 26.014797000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1319,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57873238766517,
		  26.04512484600648
		]
	  },
	  "properties" : {
		"FID" : 1319,
		"name" : "福州一贤宫",
		"lng" : 119.583195,
		"lat" : 26.041829
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1320,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57699606901373,
		  26.018342503214164
		]
	  },
	  "properties" : {
		"FID" : 1320,
		"name" : "长乐县二刘小学旧址",
		"lng" : 119.581459,
		"lat" : 26.015066000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1321,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6082099230174,
		  26.014802241411427
		]
	  },
	  "properties" : {
		"FID" : 1321,
		"name" : "响石洞天王寺",
		"lng" : 119.61265400000001,
		"lat" : 26.011527000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1322,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59757429162109,
		  25.992600475441339
		]
	  },
	  "properties" : {
		"FID" : 1322,
		"name" : "岭南大士菴",
		"lng" : 119.602018,
		"lat" : 25.989336000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1323,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60912535157766,
		  25.965532086745739
		]
	  },
	  "properties" : {
		"FID" : 1323,
		"name" : "华阳表贤祖厅",
		"lng" : 119.61356600000001,
		"lat" : 25.962291
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1324,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60212837356791,
		  26.035052048176102
		]
	  },
	  "properties" : {
		"FID" : 1324,
		"name" : "长乐三清观",
		"lng" : 119.60657399999999,
		"lat" : 26.031759999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1325,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58850356825752,
		  26.000506762434796
		]
	  },
	  "properties" : {
		"FID" : 1325,
		"name" : "严光长者寺",
		"lng" : 119.59295299999999,
		"lat" : 25.997236999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1326,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5049123729318,
		  25.967746480010977
		]
	  },
	  "properties" : {
		"FID" : 1326,
		"name" : "冰心文学馆",
		"lng" : 119.50957200000001,
		"lat" : 25.964653999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1327,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53287956563312,
		  26.044729789523412
		]
	  },
	  "properties" : {
		"FID" : 1327,
		"name" : "猴屿洞天岩景区",
		"lng" : 119.537447,
		"lat" : 26.041508
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1328,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50918262714031,
		  26.042826134832421
		]
	  },
	  "properties" : {
		"FID" : 1328,
		"name" : "猴屿洞天岩-金刚腿",
		"lng" : 119.51383199999999,
		"lat" : 26.039670000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1329,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51572637244114,
		  25.974938797807379
		]
	  },
	  "properties" : {
		"FID" : 1329,
		"name" : "天王寺",
		"lng" : 119.520347,
		"lat" : 25.971810000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1330,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63076255997021,
		  25.999978876598128
		]
	  },
	  "properties" : {
		"FID" : 1330,
		"name" : "港口村龙阳寺",
		"lng" : 119.63521799999999,
		"lat" : 25.996737
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1331,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54992149212816,
		  25.952048728918321
		]
	  },
	  "properties" : {
		"FID" : 1331,
		"name" : "义姑祠",
		"lng" : 119.554433,
		"lat" : 25.948853
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1332,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54474509184595,
		  25.960065995865396
		]
	  },
	  "properties" : {
		"FID" : 1332,
		"name" : "龙潭晓瀑",
		"lng" : 119.549271,
		"lat" : 25.956875
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1333,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51600130277383,
		  25.975672075574501
		]
	  },
	  "properties" : {
		"FID" : 1333,
		"name" : "乐寿亭",
		"lng" : 119.52062100000001,
		"lat" : 25.972542000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1334,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64020351132646,
		  26.000202747622417
		]
	  },
	  "properties" : {
		"FID" : 1334,
		"name" : "姚广孝纪念馆",
		"lng" : 119.64466899999999,
		"lat" : 25.996974999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1335,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62675900522694,
		  25.959277497045626
		]
	  },
	  "properties" : {
		"FID" : 1335,
		"name" : "仙高三落厅乐天堂",
		"lng" : 119.631208,
		"lat" : 25.956057999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1336,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51219254910647,
		  25.962234038225635
		]
	  },
	  "properties" : {
		"FID" : 1336,
		"name" : "吴航街道法治文化广场",
		"lng" : 119.516825,
		"lat" : 25.959123999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1337,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59932869280655,
		  26.022432388337918
		]
	  },
	  "properties" : {
		"FID" : 1337,
		"name" : "大宏荣香寺",
		"lng" : 119.603774,
		"lat" : 26.019148000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1338,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59963279634374,
		  26.00826667411836
		]
	  },
	  "properties" : {
		"FID" : 1338,
		"name" : "莲花宫泰山府",
		"lng" : 119.604077,
		"lat" : 26.004992000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1339,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59668489010907,
		  25.993530258027388
		]
	  },
	  "properties" : {
		"FID" : 1339,
		"name" : "岭南坊兜陈氏祖堂",
		"lng" : 119.601129,
		"lat" : 25.990265000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1340,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56869600992512,
		  26.00845920167145
		]
	  },
	  "properties" : {
		"FID" : 1340,
		"name" : "郑和纪念堂",
		"lng" : 119.573171,
		"lat" : 26.005196999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1341,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57703226783738,
		  26.016260113720381
		]
	  },
	  "properties" : {
		"FID" : 1341,
		"name" : "福州市传统风貌建筑",
		"lng" : 119.581495,
		"lat" : 26.012985
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1342,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61991378794443,
		  26.014666230876827
		]
	  },
	  "properties" : {
		"FID" : 1342,
		"name" : "兹简公祖厅",
		"lng" : 119.624362,
		"lat" : 26.011400999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1343,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62838249059662,
		  25.96139882731989
		]
	  },
	  "properties" : {
		"FID" : 1343,
		"name" : "金峰龙津寺",
		"lng" : 119.63283300000001,
		"lat" : 25.958179999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1344,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62070805723513,
		  25.990564966638605
		]
	  },
	  "properties" : {
		"FID" : 1344,
		"name" : "仙厚李氏宗祠",
		"lng" : 119.62515500000001,
		"lat" : 25.987317000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1345,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65301704751906,
		  25.984295649082181
		]
	  },
	  "properties" : {
		"FID" : 1345,
		"name" : "静心亭",
		"lng" : 119.657498,
		"lat" : 25.981100999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1346,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59644663015627,
		  25.995806843797794
		]
	  },
	  "properties" : {
		"FID" : 1346,
		"name" : "行房陈氏祖堂",
		"lng" : 119.600891,
		"lat" : 25.992540000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1347,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59763424739265,
		  26.021237958937942
		]
	  },
	  "properties" : {
		"FID" : 1347,
		"name" : "基督教大宏堂",
		"lng" : 119.60208,
		"lat" : 26.017954
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1348,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61814485022309,
		  25.985657289813691
		]
	  },
	  "properties" : {
		"FID" : 1348,
		"name" : "长乐金峰集仙大王宫",
		"lng" : 119.62259,
		"lat" : 25.982410000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1349,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51423668944601,
		  25.965787325199297
		]
	  },
	  "properties" : {
		"FID" : 1349,
		"name" : "长乐慈济宫",
		"lng" : 119.518862,
		"lat" : 25.962669000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1350,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50449852485232,
		  25.958379874665045
		]
	  },
	  "properties" : {
		"FID" : 1350,
		"name" : "世纪钟楼",
		"lng" : 119.509159,
		"lat" : 25.955295
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1351,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51596498039126,
		  25.964641455644571
		]
	  },
	  "properties" : {
		"FID" : 1351,
		"name" : "天主教长乐若瑟堂",
		"lng" : 119.520584,
		"lat" : 25.961518999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1352,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51606113216967,
		  25.953601214194624
		]
	  },
	  "properties" : {
		"FID" : 1352,
		"name" : "南山植物园",
		"lng" : 119.520679,
		"lat" : 25.950486000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1353,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62212671464721,
		  25.969015709280317
		]
	  },
	  "properties" : {
		"FID" : 1353,
		"name" : "天王殿",
		"lng" : 119.62657299999999,
		"lat" : 25.965783999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1354,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63795886677721,
		  25.97577869067198
		]
	  },
	  "properties" : {
		"FID" : 1354,
		"name" : "寺禅云法",
		"lng" : 119.64242,
		"lat" : 25.972563999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1355,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57832397779094,
		  25.974368471407523
		]
	  },
	  "properties" : {
		"FID" : 1355,
		"name" : "岩泉寺",
		"lng" : 119.58278199999999,
		"lat" : 25.971121
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1356,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58499045761248,
		  26.042921543225617
		]
	  },
	  "properties" : {
		"FID" : 1356,
		"name" : "鳌峰岩",
		"lng" : 119.589446,
		"lat" : 26.039624
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1357,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57175134169908,
		  26.005038017176069
		]
	  },
	  "properties" : {
		"FID" : 1357,
		"name" : "锦鲤岩",
		"lng" : 119.576221,
		"lat" : 26.001774999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1358,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65381488025091,
		  25.985020678844037
		]
	  },
	  "properties" : {
		"FID" : 1358,
		"name" : "山边刘村湖山堂",
		"lng" : 119.658297,
		"lat" : 25.981826999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1359,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57749112367597,
		  26.040528900758222
		]
	  },
	  "properties" : {
		"FID" : 1359,
		"name" : "天师府",
		"lng" : 119.58195499999999,
		"lat" : 26.037237000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1360,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60363014932292,
		  25.998975914200265
		]
	  },
	  "properties" : {
		"FID" : 1360,
		"name" : "基督教沙堤堂",
		"lng" : 119.608073,
		"lat" : 25.995709000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1361,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59718228221874,
		  26.032336569774685
		]
	  },
	  "properties" : {
		"FID" : 1361,
		"name" : "荣菊庵",
		"lng" : 119.601629,
		"lat" : 26.029045
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1362,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60886200562146,
		  25.957001455496538
		]
	  },
	  "properties" : {
		"FID" : 1362,
		"name" : "华林寺-通天府",
		"lng" : 119.613302,
		"lat" : 25.953766000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1363,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60676760975471,
		  25.965400448344294
		]
	  },
	  "properties" : {
		"FID" : 1363,
		"name" : "西来寺",
		"lng" : 119.611208,
		"lat" : 25.962157999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1364,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59788670757958,
		  26.02993080911218
		]
	  },
	  "properties" : {
		"FID" : 1364,
		"name" : "长乐潭头前陈祖厅",
		"lng" : 119.602333,
		"lat" : 26.026641000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1365,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58819261115319,
		  25.996500964779827
		]
	  },
	  "properties" : {
		"FID" : 1365,
		"name" : "湖中心靈官院",
		"lng" : 119.592642,
		"lat" : 25.993234000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1366,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60377317619786,
		  25.971012792090264
		]
	  },
	  "properties" : {
		"FID" : 1366,
		"name" : "赠成公祖厅",
		"lng" : 119.608214,
		"lat" : 25.967765
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1367,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61289344291005,
		  25.965940596334995
		]
	  },
	  "properties" : {
		"FID" : 1367,
		"name" : "玄帝殿",
		"lng" : 119.617335,
		"lat" : 25.962702
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1368,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60246024906702,
		  26.023572136657709
		]
	  },
	  "properties" : {
		"FID" : 1368,
		"name" : "曹朱廣积堂",
		"lng" : 119.606905,
		"lat" : 26.020288000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1369,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61613217076064,
		  25.980634801207817
		]
	  },
	  "properties" : {
		"FID" : 1369,
		"name" : "平安金峰园",
		"lng" : 119.620576,
		"lat" : 25.977388999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1370,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60266570450362,
		  26.031482420634276
		]
	  },
	  "properties" : {
		"FID" : 1370,
		"name" : "天主堂",
		"lng" : 119.607111,
		"lat" : 26.028193000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1371,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60518174405466,
		  26.033322526335247
		]
	  },
	  "properties" : {
		"FID" : 1371,
		"name" : "潭峪寺",
		"lng" : 119.609627,
		"lat" : 26.030033
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1372,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61808093335316,
		  25.971099432578225
		]
	  },
	  "properties" : {
		"FID" : 1372,
		"name" : "六林判院祖厅",
		"lng" : 119.622525,
		"lat" : 25.967862
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1373,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61197658381842,
		  25.953819074450479
		]
	  },
	  "properties" : {
		"FID" : 1373,
		"name" : "华夏梁氏宗祠",
		"lng" : 119.616417,
		"lat" : 25.950588
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1374,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59948396340162,
		  25.991536316043522
		]
	  },
	  "properties" : {
		"FID" : 1374,
		"name" : "基督教岭南堂",
		"lng" : 119.603927,
		"lat" : 25.988273
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1375,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51447869731626,
		  25.963932752529079
		]
	  },
	  "properties" : {
		"FID" : 1375,
		"name" : "郑和公园",
		"lng" : 119.519103,
		"lat" : 25.960815
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1376,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63030146858242,
		  25.979504562259741
		]
	  },
	  "properties" : {
		"FID" : 1376,
		"name" : "金峰皇恩寺",
		"lng" : 119.634755,
		"lat" : 25.976275999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1377,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63037953552266,
		  25.96373971657059
		]
	  },
	  "properties" : {
		"FID" : 1377,
		"name" : "大王宫",
		"lng" : 119.634832,
		"lat" : 25.960522000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1378,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61914650689036,
		  26.01072034832605
		]
	  },
	  "properties" : {
		"FID" : 1378,
		"name" : "圣王寺",
		"lng" : 119.623594,
		"lat" : 26.007456999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1379,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51457698119708,
		  25.964888683759753
		]
	  },
	  "properties" : {
		"FID" : 1379,
		"name" : "圣寿宝塔",
		"lng" : 119.519201,
		"lat" : 25.961770000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1380,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5962367612037,
		  25.99278781401593
		]
	  },
	  "properties" : {
		"FID" : 1380,
		"name" : "岭南信房陈氏祖堂",
		"lng" : 119.60068099999999,
		"lat" : 25.989522999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1381,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58177097004918,
		  25.975974602463072
		]
	  },
	  "properties" : {
		"FID" : 1381,
		"name" : "渤海虎泽堂",
		"lng" : 119.586225,
		"lat" : 25.972723999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1382,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61437373830924,
		  25.954864827088585
		]
	  },
	  "properties" : {
		"FID" : 1382,
		"name" : "玉封通天府",
		"lng" : 119.618815,
		"lat" : 25.951635
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1383,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61015294014427,
		  25.968719556317883
		]
	  },
	  "properties" : {
		"FID" : 1383,
		"name" : "华恩大王宫",
		"lng" : 119.614594,
		"lat" : 25.965477
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1384,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50546749394734,
		  25.966907552169243
		]
	  },
	  "properties" : {
		"FID" : 1384,
		"name" : "冰心公园",
		"lng" : 119.510125,
		"lat" : 25.963813999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1385,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51597241326137,
		  26.000054621018986
		]
	  },
	  "properties" : {
		"FID" : 1385,
		"name" : "芦际潭森林公园",
		"lng" : 119.520594,
		"lat" : 25.996908000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1386,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54165829120667,
		  26.057387583812343
		]
	  },
	  "properties" : {
		"FID" : 1386,
		"name" : "猴屿网红绿皮火车",
		"lng" : 119.5462,
		"lat" : 26.054137000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1387,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51892235531135,
		  25.95268960891535
		]
	  },
	  "properties" : {
		"FID" : 1387,
		"name" : "南山体育公园",
		"lng" : 119.52352999999999,
		"lat" : 25.949566999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1388,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61981013433633,
		  26.010700642737188
		]
	  },
	  "properties" : {
		"FID" : 1388,
		"name" : "克昌公祖厅",
		"lng" : 119.624258,
		"lat" : 26.007438
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1389,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64270793539328,
		  25.952672251593675
		]
	  },
	  "properties" : {
		"FID" : 1389,
		"name" : "巷头严氏宗祠",
		"lng" : 119.647173,
		"lat" : 25.949480999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1390,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51430871751967,
		  25.968948684690698
		]
	  },
	  "properties" : {
		"FID" : 1390,
		"name" : "葫芦山普济寺",
		"lng" : 119.518934,
		"lat" : 25.965827999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1391,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64978350402839,
		  25.984055342090912
		]
	  },
	  "properties" : {
		"FID" : 1391,
		"name" : "郑朱观音堂",
		"lng" : 119.65425999999999,
		"lat" : 25.980854999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1392,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60287934716246,
		  26.022933534683421
		]
	  },
	  "properties" : {
		"FID" : 1392,
		"name" : "华威广场",
		"lng" : 119.60732400000001,
		"lat" : 26.019649999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1393,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60826182707625,
		  25.988325175238096
		]
	  },
	  "properties" : {
		"FID" : 1393,
		"name" : "德施房祖厅",
		"lng" : 119.61270399999999,
		"lat" : 25.985067999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1394,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65697274395076,
		  25.966593265374069
		]
	  },
	  "properties" : {
		"FID" : 1394,
		"name" : "流泽境",
		"lng" : 119.661458,
		"lat" : 25.963418000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1395,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64953785428463,
		  25.983797605763971
		]
	  },
	  "properties" : {
		"FID" : 1395,
		"name" : "郑朱赤山祖厅",
		"lng" : 119.654014,
		"lat" : 25.980596999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1396,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5277396573683,
		  26.020048148937903
		]
	  },
	  "properties" : {
		"FID" : 1396,
		"name" : "金狮岩古寺",
		"lng" : 119.53232199999999,
		"lat" : 26.016856000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1397,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.68371597790033,
		  25.918086977721835
		]
	  },
	  "properties" : {
		"FID" : 1397,
		"name" : "滋澳海滩",
		"lng" : 119.688236,
		"lat" : 25.914995000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1398,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.66512602752586,
		  25.909707340675428
		]
	  },
	  "properties" : {
		"FID" : 1398,
		"name" : "漳港海滩",
		"lng" : 119.669619,
		"lat" : 25.906586000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1399,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.69966082741135,
		  25.964341532482042
		]
	  },
	  "properties" : {
		"FID" : 1399,
		"name" : "大鹤省级森林公园",
		"lng" : 119.70420300000001,
		"lat" : 25.961245000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1400,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67853473527636,
		  25.908720215959097
		]
	  },
	  "properties" : {
		"FID" : 1400,
		"name" : "北澳海滩",
		"lng" : 119.683047,
		"lat" : 25.905625000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1401,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67290675634722,
		  25.908564716690744
		]
	  },
	  "properties" : {
		"FID" : 1401,
		"name" : "南澳海滩",
		"lng" : 119.67741100000001,
		"lat" : 25.905459
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1402,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.69404034104934,
		  25.957136524343813
		]
	  },
	  "properties" : {
		"FID" : 1402,
		"name" : "长乐区象鼻澳海滩",
		"lng" : 119.698576,
		"lat" : 25.954035999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1403,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64874279689815,
		  25.916477365423443
		]
	  },
	  "properties" : {
		"FID" : 1403,
		"name" : "仙岐礁山公园",
		"lng" : 119.65321299999999,
		"lat" : 25.913321
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1404,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.92764764370722,
		  25.974814490546276
		]
	  },
	  "properties" : {
		"FID" : 1404,
		"name" : "中正门",
		"lng" : 119.931872,
		"lat" : 25.971585000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1405,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.92872792605617,
		  25.97497212597046
		]
	  },
	  "properties" : {
		"FID" : 1405,
		"name" : "陈将军庙",
		"lng" : 119.932953,
		"lat" : 25.971744000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1406,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64236152969555,
		  25.908829231501983
		]
	  },
	  "properties" : {
		"FID" : 1406,
		"name" : "海岸长城",
		"lng" : 119.646823,
		"lat" : 25.905667000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1407,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67957731138604,
		  25.949573843968412
		]
	  },
	  "properties" : {
		"FID" : 1407,
		"name" : "三角下礼堂",
		"lng" : 119.684094,
		"lat" : 25.946453000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1408,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.92709097245732,
		  25.97500936215507
		]
	  },
	  "properties" : {
		"FID" : 1408,
		"name" : "香园",
		"lng" : 119.931315,
		"lat" : 25.971779000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1409,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.70476669715414,
		  25.970138034976113
		]
	  },
	  "properties" : {
		"FID" : 1409,
		"name" : "大王宫",
		"lng" : 119.70931400000001,
		"lat" : 25.967044999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1410,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.96827795372397,
		  25.958482778078476
		]
	  },
	  "properties" : {
		"FID" : 1410,
		"name" : "白马尊王庙(莒光乡)",
		"lng" : 119.972561,
		"lat" : 25.955349999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1411,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.96887869709003,
		  25.957845700558853
		]
	  },
	  "properties" : {
		"FID" : 1411,
		"name" : "凉亭(莒光乡大埔村)",
		"lng" : 119.973163,
		"lat" : 25.954715
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1412,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65036103252284,
		  25.938364238196634
		]
	  },
	  "properties" : {
		"FID" : 1412,
		"name" : "长乐鹏谢村仙景山玄帝庙",
		"lng" : 119.65483500000001,
		"lat" : 25.935196000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1413,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.97049978523239,
		  25.962840620117735
		]
	  },
	  "properties" : {
		"FID" : 1413,
		"name" : "东莒英雄馆",
		"lng" : 119.974788,
		"lat" : 25.959710999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1414,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64245892292844,
		  25.915578595551679
		]
	  },
	  "properties" : {
		"FID" : 1414,
		"name" : "石梁徐氏祖庙",
		"lng" : 119.64692100000001,
		"lat" : 25.912412
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1415,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.97386240346718,
		  25.960326457643696
		]
	  },
	  "properties" : {
		"FID" : 1415,
		"name" : "吕何崖",
		"lng" : 119.97815799999999,
		"lat" : 25.957208000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1416,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.92827119569434,
		  25.975479099696795
		]
	  },
	  "properties" : {
		"FID" : 1416,
		"name" : "天后宫(莒光乡青帆村)",
		"lng" : 119.932496,
		"lat" : 25.972249999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1417,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.92654625748916,
		  25.975517418245278
		]
	  },
	  "properties" : {
		"FID" : 1417,
		"name" : "胡将军庙",
		"lng" : 119.93077,
		"lat" : 25.972286
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1418,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6452540734297,
		  25.920423116984317
		]
	  },
	  "properties" : {
		"FID" : 1418,
		"name" : "显应宫礼堂",
		"lng" : 119.64972,
		"lat" : 25.917258
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1419,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.96880879933656,
		  25.958543366469055
		]
	  },
	  "properties" : {
		"FID" : 1419,
		"name" : "大埔聚落",
		"lng" : 119.97309300000001,
		"lat" : 25.955411999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1420,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.97034743866158,
		  25.958397021965297
		]
	  },
	  "properties" : {
		"FID" : 1420,
		"name" : "望底坑",
		"lng" : 119.97463500000001,
		"lat" : 25.955269999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1421,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.97053563374128,
		  25.963853209232074
		]
	  },
	  "properties" : {
		"FID" : 1421,
		"name" : "直昇机停机坪",
		"lng" : 119.974824,
		"lat" : 25.960723000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1422,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.97199459745389,
		  25.960823072831683
		]
	  },
	  "properties" : {
		"FID" : 1422,
		"name" : "60战备步道",
		"lng" : 119.976286,
		"lat" : 25.957699000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1423,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6904932429491,
		  25.960676872671129
		]
	  },
	  "properties" : {
		"FID" : 1423,
		"name" : "沙帽洞",
		"lng" : 119.695025,
		"lat" : 25.957567999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1424,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.68255438394498,
		  25.947602030409442
		]
	  },
	  "properties" : {
		"FID" : 1424,
		"name" : "三角下九天宫",
		"lng" : 119.68707499999999,
		"lat" : 25.944488
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1425,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.9789450458713,
		  25.967557714010532
		]
	  },
	  "properties" : {
		"FID" : 1425,
		"name" : "石沙矶钓步道",
		"lng" : 119.983253,
		"lat" : 25.964448999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1426,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.97053270555168,
		  25.962936593920642
		]
	  },
	  "properties" : {
		"FID" : 1426,
		"name" : "中正堂",
		"lng" : 119.97482100000001,
		"lat" : 25.959807000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1427,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64377709609751,
		  25.918279195036494
		]
	  },
	  "properties" : {
		"FID" : 1427,
		"name" : "显应宫",
		"lng" : 119.648241,
		"lat" : 25.915113000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1428,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65039199870172,
		  25.938250105250258
		]
	  },
	  "properties" : {
		"FID" : 1428,
		"name" : "仙景楼",
		"lng" : 119.654866,
		"lat" : 25.935082000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1429,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.97570296469384,
		  25.963181137196752
		]
	  },
	  "properties" : {
		"FID" : 1429,
		"name" : "he xian gu yu lv dong bin",
		"lng" : 119.980003,
		"lat" : 25.960066000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1430,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64069811238454,
		  25.914678897676001
		]
	  },
	  "properties" : {
		"FID" : 1430,
		"name" : "天主堂",
		"lng" : 119.645158,
		"lat" : 25.91151
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1431,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6479097950069,
		  25.917984852134367
		]
	  },
	  "properties" : {
		"FID" : 1431,
		"name" : "仙航朱氏祖厅",
		"lng" : 119.652379,
		"lat" : 25.914826000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1432,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62023937607736,
		  25.767555244261104
		]
	  },
	  "properties" : {
		"FID" : 1432,
		"name" : "横山立云寺",
		"lng" : 119.62466999999999,
		"lat" : 25.764451999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1433,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.97566777272301,
		  25.967012845061682
		]
	  },
	  "properties" : {
		"FID" : 1433,
		"name" : "综合教练场",
		"lng" : 119.979968,
		"lat" : 25.963895000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1434,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.97817273708867,
		  25.969467267215443
		]
	  },
	  "properties" : {
		"FID" : 1434,
		"name" : "福正聚落",
		"lng" : 119.982479,
		"lat" : 25.966355
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1435,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.97685590455453,
		  25.968440390756218
		]
	  },
	  "properties" : {
		"FID" : 1435,
		"name" : "莒光游客中心",
		"lng" : 119.98115900000001,
		"lat" : 25.965325
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1436,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62645084465065,
		  25.937233929742064
		]
	  },
	  "properties" : {
		"FID" : 1436,
		"name" : "龙角峰寺",
		"lng" : 119.630898,
		"lat" : 25.934028999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1437,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62691316285375,
		  25.899874225733054
		]
	  },
	  "properties" : {
		"FID" : 1437,
		"name" : "望海楼沙滩",
		"lng" : 119.63135800000001,
		"lat" : 25.896695000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1438,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.661276160079,
		  25.944090861492075
		]
	  },
	  "properties" : {
		"FID" : 1438,
		"name" : "基督教堂",
		"lng" : 119.665766,
		"lat" : 25.940939
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1439,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.68387396960489,
		  25.970216012006446
		]
	  },
	  "properties" : {
		"FID" : 1439,
		"name" : "玉封通天府白马忠懿王",
		"lng" : 119.68839800000001,
		"lat" : 25.967089000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1440,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64887377171497,
		  25.942042388247021
		]
	  },
	  "properties" : {
		"FID" : 1440,
		"name" : "鹏程陈氏祖厅",
		"lng" : 119.653346,
		"lat" : 25.938869
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1441,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63998262585604,
		  25.919260139099787
		]
	  },
	  "properties" : {
		"FID" : 1441,
		"name" : "仙河郑大祖厅",
		"lng" : 119.644442,
		"lat" : 25.916087000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1442,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65793845038232,
		  25.965333598474675
		]
	  },
	  "properties" : {
		"FID" : 1442,
		"name" : "圣阳刘氏宗祠",
		"lng" : 119.662425,
		"lat" : 25.962160999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1443,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62826758958516,
		  25.919818823655966
		]
	  },
	  "properties" : {
		"FID" : 1443,
		"name" : "天后宫",
		"lng" : 119.632715,
		"lat" : 25.916627999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1444,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64067767917213,
		  25.921012188500548
		]
	  },
	  "properties" : {
		"FID" : 1444,
		"name" : "中堂郑氏祖庙",
		"lng" : 119.645138,
		"lat" : 25.917839000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1445,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64858773911078,
		  25.947768779204452
		]
	  },
	  "properties" : {
		"FID" : 1445,
		"name" : "长乐下郑白马尊王宫",
		"lng" : 119.65306,
		"lat" : 25.944590999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1446,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64342739974957,
		  25.920113019348509
		]
	  },
	  "properties" : {
		"FID" : 1446,
		"name" : "国公庙",
		"lng" : 119.647891,
		"lat" : 25.916944999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1447,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62883196200248,
		  25.921723354887064
		]
	  },
	  "properties" : {
		"FID" : 1447,
		"name" : "漳港九天堂",
		"lng" : 119.63328,
		"lat" : 25.918531999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1448,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6305990826869,
		  25.925631579176603
		]
	  },
	  "properties" : {
		"FID" : 1448,
		"name" : "漳港街道路顶村金甲城祖厅",
		"lng" : 119.635049,
		"lat" : 25.922440000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1449,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63964037147751,
		  25.928317794325107
		]
	  },
	  "properties" : {
		"FID" : 1449,
		"name" : "齐天府",
		"lng" : 119.64409999999999,
		"lat" : 25.925138
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1450,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64662391799504,
		  25.939612702294045
		]
	  },
	  "properties" : {
		"FID" : 1450,
		"name" : "长房祖廳",
		"lng" : 119.651093,
		"lat" : 25.936437000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1451,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62881291225334,
		  25.922645001015901
		]
	  },
	  "properties" : {
		"FID" : 1451,
		"name" : "石梁李氏宗祠",
		"lng" : 119.633261,
		"lat" : 25.919453000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1452,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64643503847461,
		  25.94134220261633
		]
	  },
	  "properties" : {
		"FID" : 1452,
		"name" : "鹏程谢氏宗祠",
		"lng" : 119.650904,
		"lat" : 25.938165000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1453,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62583805448806,
		  25.91331857991176
		]
	  },
	  "properties" : {
		"FID" : 1453,
		"name" : "漳港海潮寺",
		"lng" : 119.63028300000001,
		"lat" : 25.910129000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1454,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65066051106109,
		  25.967539514728863
		]
	  },
	  "properties" : {
		"FID" : 1454,
		"name" : "长乐仙宅鸿庆寺",
		"lng" : 119.655137,
		"lat" : 25.964352000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1455,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62806650027316,
		  25.923447531950686
		]
	  },
	  "properties" : {
		"FID" : 1455,
		"name" : "石梁朱氏祖厅",
		"lng" : 119.632514,
		"lat" : 25.920254
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1456,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62147069252937,
		  25.919720036608119
		]
	  },
	  "properties" : {
		"FID" : 1456,
		"name" : "漳港萧氏宗祠",
		"lng" : 119.625913,
		"lat" : 25.916520999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1457,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61343482793868,
		  25.916526691841977
		]
	  },
	  "properties" : {
		"FID" : 1457,
		"name" : "圣家堂",
		"lng" : 119.617873,
		"lat" : 25.913322000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1458,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62531646852447,
		  25.913177132381463
		]
	  },
	  "properties" : {
		"FID" : 1458,
		"name" : "长乐漳港圆明堂",
		"lng" : 119.629761,
		"lat" : 25.909987000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1459,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62984168756972,
		  25.926896475514823
		]
	  },
	  "properties" : {
		"FID" : 1459,
		"name" : "玉公廳",
		"lng" : 119.634291,
		"lat" : 25.923703
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1460,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61610470552385,
		  25.945643019471532
		]
	  },
	  "properties" : {
		"FID" : 1460,
		"name" : "文京寺",
		"lng" : 119.620546,
		"lat" : 25.942421
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1461,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6259871395316,
		  25.938259208420476
		]
	  },
	  "properties" : {
		"FID" : 1461,
		"name" : "龙角峰公园",
		"lng" : 119.63043399999999,
		"lat" : 25.935053
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1462,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61339484648776,
		  25.916452675122038
		]
	  },
	  "properties" : {
		"FID" : 1462,
		"name" : "天主堂",
		"lng" : 119.617833,
		"lat" : 25.913247999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1463,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63240442552146,
		  25.924671381673839
		]
	  },
	  "properties" : {
		"FID" : 1463,
		"name" : "园头林祖厅",
		"lng" : 119.63685599999999,
		"lat" : 25.921482999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1464,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63399398993103,
		  25.922452569867026
		]
	  },
	  "properties" : {
		"FID" : 1464,
		"name" : "观音堂",
		"lng" : 119.638447,
		"lat" : 25.919267999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1465,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65386682254174,
		  25.957243668097394
		]
	  },
	  "properties" : {
		"FID" : 1465,
		"name" : "龙峰显赫宫",
		"lng" : 119.65834700000001,
		"lat" : 25.954069
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1466,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62225962329197,
		  25.969065592556078
		]
	  },
	  "properties" : {
		"FID" : 1466,
		"name" : "六林观音寺",
		"lng" : 119.626706,
		"lat" : 25.965834000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1467,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62578109080094,
		  25.913432727616332
		]
	  },
	  "properties" : {
		"FID" : 1467,
		"name" : "钟流观",
		"lng" : 119.63022599999999,
		"lat" : 25.910243000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1468,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63201674391122,
		  25.9255054990053
		]
	  },
	  "properties" : {
		"FID" : 1468,
		"name" : "察院厅",
		"lng" : 119.63646799999999,
		"lat" : 25.922315999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1469,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63216961717102,
		  25.925200074704552
		]
	  },
	  "properties" : {
		"FID" : 1469,
		"name" : "楼下旧厝厅",
		"lng" : 119.63662100000001,
		"lat" : 25.922011000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1470,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62046965461599,
		  25.914931912630291
		]
	  },
	  "properties" : {
		"FID" : 1470,
		"name" : "长乐漳港南阳忠烈侯大使",
		"lng" : 119.624911,
		"lat" : 25.911735
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1471,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64870394012047,
		  25.970461003688868
		]
	  },
	  "properties" : {
		"FID" : 1471,
		"name" : "占忠公祖厅",
		"lng" : 119.653178,
		"lat" : 25.967268000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1472,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62141024040019,
		  25.898754061894852
		]
	  },
	  "properties" : {
		"FID" : 1472,
		"name" : "菜佛垱念佛堂",
		"lng" : 119.625851,
		"lat" : 25.895568999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1473,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61368952882644,
		  25.975018125539656
		]
	  },
	  "properties" : {
		"FID" : 1473,
		"name" : "金峰广场",
		"lng" : 119.618132,
		"lat" : 25.971774
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1474,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.65697274395076,
		  25.966593265374069
		]
	  },
	  "properties" : {
		"FID" : 1474,
		"name" : "流泽境",
		"lng" : 119.661458,
		"lat" : 25.963418000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1475,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62912672398173,
		  25.935284111435781
		]
	  },
	  "properties" : {
		"FID" : 1475,
		"name" : "林园寺",
		"lng" : 119.63357600000001,
		"lat" : 25.932084
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1476,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62394005807454,
		  25.933062194540945
		]
	  },
	  "properties" : {
		"FID" : 1476,
		"name" : "长乐龙峰显应堂",
		"lng" : 119.62838499999999,
		"lat" : 25.929856999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1477,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64270793539328,
		  25.952672251593675
		]
	  },
	  "properties" : {
		"FID" : 1477,
		"name" : "巷头严氏宗祠",
		"lng" : 119.647173,
		"lat" : 25.949480999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1478,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61942600519056,
		  25.973962013552992
		]
	  },
	  "properties" : {
		"FID" : 1478,
		"name" : "金峯林氏宗祠",
		"lng" : 119.62387099999999,
		"lat" : 25.970724000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1479,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62212671464721,
		  25.969015709280317
		]
	  },
	  "properties" : {
		"FID" : 1479,
		"name" : "天王殿",
		"lng" : 119.62657299999999,
		"lat" : 25.965783999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1480,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61456956383959,
		  25.956272614648661
		]
	  },
	  "properties" : {
		"FID" : 1480,
		"name" : "长乐区濠溪刘氏宗祠",
		"lng" : 119.619011,
		"lat" : 25.953042
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1481,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62419895399711,
		  25.973491343312883
		]
	  },
	  "properties" : {
		"FID" : 1481,
		"name" : "石竹山九们仙君",
		"lng" : 119.628647,
		"lat" : 25.970258999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1482,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61893639015337,
		  25.944637577718794
		]
	  },
	  "properties" : {
		"FID" : 1482,
		"name" : "陈氏守思祖厅",
		"lng" : 119.623379,
		"lat" : 25.941419
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1483,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61959002188883,
		  25.94471295204011
		]
	  },
	  "properties" : {
		"FID" : 1483,
		"name" : "陈氏忠义祖厅",
		"lng" : 119.624033,
		"lat" : 25.941495
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1484,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62838249059662,
		  25.96139882731989
		]
	  },
	  "properties" : {
		"FID" : 1484,
		"name" : "金峰龙津寺",
		"lng" : 119.63283300000001,
		"lat" : 25.958179999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1485,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62394820375796,
		  25.930959764172183
		]
	  },
	  "properties" : {
		"FID" : 1485,
		"name" : "龙峰杨氏宗祠",
		"lng" : 119.628393,
		"lat" : 25.927755999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1486,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62675900522694,
		  25.959277497045626
		]
	  },
	  "properties" : {
		"FID" : 1486,
		"name" : "仙高三落厅乐天堂",
		"lng" : 119.631208,
		"lat" : 25.956057999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1487,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62058680018235,
		  25.925818112102331
		]
	  },
	  "properties" : {
		"FID" : 1487,
		"name" : "关湖边陈祖厅",
		"lng" : 119.625029,
		"lat" : 25.922613999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1488,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64393759722428,
		  25.963870794955294
		]
	  },
	  "properties" : {
		"FID" : 1488,
		"name" : "笏峰黄氏宗祠",
		"lng" : 119.648405,
		"lat" : 25.960674000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1489,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61437373830924,
		  25.954864827088585
		]
	  },
	  "properties" : {
		"FID" : 1489,
		"name" : "玉封通天府",
		"lng" : 119.618815,
		"lat" : 25.951635
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1490,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61808093335316,
		  25.971099432578225
		]
	  },
	  "properties" : {
		"FID" : 1490,
		"name" : "六林判院祖厅",
		"lng" : 119.622525,
		"lat" : 25.967862
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1491,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64444992956621,
		  25.964182135561838
		]
	  },
	  "properties" : {
		"FID" : 1491,
		"name" : "蔡宅观音堂",
		"lng" : 119.64891799999999,
		"lat" : 25.960985999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1492,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63037953552266,
		  25.96373971657059
		]
	  },
	  "properties" : {
		"FID" : 1492,
		"name" : "大王宫",
		"lng" : 119.634832,
		"lat" : 25.960522000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1493,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62281422784167,
		  25.941652328056829
		]
	  },
	  "properties" : {
		"FID" : 1493,
		"name" : "毓麟宫",
		"lng" : 119.627259,
		"lat" : 25.93844
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1494,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62990900498009,
		  25.907777534214564
		]
	  },
	  "properties" : {
		"FID" : 1494,
		"name" : "中国长乐海蚌公园(暂停开放)",
		"lng" : 119.63435699999999,
		"lat" : 25.904596999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1495,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61399892614756,
		  25.815020093170652
		]
	  },
	  "properties" : {
		"FID" : 1495,
		"name" : "海螺塔",
		"lng" : 119.61843,
		"lat" : 25.811882000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1496,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.615996766813,
		  25.945442983348716
		]
	  },
	  "properties" : {
		"FID" : 1496,
		"name" : "文昌祠",
		"lng" : 119.62043799999999,
		"lat" : 25.942221
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1497,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24974074865452,
		  25.524144894908545
		]
	  },
	  "properties" : {
		"FID" : 1497,
		"name" : "武当别院",
		"lng" : 119.254462,
		"lat" : 25.521322999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1498,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24962281178118,
		  25.523453688617959
		]
	  },
	  "properties" : {
		"FID" : 1498,
		"name" : "蒜岭村古驿道",
		"lng" : 119.254344,
		"lat" : 25.520631999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1499,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26731137521709,
		  25.528546478900989
		]
	  },
	  "properties" : {
		"FID" : 1499,
		"name" : "木化石公园",
		"lng" : 119.272041,
		"lat" : 25.525732000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1500,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25694555038709,
		  25.501836598860706
		]
	  },
	  "properties" : {
		"FID" : 1500,
		"name" : "福海宫",
		"lng" : 119.261667,
		"lat" : 25.499023999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1501,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22818784763483,
		  25.508275924961289
		]
	  },
	  "properties" : {
		"FID" : 1501,
		"name" : "福兴寺",
		"lng" : 119.23291500000001,
		"lat" : 25.505464
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1502,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26459821536419,
		  25.531063425345486
		]
	  },
	  "properties" : {
		"FID" : 1502,
		"name" : "天生林艺园",
		"lng" : 119.26932600000001,
		"lat" : 25.528245999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1503,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26578327743503,
		  25.532254942654632
		]
	  },
	  "properties" : {
		"FID" : 1503,
		"name" : "星球大战",
		"lng" : 119.270512,
		"lat" : 25.529437999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1504,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26655965909566,
		  25.532699486505056
		]
	  },
	  "properties" : {
		"FID" : 1504,
		"name" : "翠竹园",
		"lng" : 119.271289,
		"lat" : 25.529883000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1505,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26761625923393,
		  25.526792642136186
		]
	  },
	  "properties" : {
		"FID" : 1505,
		"name" : "观音阁",
		"lng" : 119.272346,
		"lat" : 25.523979000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1506,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26651092040669,
		  25.529646494014827
		]
	  },
	  "properties" : {
		"FID" : 1506,
		"name" : "旋转木马",
		"lng" : 119.27124000000001,
		"lat" : 25.526831000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1507,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26086943102919,
		  25.532597406655782
		]
	  },
	  "properties" : {
		"FID" : 1507,
		"name" : "福园",
		"lng" : 119.265595,
		"lat" : 25.529776999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1508,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26659477850352,
		  25.489763027455112
		]
	  },
	  "properties" : {
		"FID" : 1508,
		"name" : "咸宁宫",
		"lng" : 119.271321,
		"lat" : 25.48696
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1509,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.262390493347,
		  25.533311705398692
		]
	  },
	  "properties" : {
		"FID" : 1509,
		"name" : "民族园",
		"lng" : 119.267117,
		"lat" : 25.530491999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1510,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26219195755567,
		  25.542265931559974
		]
	  },
	  "properties" : {
		"FID" : 1510,
		"name" : "即心寺",
		"lng" : 119.266919,
		"lat" : 25.539442999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1511,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27972802244827,
		  25.552320038662501
		]
	  },
	  "properties" : {
		"FID" : 1511,
		"name" : "福清渔溪霞瑶寺",
		"lng" : 119.28447199999999,
		"lat" : 25.549510000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1512,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22525587033023,
		  25.489094233939586
		]
	  },
	  "properties" : {
		"FID" : 1512,
		"name" : "福清千佛寺",
		"lng" : 119.229984,
		"lat" : 25.48629
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1513,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28742259617837,
		  25.47256074698997
		]
	  },
	  "properties" : {
		"FID" : 1513,
		"name" : "江阴芝山教会",
		"lng" : 119.292171,
		"lat" : 25.469785999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1514,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29089215419533,
		  25.476217601189518
		]
	  },
	  "properties" : {
		"FID" : 1514,
		"name" : "泰山府",
		"lng" : 119.295646,
		"lat" : 25.473447
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1515,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22516679084431,
		  25.489123176992337
		]
	  },
	  "properties" : {
		"FID" : 1515,
		"name" : "明善寺",
		"lng" : 119.229895,
		"lat" : 25.486319000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1516,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2910139665228,
		  25.476224417987769
		]
	  },
	  "properties" : {
		"FID" : 1516,
		"name" : "五佛寺",
		"lng" : 119.295768,
		"lat" : 25.473454
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1517,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28763624387729,
		  25.473143594482714
		]
	  },
	  "properties" : {
		"FID" : 1517,
		"name" : "基督教芝山堂",
		"lng" : 119.292385,
		"lat" : 25.470369000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1518,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29141198760865,
		  25.481186159976968
		]
	  },
	  "properties" : {
		"FID" : 1518,
		"name" : "嵩山胜境",
		"lng" : 119.296167,
		"lat" : 25.478414999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1519,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21927531520323,
		  25.485170142838246
		]
	  },
	  "properties" : {
		"FID" : 1519,
		"name" : "福德庙",
		"lng" : 119.224009,
		"lat" : 25.482372000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1520,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2051462787195,
		  25.490777454199552
		]
	  },
	  "properties" : {
		"FID" : 1520,
		"name" : "江滨公园",
		"lng" : 119.20989899999999,
		"lat" : 25.487994
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1521,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20544355877662,
		  25.493168546686839
		]
	  },
	  "properties" : {
		"FID" : 1521,
		"name" : "福源寺",
		"lng" : 119.210196,
		"lat" : 25.490383999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1522,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21517077672213,
		  25.482364256509953
		]
	  },
	  "properties" : {
		"FID" : 1522,
		"name" : "加头村文兴堂",
		"lng" : 119.219909,
		"lat" : 25.479571
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1523,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20937636052631,
		  25.479205704284404
		]
	  },
	  "properties" : {
		"FID" : 1523,
		"name" : "鳌峰宫",
		"lng" : 119.214122,
		"lat" : 25.476420000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1524,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20546436838596,
		  25.496202461484479
		]
	  },
	  "properties" : {
		"FID" : 1524,
		"name" : "万佛殿",
		"lng" : 119.210217,
		"lat" : 25.493417000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1525,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23230170305862,
		  25.561927583868812
		]
	  },
	  "properties" : {
		"FID" : 1525,
		"name" : "碧峰寺",
		"lng" : 119.23703,
		"lat" : 25.559094999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1526,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32510346438875,
		  25.527006752634666
		]
	  },
	  "properties" : {
		"FID" : 1526,
		"name" : "竹埔禅寺",
		"lng" : 119.32992299999999,
		"lat" : 25.524281999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1527,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30008030043129,
		  25.419152457574842
		]
	  },
	  "properties" : {
		"FID" : 1527,
		"name" : "玉玺山公园",
		"lng" : 119.304845,
		"lat" : 25.416409999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1528,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29259058149621,
		  25.475273737290351
		]
	  },
	  "properties" : {
		"FID" : 1528,
		"name" : "高局基督教",
		"lng" : 119.297347,
		"lat" : 25.472505999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1529,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20338985521903,
		  25.48646680620125
		]
	  },
	  "properties" : {
		"FID" : 1529,
		"name" : "凤池宫",
		"lng" : 119.208145,
		"lat" : 25.483687
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1530,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20334391127594,
		  25.484707247664037
		]
	  },
	  "properties" : {
		"FID" : 1530,
		"name" : "炉台宫",
		"lng" : 119.208099,
		"lat" : 25.481928
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1531,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32230981407861,
		  25.487136835587574
		]
	  },
	  "properties" : {
		"FID" : 1531,
		"name" : "锦埔翁氏支祠",
		"lng" : 119.32712100000001,
		"lat" : 25.484418999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1532,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27277244263909,
		  25.583574761604897
		]
	  },
	  "properties" : {
		"FID" : 1532,
		"name" : "资福禅寺",
		"lng" : 119.277511,
		"lat" : 25.580745
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1533,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20213809510668,
		  25.483148104037618
		]
	  },
	  "properties" : {
		"FID" : 1533,
		"name" : "江口镇港后村陈氏宗祠",
		"lng" : 119.206895,
		"lat" : 25.480371000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1534,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31010800642559,
		  25.516247646525084
		]
	  },
	  "properties" : {
		"FID" : 1534,
		"name" : "瓊田禅寺",
		"lng" : 119.314898,
		"lat" : 25.513497999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1535,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31463286319887,
		  25.591498715344066
		]
	  },
	  "properties" : {
		"FID" : 1535,
		"name" : "九龙寺",
		"lng" : 119.31943699999999,
		"lat" : 25.588730000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1536,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31361289053908,
		  25.455288003766871
		]
	  },
	  "properties" : {
		"FID" : 1536,
		"name" : "琴江翁氏宗祠",
		"lng" : 119.318405,
		"lat" : 25.452562
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1537,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31015061276592,
		  25.466345209320647
		]
	  },
	  "properties" : {
		"FID" : 1537,
		"name" : "沾泽村上銮宫",
		"lng" : 119.314937,
		"lat" : 25.463609999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1538,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.16402144969335,
		  25.585793709235652
		]
	  },
	  "properties" : {
		"FID" : 1538,
		"name" : "文明宫",
		"lng" : 119.16886,
		"lat" : 25.583048000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1539,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30424843078926,
		  25.453237650971527
		]
	  },
	  "properties" : {
		"FID" : 1539,
		"name" : "占泽河休闲公园",
		"lng" : 119.309023,
		"lat" : 25.450495
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1540,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35809010275759,
		  25.560724060791909
		]
	  },
	  "properties" : {
		"FID" : 1540,
		"name" : "妈祖宫",
		"lng" : 119.36296900000001,
		"lat" : 25.558045
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1541,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30775365736039,
		  25.580189900001809
		]
	  },
	  "properties" : {
		"FID" : 1541,
		"name" : "林氏宗祠",
		"lng" : 119.312544,
		"lat" : 25.577413
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1542,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29406448368692,
		  25.607519693650993
		]
	  },
	  "properties" : {
		"FID" : 1542,
		"name" : "基督教渔溪堂",
		"lng" : 119.298833,
		"lat" : 25.604707999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1543,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29661038244122,
		  25.60653415737762
		]
	  },
	  "properties" : {
		"FID" : 1543,
		"name" : "东门堂基督徒聚会处",
		"lng" : 119.301383,
		"lat" : 25.603726999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1544,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32310088486096,
		  25.5464842982947
		]
	  },
	  "properties" : {
		"FID" : 1544,
		"name" : "福德堂",
		"lng" : 119.327918,
		"lat" : 25.543748999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1545,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32505486474774,
		  25.455414253325031
		]
	  },
	  "properties" : {
		"FID" : 1545,
		"name" : "东兴境",
		"lng" : 119.329869,
		"lat" : 25.45271
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1546,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19753059107748,
		  25.575610283100215
		]
	  },
	  "properties" : {
		"FID" : 1546,
		"name" : "灵溪宫",
		"lng" : 119.202302,
		"lat" : 25.572808999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1547,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2986921656609,
		  25.602529989791069
		]
	  },
	  "properties" : {
		"FID" : 1547,
		"name" : "虞阳公园",
		"lng" : 119.303468,
		"lat" : 25.599727999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1548,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36754644003329,
		  25.590180246169908
		]
	  },
	  "properties" : {
		"FID" : 1548,
		"name" : "树下祠堂",
		"lng" : 119.372439,
		"lat" : 25.587502000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1549,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31085958427495,
		  25.462255860212277
		]
	  },
	  "properties" : {
		"FID" : 1549,
		"name" : "普光堂",
		"lng" : 119.315647,
		"lat" : 25.459523000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1550,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29184937512507,
		  25.602407975594851
		]
	  },
	  "properties" : {
		"FID" : 1550,
		"name" : "天主堂",
		"lng" : 119.29661400000001,
		"lat" : 25.599595000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1551,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34054505213778,
		  25.574245966694907
		]
	  },
	  "properties" : {
		"FID" : 1551,
		"name" : "松湖境",
		"lng" : 119.34539700000001,
		"lat" : 25.571532999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1552,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32486643557384,
		  25.547022111559347
		]
	  },
	  "properties" : {
		"FID" : 1552,
		"name" : "霞堂寺",
		"lng" : 119.32968700000001,
		"lat" : 25.54429
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1553,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29983388661475,
		  25.457758422910469
		]
	  },
	  "properties" : {
		"FID" : 1553,
		"name" : "报恩寺",
		"lng" : 119.30460100000001,
		"lat" : 25.455006999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1554,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32936823534702,
		  25.44671096166968
		]
	  },
	  "properties" : {
		"FID" : 1554,
		"name" : "赤厝朝阳公园",
		"lng" : 119.33419000000001,
		"lat" : 25.444016999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1555,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35745294340718,
		  25.561204164859042
		]
	  },
	  "properties" : {
		"FID" : 1555,
		"name" : "陈氏祠堂",
		"lng" : 119.362331,
		"lat" : 25.558523999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1556,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30322368914899,
		  25.433920060789077
		]
	  },
	  "properties" : {
		"FID" : 1556,
		"name" : "东坪山基督教",
		"lng" : 119.30799500000001,
		"lat" : 25.431180000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1557,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29470032421892,
		  25.432853185737056
		]
	  },
	  "properties" : {
		"FID" : 1557,
		"name" : "玉屿竹溪寺",
		"lng" : 119.299457,
		"lat" : 25.430098999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1558,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30030268879302,
		  25.435829540920501
		]
	  },
	  "properties" : {
		"FID" : 1558,
		"name" : "下石螺江境",
		"lng" : 119.305069,
		"lat" : 25.433084000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1559,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29328687155012,
		  25.605606101549835
		]
	  },
	  "properties" : {
		"FID" : 1559,
		"name" : "文武名祠",
		"lng" : 119.29805399999999,
		"lat" : 25.602793999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1560,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30359713322612,
		  25.445992097786934
		]
	  },
	  "properties" : {
		"FID" : 1560,
		"name" : "福清何厝基督教堂",
		"lng" : 119.30837,
		"lat" : 25.443249999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1561,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29121638069365,
		  25.602099815003093
		]
	  },
	  "properties" : {
		"FID" : 1561,
		"name" : "福清渔溪虞粮基督教聚会点",
		"lng" : 119.29598,
		"lat" : 25.599285999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1562,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30492574126502,
		  25.446007745602067
		]
	  },
	  "properties" : {
		"FID" : 1562,
		"name" : "震武殿",
		"lng" : 119.309701,
		"lat" : 25.443268
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1563,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30834010968199,
		  25.437550674697277
		]
	  },
	  "properties" : {
		"FID" : 1563,
		"name" : "钱塘基督教堂",
		"lng" : 119.313121,
		"lat" : 25.434819000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1564,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30035659290883,
		  25.435861455677415
		]
	  },
	  "properties" : {
		"FID" : 1564,
		"name" : "螺江胜境",
		"lng" : 119.30512299999999,
		"lat" : 25.433115999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1565,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33524459513765,
		  25.521847867802322
		]
	  },
	  "properties" : {
		"FID" : 1565,
		"name" : "高岭基督教堂",
		"lng" : 119.34008300000001,
		"lat" : 25.519144000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1566,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3574240275255,
		  25.560614986376958
		]
	  },
	  "properties" : {
		"FID" : 1566,
		"name" : "文化公园",
		"lng" : 119.362302,
		"lat" : 25.557935000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1567,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19285201278238,
		  25.592361596717708
		]
	  },
	  "properties" : {
		"FID" : 1567,
		"name" : "山头寺",
		"lng" : 119.197633,
		"lat" : 25.589561
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1568,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18527297920453,
		  25.57363118689883
		]
	  },
	  "properties" : {
		"FID" : 1568,
		"name" : "福清西峰寺",
		"lng" : 119.190067,
		"lat" : 25.570851000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1569,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26885814792485,
		  25.595968514197423
		]
	  },
	  "properties" : {
		"FID" : 1569,
		"name" : "竹渎禅寺",
		"lng" : 119.273594,
		"lat" : 25.593129999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1570,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31361582624154,
		  25.456083191420461
		]
	  },
	  "properties" : {
		"FID" : 1570,
		"name" : "鳌峰林氏宗祠",
		"lng" : 119.31840800000001,
		"lat" : 25.453357
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1571,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2602073709696,
		  25.687984914345421
		]
	  },
	  "properties" : {
		"FID" : 1571,
		"name" : "应峰寺",
		"lng" : 119.264944,
		"lat" : 25.685096999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1572,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25985654463003,
		  25.688110176877892
		]
	  },
	  "properties" : {
		"FID" : 1572,
		"name" : "应峯寺五方殿",
		"lng" : 119.264593,
		"lat" : 25.685222
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1573,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24136916094534,
		  25.702256523950471
		]
	  },
	  "properties" : {
		"FID" : 1573,
		"name" : "东张镇香山小洱海",
		"lng" : 119.246104,
		"lat" : 25.699356999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1574,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24087102841321,
		  25.702419537383467
		]
	  },
	  "properties" : {
		"FID" : 1574,
		"name" : "香山宫",
		"lng" : 119.245606,
		"lat" : 25.69952
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1575,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23555713288492,
		  25.702205058257331
		]
	  },
	  "properties" : {
		"FID" : 1575,
		"name" : "香山寺",
		"lng" : 119.24029400000001,
		"lat" : 25.699307000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1576,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24455490380686,
		  25.712969532679164
		]
	  },
	  "properties" : {
		"FID" : 1576,
		"name" : "东张玉井庙",
		"lng" : 119.24929,
		"lat" : 25.710063999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1577,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25037859435467,
		  25.71583054553523
		]
	  },
	  "properties" : {
		"FID" : 1577,
		"name" : "白豸公园",
		"lng" : 119.25511400000001,
		"lat" : 25.712924000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1578,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27993797168375,
		  25.698702573334586
		]
	  },
	  "properties" : {
		"FID" : 1578,
		"name" : "紫云宝塔",
		"lng" : 119.284693,
		"lat" : 25.695827000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1579,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24496275477827,
		  25.715510919425196
		]
	  },
	  "properties" : {
		"FID" : 1579,
		"name" : "西山寺",
		"lng" : 119.249698,
		"lat" : 25.712603999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1580,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2478219652244,
		  25.713696780858029
		]
	  },
	  "properties" : {
		"FID" : 1580,
		"name" : "元临俄候祖厅",
		"lng" : 119.252557,
		"lat" : 25.710791
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1581,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23732069753571,
		  25.718448407304528
		]
	  },
	  "properties" : {
		"FID" : 1581,
		"name" : "东张滑翔伞基地",
		"lng" : 119.242058,
		"lat" : 25.715541000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1582,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24003951828109,
		  25.719889849184288
		]
	  },
	  "properties" : {
		"FID" : 1582,
		"name" : "溪柄山庄公园",
		"lng" : 119.244776,
		"lat" : 25.716981000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1583,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29246791410169,
		  25.71714297920726
		]
	  },
	  "properties" : {
		"FID" : 1583,
		"name" : "石竹山省级风景名胜区",
		"lng" : 119.297242,
		"lat" : 25.714275000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1584,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21341246223719,
		  25.701799232567975
		]
	  },
	  "properties" : {
		"FID" : 1584,
		"name" : "宋朝请大夫何一之墓道",
		"lng" : 119.218169,
		"lat" : 25.698917999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1585,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22435081785834,
		  25.683450955965196
		]
	  },
	  "properties" : {
		"FID" : 1585,
		"name" : "园池王氏支祠",
		"lng" : 119.229094,
		"lat" : 25.680568999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1586,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22152400106516,
		  25.69868361268032
		]
	  },
	  "properties" : {
		"FID" : 1586,
		"name" : "万安境",
		"lng" : 119.226271,
		"lat" : 25.695796000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1587,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22500641112984,
		  25.683310375190995
		]
	  },
	  "properties" : {
		"FID" : 1587,
		"name" : "开闽王氏祖厅廳",
		"lng" : 119.229749,
		"lat" : 25.680427999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1588,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23995047262081,
		  25.720161981854218
		]
	  },
	  "properties" : {
		"FID" : 1588,
		"name" : "移民休闲公园",
		"lng" : 119.244687,
		"lat" : 25.717252999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1589,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22142789110015,
		  25.698862624844708
		]
	  },
	  "properties" : {
		"FID" : 1589,
		"name" : "万安宫",
		"lng" : 119.226175,
		"lat" : 25.695975000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1590,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30330083081877,
		  25.673673119427775
		]
	  },
	  "properties" : {
		"FID" : 1590,
		"name" : "宅角宫",
		"lng" : 119.30809000000001,
		"lat" : 25.670846000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1591,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21566337803387,
		  25.673193856266096
		]
	  },
	  "properties" : {
		"FID" : 1591,
		"name" : "灵石西山寺",
		"lng" : 119.220415,
		"lat" : 25.670324999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1592,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24840424692128,
		  25.736669446314561
		]
	  },
	  "properties" : {
		"FID" : 1592,
		"name" : "梨洋报恩寺",
		"lng" : 119.253141,
		"lat" : 25.733751000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1593,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26270075118795,
		  25.731130656386917
		]
	  },
	  "properties" : {
		"FID" : 1593,
		"name" : "祖厅",
		"lng" : 119.267442,
		"lat" : 25.728221000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1594,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21897990368191,
		  25.650082812059185
		]
	  },
	  "properties" : {
		"FID" : 1594,
		"name" : "灵石山国家森林公园",
		"lng" : 119.223726,
		"lat" : 25.647221999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1595,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29867793732652,
		  25.700421912530501
		]
	  },
	  "properties" : {
		"FID" : 1595,
		"name" : "福清西站站前广场",
		"lng" : 119.303461,
		"lat" : 25.697572999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1596,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2180756640518,
		  25.666866130777731
		]
	  },
	  "properties" : {
		"FID" : 1596,
		"name" : "云石寺",
		"lng" : 119.222824,
		"lat" : 25.663997999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1597,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31155365136912,
		  25.700041788582077
		]
	  },
	  "properties" : {
		"FID" : 1597,
		"name" : "圣来寺",
		"lng" : 119.31636,
		"lat" : 25.697216000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1598,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30636688576423,
		  25.678937324045986
		]
	  },
	  "properties" : {
		"FID" : 1598,
		"name" : "福清武汉(湖北全境)",
		"lng" : 119.311162,
		"lat" : 25.676113000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1599,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.272523020639,
		  25.741821529867156
		]
	  },
	  "properties" : {
		"FID" : 1599,
		"name" : "延寿寺",
		"lng" : 119.27727299999999,
		"lat" : 25.738914000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1600,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27551218727136,
		  25.643407030266705
		]
	  },
	  "properties" : {
		"FID" : 1600,
		"name" : "侨丰陈白林家古厝",
		"lng" : 119.280258,
		"lat" : 25.640554000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1601,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31171746845948,
		  25.698337581449856
		]
	  },
	  "properties" : {
		"FID" : 1601,
		"name" : "颐景公园",
		"lng" : 119.316524,
		"lat" : 25.695512999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1602,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30938600377021,
		  25.696314827196868
		]
	  },
	  "properties" : {
		"FID" : 1602,
		"name" : "仙董境",
		"lng" : 119.314188,
		"lat" : 25.693487000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1603,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27169655807653,
		  25.745413392844444
		]
	  },
	  "properties" : {
		"FID" : 1603,
		"name" : "南埔元帅宫",
		"lng" : 119.27644600000001,
		"lat" : 25.742502999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1604,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31216726456003,
		  25.703068255311887
		]
	  },
	  "properties" : {
		"FID" : 1604,
		"name" : "宏路基督徒聚会处",
		"lng" : 119.316975,
		"lat" : 25.700241999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1605,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31412017606269,
		  25.681203174199869
		]
	  },
	  "properties" : {
		"FID" : 1605,
		"name" : "尊王庙",
		"lng" : 119.31892999999999,
		"lat" : 25.678391999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1606,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31246798474109,
		  25.685730596717914
		]
	  },
	  "properties" : {
		"FID" : 1606,
		"name" : "嵩山境",
		"lng" : 119.317275,
		"lat" : 25.682914
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1607,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30373861413986,
		  25.746755786849562
		]
	  },
	  "properties" : {
		"FID" : 1607,
		"name" : "太城寺",
		"lng" : 119.30853399999999,
		"lat" : 25.74389
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1608,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18703011821955,
		  25.685938382243663
		]
	  },
	  "properties" : {
		"FID" : 1608,
		"name" : "华石村瑞峰寺",
		"lng" : 119.191829,
		"lat" : 25.683104
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1609,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3271486234801,
		  25.700276287753173
		]
	  },
	  "properties" : {
		"FID" : 1609,
		"name" : "福清市湿地公园",
		"lng" : 119.331985,
		"lat" : 25.697479999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1610,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31665324619905,
		  25.682186892978979
		]
	  },
	  "properties" : {
		"FID" : 1610,
		"name" : "灵岩寺院",
		"lng" : 119.321468,
		"lat" : 25.679379999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1611,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22753070429965,
		  25.748481667875019
		]
	  },
	  "properties" : {
		"FID" : 1611,
		"name" : "岚湖山观景台",
		"lng" : 119.232276,
		"lat" : 25.745562
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1612,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31692973239835,
		  25.708780350156207
		]
	  },
	  "properties" : {
		"FID" : 1612,
		"name" : "福清宏路基督教堂",
		"lng" : 119.321747,
		"lat" : 25.705960000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1613,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27564361655854,
		  25.635641262014232
		]
	  },
	  "properties" : {
		"FID" : 1613,
		"name" : "回龙寺",
		"lng" : 119.280389,
		"lat" : 25.632791999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1614,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3555712760526,
		  25.712334778479153
		]
	  },
	  "properties" : {
		"FID" : 1614,
		"name" : "龙江公园",
		"lng" : 119.36045799999999,
		"lat" : 25.709582000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1615,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38090258718948,
		  25.715255836052865
		]
	  },
	  "properties" : {
		"FID" : 1615,
		"name" : "瑞云塔",
		"lng" : 119.38581499999999,
		"lat" : 25.712530000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1616,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27170255241276,
		  25.745412386454223
		]
	  },
	  "properties" : {
		"FID" : 1616,
		"name" : "瓜园境",
		"lng" : 119.27645200000001,
		"lat" : 25.742502000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1617,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31428580298514,
		  25.708820369376969
		]
	  },
	  "properties" : {
		"FID" : 1617,
		"name" : "真耶稣教会",
		"lng" : 119.319098,
		"lat" : 25.705995000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1618,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31913568553423,
		  25.70596964225
		]
	  },
	  "properties" : {
		"FID" : 1618,
		"name" : "宏路街道南宅村厚德堂",
		"lng" : 119.32395699999999,
		"lat" : 25.703154999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1619,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31230861197884,
		  25.708232758785257
		]
	  },
	  "properties" : {
		"FID" : 1619,
		"name" : "钟氏外厝祖厅",
		"lng" : 119.317117,
		"lat" : 25.705404000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1620,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31536215525421,
		  25.703276367289071
		]
	  },
	  "properties" : {
		"FID" : 1620,
		"name" : "玄天上帝",
		"lng" : 119.320176,
		"lat" : 25.700455999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1621,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36570887277644,
		  25.730697010708415
		]
	  },
	  "properties" : {
		"FID" : 1621,
		"name" : "福清革命历史纪念碑",
		"lng" : 119.37061,
		"lat" : 25.727948000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1622,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35075991352745,
		  25.707238546052995
		]
	  },
	  "properties" : {
		"FID" : 1622,
		"name" : "林则徐公园",
		"lng" : 119.355639,
		"lat" : 25.704481000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1623,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31890218950836,
		  25.718667972595441
		]
	  },
	  "properties" : {
		"FID" : 1623,
		"name" : "NS蹦床公园",
		"lng" : 119.323724,
		"lat" : 25.715845999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1624,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37846238771823,
		  25.722632672457895
		]
	  },
	  "properties" : {
		"FID" : 1624,
		"name" : "街心公园",
		"lng" : 119.383374,
		"lat" : 25.719901
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1625,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31939717681188,
		  25.692603064863423
		]
	  },
	  "properties" : {
		"FID" : 1625,
		"name" : "丁氏宗祠",
		"lng" : 119.324218,
		"lat" : 25.689796000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1626,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38358360621936,
		  25.725815946455686
		]
	  },
	  "properties" : {
		"FID" : 1626,
		"name" : "福清市体育公园",
		"lng" : 119.388498,
		"lat" : 25.723085999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1627,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3217117810949,
		  25.704899147789078
		]
	  },
	  "properties" : {
		"FID" : 1627,
		"name" : "宏欣公园",
		"lng" : 119.326538,
		"lat" : 25.702089999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1628,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35115545729322,
		  25.731694333601975
		]
	  },
	  "properties" : {
		"FID" : 1628,
		"name" : "应天禅寺",
		"lng" : 119.356037,
		"lat" : 25.728923999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1629,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34571007941445,
		  25.708107433303937
		]
	  },
	  "properties" : {
		"FID" : 1629,
		"name" : "龙江生态文化园",
		"lng" : 119.35058100000001,
		"lat" : 25.705341000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1630,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36887926652463,
		  25.720803806487552
		]
	  },
	  "properties" : {
		"FID" : 1630,
		"name" : "福清茶亭西涧寺",
		"lng" : 119.373783,
		"lat" : 25.718063999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1631,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38492038207784,
		  25.682716172551487
		]
	  },
	  "properties" : {
		"FID" : 1631,
		"name" : "林氏宗祠(苍霞)",
		"lng" : 119.389832,
		"lat" : 25.680009999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1632,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31161103366152,
		  25.720309629161434
		]
	  },
	  "properties" : {
		"FID" : 1632,
		"name" : "仙埔境",
		"lng" : 119.316419,
		"lat" : 25.717472999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1633,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38038382511694,
		  25.715634403726458
		]
	  },
	  "properties" : {
		"FID" : 1633,
		"name" : "天后宫",
		"lng" : 119.385296,
		"lat" : 25.712907999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1634,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31058723554411,
		  25.662907586211166
		]
	  },
	  "properties" : {
		"FID" : 1634,
		"name" : "清灵寺",
		"lng" : 119.315389,
		"lat" : 25.660098999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1635,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31736858702438,
		  25.71280269198795
		]
	  },
	  "properties" : {
		"FID" : 1635,
		"name" : "龙塘村口袋公园",
		"lng" : 119.322187,
		"lat" : 25.709980999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1636,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37766239741205,
		  25.729152927483387
		]
	  },
	  "properties" : {
		"FID" : 1636,
		"name" : "万寿禅寺",
		"lng" : 119.38257400000001,
		"lat" : 25.726417000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1637,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38173596039654,
		  25.638463382099896
		]
	  },
	  "properties" : {
		"FID" : 1637,
		"name" : "福清市吉水禅寺",
		"lng" : 119.38664300000001,
		"lat" : 25.635777000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1638,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37598888138885,
		  25.711258497724476
		]
	  },
	  "properties" : {
		"FID" : 1638,
		"name" : "南涧寺",
		"lng" : 119.380898,
		"lat" : 25.708531000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1639,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34238639677332,
		  25.713381077356814
		]
	  },
	  "properties" : {
		"FID" : 1639,
		"name" : "圣帝宫",
		"lng" : 119.347252,
		"lat" : 25.710605999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1640,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3088826779621,
		  25.646057585007394
		]
	  },
	  "properties" : {
		"FID" : 1640,
		"name" : "邱氏纪念堂",
		"lng" : 119.31368000000001,
		"lat" : 25.643253999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1641,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33719341593472,
		  25.703930358104966
		]
	  },
	  "properties" : {
		"FID" : 1641,
		"name" : "市民休闲公园",
		"lng" : 119.342049,
		"lat" : 25.701150999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1642,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36445619285769,
		  25.73208334221189
		]
	  },
	  "properties" : {
		"FID" : 1642,
		"name" : "清风广场",
		"lng" : 119.369356,
		"lat" : 25.729331999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1643,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32595674001452,
		  25.742807986591718
		]
	  },
	  "properties" : {
		"FID" : 1643,
		"name" : "珠山寺",
		"lng" : 119.330794,
		"lat" : 25.739985999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1644,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31788948335789,
		  25.714132424196396
		]
	  },
	  "properties" : {
		"FID" : 1644,
		"name" : "龙塘胜境",
		"lng" : 119.322709,
		"lat" : 25.711310999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1645,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31955697889133,
		  25.704524064592075
		]
	  },
	  "properties" : {
		"FID" : 1645,
		"name" : "唐正亭支祠",
		"lng" : 119.32437899999999,
		"lat" : 25.701711
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1646,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37924693216115,
		  25.722515007324006
		]
	  },
	  "properties" : {
		"FID" : 1646,
		"name" : "福清一拂法治文化公园",
		"lng" : 119.384159,
		"lat" : 25.719784000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1647,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36226139862455,
		  25.750963923814101
		]
	  },
	  "properties" : {
		"FID" : 1647,
		"name" : "基督教马山堂",
		"lng" : 119.36716,
		"lat" : 25.748199
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1648,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36555958664803,
		  25.683543867406883
		]
	  },
	  "properties" : {
		"FID" : 1648,
		"name" : "后坑莽天圣王寺",
		"lng" : 119.370457,
		"lat" : 25.680820000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1649,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32095234451856,
		  25.636553421832584
		]
	  },
	  "properties" : {
		"FID" : 1649,
		"name" : "印林禅寺",
		"lng" : 119.325772,
		"lat" : 25.633776999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1650,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3193494287319,
		  25.70387311271098
		]
	  },
	  "properties" : {
		"FID" : 1650,
		"name" : "唐肇仪故居",
		"lng" : 119.32417100000001,
		"lat" : 25.701059999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1651,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36634201016662,
		  25.693004824346772
		]
	  },
	  "properties" : {
		"FID" : 1651,
		"name" : "玉融山公园",
		"lng" : 119.371241,
		"lat" : 25.690276999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1652,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37236607244786,
		  25.706834508958199
		]
	  },
	  "properties" : {
		"FID" : 1652,
		"name" : "笃思公园",
		"lng" : 119.377272,
		"lat" : 25.704105999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1653,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3604984514381,
		  25.713420260204082
		]
	  },
	  "properties" : {
		"FID" : 1653,
		"name" : "天宝陂(福清现存的唐朝古迹)",
		"lng" : 119.365392,
		"lat" : 25.710674000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1654,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30419994154322,
		  25.744633755869465
		]
	  },
	  "properties" : {
		"FID" : 1654,
		"name" : "霞满半山腰主题公园",
		"lng" : 119.30899599999999,
		"lat" : 25.741769999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1655,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.15228458879162,
		  25.732448373006275
		]
	  },
	  "properties" : {
		"FID" : 1655,
		"name" : "南少林寺广场",
		"lng" : 119.157158,
		"lat" : 25.729652999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1656,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34487034274552,
		  25.710235026820172
		]
	  },
	  "properties" : {
		"FID" : 1656,
		"name" : "福人基督教堂",
		"lng" : 119.34974,
		"lat" : 25.707466
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1657,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18137851242071,
		  25.691689353297008
		]
	  },
	  "properties" : {
		"FID" : 1657,
		"name" : "侨翅亭",
		"lng" : 119.186189,
		"lat" : 25.688862
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1658,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38346825668894,
		  25.717770578457777
		]
	  },
	  "properties" : {
		"FID" : 1658,
		"name" : "竹溪寺",
		"lng" : 119.38838199999999,
		"lat" : 25.715045
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1659,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37993122914899,
		  25.726759854244278
		]
	  },
	  "properties" : {
		"FID" : 1659,
		"name" : "福华堂",
		"lng" : 119.384844,
		"lat" : 25.724027
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1660,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37768727069762,
		  25.717348384133341
		]
	  },
	  "properties" : {
		"FID" : 1660,
		"name" : "福清市南门教堂",
		"lng" : 119.382598,
		"lat" : 25.714618999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1661,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35422813440857,
		  25.713718574638225
		]
	  },
	  "properties" : {
		"FID" : 1661,
		"name" : "龙泉境",
		"lng" : 119.35911299999999,
		"lat" : 25.710963
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1662,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3771718707883,
		  25.71385089836582
		]
	  },
	  "properties" : {
		"FID" : 1662,
		"name" : "水南园",
		"lng" : 119.382082,
		"lat" : 25.711123000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1663,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37837115336275,
		  25.713207582164056
		]
	  },
	  "properties" : {
		"FID" : 1663,
		"name" : "甲飞兰公园",
		"lng" : 119.38328199999999,
		"lat" : 25.710481000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1664,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37431427935377,
		  25.696063895732159
		]
	  },
	  "properties" : {
		"FID" : 1664,
		"name" : "霞楼延庆寺",
		"lng" : 119.379221,
		"lat" : 25.693342999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1665,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37981688076675,
		  25.718941619669163
		]
	  },
	  "properties" : {
		"FID" : 1665,
		"name" : "福清市利桥天主教堂",
		"lng" : 119.38472899999999,
		"lat" : 25.716213
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1666,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36574461930171,
		  25.733534557977226
		]
	  },
	  "properties" : {
		"FID" : 1666,
		"name" : "虎溪西园",
		"lng" : 119.37064599999999,
		"lat" : 25.730784
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1667,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38261148861729,
		  25.719312939966848
		]
	  },
	  "properties" : {
		"FID" : 1667,
		"name" : "林氏宗祠",
		"lng" : 119.387525,
		"lat" : 25.716586
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1668,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3704111086757,
		  25.743024582994082
		]
	  },
	  "properties" : {
		"FID" : 1668,
		"name" : "福清基督教堂奎岭分堂",
		"lng" : 119.37531799999999,
		"lat" : 25.740273999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1669,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36159439993418,
		  25.735416946087749
		]
	  },
	  "properties" : {
		"FID" : 1669,
		"name" : "溪前千秋宫",
		"lng" : 119.366491,
		"lat" : 25.732659999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1670,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37458819098393,
		  25.720974059226176
		]
	  },
	  "properties" : {
		"FID" : 1670,
		"name" : "福清西大基督教堂",
		"lng" : 119.379497,
		"lat" : 25.718240000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1671,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34416994277406,
		  25.704869357114092
		]
	  },
	  "properties" : {
		"FID" : 1671,
		"name" : "福清市气象科普公园",
		"lng" : 119.34903799999999,
		"lat" : 25.702102
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1672,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33454840151721,
		  25.729365147558187
		]
	  },
	  "properties" : {
		"FID" : 1672,
		"name" : "清泰公园",
		"lng" : 119.339401,
		"lat" : 25.726566999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1673,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33658809250592,
		  25.709736589900114
		]
	  },
	  "properties" : {
		"FID" : 1673,
		"name" : "三相宫",
		"lng" : 119.341443,
		"lat" : 25.706952999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1674,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36805141182401,
		  25.71673651461683
		]
	  },
	  "properties" : {
		"FID" : 1674,
		"name" : "旌马亭",
		"lng" : 119.37295399999999,
		"lat" : 25.713998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1675,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33032612802758,
		  25.705793187289743
		]
	  },
	  "properties" : {
		"FID" : 1675,
		"name" : "福清城关基督教堂中联城点",
		"lng" : 119.33516899999999,
		"lat" : 25.702999999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1676,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3207376310599,
		  25.638283635694794
		]
	  },
	  "properties" : {
		"FID" : 1676,
		"name" : "鲤鱼山公园(上塘)",
		"lng" : 119.325557,
		"lat" : 25.635505999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1677,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3312535299158,
		  25.703595257534012
		]
	  },
	  "properties" : {
		"FID" : 1677,
		"name" : "宏路基督教堂中联城聚会处",
		"lng" : 119.33609800000001,
		"lat" : 25.700804999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1678,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38423238197048,
		  25.725633477034567
		]
	  },
	  "properties" : {
		"FID" : 1678,
		"name" : "福清市体育公园-体育文化广场",
		"lng" : 119.38914699999999,
		"lat" : 25.722904
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1679,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35048126055327,
		  25.708458653792118
		]
	  },
	  "properties" : {
		"FID" : 1679,
		"name" : "观音埔湿地公园",
		"lng" : 119.35536,
		"lat" : 25.7057
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1680,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33429615948759,
		  25.72553048437381
		]
	  },
	  "properties" : {
		"FID" : 1680,
		"name" : "老伯宫",
		"lng" : 119.33914799999999,
		"lat" : 25.722733999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1681,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35434796676971,
		  25.71359232181338
		]
	  },
	  "properties" : {
		"FID" : 1681,
		"name" : "境泉龙",
		"lng" : 119.359233,
		"lat" : 25.710837000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1682,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34056675920418,
		  25.711397244836579
		]
	  },
	  "properties" : {
		"FID" : 1682,
		"name" : "王氏宗祠",
		"lng" : 119.345429,
		"lat" : 25.70862
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1683,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37789600185059,
		  25.745690089612026
		]
	  },
	  "properties" : {
		"FID" : 1683,
		"name" : "林氏祖厅",
		"lng" : 119.38280899999999,
		"lat" : 25.742944999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1684,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35589603544399,
		  25.749221921154145
		]
	  },
	  "properties" : {
		"FID" : 1684,
		"name" : "曾氏祖厅",
		"lng" : 119.360786,
		"lat" : 25.746448999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1685,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36883952622699,
		  25.717881246668718
		]
	  },
	  "properties" : {
		"FID" : 1685,
		"name" : "福耀亭",
		"lng" : 119.373743,
		"lat" : 25.715143000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1686,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36730538890858,
		  25.753928333540728
		]
	  },
	  "properties" : {
		"FID" : 1686,
		"name" : "虫出没口袋公园",
		"lng" : 119.37221,
		"lat" : 25.751168
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1687,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37854622887873,
		  25.724065399086044
		]
	  },
	  "properties" : {
		"FID" : 1687,
		"name" : "向高街口袋公园",
		"lng" : 119.383458,
		"lat" : 25.721333000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1688,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37048486486454,
		  25.718789944250997
		]
	  },
	  "properties" : {
		"FID" : 1688,
		"name" : "龙江街道党建主题公园",
		"lng" : 119.37539,
		"lat" : 25.716052999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1689,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38330566430292,
		  25.713202182629999
		]
	  },
	  "properties" : {
		"FID" : 1689,
		"name" : "吴氏宗祠",
		"lng" : 119.38821900000001,
		"lat" : 25.710478999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1690,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36569070967231,
		  25.719848017854755
		]
	  },
	  "properties" : {
		"FID" : 1690,
		"name" : "龙江融侨园",
		"lng" : 119.370591,
		"lat" : 25.717105
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1691,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35037749204872,
		  25.707557337236217
		]
	  },
	  "properties" : {
		"FID" : 1691,
		"name" : "福清市党建公园",
		"lng" : 119.355256,
		"lat" : 25.704799000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1692,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36780632826628,
		  25.721212252255803
		]
	  },
	  "properties" : {
		"FID" : 1692,
		"name" : "九亩底广场及茶亭公园",
		"lng" : 119.372709,
		"lat" : 25.718471000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1693,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31308274344289,
		  25.646377950904693
		]
	  },
	  "properties" : {
		"FID" : 1693,
		"name" : "祖厅",
		"lng" : 119.317888,
		"lat" : 25.643581999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1694,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34311834398932,
		  25.723734461720316
		]
	  },
	  "properties" : {
		"FID" : 1694,
		"name" : "雲林池-生态造景空间",
		"lng" : 119.34798600000001,
		"lat" : 25.720955
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1695,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35669503800729,
		  25.707488484816913
		]
	  },
	  "properties" : {
		"FID" : 1695,
		"name" : "观音埔池阿财",
		"lng" : 119.361583,
		"lat" : 25.704740000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1696,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34116394192365,
		  25.74814569341649
		]
	  },
	  "properties" : {
		"FID" : 1696,
		"name" : "官品寺",
		"lng" : 119.34603,
		"lat" : 25.745349000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1697,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35006651028104,
		  25.72719058339321
		]
	  },
	  "properties" : {
		"FID" : 1697,
		"name" : "两馆一中心东南角公园",
		"lng" : 119.354946,
		"lat" : 25.724421
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1698,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36105413777952,
		  25.708109627635498
		]
	  },
	  "properties" : {
		"FID" : 1698,
		"name" : "玉融山公园沐风亭",
		"lng" : 119.365948,
		"lat" : 25.705366999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1699,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33554796965211,
		  25.710317826804172
		]
	  },
	  "properties" : {
		"FID" : 1699,
		"name" : "真耶稣教会石门教堂",
		"lng" : 119.340401,
		"lat" : 25.707532
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1700,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35184178997585,
		  25.699766821320079
		]
	  },
	  "properties" : {
		"FID" : 1700,
		"name" : "双拥公园·尊崇小广场",
		"lng" : 119.356722,
		"lat" : 25.697015
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1701,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37054905666794,
		  25.728725370689681
		]
	  },
	  "properties" : {
		"FID" : 1701,
		"name" : "福泰公园",
		"lng" : 119.375455,
		"lat" : 25.725982999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1702,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32565301573598,
		  25.720207911414072
		]
	  },
	  "properties" : {
		"FID" : 1702,
		"name" : "修仁里霞河境",
		"lng" : 119.330488,
		"lat" : 25.717397999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1703,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38514761112147,
		  25.731842448994033
		]
	  },
	  "properties" : {
		"FID" : 1703,
		"name" : "上瓦瑶公园",
		"lng" : 119.390063,
		"lat" : 25.729109999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1704,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29969133395895,
		  25.631117906020606
		]
	  },
	  "properties" : {
		"FID" : 1704,
		"name" : "庄氏祖厅",
		"lng" : 119.30447100000001,
		"lat" : 25.628305000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1705,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38190594517673,
		  25.743926175014721
		]
	  },
	  "properties" : {
		"FID" : 1705,
		"name" : "中和寺",
		"lng" : 119.386821,
		"lat" : 25.741185000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1706,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36534920821414,
		  25.744877474302431
		]
	  },
	  "properties" : {
		"FID" : 1706,
		"name" : "福清市消防文化主题公园",
		"lng" : 119.370251,
		"lat" : 25.74212
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1707,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37601586590114,
		  25.711208447109801
		]
	  },
	  "properties" : {
		"FID" : 1707,
		"name" : "福清龙江水南南涧宫管理委员会",
		"lng" : 119.380925,
		"lat" : 25.708480999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1708,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37916300076488,
		  25.722246922479243
		]
	  },
	  "properties" : {
		"FID" : 1708,
		"name" : "福清市宪法主题公园",
		"lng" : 119.384075,
		"lat" : 25.719515999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1709,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37479630275918,
		  25.73064323385659
		]
	  },
	  "properties" : {
		"FID" : 1709,
		"name" : "大北溪滨水公园",
		"lng" : 119.379706,
		"lat" : 25.727903999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1710,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36392810416071,
		  25.728173827263294
		]
	  },
	  "properties" : {
		"FID" : 1710,
		"name" : "灵石谷",
		"lng" : 119.368827,
		"lat" : 25.725424
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1711,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36457890903098,
		  25.720681854799107
		]
	  },
	  "properties" : {
		"FID" : 1711,
		"name" : "基督教福华堂公馆点",
		"lng" : 119.369478,
		"lat" : 25.717936999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1712,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37465730446327,
		  25.71875977884422
		]
	  },
	  "properties" : {
		"FID" : 1712,
		"name" : "滨水公园",
		"lng" : 119.379566,
		"lat" : 25.716027
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1713,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.370645342006,
		  25.683877214152954
		]
	  },
	  "properties" : {
		"FID" : 1713,
		"name" : "极乐寺",
		"lng" : 119.37554799999999,
		"lat" : 25.681159000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1714,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34312924193274,
		  25.711509752379797
		]
	  },
	  "properties" : {
		"FID" : 1714,
		"name" : "致一广场",
		"lng" : 119.34799599999999,
		"lat" : 25.708736999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1715,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36796450717227,
		  25.743219409620345
		]
	  },
	  "properties" : {
		"FID" : 1715,
		"name" : "中非友好公园",
		"lng" : 119.37286899999999,
		"lat" : 25.740466000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1716,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38351223338979,
		  25.717854598772394
		]
	  },
	  "properties" : {
		"FID" : 1716,
		"name" : "观音佛殿",
		"lng" : 119.388426,
		"lat" : 25.715129000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1717,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33276919406946,
		  25.709892783922864
		]
	  },
	  "properties" : {
		"FID" : 1717,
		"name" : "基督之家",
		"lng" : 119.33761699999999,
		"lat" : 25.707101999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1718,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37864080865546,
		  25.742153483417233
		]
	  },
	  "properties" : {
		"FID" : 1718,
		"name" : "基督教福阳堂",
		"lng" : 119.383554,
		"lat" : 25.739411
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1719,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35273327164798,
		  25.701803491541668
		]
	  },
	  "properties" : {
		"FID" : 1719,
		"name" : "观音埔家园街心公园",
		"lng" : 119.357615,
		"lat" : 25.699051999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1720,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35411259924227,
		  25.736420333261044
		]
	  },
	  "properties" : {
		"FID" : 1720,
		"name" : "古典园林公园",
		"lng" : 119.358999,
		"lat" : 25.733651999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1721,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34563451109679,
		  25.704051387790411
		]
	  },
	  "properties" : {
		"FID" : 1721,
		"name" : "基督教名城聚会点",
		"lng" : 119.350505,
		"lat" : 25.701287000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1722,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36674531953558,
		  25.736235873160325
		]
	  },
	  "properties" : {
		"FID" : 1722,
		"name" : "闽江调水主题公园",
		"lng" : 119.37164799999999,
		"lat" : 25.733485000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1723,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37291918551267,
		  25.738914672957709
		]
	  },
	  "properties" : {
		"FID" : 1723,
		"name" : "长兴境",
		"lng" : 119.37782799999999,
		"lat" : 25.736169
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1724,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37109782044101,
		  25.738409233856679
		]
	  },
	  "properties" : {
		"FID" : 1724,
		"name" : "庄氏宗祠",
		"lng" : 119.37600500000001,
		"lat" : 25.735662000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1725,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38391399960042,
		  25.732225332770408
		]
	  },
	  "properties" : {
		"FID" : 1725,
		"name" : "灵石谷(融北店)",
		"lng" : 119.388829,
		"lat" : 25.729492
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1726,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35630215010987,
		  25.713395260037363
		]
	  },
	  "properties" : {
		"FID" : 1726,
		"name" : "福清体育冠军园",
		"lng" : 119.36118999999999,
		"lat" : 25.710643000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1727,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35790440559914,
		  25.720122585449641
		]
	  },
	  "properties" : {
		"FID" : 1727,
		"name" : "胜田广场",
		"lng" : 119.36279500000001,
		"lat" : 25.717369000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1728,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35123965397375,
		  25.700697278343849
		]
	  },
	  "properties" : {
		"FID" : 1728,
		"name" : "口袋公园",
		"lng" : 119.35611900000001,
		"lat" : 25.697944
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1729,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33236188391534,
		  25.710935112784451
		]
	  },
	  "properties" : {
		"FID" : 1729,
		"name" : "基督教福华堂(香山点)",
		"lng" : 119.337209,
		"lat" : 25.708143
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1730,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36173687448245,
		  25.71344359008674
		]
	  },
	  "properties" : {
		"FID" : 1730,
		"name" : "福耀园-望江楼",
		"lng" : 119.366632,
		"lat" : 25.710699000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1731,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36464483125339,
		  25.720704784620473
		]
	  },
	  "properties" : {
		"FID" : 1731,
		"name" : "福清城关基督教公馆点",
		"lng" : 119.369544,
		"lat" : 25.717960000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1732,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36476983623071,
		  25.732013909389028
		]
	  },
	  "properties" : {
		"FID" : 1732,
		"name" : "清风园(清荣大道)",
		"lng" : 119.36967,
		"lat" : 25.729263
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1733,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35759175089399,
		  25.734557068871013
		]
	  },
	  "properties" : {
		"FID" : 1733,
		"name" : "基督教福华堂凯景聚会点",
		"lng" : 119.362483,
		"lat" : 25.731795000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1734,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36309168282671,
		  25.720443626528105
		]
	  },
	  "properties" : {
		"FID" : 1734,
		"name" : "书音阁",
		"lng" : 119.36798899999999,
		"lat" : 25.717697000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1735,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34496024159681,
		  25.709543498028424
		]
	  },
	  "properties" : {
		"FID" : 1735,
		"name" : "霞盛牌坊",
		"lng" : 119.34983,
		"lat" : 25.706775
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1736,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34962400857242,
		  25.74325135565369
		]
	  },
	  "properties" : {
		"FID" : 1736,
		"name" : "福清市瑶峰王氏宗祠",
		"lng" : 119.35450400000001,
		"lat" : 25.740472
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1737,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35734789515229,
		  25.723838443408088
		]
	  },
	  "properties" : {
		"FID" : 1737,
		"name" : "合兴境",
		"lng" : 119.362238,
		"lat" : 25.721081999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1738,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36647847803862,
		  25.751240758363309
		]
	  },
	  "properties" : {
		"FID" : 1738,
		"name" : "福清林长制主题公园",
		"lng" : 119.371382,
		"lat" : 25.748481000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1739,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36562094682137,
		  25.717731942699686
		]
	  },
	  "properties" : {
		"FID" : 1739,
		"name" : "滨江休闲带",
		"lng" : 119.370521,
		"lat" : 25.71499
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1740,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38335393291432,
		  25.722659333507508
		]
	  },
	  "properties" : {
		"FID" : 1740,
		"name" : "向阳井街口袋公园",
		"lng" : 119.388268,
		"lat" : 25.719930999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1741,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.14844618095722,
		  25.637273561088318
		]
	  },
	  "properties" : {
		"FID" : 1741,
		"name" : "金芝宫",
		"lng" : 119.15331999999999,
		"lat" : 25.634533999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1742,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32650387425143,
		  25.633127221885417
		]
	  },
	  "properties" : {
		"FID" : 1742,
		"name" : "林氏支祠",
		"lng" : 119.331334,
		"lat" : 25.630362999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1743,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.384998659532,
		  25.718548156032977
		]
	  },
	  "properties" : {
		"FID" : 1743,
		"name" : "福寿禄财喜花园",
		"lng" : 119.38991300000001,
		"lat" : 25.715823
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1744,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38114828296588,
		  25.677819944484938
		]
	  },
	  "properties" : {
		"FID" : 1744,
		"name" : "福清站站前广场",
		"lng" : 119.38605800000001,
		"lat" : 25.675114000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1745,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37011620722747,
		  25.67898727811172
		]
	  },
	  "properties" : {
		"FID" : 1745,
		"name" : "幽巗寺",
		"lng" : 119.375018,
		"lat" : 25.676271
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1746,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38376571796599,
		  25.72342051459048
		]
	  },
	  "properties" : {
		"FID" : 1746,
		"name" : "黄义观",
		"lng" : 119.38867999999999,
		"lat" : 25.720692
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1747,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36857060121692,
		  25.720473972395443
		]
	  },
	  "properties" : {
		"FID" : 1747,
		"name" : "渊灵殿",
		"lng" : 119.373474,
		"lat" : 25.717734
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1748,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37789479914099,
		  25.708573452588531
		]
	  },
	  "properties" : {
		"FID" : 1748,
		"name" : "广药白云山",
		"lng" : 119.382805,
		"lat" : 25.705849000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1749,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35037461324197,
		  25.706003507559682
		]
	  },
	  "properties" : {
		"FID" : 1749,
		"name" : "基督教溪南堂",
		"lng" : 119.355253,
		"lat" : 25.703246
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1750,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37511088139163,
		  25.640020281281625
		]
	  },
	  "properties" : {
		"FID" : 1750,
		"name" : "福清市吉水寺海会楼",
		"lng" : 119.380014,
		"lat" : 25.637328
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1751,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38426504371766,
		  25.729969873504416
		]
	  },
	  "properties" : {
		"FID" : 1751,
		"name" : "干原海蛎花哈",
		"lng" : 119.38918,
		"lat" : 25.727238
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1752,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38290037515075,
		  25.719211707183064
		]
	  },
	  "properties" : {
		"FID" : 1752,
		"name" : "东林祖社",
		"lng" : 119.38781400000001,
		"lat" : 25.716484999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1753,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37311226945907,
		  25.722382236696415
		]
	  },
	  "properties" : {
		"FID" : 1753,
		"name" : "妙音精舍",
		"lng" : 119.37802000000001,
		"lat" : 25.719646000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1754,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17741374245868,
		  25.728177821287865
		]
	  },
	  "properties" : {
		"FID" : 1754,
		"name" : "五福寺",
		"lng" : 119.18223500000001,
		"lat" : 25.725338000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1755,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36051942012733,
		  25.726771569518359
		]
	  },
	  "properties" : {
		"FID" : 1755,
		"name" : "清展堂",
		"lng" : 119.365414,
		"lat" : 25.724018000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1756,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3737197416892,
		  25.696206531869667
		]
	  },
	  "properties" : {
		"FID" : 1756,
		"name" : "观音堂",
		"lng" : 119.378626,
		"lat" : 25.693484999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1757,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36995190191475,
		  25.724999941307576
		]
	  },
	  "properties" : {
		"FID" : 1757,
		"name" : "侯昆谷",
		"lng" : 119.37485700000001,
		"lat" : 25.722259000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1758,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24868322341564,
		  25.709618465420796
		]
	  },
	  "properties" : {
		"FID" : 1758,
		"name" : "东张库区移民公园(暂停开放)",
		"lng" : 119.253418,
		"lat" : 25.706714999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1759,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28588235043695,
		  25.70910733354404
		]
	  },
	  "properties" : {
		"FID" : 1759,
		"name" : "石竹山省级风景名胜区-石竹山道院(暂停开放)",
		"lng" : 119.290646,
		"lat" : 25.706233999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1760,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25201154443832,
		  25.644830945477736
		]
	  },
	  "properties" : {
		"FID" : 1760,
		"name" : "黄檗寺",
		"lng" : 119.256742,
		"lat" : 25.641960999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1761,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21997552639925,
		  25.656214689117203
		]
	  },
	  "properties" : {
		"FID" : 1761,
		"name" : "龙潭山水风景区(暂停开放)",
		"lng" : 119.224721,
		"lat" : 25.65335
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1762,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23380766841481,
		  25.791546551636969
		]
	  },
	  "properties" : {
		"FID" : 1762,
		"name" : "一都罗汉寺",
		"lng" : 119.238552,
		"lat" : 25.788598
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1763,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19973945113156,
		  25.804745799287911
		]
	  },
	  "properties" : {
		"FID" : 1763,
		"name" : "东关寨",
		"lng" : 119.20452400000001,
		"lat" : 25.801822999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1764,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22753070429965,
		  25.748481667875019
		]
	  },
	  "properties" : {
		"FID" : 1764,
		"name" : "岚湖山观景台",
		"lng" : 119.232276,
		"lat" : 25.745562
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1765,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24840424692128,
		  25.736669446314561
		]
	  },
	  "properties" : {
		"FID" : 1765,
		"name" : "梨洋报恩寺",
		"lng" : 119.253141,
		"lat" : 25.733751000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1766,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23510838361751,
		  25.831453918988593
		]
	  },
	  "properties" : {
		"FID" : 1766,
		"name" : "大化山风景区",
		"lng" : 119.23985500000001,
		"lat" : 25.828479999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1767,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19684462233441,
		  25.775859823927423
		]
	  },
	  "properties" : {
		"FID" : 1767,
		"name" : "显济庙",
		"lng" : 119.201632,
		"lat" : 25.772959
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1768,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28051314975878,
		  25.82163752083234
		]
	  },
	  "properties" : {
		"FID" : 1768,
		"name" : "福清镜洋天竺寺",
		"lng" : 119.28527800000001,
		"lat" : 25.818691000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1769,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29280850438573,
		  25.769294179749586
		]
	  },
	  "properties" : {
		"FID" : 1769,
		"name" : "沈氏祠堂",
		"lng" : 119.29758699999999,
		"lat" : 25.766397000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1770,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19377890393578,
		  25.77922397782007
		]
	  },
	  "properties" : {
		"FID" : 1770,
		"name" : "一都状元府",
		"lng" : 119.198572,
		"lat" : 25.776326000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1771,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25235646942025,
		  25.807646787949619
		]
	  },
	  "properties" : {
		"FID" : 1771,
		"name" : "蝴蝶泉",
		"lng" : 119.257099,
		"lat" : 25.804687000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1772,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30217943727951,
		  25.786506965302362
		]
	  },
	  "properties" : {
		"FID" : 1772,
		"name" : "壶山寺",
		"lng" : 119.30697499999999,
		"lat" : 25.783615000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1773,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19703542132446,
		  25.769572378177728
		]
	  },
	  "properties" : {
		"FID" : 1773,
		"name" : "一都村状元故里",
		"lng" : 119.20182200000001,
		"lat" : 25.766674999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1774,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27170255241276,
		  25.745412386454223
		]
	  },
	  "properties" : {
		"FID" : 1774,
		"name" : "瓜园境",
		"lng" : 119.27645200000001,
		"lat" : 25.742502000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1775,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27169655807653,
		  25.745413392844444
		]
	  },
	  "properties" : {
		"FID" : 1775,
		"name" : "南埔元帅宫",
		"lng" : 119.27644600000001,
		"lat" : 25.742502999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1776,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19506897113594,
		  25.782722150844872
		]
	  },
	  "properties" : {
		"FID" : 1776,
		"name" : "上生寺",
		"lng" : 119.19986,
		"lat" : 25.779820000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1777,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.272523020639,
		  25.741821529867156
		]
	  },
	  "properties" : {
		"FID" : 1777,
		"name" : "延寿寺",
		"lng" : 119.27727299999999,
		"lat" : 25.738914000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1778,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3105392498599,
		  25.784761863367308
		]
	  },
	  "properties" : {
		"FID" : 1778,
		"name" : "福清市仙井岩禅寺",
		"lng" : 119.31535,
		"lat" : 25.781886
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1779,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28444316004074,
		  25.819496064771883
		]
	  },
	  "properties" : {
		"FID" : 1779,
		"name" : "方世培故居",
		"lng" : 119.289213,
		"lat" : 25.816555999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1780,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30373861413986,
		  25.746755786849562
		]
	  },
	  "properties" : {
		"FID" : 1780,
		"name" : "太城寺",
		"lng" : 119.30853399999999,
		"lat" : 25.74389
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1781,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26270075118795,
		  25.731130656386917
		]
	  },
	  "properties" : {
		"FID" : 1781,
		"name" : "祖厅",
		"lng" : 119.267442,
		"lat" : 25.728221000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1782,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24003951828109,
		  25.719889849184288
		]
	  },
	  "properties" : {
		"FID" : 1782,
		"name" : "溪柄山庄公园",
		"lng" : 119.244776,
		"lat" : 25.716981000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1783,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23732069753571,
		  25.718448407304528
		]
	  },
	  "properties" : {
		"FID" : 1783,
		"name" : "东张滑翔伞基地",
		"lng" : 119.242058,
		"lat" : 25.715541000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1784,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29920063062447,
		  25.800087365329631
		]
	  },
	  "properties" : {
		"FID" : 1784,
		"name" : "何氏宗祠",
		"lng" : 119.30399199999999,
		"lat" : 25.797181999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1785,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24496275477827,
		  25.715510919425196
		]
	  },
	  "properties" : {
		"FID" : 1785,
		"name" : "西山寺",
		"lng" : 119.249698,
		"lat" : 25.712603999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1786,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29408393243291,
		  25.816762114057401
		]
	  },
	  "properties" : {
		"FID" : 1786,
		"name" : "上店群心园",
		"lng" : 119.298868,
		"lat" : 25.813838000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1787,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23995047262081,
		  25.720161981854218
		]
	  },
	  "properties" : {
		"FID" : 1787,
		"name" : "移民休闲公园",
		"lng" : 119.244687,
		"lat" : 25.717252999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1788,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25037859435467,
		  25.71583054553523
		]
	  },
	  "properties" : {
		"FID" : 1788,
		"name" : "白豸公园",
		"lng" : 119.25511400000001,
		"lat" : 25.712924000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1789,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30419994154322,
		  25.744633755869465
		]
	  },
	  "properties" : {
		"FID" : 1789,
		"name" : "霞满半山腰主题公园",
		"lng" : 119.30899599999999,
		"lat" : 25.741769999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1790,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31086010901078,
		  25.79194662789784
		]
	  },
	  "properties" : {
		"FID" : 1790,
		"name" : "波兰村生命公园",
		"lng" : 119.31567200000001,
		"lat" : 25.789066999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1791,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2478219652244,
		  25.713696780858029
		]
	  },
	  "properties" : {
		"FID" : 1791,
		"name" : "元临俄候祖厅",
		"lng" : 119.252557,
		"lat" : 25.710791
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1792,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24455490380686,
		  25.712969532679164
		]
	  },
	  "properties" : {
		"FID" : 1792,
		"name" : "东张玉井庙",
		"lng" : 119.24929,
		"lat" : 25.710063999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1793,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31718862713835,
		  25.757111975671513
		]
	  },
	  "properties" : {
		"FID" : 1793,
		"name" : "天池山旅游观光",
		"lng" : 119.32201000000001,
		"lat" : 25.754265
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1794,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29246791410169,
		  25.71714297920726
		]
	  },
	  "properties" : {
		"FID" : 1794,
		"name" : "石竹山省级风景名胜区",
		"lng" : 119.297242,
		"lat" : 25.714275000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1795,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30293820580971,
		  25.825151551871759
		]
	  },
	  "properties" : {
		"FID" : 1795,
		"name" : "洪氏宗祠",
		"lng" : 119.307738,
		"lat" : 25.822237000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1796,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18196127311323,
		  25.818535844882355
		]
	  },
	  "properties" : {
		"FID" : 1796,
		"name" : "凤岭亭",
		"lng" : 119.18678,
		"lat" : 25.815633999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1797,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30088193077307,
		  25.823977382407254
		]
	  },
	  "properties" : {
		"FID" : 1797,
		"name" : "红星基督教堂",
		"lng" : 119.305678,
		"lat" : 25.821059999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1798,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23555713288492,
		  25.702205058257331
		]
	  },
	  "properties" : {
		"FID" : 1798,
		"name" : "香山寺",
		"lng" : 119.24029400000001,
		"lat" : 25.699307000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1799,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.11435260123646,
		  25.782689211333174
		]
	  },
	  "properties" : {
		"FID" : 1799,
		"name" : "后溪旅游区",
		"lng" : 119.119288,
		"lat" : 25.779917999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1800,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38794822603383,
		  25.741123400332633
		]
	  },
	  "properties" : {
		"FID" : 1800,
		"name" : "玉屏山公园",
		"lng" : 119.392865,
		"lat" : 25.738386999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1801,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3555712760526,
		  25.712334778479153
		]
	  },
	  "properties" : {
		"FID" : 1801,
		"name" : "龙江公园",
		"lng" : 119.36045799999999,
		"lat" : 25.709582000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1802,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38090258718948,
		  25.715255836052865
		]
	  },
	  "properties" : {
		"FID" : 1802,
		"name" : "瑞云塔",
		"lng" : 119.38581499999999,
		"lat" : 25.712530000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1803,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36570887277644,
		  25.730697010708415
		]
	  },
	  "properties" : {
		"FID" : 1803,
		"name" : "福清革命历史纪念碑",
		"lng" : 119.37061,
		"lat" : 25.727948000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1804,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29949389568253,
		  25.830000563186818
		]
	  },
	  "properties" : {
		"FID" : 1804,
		"name" : "福建农业职业技术学院同心桥",
		"lng" : 119.304288,
		"lat" : 25.827076999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1805,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31155365136912,
		  25.700041788582077
		]
	  },
	  "properties" : {
		"FID" : 1805,
		"name" : "圣来寺",
		"lng" : 119.31636,
		"lat" : 25.697216000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1806,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39012944336875,
		  25.708008284344444
		]
	  },
	  "properties" : {
		"FID" : 1806,
		"name" : "齐天大圣",
		"lng" : 119.395044,
		"lat" : 25.705290999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1807,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38358360621936,
		  25.725815946455686
		]
	  },
	  "properties" : {
		"FID" : 1807,
		"name" : "福清市体育公园",
		"lng" : 119.388498,
		"lat" : 25.723085999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1808,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37846238771823,
		  25.722632672457895
		]
	  },
	  "properties" : {
		"FID" : 1808,
		"name" : "街心公园",
		"lng" : 119.383374,
		"lat" : 25.719901
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1809,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24136916094534,
		  25.702256523950471
		]
	  },
	  "properties" : {
		"FID" : 1809,
		"name" : "东张镇香山小洱海",
		"lng" : 119.246104,
		"lat" : 25.699356999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1810,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35115545729322,
		  25.731694333601975
		]
	  },
	  "properties" : {
		"FID" : 1810,
		"name" : "应天禅寺",
		"lng" : 119.356037,
		"lat" : 25.728923999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1811,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35075991352745,
		  25.707238546052995
		]
	  },
	  "properties" : {
		"FID" : 1811,
		"name" : "林则徐公园",
		"lng" : 119.355639,
		"lat" : 25.704481000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1812,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3427619771433,
		  25.763526795296617
		]
	  },
	  "properties" : {
		"FID" : 1812,
		"name" : "清泉寺",
		"lng" : 119.347632,
		"lat" : 25.760724
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1813,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34571007941445,
		  25.708107433303937
		]
	  },
	  "properties" : {
		"FID" : 1813,
		"name" : "龙江生态文化园",
		"lng" : 119.35058100000001,
		"lat" : 25.705341000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1814,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30792081556328,
		  25.842710817230472
		]
	  },
	  "properties" : {
		"FID" : 1814,
		"name" : "福海禅寺",
		"lng" : 119.312731,
		"lat" : 25.839794000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1815,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3616439908711,
		  25.713443714852424
		]
	  },
	  "properties" : {
		"FID" : 1815,
		"name" : "福耀园",
		"lng" : 119.366539,
		"lat" : 25.710699000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1816,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36887926652463,
		  25.720803806487552
		]
	  },
	  "properties" : {
		"FID" : 1816,
		"name" : "福清茶亭西涧寺",
		"lng" : 119.373783,
		"lat" : 25.718063999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1817,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38038382511694,
		  25.715634403726458
		]
	  },
	  "properties" : {
		"FID" : 1817,
		"name" : "天后宫",
		"lng" : 119.385296,
		"lat" : 25.712907999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1818,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21341246223719,
		  25.701799232567975
		]
	  },
	  "properties" : {
		"FID" : 1818,
		"name" : "宋朝请大夫何一之墓道",
		"lng" : 119.218169,
		"lat" : 25.698917999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1819,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38854057683844,
		  25.708626164838222
		]
	  },
	  "properties" : {
		"FID" : 1819,
		"name" : "东湖境五显庙",
		"lng" : 119.393455,
		"lat" : 25.705908000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1820,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38817644901542,
		  25.724370906872259
		]
	  },
	  "properties" : {
		"FID" : 1820,
		"name" : "龙山寺",
		"lng" : 119.393092,
		"lat" : 25.721644000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1821,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37766239741205,
		  25.729152927483387
		]
	  },
	  "properties" : {
		"FID" : 1821,
		"name" : "万寿禅寺",
		"lng" : 119.38257400000001,
		"lat" : 25.726417000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1822,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37598888138885,
		  25.711258497724476
		]
	  },
	  "properties" : {
		"FID" : 1822,
		"name" : "南涧寺",
		"lng" : 119.380898,
		"lat" : 25.708531000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1823,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4125897778562,
		  25.767885185318832
		]
	  },
	  "properties" : {
		"FID" : 1823,
		"name" : "激情广场",
		"lng" : 119.41749799999999,
		"lat" : 25.765129999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1824,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40285318860163,
		  25.698314647573618
		]
	  },
	  "properties" : {
		"FID" : 1824,
		"name" : "天主堂",
		"lng" : 119.407764,
		"lat" : 25.695602999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1825,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32595674001452,
		  25.742807986591718
		]
	  },
	  "properties" : {
		"FID" : 1825,
		"name" : "珠山寺",
		"lng" : 119.330794,
		"lat" : 25.739985999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1826,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36445619285769,
		  25.73208334221189
		]
	  },
	  "properties" : {
		"FID" : 1826,
		"name" : "清风广场",
		"lng" : 119.369356,
		"lat" : 25.729331999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1827,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34238639677332,
		  25.713381077356814
		]
	  },
	  "properties" : {
		"FID" : 1827,
		"name" : "圣帝宫",
		"lng" : 119.347252,
		"lat" : 25.710605999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1828,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36874811503773,
		  25.764374777665651
		]
	  },
	  "properties" : {
		"FID" : 1828,
		"name" : "北涧芦山寺",
		"lng" : 119.373655,
		"lat" : 25.761610000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1829,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36226139862455,
		  25.750963923814101
		]
	  },
	  "properties" : {
		"FID" : 1829,
		"name" : "基督教马山堂",
		"lng" : 119.36716,
		"lat" : 25.748199
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1830,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4120031459769,
		  25.794733943094862
		]
	  },
	  "properties" : {
		"FID" : 1830,
		"name" : "德胜公园",
		"lng" : 119.41691400000001,
		"lat" : 25.791962999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1831,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37924693216115,
		  25.722515007324006
		]
	  },
	  "properties" : {
		"FID" : 1831,
		"name" : "福清一拂法治文化公园",
		"lng" : 119.384159,
		"lat" : 25.719784000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1832,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.42369458894586,
		  25.728035608221735
		]
	  },
	  "properties" : {
		"FID" : 1832,
		"name" : "真人庙",
		"lng" : 119.428585,
		"lat" : 25.725293000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1833,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33719341593472,
		  25.703930358104966
		]
	  },
	  "properties" : {
		"FID" : 1833,
		"name" : "市民休闲公园",
		"lng" : 119.342049,
		"lat" : 25.701150999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1834,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3271486234801,
		  25.700276287753173
		]
	  },
	  "properties" : {
		"FID" : 1834,
		"name" : "福清市湿地公园",
		"lng" : 119.331985,
		"lat" : 25.697479999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1835,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34332972581736,
		  25.806940023918436
		]
	  },
	  "properties" : {
		"FID" : 1835,
		"name" : "福建榕树王",
		"lng" : 119.348204,
		"lat" : 25.804112
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1836,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22152400106516,
		  25.69868361268032
		]
	  },
	  "properties" : {
		"FID" : 1836,
		"name" : "万安境",
		"lng" : 119.226271,
		"lat" : 25.695796000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1837,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37236607244786,
		  25.706834508958199
		]
	  },
	  "properties" : {
		"FID" : 1837,
		"name" : "笃思公园",
		"lng" : 119.377272,
		"lat" : 25.704105999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1838,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36964349754027,
		  25.707748855800538
		]
	  },
	  "properties" : {
		"FID" : 1838,
		"name" : "福山寺",
		"lng" : 119.37454700000001,
		"lat" : 25.705017000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1839,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40964939482619,
		  25.761358535187416
		]
	  },
	  "properties" : {
		"FID" : 1839,
		"name" : "洪春松涛园",
		"lng" : 119.41455999999999,
		"lat" : 25.758609
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1840,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24087102841321,
		  25.702419537383467
		]
	  },
	  "properties" : {
		"FID" : 1840,
		"name" : "香山宫",
		"lng" : 119.245606,
		"lat" : 25.69952
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1841,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.15228458879162,
		  25.732448373006275
		]
	  },
	  "properties" : {
		"FID" : 1841,
		"name" : "南少林寺广场",
		"lng" : 119.157158,
		"lat" : 25.729652999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1842,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34487034274552,
		  25.710235026820172
		]
	  },
	  "properties" : {
		"FID" : 1842,
		"name" : "福人基督教堂",
		"lng" : 119.34974,
		"lat" : 25.707466
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1843,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3604984514381,
		  25.713420260204082
		]
	  },
	  "properties" : {
		"FID" : 1843,
		"name" : "天宝陂(福清现存的唐朝古迹)",
		"lng" : 119.365392,
		"lat" : 25.710674000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1844,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17741374245868,
		  25.728177821287865
		]
	  },
	  "properties" : {
		"FID" : 1844,
		"name" : "五福寺",
		"lng" : 119.18223500000001,
		"lat" : 25.725338000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1845,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41571286461053,
		  25.800416167880648
		]
	  },
	  "properties" : {
		"FID" : 1845,
		"name" : "德福公园",
		"lng" : 119.42062,
		"lat" : 25.797639
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1846,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31692973239835,
		  25.708780350156207
		]
	  },
	  "properties" : {
		"FID" : 1846,
		"name" : "福清宏路基督教堂",
		"lng" : 119.321747,
		"lat" : 25.705960000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1847,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.08968336470551,
		  25.839923794260432
		]
	  },
	  "properties" : {
		"FID" : 1847,
		"name" : "乐峰赤壁景区",
		"lng" : 119.094632,
		"lat" : 25.837126000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1848,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40419302389873,
		  25.724288075713776
		]
	  },
	  "properties" : {
		"FID" : 1848,
		"name" : "龙溪境",
		"lng" : 119.409105,
		"lat" : 25.721561999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1849,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35422813440857,
		  25.713718574638225
		]
	  },
	  "properties" : {
		"FID" : 1849,
		"name" : "龙泉境",
		"lng" : 119.35911299999999,
		"lat" : 25.710963
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1850,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40797221356743,
		  25.704752907280266
		]
	  },
	  "properties" : {
		"FID" : 1850,
		"name" : "周氏祠堂",
		"lng" : 119.41288,
		"lat" : 25.702036
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1851,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31171746845948,
		  25.698337581449856
		]
	  },
	  "properties" : {
		"FID" : 1851,
		"name" : "颐景公园",
		"lng" : 119.316524,
		"lat" : 25.695512999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1852,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39198274840568,
		  25.729754708828594
		]
	  },
	  "properties" : {
		"FID" : 1852,
		"name" : "龙山公园",
		"lng" : 119.396899,
		"lat" : 25.727025999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1853,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38346825668894,
		  25.717770578457777
		]
	  },
	  "properties" : {
		"FID" : 1853,
		"name" : "竹溪寺",
		"lng" : 119.38838199999999,
		"lat" : 25.715045
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1854,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30564002538699,
		  25.829174305673135
		]
	  },
	  "properties" : {
		"FID" : 1854,
		"name" : "张公庙",
		"lng" : 119.310445,
		"lat" : 25.826262
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1855,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27993797168375,
		  25.698702573334586
		]
	  },
	  "properties" : {
		"FID" : 1855,
		"name" : "紫云宝塔",
		"lng" : 119.284693,
		"lat" : 25.695827000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1856,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36574461930171,
		  25.733534557977226
		]
	  },
	  "properties" : {
		"FID" : 1856,
		"name" : "虎溪西园",
		"lng" : 119.37064599999999,
		"lat" : 25.730784
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1857,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3704111086757,
		  25.743024582994082
		]
	  },
	  "properties" : {
		"FID" : 1857,
		"name" : "福清基督教堂奎岭分堂",
		"lng" : 119.37531799999999,
		"lat" : 25.740273999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1858,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36159439993418,
		  25.735416946087749
		]
	  },
	  "properties" : {
		"FID" : 1858,
		"name" : "溪前千秋宫",
		"lng" : 119.366491,
		"lat" : 25.732659999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1859,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33454840151721,
		  25.729365147558187
		]
	  },
	  "properties" : {
		"FID" : 1859,
		"name" : "清泰公园",
		"lng" : 119.339401,
		"lat" : 25.726566999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1860,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31913568553423,
		  25.70596964225
		]
	  },
	  "properties" : {
		"FID" : 1860,
		"name" : "宏路街道南宅村厚德堂",
		"lng" : 119.32395699999999,
		"lat" : 25.703154999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1861,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31890218950836,
		  25.718667972595441
		]
	  },
	  "properties" : {
		"FID" : 1861,
		"name" : "NS蹦床公园",
		"lng" : 119.323724,
		"lat" : 25.715845999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1862,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34416994277406,
		  25.704869357114092
		]
	  },
	  "properties" : {
		"FID" : 1862,
		"name" : "福清市气象科普公园",
		"lng" : 119.34903799999999,
		"lat" : 25.702102
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1863,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33658809250592,
		  25.709736589900114
		]
	  },
	  "properties" : {
		"FID" : 1863,
		"name" : "三相宫",
		"lng" : 119.341443,
		"lat" : 25.706952999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1864,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3771718707883,
		  25.71385089836582
		]
	  },
	  "properties" : {
		"FID" : 1864,
		"name" : "水南园",
		"lng" : 119.382082,
		"lat" : 25.711123000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1865,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37837115336275,
		  25.713207582164056
		]
	  },
	  "properties" : {
		"FID" : 1865,
		"name" : "甲飞兰公园",
		"lng" : 119.38328199999999,
		"lat" : 25.710481000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1866,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40937365501938,
		  25.728055343781051
		]
	  },
	  "properties" : {
		"FID" : 1866,
		"name" : "火墩尾山公园",
		"lng" : 119.414282,
		"lat" : 25.725325000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1867,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3982189357575,
		  25.794135814918423
		]
	  },
	  "properties" : {
		"FID" : 1867,
		"name" : "清界寺",
		"lng" : 119.403139,
		"lat" : 25.791370000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1868,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37981688076675,
		  25.718941619669163
		]
	  },
	  "properties" : {
		"FID" : 1868,
		"name" : "福清市利桥天主教堂",
		"lng" : 119.38472899999999,
		"lat" : 25.716213
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1869,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38261148861729,
		  25.719312939966848
		]
	  },
	  "properties" : {
		"FID" : 1869,
		"name" : "林氏宗祠",
		"lng" : 119.387525,
		"lat" : 25.716586
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1870,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38423238197048,
		  25.725633477034567
		]
	  },
	  "properties" : {
		"FID" : 1870,
		"name" : "福清市体育公园-体育文化广场",
		"lng" : 119.38914699999999,
		"lat" : 25.722904
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1871,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37458819098393,
		  25.720974059226176
		]
	  },
	  "properties" : {
		"FID" : 1871,
		"name" : "福清西大基督教堂",
		"lng" : 119.379497,
		"lat" : 25.718240000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1872,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33429615948759,
		  25.72553048437381
		]
	  },
	  "properties" : {
		"FID" : 1872,
		"name" : "老伯宫",
		"lng" : 119.33914799999999,
		"lat" : 25.722733999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1873,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35048126055327,
		  25.708458653792118
		]
	  },
	  "properties" : {
		"FID" : 1873,
		"name" : "观音埔湿地公园",
		"lng" : 119.35536,
		"lat" : 25.7057
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1874,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36805141182401,
		  25.71673651461683
		]
	  },
	  "properties" : {
		"FID" : 1874,
		"name" : "旌马亭",
		"lng" : 119.37295399999999,
		"lat" : 25.713998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1875,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37789600185059,
		  25.745690089612026
		]
	  },
	  "properties" : {
		"FID" : 1875,
		"name" : "林氏祖厅",
		"lng" : 119.38280899999999,
		"lat" : 25.742944999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1876,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36730538890858,
		  25.753928333540728
		]
	  },
	  "properties" : {
		"FID" : 1876,
		"name" : "虫出没口袋公园",
		"lng" : 119.37221,
		"lat" : 25.751168
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1877,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35434796676971,
		  25.71359232181338
		]
	  },
	  "properties" : {
		"FID" : 1877,
		"name" : "境泉龙",
		"lng" : 119.359233,
		"lat" : 25.710837000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1878,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34056675920418,
		  25.711397244836579
		]
	  },
	  "properties" : {
		"FID" : 1878,
		"name" : "王氏宗祠",
		"lng" : 119.345429,
		"lat" : 25.70862
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1879,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35589603544399,
		  25.749221921154145
		]
	  },
	  "properties" : {
		"FID" : 1879,
		"name" : "曾氏祖厅",
		"lng" : 119.360786,
		"lat" : 25.746448999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1880,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40896018399911,
		  25.729493928180542
		]
	  },
	  "properties" : {
		"FID" : 1880,
		"name" : "福清白马尊王庙",
		"lng" : 119.41386900000001,
		"lat" : 25.726762999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1881,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35037749204872,
		  25.707557337236217
		]
	  },
	  "properties" : {
		"FID" : 1881,
		"name" : "福清市党建公园",
		"lng" : 119.355256,
		"lat" : 25.704799000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1882,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.06843091944944,
		  25.754986252283178
		]
	  },
	  "properties" : {
		"FID" : 1882,
		"name" : "云岩汉堡岩",
		"lng" : 119.073357,
		"lat" : 25.752227000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1883,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34116394192365,
		  25.74814569341649
		]
	  },
	  "properties" : {
		"FID" : 1883,
		"name" : "官品寺",
		"lng" : 119.34603,
		"lat" : 25.745349000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1884,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36883952622699,
		  25.717881246668718
		]
	  },
	  "properties" : {
		"FID" : 1884,
		"name" : "福耀亭",
		"lng" : 119.373743,
		"lat" : 25.715143000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1885,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38190338284596,
		  25.844060209331069
		]
	  },
	  "properties" : {
		"FID" : 1885,
		"name" : "清风洞岳飞大元帅庙",
		"lng" : 119.386826,
		"lat" : 25.841258
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1886,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3920386068725,
		  25.718371396469088
		]
	  },
	  "properties" : {
		"FID" : 1886,
		"name" : "社区公园",
		"lng" : 119.39695399999999,
		"lat" : 25.715648999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1887,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40208754712772,
		  25.741239050421903
		]
	  },
	  "properties" : {
		"FID" : 1887,
		"name" : "福清石井基督教聚会点",
		"lng" : 119.40700200000001,
		"lat" : 25.738503999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1888,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40233269620174,
		  25.740961945536959
		]
	  },
	  "properties" : {
		"FID" : 1888,
		"name" : "玉井境",
		"lng" : 119.407247,
		"lat" : 25.738226999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1889,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37854622887873,
		  25.724065399086044
		]
	  },
	  "properties" : {
		"FID" : 1889,
		"name" : "向高街口袋公园",
		"lng" : 119.383458,
		"lat" : 25.721333000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1890,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41027034810251,
		  25.769548710578704
		]
	  },
	  "properties" : {
		"FID" : 1890,
		"name" : "林文镜祖居",
		"lng" : 119.415181,
		"lat" : 25.766794000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1891,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41182269993317,
		  25.771673921433564
		]
	  },
	  "properties" : {
		"FID" : 1891,
		"name" : "溪头安龙堂",
		"lng" : 119.416732,
		"lat" : 25.768916999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1892,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37048486486454,
		  25.718789944250997
		]
	  },
	  "properties" : {
		"FID" : 1892,
		"name" : "龙江街道党建主题公园",
		"lng" : 119.37539,
		"lat" : 25.716052999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1893,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38330566430292,
		  25.713202182629999
		]
	  },
	  "properties" : {
		"FID" : 1893,
		"name" : "吴氏宗祠",
		"lng" : 119.38821900000001,
		"lat" : 25.710478999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1894,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36569070967231,
		  25.719848017854755
		]
	  },
	  "properties" : {
		"FID" : 1894,
		"name" : "龙江融侨园",
		"lng" : 119.370591,
		"lat" : 25.717105
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1895,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3217117810949,
		  25.704899147789078
		]
	  },
	  "properties" : {
		"FID" : 1895,
		"name" : "宏欣公园",
		"lng" : 119.326538,
		"lat" : 25.702089999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1896,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31921971386851,
		  25.837179119840091
		]
	  },
	  "properties" : {
		"FID" : 1896,
		"name" : "白马寺",
		"lng" : 119.324051,
		"lat" : 25.834287
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1897,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41166292965336,
		  25.700015436651682
		]
	  },
	  "properties" : {
		"FID" : 1897,
		"name" : "钟山寺",
		"lng" : 119.416567,
		"lat" : 25.697299000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1898,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34311834398932,
		  25.723734461720316
		]
	  },
	  "properties" : {
		"FID" : 1898,
		"name" : "雲林池-生态造景空间",
		"lng" : 119.34798600000001,
		"lat" : 25.720955
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1899,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32433789280776,
		  25.849252083863767
		]
	  },
	  "properties" : {
		"FID" : 1899,
		"name" : "青口镇东台后厝官厅",
		"lng" : 119.32917999999999,
		"lat" : 25.846361999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1900,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31736858702438,
		  25.71280269198795
		]
	  },
	  "properties" : {
		"FID" : 1900,
		"name" : "龙塘村口袋公园",
		"lng" : 119.322187,
		"lat" : 25.709980999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1901,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31216726456003,
		  25.703068255311887
		]
	  },
	  "properties" : {
		"FID" : 1901,
		"name" : "宏路基督徒聚会处",
		"lng" : 119.316975,
		"lat" : 25.700241999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1902,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35006651028104,
		  25.72719058339321
		]
	  },
	  "properties" : {
		"FID" : 1902,
		"name" : "两馆一中心东南角公园",
		"lng" : 119.354946,
		"lat" : 25.724421
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1903,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33554796965211,
		  25.710317826804172
		]
	  },
	  "properties" : {
		"FID" : 1903,
		"name" : "真耶稣教会石门教堂",
		"lng" : 119.340401,
		"lat" : 25.707532
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1904,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36780632826628,
		  25.721212252255803
		]
	  },
	  "properties" : {
		"FID" : 1904,
		"name" : "九亩底广场及茶亭公园",
		"lng" : 119.372709,
		"lat" : 25.718471000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1905,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.42022388278039,
		  25.760099112368692
		]
	  },
	  "properties" : {
		"FID" : 1905,
		"name" : "玉岭村史馆",
		"lng" : 119.425122,
		"lat" : 25.757342000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1906,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41896765609715,
		  25.726270565449923
		]
	  },
	  "properties" : {
		"FID" : 1906,
		"name" : "天主堂",
		"lng" : 119.42386500000001,
		"lat" : 25.723534000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1907,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28583062887047,
		  25.706328911262052
		]
	  },
	  "properties" : {
		"FID" : 1907,
		"name" : "石竹寺",
		"lng" : 119.290594,
		"lat" : 25.703457
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1908,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38514761112147,
		  25.731842448994033
		]
	  },
	  "properties" : {
		"FID" : 1908,
		"name" : "上瓦瑶公园",
		"lng" : 119.390063,
		"lat" : 25.729109999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1909,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35669503800729,
		  25.707488484816913
		]
	  },
	  "properties" : {
		"FID" : 1909,
		"name" : "观音埔池阿财",
		"lng" : 119.361583,
		"lat" : 25.704740000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1910,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41275374453832,
		  25.770628922668678
		]
	  },
	  "properties" : {
		"FID" : 1910,
		"name" : "林氏祠堂",
		"lng" : 119.41766200000001,
		"lat" : 25.767872000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1911,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31230861197884,
		  25.708232758785257
		]
	  },
	  "properties" : {
		"FID" : 1911,
		"name" : "钟氏外厝祖厅",
		"lng" : 119.317117,
		"lat" : 25.705404000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1912,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39380702860441,
		  25.7008956227608
		]
	  },
	  "properties" : {
		"FID" : 1912,
		"name" : "倪氏宗祠",
		"lng" : 119.39872099999999,
		"lat" : 25.698183
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1913,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4052802681551,
		  25.73044886062964
		]
	  },
	  "properties" : {
		"FID" : 1913,
		"name" : "金鸡岭真灵寺",
		"lng" : 119.410192,
		"lat" : 25.727719
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1914,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32547387073478,
		  25.846920408371822
		]
	  },
	  "properties" : {
		"FID" : 1914,
		"name" : "后厝双江陈氏宗祠",
		"lng" : 119.33031800000001,
		"lat" : 25.844034000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1915,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31161103366152,
		  25.720309629161434
		]
	  },
	  "properties" : {
		"FID" : 1915,
		"name" : "仙埔境",
		"lng" : 119.316419,
		"lat" : 25.717472999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1916,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35184178997585,
		  25.699766821320079
		]
	  },
	  "properties" : {
		"FID" : 1916,
		"name" : "双拥公园·尊崇小广场",
		"lng" : 119.356722,
		"lat" : 25.697015
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1917,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39420436864664,
		  25.736807259790954
		]
	  },
	  "properties" : {
		"FID" : 1917,
		"name" : "象牙塔",
		"lng" : 119.39912099999999,
		"lat" : 25.734075000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1918,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38190594517673,
		  25.743926175014721
		]
	  },
	  "properties" : {
		"FID" : 1918,
		"name" : "中和寺",
		"lng" : 119.386821,
		"lat" : 25.741185000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1919,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37054905666794,
		  25.728725370689681
		]
	  },
	  "properties" : {
		"FID" : 1919,
		"name" : "福泰公园",
		"lng" : 119.375455,
		"lat" : 25.725982999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1920,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36534920821414,
		  25.744877474302431
		]
	  },
	  "properties" : {
		"FID" : 1920,
		"name" : "福清市消防文化主题公园",
		"lng" : 119.370251,
		"lat" : 25.74212
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1921,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36392810416071,
		  25.728173827263294
		]
	  },
	  "properties" : {
		"FID" : 1921,
		"name" : "灵石谷",
		"lng" : 119.368827,
		"lat" : 25.725424
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1922,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36457890903098,
		  25.720681854799107
		]
	  },
	  "properties" : {
		"FID" : 1922,
		"name" : "基督教福华堂公馆点",
		"lng" : 119.369478,
		"lat" : 25.717936999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1923,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36105413777952,
		  25.708109627635498
		]
	  },
	  "properties" : {
		"FID" : 1923,
		"name" : "玉融山公园沐风亭",
		"lng" : 119.365948,
		"lat" : 25.705366999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1924,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38878514751705,
		  25.700574766540985
		]
	  },
	  "properties" : {
		"FID" : 1924,
		"name" : "陈氏宗祠",
		"lng" : 119.393699,
		"lat" : 25.697861
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1925,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.06610088675089,
		  25.783929111360347
		]
	  },
	  "properties" : {
		"FID" : 1925,
		"name" : "赤壁斗湖",
		"lng" : 119.071026,
		"lat" : 25.78115
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1926,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22142789110015,
		  25.698862624844708
		]
	  },
	  "properties" : {
		"FID" : 1926,
		"name" : "万安宫",
		"lng" : 119.226175,
		"lat" : 25.695975000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1927,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31536215525421,
		  25.703276367289071
		]
	  },
	  "properties" : {
		"FID" : 1927,
		"name" : "玄天上帝",
		"lng" : 119.320176,
		"lat" : 25.700455999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1928,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36796450717227,
		  25.743219409620345
		]
	  },
	  "properties" : {
		"FID" : 1928,
		"name" : "中非友好公园",
		"lng" : 119.37286899999999,
		"lat" : 25.740466000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1929,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34312924193274,
		  25.711509752379797
		]
	  },
	  "properties" : {
		"FID" : 1929,
		"name" : "致一广场",
		"lng" : 119.34799599999999,
		"lat" : 25.708736999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1930,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40479083453076,
		  25.705298921165877
		]
	  },
	  "properties" : {
		"FID" : 1930,
		"name" : "松潭旧教堂",
		"lng" : 119.409701,
		"lat" : 25.702583000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1931,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41425513701658,
		  25.787336028263951
		]
	  },
	  "properties" : {
		"FID" : 1931,
		"name" : "阳下东田基督教堂",
		"lng" : 119.419163,
		"lat" : 25.784568
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1932,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40822805950384,
		  25.762743612664629
		]
	  },
	  "properties" : {
		"FID" : 1932,
		"name" : "阳下乡贤馆",
		"lng" : 119.41314,
		"lat" : 25.759993999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1933,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.42197592366058,
		  25.80740950650036
		]
	  },
	  "properties" : {
		"FID" : 1933,
		"name" : "下溪尾李氏祠堂",
		"lng" : 119.426875,
		"lat" : 25.804621999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1934,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37601586590114,
		  25.711208447109801
		]
	  },
	  "properties" : {
		"FID" : 1934,
		"name" : "福清龙江水南南涧宫管理委员会",
		"lng" : 119.380925,
		"lat" : 25.708480999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1935,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37916300076488,
		  25.722246922479243
		]
	  },
	  "properties" : {
		"FID" : 1935,
		"name" : "福清市宪法主题公园",
		"lng" : 119.384075,
		"lat" : 25.719515999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1936,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37479630275918,
		  25.73064323385659
		]
	  },
	  "properties" : {
		"FID" : 1936,
		"name" : "大北溪滨水公园",
		"lng" : 119.379706,
		"lat" : 25.727903999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1937,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41401578520708,
		  25.721969945939264
		]
	  },
	  "properties" : {
		"FID" : 1937,
		"name" : "南宅公园",
		"lng" : 119.418919,
		"lat" : 25.719239999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1938,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37864080865546,
		  25.742153483417233
		]
	  },
	  "properties" : {
		"FID" : 1938,
		"name" : "基督教福阳堂",
		"lng" : 119.383554,
		"lat" : 25.739411
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1939,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37465730446327,
		  25.71875977884422
		]
	  },
	  "properties" : {
		"FID" : 1939,
		"name" : "滨水公园",
		"lng" : 119.379566,
		"lat" : 25.716027
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1940,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38855179547612,
		  25.758773336787154
		]
	  },
	  "properties" : {
		"FID" : 1940,
		"name" : "金山胜境",
		"lng" : 119.39346999999999,
		"lat" : 25.756027
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1941,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31428580298514,
		  25.708820369376969
		]
	  },
	  "properties" : {
		"FID" : 1941,
		"name" : "真耶稣教会",
		"lng" : 119.319098,
		"lat" : 25.705995000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1942,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29784445471414,
		  25.846942165281778
		]
	  },
	  "properties" : {
		"FID" : 1942,
		"name" : "龙溪境",
		"lng" : 119.302637,
		"lat" : 25.844004999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1943,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34275698367264,
		  25.763555821155268
		]
	  },
	  "properties" : {
		"FID" : 1943,
		"name" : "福德庙",
		"lng" : 119.347627,
		"lat" : 25.760753000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1944,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1462159726575,
		  25.784112819918633
		]
	  },
	  "properties" : {
		"FID" : 1944,
		"name" : "一都慢城彩虹步道",
		"lng" : 119.151105,
		"lat" : 25.781298
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1945,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36674531953558,
		  25.736235873160325
		]
	  },
	  "properties" : {
		"FID" : 1945,
		"name" : "闽江调水主题公园",
		"lng" : 119.37164799999999,
		"lat" : 25.733485000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1946,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35411259924227,
		  25.736420333261044
		]
	  },
	  "properties" : {
		"FID" : 1946,
		"name" : "古典园林公园",
		"lng" : 119.358999,
		"lat" : 25.733651999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1947,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37291918551267,
		  25.738914672957709
		]
	  },
	  "properties" : {
		"FID" : 1947,
		"name" : "长兴境",
		"lng" : 119.37782799999999,
		"lat" : 25.736169
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1948,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37109782044101,
		  25.738409233856679
		]
	  },
	  "properties" : {
		"FID" : 1948,
		"name" : "庄氏宗祠",
		"lng" : 119.37600500000001,
		"lat" : 25.735662000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1949,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3312535299158,
		  25.703595257534012
		]
	  },
	  "properties" : {
		"FID" : 1949,
		"name" : "宏路基督教堂中联城聚会处",
		"lng" : 119.33609800000001,
		"lat" : 25.700804999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1950,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.34563451109679,
		  25.704051387790411
		]
	  },
	  "properties" : {
		"FID" : 1950,
		"name" : "基督教名城聚会点",
		"lng" : 119.350505,
		"lat" : 25.701287000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1951,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38391399960042,
		  25.732225332770408
		]
	  },
	  "properties" : {
		"FID" : 1951,
		"name" : "灵石谷(融北店)",
		"lng" : 119.388829,
		"lat" : 25.729492
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1952,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53987123825148,
		  25.514604802185509
		]
	  },
	  "properties" : {
		"FID" : 1952,
		"name" : "东郭村城山基督教堂",
		"lng" : 119.54437900000001,
		"lat" : 25.511666000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1953,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5246987739372,
		  25.518578815711447
		]
	  },
	  "properties" : {
		"FID" : 1953,
		"name" : "乐仙园",
		"lng" : 119.52925500000001,
		"lat" : 25.515675999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1954,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53717521698204,
		  25.500300268091724
		]
	  },
	  "properties" : {
		"FID" : 1954,
		"name" : "薛港公园",
		"lng" : 119.54169,
		"lat" : 25.497371999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1955,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52210543193328,
		  25.511378566076409
		]
	  },
	  "properties" : {
		"FID" : 1955,
		"name" : "基督教赤安堂",
		"lng" : 119.52667,
		"lat" : 25.508485
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1956,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55108469889917,
		  25.516857340521703
		]
	  },
	  "properties" : {
		"FID" : 1956,
		"name" : "福清城山寺",
		"lng" : 119.55556199999999,
		"lat" : 25.513895000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1957,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51877840514956,
		  25.51759339414572
		]
	  },
	  "properties" : {
		"FID" : 1957,
		"name" : "凤山境",
		"lng" : 119.523355,
		"lat" : 25.514707000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1958,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53954437530226,
		  25.499223346103673
		]
	  },
	  "properties" : {
		"FID" : 1958,
		"name" : "翁氏宗祠",
		"lng" : 119.54405199999999,
		"lat" : 25.496289999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1959,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53555584892194,
		  25.492201096590588
		]
	  },
	  "properties" : {
		"FID" : 1959,
		"name" : "王沃教堂",
		"lng" : 119.540075,
		"lat" : 25.489279
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1960,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52071397812755,
		  25.492444069836687
		]
	  },
	  "properties" : {
		"FID" : 1960,
		"name" : "翁氏宗祠",
		"lng" : 119.525282,
		"lat" : 25.489560000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1961,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55681396921099,
		  25.508953694216626
		]
	  },
	  "properties" : {
		"FID" : 1961,
		"name" : "翁氏支祠",
		"lng" : 119.561277,
		"lat" : 25.505984000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1962,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51709306068143,
		  25.536960129023512
		]
	  },
	  "properties" : {
		"FID" : 1962,
		"name" : "三山东基督教堂",
		"lng" : 119.521677,
		"lat" : 25.534071999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1963,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51411162098979,
		  25.534084689161137
		]
	  },
	  "properties" : {
		"FID" : 1963,
		"name" : "王氏宗祠",
		"lng" : 119.51870599999999,
		"lat" : 25.531206000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1964,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55841931583566,
		  25.526409811779232
		]
	  },
	  "properties" : {
		"FID" : 1964,
		"name" : "海瑶公园",
		"lng" : 119.56288000000001,
		"lat" : 25.523432
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1965,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51512018662565,
		  25.534810813031303
		]
	  },
	  "properties" : {
		"FID" : 1965,
		"name" : "前魏胜境王井宫",
		"lng" : 119.519711,
		"lat" : 25.531929000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1966,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51294248882492,
		  25.532958952916378
		]
	  },
	  "properties" : {
		"FID" : 1966,
		"name" : "灵石谷",
		"lng" : 119.51754099999999,
		"lat" : 25.530083999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1967,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54357984909069,
		  25.487139614432973
		]
	  },
	  "properties" : {
		"FID" : 1967,
		"name" : "南阳陈氏宗祠",
		"lng" : 119.548075,
		"lat" : 25.484200999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1968,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49527631090244,
		  25.504583503181554
		]
	  },
	  "properties" : {
		"FID" : 1968,
		"name" : "福兴寺",
		"lng" : 119.499938,
		"lat" : 25.50177
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1969,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57067844624676,
		  25.51853990586601
		]
	  },
	  "properties" : {
		"FID" : 1969,
		"name" : "江氏宗祠",
		"lng" : 119.575115,
		"lat" : 25.515549
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1970,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49931398617821,
		  25.523492602478747
		]
	  },
	  "properties" : {
		"FID" : 1970,
		"name" : "卢氏宗祠",
		"lng" : 119.503962,
		"lat" : 25.520661
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1971,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56678251315675,
		  25.493106855733718
		]
	  },
	  "properties" : {
		"FID" : 1971,
		"name" : "桐山村活动场",
		"lng" : 119.571224,
		"lat" : 25.490127999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1972,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49464934736406,
		  25.526983757282633
		]
	  },
	  "properties" : {
		"FID" : 1972,
		"name" : "福清市港头镇基督教西芦堂",
		"lng" : 119.499315,
		"lat" : 25.524165
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1973,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5663821744093,
		  25.473465931947054
		]
	  },
	  "properties" : {
		"FID" : 1973,
		"name" : "高山公园",
		"lng" : 119.570823,
		"lat" : 25.470493000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1974,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50536147298678,
		  25.536861131962745
		]
	  },
	  "properties" : {
		"FID" : 1974,
		"name" : "积穀禅林",
		"lng" : 119.50998800000001,
		"lat" : 25.534006999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1975,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55525455306743,
		  25.478353257473092
		]
	  },
	  "properties" : {
		"FID" : 1975,
		"name" : "河仁文化公园",
		"lng" : 119.559719,
		"lat" : 25.475394999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1976,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56313090072874,
		  25.474171988470726
		]
	  },
	  "properties" : {
		"FID" : 1976,
		"name" : "真耶稣教堂",
		"lng" : 119.567578,
		"lat" : 25.471202999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1977,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56491364833343,
		  25.540681771411062
		]
	  },
	  "properties" : {
		"FID" : 1977,
		"name" : "福清埕边基督教堂",
		"lng" : 119.569362,
		"lat" : 25.537690000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1978,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56957227710411,
		  25.480896542736414
		]
	  },
	  "properties" : {
		"FID" : 1978,
		"name" : "崇恩寺",
		"lng" : 119.57400800000001,
		"lat" : 25.477917999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1979,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52055153006353,
		  25.560309128642842
		]
	  },
	  "properties" : {
		"FID" : 1979,
		"name" : "福清东龙湾海水温泉",
		"lng" : 119.525125,
		"lat" : 25.557403000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1980,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56126384629442,
		  25.477865402730945
		]
	  },
	  "properties" : {
		"FID" : 1980,
		"name" : "怡和亭",
		"lng" : 119.565715,
		"lat" : 25.474898
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1981,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55376825294599,
		  25.475251901744965
		]
	  },
	  "properties" : {
		"FID" : 1981,
		"name" : "东山宫",
		"lng" : 119.55823599999999,
		"lat" : 25.472297000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1982,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56064611900858,
		  25.469951416534606
		]
	  },
	  "properties" : {
		"FID" : 1982,
		"name" : "福清市高山镇刘厝祠堂",
		"lng" : 119.56509800000001,
		"lat" : 25.466987
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1983,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51678044081149,
		  25.474611177268155
		]
	  },
	  "properties" : {
		"FID" : 1983,
		"name" : "文兴寺",
		"lng" : 119.521361,
		"lat" : 25.471743
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1984,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57724866331007,
		  25.497634145155189
		]
	  },
	  "properties" : {
		"FID" : 1984,
		"name" : "聚龙宫",
		"lng" : 119.58167400000001,
		"lat" : 25.494644000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1985,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.556797666714,
		  25.470497689711003
		]
	  },
	  "properties" : {
		"FID" : 1985,
		"name" : "高山基督教堂",
		"lng" : 119.561258,
		"lat" : 25.467538999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1986,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56108903052927,
		  25.470157106169548
		]
	  },
	  "properties" : {
		"FID" : 1986,
		"name" : "福音堂",
		"lng" : 119.56554,
		"lat" : 25.467192000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1987,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56147059095548,
		  25.473401500260437
		]
	  },
	  "properties" : {
		"FID" : 1987,
		"name" : "功德亭",
		"lng" : 119.565921,
		"lat" : 25.470434999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1988,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52819299572444,
		  25.56673789533173
		]
	  },
	  "properties" : {
		"FID" : 1988,
		"name" : "西塘寺",
		"lng" : 119.532741,
		"lat" : 25.563808999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1989,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58990504519973,
		  25.50494383559759
		]
	  },
	  "properties" : {
		"FID" : 1989,
		"name" : "龙尾龙江寺",
		"lng" : 119.594318,
		"lat" : 25.501946
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1990,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.54625180696108,
		  25.464702096118316
		]
	  },
	  "properties" : {
		"FID" : 1990,
		"name" : "福清青乐仔故居",
		"lng" : 119.550738,
		"lat" : 25.461763999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1991,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49331310522832,
		  25.558120704173263
		]
	  },
	  "properties" : {
		"FID" : 1991,
		"name" : "翁氏宗祠",
		"lng" : 119.497986,
		"lat" : 25.555295000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1992,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.46705538966947,
		  25.500641627329987
		]
	  },
	  "properties" : {
		"FID" : 1992,
		"name" : "叶相祖堂",
		"lng" : 119.471818,
		"lat" : 25.497910999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1993,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.49414327509386,
		  25.55704779856757
		]
	  },
	  "properties" : {
		"FID" : 1993,
		"name" : "陈家祖厅",
		"lng" : 119.498813,
		"lat" : 25.554220000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1994,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59920598869445,
		  25.500407973584693
		]
	  },
	  "properties" : {
		"FID" : 1994,
		"name" : "天后宫",
		"lng" : 119.60361399999999,
		"lat" : 25.497412000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1995,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.57482614024595,
		  25.471887085338011
		]
	  },
	  "properties" : {
		"FID" : 1995,
		"name" : "前洋郑氏宗祠",
		"lng" : 119.57925299999999,
		"lat" : 25.468906
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1996,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.56667313099111,
		  25.467496720308535
		]
	  },
	  "properties" : {
		"FID" : 1996,
		"name" : "王氏宗祠",
		"lng" : 119.571113,
		"lat" : 25.464524999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1997,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59905290947988,
		  25.50091016218942
		]
	  },
	  "properties" : {
		"FID" : 1997,
		"name" : "李氏宗祠",
		"lng" : 119.603461,
		"lat" : 25.497914000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1998,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59911898954975,
		  25.500047888065772
		]
	  },
	  "properties" : {
		"FID" : 1998,
		"name" : "北垞公园",
		"lng" : 119.603527,
		"lat" : 25.497052
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 1999,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59890485747847,
		  25.501034235562063
		]
	  },
	  "properties" : {
		"FID" : 1999,
		"name" : "大圣宫",
		"lng" : 119.603313,
		"lat" : 25.498038000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2000,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.51002886956445,
		  25.450319702601146
		]
	  },
	  "properties" : {
		"FID" : 2000,
		"name" : "龙潭寺",
		"lng" : 119.51463200000001,
		"lat" : 25.447476999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2001,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58204217425852,
		  25.459265671141758
		]
	  },
	  "properties" : {
		"FID" : 2001,
		"name" : "西江公园",
		"lng" : 119.586459,
		"lat" : 25.456282999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2002,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.44776419413476,
		  25.604068493652903
		]
	  },
	  "properties" : {
		"FID" : 2002,
		"name" : "庐江公园",
		"lng" : 119.45259299999999,
		"lat" : 25.601347000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2003,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6000341754267,
		  25.500842878435467
		]
	  },
	  "properties" : {
		"FID" : 2003,
		"name" : "仁主大王宫",
		"lng" : 119.60444200000001,
		"lat" : 25.497847
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2004,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.48415625439716,
		  25.571961652960486
		]
	  },
	  "properties" : {
		"FID" : 2004,
		"name" : "王氏祠堂",
		"lng" : 119.48886400000001,
		"lat" : 25.569158000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2005,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43792147204583,
		  25.619853172284511
		]
	  },
	  "properties" : {
		"FID" : 2005,
		"name" : "福庐山公园",
		"lng" : 119.44277599999999,
		"lat" : 25.617144
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2006,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60158339178591,
		  25.502357834240815
		]
	  },
	  "properties" : {
		"FID" : 2006,
		"name" : "新兴寺",
		"lng" : 119.605991,
		"lat" : 25.499362000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2007,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43177434729974,
		  25.605769926390696
		]
	  },
	  "properties" : {
		"FID" : 2007,
		"name" : "福清云峰寺",
		"lng" : 119.43664099999999,
		"lat" : 25.603076999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2008,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59746370517959,
		  25.482392174381179
		]
	  },
	  "properties" : {
		"FID" : 2008,
		"name" : "玉楼村公园",
		"lng" : 119.601871,
		"lat" : 25.479400999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2009,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47162050231549,
		  25.559927050762763
		]
	  },
	  "properties" : {
		"FID" : 2009,
		"name" : "龙湖公园",
		"lng" : 119.476372,
		"lat" : 25.557164
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2010,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58318892193128,
		  25.437696183364984
		]
	  },
	  "properties" : {
		"FID" : 2010,
		"name" : "杨氏宗祠",
		"lng" : 119.587603,
		"lat" : 25.434718
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2011,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4604421646531,
		  25.552238549456373
		]
	  },
	  "properties" : {
		"FID" : 2011,
		"name" : "沁塘基督教堂",
		"lng" : 119.46523000000001,
		"lat" : 25.549507999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2012,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53368029034937,
		  25.586034187509238
		]
	  },
	  "properties" : {
		"FID" : 2012,
		"name" : "田都马元帅府",
		"lng" : 119.538212,
		"lat" : 25.583083999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2013,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39446476384779,
		  25.572304069933612
		]
	  },
	  "properties" : {
		"FID" : 2013,
		"name" : "曹氏宗祠",
		"lng" : 119.39936899999999,
		"lat" : 25.569651
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2014,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.46419854321367,
		  25.560960413979306
		]
	  },
	  "properties" : {
		"FID" : 2014,
		"name" : "林氏宗祠",
		"lng" : 119.468975,
		"lat" : 25.558216999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2015,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63371777034052,
		  25.398058527139142
		]
	  },
	  "properties" : {
		"FID" : 2015,
		"name" : "护国禅寺",
		"lng" : 119.638133,
		"lat" : 25.395118
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2016,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50224478236372,
		  25.455906052514461
		]
	  },
	  "properties" : {
		"FID" : 2016,
		"name" : "西叶胜境",
		"lng" : 119.506877,
		"lat" : 25.453085000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2017,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47346450969484,
		  25.592302924643771
		]
	  },
	  "properties" : {
		"FID" : 2017,
		"name" : "基督教东华堂",
		"lng" : 119.478212,
		"lat" : 25.589521999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2018,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.44075137250998,
		  25.670011034347741
		]
	  },
	  "properties" : {
		"FID" : 2018,
		"name" : "林则徐祖居",
		"lng" : 119.44560300000001,
		"lat" : 25.667273000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2019,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5885786231691,
		  25.468675381551062
		]
	  },
	  "properties" : {
		"FID" : 2019,
		"name" : "仙井杨氏宗祠",
		"lng" : 119.59299,
		"lat" : 25.465688
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2020,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.52881734868578,
		  25.437027479922282
		]
	  },
	  "properties" : {
		"FID" : 2020,
		"name" : "金华寺",
		"lng" : 119.533354,
		"lat" : 25.434135999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2021,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39235169644178,
		  25.584202141153728
		]
	  },
	  "properties" : {
		"FID" : 2021,
		"name" : "基督教院边堂",
		"lng" : 119.397257,
		"lat" : 25.581544000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2022,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.571494675518,
		  25.576113287867894
		]
	  },
	  "properties" : {
		"FID" : 2022,
		"name" : "郭氏祠堂",
		"lng" : 119.575934,
		"lat" : 25.573101000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2023,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45747368787536,
		  25.610202330626201
		]
	  },
	  "properties" : {
		"FID" : 2023,
		"name" : "张氏宗祠",
		"lng" : 119.46227500000001,
		"lat" : 25.607455999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2024,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45698831298854,
		  25.635842645908944
		]
	  },
	  "properties" : {
		"FID" : 2024,
		"name" : "郑氏祠堂",
		"lng" : 119.461793,
		"lat" : 25.633085999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2025,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.42829955368902,
		  25.607474636614718
		]
	  },
	  "properties" : {
		"FID" : 2025,
		"name" : "薛氏宗祠",
		"lng" : 119.433173,
		"lat" : 25.604786000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2026,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39394444781603,
		  25.54897240840544
		]
	  },
	  "properties" : {
		"FID" : 2026,
		"name" : "陈氏宗祠(岸兜)",
		"lng" : 119.398847,
		"lat" : 25.546327999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2027,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45623776021155,
		  25.612682421453275
		]
	  },
	  "properties" : {
		"FID" : 2027,
		"name" : "方氏宗祠",
		"lng" : 119.461043,
		"lat" : 25.609938
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2028,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3712571456408,
		  25.599103858164934
		]
	  },
	  "properties" : {
		"FID" : 2028,
		"name" : "倪氏祠堂",
		"lng" : 119.376154,
		"lat" : 25.596426000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2029,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45250479223823,
		  25.625896542877637
		]
	  },
	  "properties" : {
		"FID" : 2029,
		"name" : "天主堂",
		"lng" : 119.457322,
		"lat" : 25.623155000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2030,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5117114142119,
		  25.416637343045242
		]
	  },
	  "properties" : {
		"FID" : 2030,
		"name" : "龙兴寺",
		"lng" : 119.516306,
		"lat" : 25.413796999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2031,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45233934596168,
		  25.625501987170338
		]
	  },
	  "properties" : {
		"FID" : 2031,
		"name" : "上薛村天主教堂融善楼",
		"lng" : 119.457157,
		"lat" : 25.622761000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2032,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.44629269394673,
		  25.584871431250686
		]
	  },
	  "properties" : {
		"FID" : 2032,
		"name" : "南厝基督教堂",
		"lng" : 119.45112399999999,
		"lat" : 25.582160999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2033,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.48450253783324,
		  25.571731586295936
		]
	  },
	  "properties" : {
		"FID" : 2033,
		"name" : "青山寺",
		"lng" : 119.489209,
		"lat" : 25.568926999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2034,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53347763647089,
		  25.586264789591304
		]
	  },
	  "properties" : {
		"FID" : 2034,
		"name" : "观音堂",
		"lng" : 119.53801,
		"lat" : 25.583314999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2035,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43597922424331,
		  25.618489212569841
		]
	  },
	  "properties" : {
		"FID" : 2035,
		"name" : "福庐寺",
		"lng" : 119.440838,
		"lat" : 25.615784000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2036,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.44795410291889,
		  25.531275038949094
		]
	  },
	  "properties" : {
		"FID" : 2036,
		"name" : "余氏宗祠",
		"lng" : 119.452777,
		"lat" : 25.528580999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2037,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43457643868665,
		  25.588302036177488
		]
	  },
	  "properties" : {
		"FID" : 2037,
		"name" : "海仔温泉",
		"lng" : 119.439436,
		"lat" : 25.585612000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2038,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.62690906557896,
		  25.425357031253402
		]
	  },
	  "properties" : {
		"FID" : 2038,
		"name" : "东京山",
		"lng" : 119.63132,
		"lat" : 25.422402000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2039,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53040059661711,
		  25.393755158700362
		]
	  },
	  "properties" : {
		"FID" : 2039,
		"name" : "梅塘毛氏宗祠",
		"lng" : 119.53492900000001,
		"lat" : 25.390868000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2040,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40738449463912,
		  25.614815712007797
		]
	  },
	  "properties" : {
		"FID" : 2040,
		"name" : "陈氏祠堂",
		"lng" : 119.41228599999999,
		"lat" : 25.612143
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2041,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5303919112432,
		  25.444944248190382
		]
	  },
	  "properties" : {
		"FID" : 2041,
		"name" : "纪念碑",
		"lng" : 119.534924,
		"lat" : 25.442046999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2042,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39219849273569,
		  25.573520940670775
		]
	  },
	  "properties" : {
		"FID" : 2042,
		"name" : "何氏支祠",
		"lng" : 119.397103,
		"lat" : 25.570867
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2043,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43492179835228,
		  25.66043902957275
		]
	  },
	  "properties" : {
		"FID" : 2043,
		"name" : "宝光寺",
		"lng" : 119.439786,
		"lat" : 25.657716000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2044,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.44576857996709,
		  25.459800492774637
		]
	  },
	  "properties" : {
		"FID" : 2044,
		"name" : "前薛村妈祖庙",
		"lng" : 119.450592,
		"lat" : 25.457132000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2045,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60575057164449,
		  25.391576332459476
		]
	  },
	  "properties" : {
		"FID" : 2045,
		"name" : "聚仙台景区",
		"lng" : 119.61015,
		"lat" : 25.388608000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2046,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5354371529757,
		  25.440834644841857
		]
	  },
	  "properties" : {
		"FID" : 2046,
		"name" : "福建省福清市目屿岛球尾自然风景区",
		"lng" : 119.539953,
		"lat" : 25.437926000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2047,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45828335806893,
		  25.607635202832324
		]
	  },
	  "properties" : {
		"FID" : 2047,
		"name" : "龙田基督教堂",
		"lng" : 119.463082,
		"lat" : 25.604887999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2048,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.59824697714781,
		  25.411663636413728
		]
	  },
	  "properties" : {
		"FID" : 2048,
		"name" : "文山天主堂",
		"lng" : 119.602649,
		"lat" : 25.408688999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2049,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45589731059546,
		  25.537319097690393
		]
	  },
	  "properties" : {
		"FID" : 2049,
		"name" : "基督教旺宅堂",
		"lng" : 119.46069799999999,
		"lat" : 25.534604999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2050,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45438317210184,
		  25.532490859712954
		]
	  },
	  "properties" : {
		"FID" : 2050,
		"name" : "芦华基督教堂",
		"lng" : 119.459188,
		"lat" : 25.529782000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2051,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35809010275759,
		  25.560724060791909
		]
	  },
	  "properties" : {
		"FID" : 2051,
		"name" : "妈祖宫",
		"lng" : 119.36296900000001,
		"lat" : 25.558045
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2052,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6984140640274,
		  25.481486154389604
		]
	  },
	  "properties" : {
		"FID" : 2052,
		"name" : "如意湖公园",
		"lng" : 119.70292000000001,
		"lat" : 25.478642000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2053,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.53763887635161,
		  25.398577426494729
		]
	  },
	  "properties" : {
		"FID" : 2053,
		"name" : "海巡王庙",
		"lng" : 119.542145,
		"lat" : 25.395672000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2054,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41679988651285,
		  25.564849452501022
		]
	  },
	  "properties" : {
		"FID" : 2054,
		"name" : "谢氏祠堂",
		"lng" : 119.421688,
		"lat" : 25.562190999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2055,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.68934681248345,
		  25.585861547984688
		]
	  },
	  "properties" : {
		"FID" : 2055,
		"name" : "半洋石帆",
		"lng" : 119.69385,
		"lat" : 25.582967
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2056,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.44982429586318,
		  25.462655841268884
		]
	  },
	  "properties" : {
		"FID" : 2056,
		"name" : "薛氏宗祠",
		"lng" : 119.45463700000001,
		"lat" : 25.459978
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2057,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41791592094751,
		  25.650506298840838
		]
	  },
	  "properties" : {
		"FID" : 2057,
		"name" : "陈氏祠堂",
		"lng" : 119.422809,
		"lat" : 25.64781
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2058,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61067630368117,
		  25.401600953872418
		]
	  },
	  "properties" : {
		"FID" : 2058,
		"name" : "西来寺",
		"lng" : 119.615077,
		"lat" : 25.398634000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2059,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38802754000979,
		  25.590466023665993
		]
	  },
	  "properties" : {
		"FID" : 2059,
		"name" : "锦美基督教堂",
		"lng" : 119.392933,
		"lat" : 25.587803999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2060,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.70171073906361,
		  25.482859550562051
		]
	  },
	  "properties" : {
		"FID" : 2060,
		"name" : "金井湾市民广场",
		"lng" : 119.70622,
		"lat" : 25.48002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2061,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45181988825524,
		  25.58464234031733
		]
	  },
	  "properties" : {
		"FID" : 2061,
		"name" : "七井坑基督教堂",
		"lng" : 119.456636,
		"lat" : 25.58192
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2062,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.71380673813775,
		  25.440339073473336
		]
	  },
	  "properties" : {
		"FID" : 2062,
		"name" : "刘氏宗祠",
		"lng" : 119.718322,
		"lat" : 25.437525999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2063,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.5955259779591,
		  25.467427451764056
		]
	  },
	  "properties" : {
		"FID" : 2063,
		"name" : "蔡氏宗祠",
		"lng" : 119.59993299999999,
		"lat" : 25.46444
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2064,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.74142373807777,
		  25.50286309233045
		]
	  },
	  "properties" : {
		"FID" : 2064,
		"name" : "平潭雕塑园",
		"lng" : 119.74594399999999,
		"lat" : 25.500052
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2065,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73198663941949,
		  25.48620945480269
		]
	  },
	  "properties" : {
		"FID" : 2065,
		"name" : "潮海寺",
		"lng" : 119.736509,
		"lat" : 25.4834
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2066,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.70857833549378,
		  25.478534865047109
		]
	  },
	  "properties" : {
		"FID" : 2066,
		"name" : "天牛河公园",
		"lng" : 119.713093,
		"lat" : 25.475705999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2067,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36754644003329,
		  25.590180246169908
		]
	  },
	  "properties" : {
		"FID" : 2067,
		"name" : "树下祠堂",
		"lng" : 119.372439,
		"lat" : 25.587502000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2068,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.68959451671822,
		  25.585747074404978
		]
	  },
	  "properties" : {
		"FID" : 2068,
		"name" : "石牌洋",
		"lng" : 119.694098,
		"lat" : 25.582853
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2069,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50270694250709,
		  25.43591081773873
		]
	  },
	  "properties" : {
		"FID" : 2069,
		"name" : "福清市沙埔镇赤礁村商氏祠堂",
		"lng" : 119.507336,
		"lat" : 25.433093
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2070,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47621879478422,
		  25.583925309666792
		]
	  },
	  "properties" : {
		"FID" : 2070,
		"name" : "吴氏宗祠",
		"lng" : 119.48095600000001,
		"lat" : 25.581140000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2071,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45296331476662,
		  25.474463964545368
		]
	  },
	  "properties" : {
		"FID" : 2071,
		"name" : "福清泽岐基督教堂",
		"lng" : 119.457768,
		"lat" : 25.471775999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2072,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58228637459582,
		  25.460185020336567
		]
	  },
	  "properties" : {
		"FID" : 2072,
		"name" : "林氏宗祠",
		"lng" : 119.586703,
		"lat" : 25.457201999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2073,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47138768091044,
		  25.560205509272933
		]
	  },
	  "properties" : {
		"FID" : 2073,
		"name" : "龙湖公园-龙湖文化广场",
		"lng" : 119.47614,
		"lat" : 25.557442999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2074,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41561603809269,
		  25.55664538180077
		]
	  },
	  "properties" : {
		"FID" : 2074,
		"name" : "农耕公园",
		"lng" : 119.42050500000001,
		"lat" : 25.553991
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2075,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.44460735299694,
		  25.611164005334377
		]
	  },
	  "properties" : {
		"FID" : 2075,
		"name" : "龙田镇青春广场",
		"lng" : 119.449445,
		"lat" : 25.608446000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2076,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45619083393112,
		  25.609780047067989
		]
	  },
	  "properties" : {
		"FID" : 2076,
		"name" : "万国广场",
		"lng" : 119.46099599999999,
		"lat" : 25.607036999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2077,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4073654978786,
		  25.547786947342637
		]
	  },
	  "properties" : {
		"FID" : 2077,
		"name" : "共享公园",
		"lng" : 119.412262,
		"lat" : 25.545141000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2078,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40776460485684,
		  25.550593139919503
		]
	  },
	  "properties" : {
		"FID" : 2078,
		"name" : "翁氏宗祠",
		"lng" : 119.412661,
		"lat" : 25.547946
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2079,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43736501612916,
		  25.582145255376474
		]
	  },
	  "properties" : {
		"FID" : 2079,
		"name" : "谢氏支祠",
		"lng" : 119.442218,
		"lat" : 25.579453000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2080,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38173596039654,
		  25.638463382099896
		]
	  },
	  "properties" : {
		"FID" : 2080,
		"name" : "福清市吉水禅寺",
		"lng" : 119.38664300000001,
		"lat" : 25.635777000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2081,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.58175379878799,
		  25.460089728058779
		]
	  },
	  "properties" : {
		"FID" : 2081,
		"name" : "西江堂",
		"lng" : 119.58617099999999,
		"lat" : 25.457107000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2082,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.69082437716658,
		  25.594744651405815
		]
	  },
	  "properties" : {
		"FID" : 2082,
		"name" : "康安五显大王宫",
		"lng" : 119.69533,
		"lat" : 25.591849
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2083,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.44606578514005,
		  25.467559070730896
		]
	  },
	  "properties" : {
		"FID" : 2083,
		"name" : "海滨公园",
		"lng" : 119.450889,
		"lat" : 25.464887999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2084,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.48445735846835,
		  25.5719235272703
		]
	  },
	  "properties" : {
		"FID" : 2084,
		"name" : "君汉厝祖厅",
		"lng" : 119.489164,
		"lat" : 25.569119000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2085,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.67497200072147,
		  25.475756686680146
		]
	  },
	  "properties" : {
		"FID" : 2085,
		"name" : "娘宫妈祖宫",
		"lng" : 119.67944799999999,
		"lat" : 25.472873
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2086,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47680125784312,
		  25.592105306755798
		]
	  },
	  "properties" : {
		"FID" : 2086,
		"name" : "何氏宗祠",
		"lng" : 119.481537,
		"lat" : 25.589314999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2087,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.7428785274285,
		  25.503626125184102
		]
	  },
	  "properties" : {
		"FID" : 2087,
		"name" : "竹屿湖公园",
		"lng" : 119.747398,
		"lat" : 25.500814999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2088,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.48387013711417,
		  25.613933147968321
		]
	  },
	  "properties" : {
		"FID" : 2088,
		"name" : "东营村天主教堂",
		"lng" : 119.48858199999999,
		"lat" : 25.611113
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2089,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.70555694607918,
		  25.613557844952705
		]
	  },
	  "properties" : {
		"FID" : 2089,
		"name" : "苏澳基督教堂",
		"lng" : 119.71007899999999,
		"lat" : 25.610676999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2090,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60503545218907,
		  25.350692034150264
		]
	  },
	  "properties" : {
		"FID" : 2090,
		"name" : "福清东瀚镇莲峰村滨海旅游区",
		"lng" : 119.609432,
		"lat" : 25.347729000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2091,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47541401373472,
		  25.596732270534574
		]
	  },
	  "properties" : {
		"FID" : 2091,
		"name" : "施氏旧厝底祖厅",
		"lng" : 119.480155,
		"lat" : 25.593944
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2092,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50298873838611,
		  25.439363418338687
		]
	  },
	  "properties" : {
		"FID" : 2092,
		"name" : "福清市沙埔镇赤礁村林氏祠堂",
		"lng" : 119.507617,
		"lat" : 25.436544000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2093,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.68986005260128,
		  25.448507787214957
		]
	  },
	  "properties" : {
		"FID" : 2093,
		"name" : "吉钓基督教堂",
		"lng" : 119.694354,
		"lat" : 25.445658000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2094,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.50924979175596,
		  25.411893273544237
		]
	  },
	  "properties" : {
		"FID" : 2094,
		"name" : "沙埔镇龙洋村莫厝祠堂",
		"lng" : 119.513853,
		"lat" : 25.409061000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2095,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76976367392982,
		  25.496508571433601
		]
	  },
	  "properties" : {
		"FID" : 2095,
		"name" : "金峰寺",
		"lng" : 119.77425100000001,
		"lat" : 25.493689
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2096,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47631139584543,
		  25.607441367280092
		]
	  },
	  "properties" : {
		"FID" : 2096,
		"name" : "东施村功德碑",
		"lng" : 119.48105,
		"lat" : 25.604645999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2097,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.55744239898067,
		  25.396127744327927
		]
	  },
	  "properties" : {
		"FID" : 2097,
		"name" : "夏田陈氏宗祠",
		"lng" : 119.561896,
		"lat" : 25.393184000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2098,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76601054294726,
		  25.411880146785755
		]
	  },
	  "properties" : {
		"FID" : 2098,
		"name" : "三军联合作战演习纪念碑",
		"lng" : 119.770498,
		"lat" : 25.409084
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2099,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40537798785601,
		  25.68187984921985
		]
	  },
	  "properties" : {
		"FID" : 2099,
		"name" : "东林寺",
		"lng" : 119.410286,
		"lat" : 25.679175999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2100,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.61810530824792,
		  25.349041024033458
		]
	  },
	  "properties" : {
		"FID" : 2100,
		"name" : "弘福寺",
		"lng" : 119.622505,
		"lat" : 25.346088000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2101,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73741656875066,
		  25.465452636340192
		]
	  },
	  "properties" : {
		"FID" : 2101,
		"name" : "平潭国际旅游岛·南寨山景区",
		"lng" : 119.741936,
		"lat" : 25.462651000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2102,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.70220759447876,
		  25.478465618751379
		]
	  },
	  "properties" : {
		"FID" : 2102,
		"name" : "世茂纳米公园",
		"lng" : 119.706717,
		"lat" : 25.475628
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2103,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.46103582165446,
		  25.690413548922102
		]
	  },
	  "properties" : {
		"FID" : 2103,
		"name" : "海口基督堂",
		"lng" : 119.46583200000001,
		"lat" : 25.687619999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2104,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.44105189104644,
		  25.659374341045353
		]
	  },
	  "properties" : {
		"FID" : 2104,
		"name" : "善福堂",
		"lng" : 119.445902,
		"lat" : 25.656641
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2105,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41980202290881,
		  25.683615559679605
		]
	  },
	  "properties" : {
		"FID" : 2105,
		"name" : "永鸿野生动物世界",
		"lng" : 119.424695,
		"lat" : 25.680900999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2106,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40805486456195,
		  25.590360637244341
		]
	  },
	  "properties" : {
		"FID" : 2106,
		"name" : "福清镜柳圃寺",
		"lng" : 119.412954,
		"lat" : 25.587698
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2107,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77891487907559,
		  25.511372442500015
		]
	  },
	  "properties" : {
		"FID" : 2107,
		"name" : "平潭城关基督教堂(一堂)",
		"lng" : 119.78338599999999,
		"lat" : 25.508538999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2108,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35745294340718,
		  25.561204164859042
		]
	  },
	  "properties" : {
		"FID" : 2108,
		"name" : "陈氏祠堂",
		"lng" : 119.362331,
		"lat" : 25.558523999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2109,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.39012944336875,
		  25.708008284344444
		]
	  },
	  "properties" : {
		"FID" : 2109,
		"name" : "齐天大圣",
		"lng" : 119.395044,
		"lat" : 25.705290999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2110,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40555823297943,
		  25.586960198803457
		]
	  },
	  "properties" : {
		"FID" : 2110,
		"name" : "南华村何氏宗祠",
		"lng" : 119.410459,
		"lat" : 25.584299999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2111,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45064533204106,
		  25.628237409825058
		]
	  },
	  "properties" : {
		"FID" : 2111,
		"name" : "上薛岭头顶基督教堂",
		"lng" : 119.455468,
		"lat" : 25.625499000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2112,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45157857661749,
		  25.566071511020461
		]
	  },
	  "properties" : {
		"FID" : 2112,
		"name" : "龙岭寺",
		"lng" : 119.456394,
		"lat" : 25.563357
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2113,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31463286319887,
		  25.591498715344066
		]
	  },
	  "properties" : {
		"FID" : 2113,
		"name" : "九龙寺",
		"lng" : 119.31943699999999,
		"lat" : 25.588730000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2114,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31361289053908,
		  25.455288003766871
		]
	  },
	  "properties" : {
		"FID" : 2114,
		"name" : "琴江翁氏宗祠",
		"lng" : 119.318405,
		"lat" : 25.452562
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2115,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.42658415663095,
		  25.625141129746265
		]
	  },
	  "properties" : {
		"FID" : 2115,
		"name" : "龙田灵岩寺",
		"lng" : 119.431462,
		"lat" : 25.622447000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2116,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.4565616755789,
		  25.599993756196241
		]
	  },
	  "properties" : {
		"FID" : 2116,
		"name" : "龙田镇观音阁寺",
		"lng" : 119.461365,
		"lat" : 25.597254
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2117,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.70317560576483,
		  25.438250331162163
		]
	  },
	  "properties" : {
		"FID" : 2117,
		"name" : "虞塘祖庙",
		"lng" : 119.707683,
		"lat" : 25.435424000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2118,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38492038207784,
		  25.682716172551487
		]
	  },
	  "properties" : {
		"FID" : 2118,
		"name" : "林氏宗祠(苍霞)",
		"lng" : 119.389832,
		"lat" : 25.680009999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2119,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43882697845997,
		  25.681272195147908
		]
	  },
	  "properties" : {
		"FID" : 2119,
		"name" : "福清市海口镇东埔基督教堂",
		"lng" : 119.443684,
		"lat" : 25.678532000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2120,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40285318860163,
		  25.698314647573618
		]
	  },
	  "properties" : {
		"FID" : 2120,
		"name" : "天主堂",
		"lng" : 119.407764,
		"lat" : 25.695602999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2121,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.43597620180068,
		  25.618701301480524
		]
	  },
	  "properties" : {
		"FID" : 2121,
		"name" : "福庐僊宫楼",
		"lng" : 119.44083500000001,
		"lat" : 25.615995999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2122,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38854057683844,
		  25.708626164838222
		]
	  },
	  "properties" : {
		"FID" : 2122,
		"name" : "东湖境五显庙",
		"lng" : 119.393455,
		"lat" : 25.705908000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2123,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.70256215478496,
		  25.438295226519386
		]
	  },
	  "properties" : {
		"FID" : 2123,
		"name" : "建民沙坝",
		"lng" : 119.707069,
		"lat" : 25.435468
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2124,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30008030043129,
		  25.419152457574842
		]
	  },
	  "properties" : {
		"FID" : 2124,
		"name" : "玉玺山公园",
		"lng" : 119.304845,
		"lat" : 25.416409999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2125,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28742259617837,
		  25.47256074698997
		]
	  },
	  "properties" : {
		"FID" : 2125,
		"name" : "江阴芝山教会",
		"lng" : 119.292171,
		"lat" : 25.469785999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2126,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.63552009191478,
		  25.465855260720005
		]
	  },
	  "properties" : {
		"FID" : 2126,
		"name" : "赤表村小公园",
		"lng" : 119.639942,
		"lat" : 25.462903000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2127,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32520671726552,
		  25.615096599376788
		]
	  },
	  "properties" : {
		"FID" : 2127,
		"name" : "鳌江宝塔",
		"lng" : 119.330033,
		"lat" : 25.612338000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2128,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.68640867980034,
		  25.597338407812437
		]
	  },
	  "properties" : {
		"FID" : 2128,
		"name" : "渔舟识趣",
		"lng" : 119.690909,
		"lat" : 25.594434
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2129,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47444805817513,
		  25.577156584414418
		]
	  },
	  "properties" : {
		"FID" : 2129,
		"name" : "化北寺回善堂",
		"lng" : 119.479191,
		"lat" : 25.574379
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2130,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32510346438875,
		  25.527006752634666
		]
	  },
	  "properties" : {
		"FID" : 2130,
		"name" : "竹埔禅寺",
		"lng" : 119.32992299999999,
		"lat" : 25.524281999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2131,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.71089357551516,
		  25.53642876365187
		]
	  },
	  "properties" : {
		"FID" : 2131,
		"name" : "神马三相府",
		"lng" : 119.715414,
		"lat" : 25.533584999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2132,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.443492938079,
		  25.618923188085041
		]
	  },
	  "properties" : {
		"FID" : 2132,
		"name" : "施氏宗祠",
		"lng" : 119.448334,
		"lat" : 25.616204
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2133,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45436310671676,
		  25.613680411878725
		]
	  },
	  "properties" : {
		"FID" : 2133,
		"name" : "卢寿贵传人卢兴明寓所",
		"lng" : 119.459174,
		"lat" : 25.610939999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2134,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.75866495799477,
		  25.441213664690416
		]
	  },
	  "properties" : {
		"FID" : 2134,
		"name" : "平潭岛海滩",
		"lng" : 119.763165,
		"lat" : 25.438416
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2135,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40865500205214,
		  25.60856259409772
		]
	  },
	  "properties" : {
		"FID" : 2135,
		"name" : "灵瑞禅寺",
		"lng" : 119.413555,
		"lat" : 25.605892000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2136,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.7213852812454,
		  25.611427853694405
		]
	  },
	  "properties" : {
		"FID" : 2136,
		"name" : "桃花寨遗址",
		"lng" : 119.725916,
		"lat" : 25.608566
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2137,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.64441575733751,
		  25.395254998332806
		]
	  },
	  "properties" : {
		"FID" : 2137,
		"name" : "齐天府",
		"lng" : 119.648843,
		"lat" : 25.392332
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2138,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.41885496060117,
		  25.626790132034785
		]
	  },
	  "properties" : {
		"FID" : 2138,
		"name" : "基督教西坑聚会处",
		"lng" : 119.423745,
		"lat" : 25.624103999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2139,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79208147167208,
		  25.512391492378413
		]
	  },
	  "properties" : {
		"FID" : 2139,
		"name" : "平潭第二教堂",
		"lng" : 119.79652299999999,
		"lat" : 25.509540000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2140,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60851978657375,
		  25.428308535642632
		]
	  },
	  "properties" : {
		"FID" : 2140,
		"name" : "林氏宗祠",
		"lng" : 119.612922,
		"lat" : 25.425335
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2141,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.60365770438482,
		  25.431067736801989
		]
	  },
	  "properties" : {
		"FID" : 2141,
		"name" : "太子亭公园",
		"lng" : 119.60805999999999,
		"lat" : 25.428090999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2142,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35128141560611,
		  25.609605191313715
		]
	  },
	  "properties" : {
		"FID" : 2142,
		"name" : "林氏祠堂",
		"lng" : 119.356154,
		"lat" : 25.606895999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2143,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6878397541506,
		  25.445704644288522
		]
	  },
	  "properties" : {
		"FID" : 2143,
		"name" : "林厝祖厅",
		"lng" : 119.692331,
		"lat" : 25.442851999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2144,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.45755795209101,
		  25.610106494413223
		]
	  },
	  "properties" : {
		"FID" : 2144,
		"name" : "龙田张厝祠",
		"lng" : 119.46235900000001,
		"lat" : 25.60736
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2145,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37598888138885,
		  25.711258497724476
		]
	  },
	  "properties" : {
		"FID" : 2145,
		"name" : "南涧寺",
		"lng" : 119.380898,
		"lat" : 25.708531000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2146,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32337285344315,
		  25.62055252060458
		]
	  },
	  "properties" : {
		"FID" : 2146,
		"name" : "泰山宫",
		"lng" : 119.32819600000001,
		"lat" : 25.617788000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2147,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.47511892881187,
		  25.583747108704024
		]
	  },
	  "properties" : {
		"FID" : 2147,
		"name" : "吴氏大庴底祖厅",
		"lng" : 119.47986,
		"lat" : 25.580964999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2148,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79176203104012,
		  25.521688983372474
		]
	  },
	  "properties" : {
		"FID" : 2148,
		"name" : "莲花山公园",
		"lng" : 119.796205,
		"lat" : 25.518834999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2149,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77891487907559,
		  25.511372442500015
		]
	  },
	  "properties" : {
		"FID" : 2149,
		"name" : "平潭城关基督教堂(一堂)",
		"lng" : 119.78338599999999,
		"lat" : 25.508538999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2150,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78352046661637,
		  25.514060962496711
		]
	  },
	  "properties" : {
		"FID" : 2150,
		"name" : "平潭桂秋馥境",
		"lng" : 119.787982,
		"lat" : 25.511220999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2151,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79883649579172,
		  25.526700812683448
		]
	  },
	  "properties" : {
		"FID" : 2151,
		"name" : "基督徒聚会处华夏庄园堂点",
		"lng" : 119.803262,
		"lat" : 25.523834000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2152,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78072055283917,
		  25.512467938066774
		]
	  },
	  "properties" : {
		"FID" : 2152,
		"name" : "圣王庙",
		"lng" : 119.78518800000001,
		"lat" : 25.509632
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2153,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79208147167208,
		  25.512391492378413
		]
	  },
	  "properties" : {
		"FID" : 2153,
		"name" : "平潭第二教堂",
		"lng" : 119.79652299999999,
		"lat" : 25.509540000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2154,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79252338430378,
		  25.54283529912361
		]
	  },
	  "properties" : {
		"FID" : 2154,
		"name" : "平潭龙兴寺",
		"lng" : 119.796966,
		"lat" : 25.539973
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2155,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77875673615902,
		  25.508846472801906
		]
	  },
	  "properties" : {
		"FID" : 2155,
		"name" : "五福庙",
		"lng" : 119.78322799999999,
		"lat" : 25.506014
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2156,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.8042450223012,
		  25.538249907142053
		]
	  },
	  "properties" : {
		"FID" : 2156,
		"name" : "平潭李子团",
		"lng" : 119.808657,
		"lat" : 25.53537
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2157,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.7773991584347,
		  25.50655521897751
		]
	  },
	  "properties" : {
		"FID" : 2157,
		"name" : "天主堂",
		"lng" : 119.781873,
		"lat" : 25.503724999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2158,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76146292266642,
		  25.53570598060158
		]
	  },
	  "properties" : {
		"FID" : 2158,
		"name" : "施天章故居",
		"lng" : 119.76596600000001,
		"lat" : 25.532879999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2159,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79034018265392,
		  25.541547578122071
		]
	  },
	  "properties" : {
		"FID" : 2159,
		"name" : "田中基督教堂",
		"lng" : 119.794788,
		"lat" : 25.538689000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2160,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77883671704978,
		  25.511401360546522
		]
	  },
	  "properties" : {
		"FID" : 2160,
		"name" : "福音堂",
		"lng" : 119.78330800000001,
		"lat" : 25.508568
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2161,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77672681523858,
		  25.506679511159156
		]
	  },
	  "properties" : {
		"FID" : 2161,
		"name" : "福胜正镜都城隍庙",
		"lng" : 119.78120199999999,
		"lat" : 25.50385
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2162,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78160581331802,
		  25.5071203664527
		]
	  },
	  "properties" : {
		"FID" : 2162,
		"name" : "瑞山公园",
		"lng" : 119.78607100000001,
		"lat" : 25.504284999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2163,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78064542782226,
		  25.512002700656801
		]
	  },
	  "properties" : {
		"FID" : 2163,
		"name" : "福恩境",
		"lng" : 119.785113,
		"lat" : 25.509167000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2164,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78776749798747,
		  25.508066841118922
		]
	  },
	  "properties" : {
		"FID" : 2164,
		"name" : "平潭风力发电纪念塔",
		"lng" : 119.792219,
		"lat" : 25.505223000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2165,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79860979383407,
		  25.528292968789401
		]
	  },
	  "properties" : {
		"FID" : 2165,
		"name" : "寿仙谷",
		"lng" : 119.80303600000001,
		"lat" : 25.525426
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2166,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78416440056019,
		  25.506875565065705
		]
	  },
	  "properties" : {
		"FID" : 2166,
		"name" : "平潭特",
		"lng" : 119.788624,
		"lat" : 25.504037
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2167,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.80305727024185,
		  25.531978704263285
		]
	  },
	  "properties" : {
		"FID" : 2167,
		"name" : "上楼大王宫",
		"lng" : 119.807472,
		"lat" : 25.529102999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2168,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78986373543192,
		  25.5037905415826
		]
	  },
	  "properties" : {
		"FID" : 2168,
		"name" : "新潭城市广场",
		"lng" : 119.79431,
		"lat" : 25.500945000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2169,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76863837085048,
		  25.515940558059974
		]
	  },
	  "properties" : {
		"FID" : 2169,
		"name" : "平潭福德洋圣境",
		"lng" : 119.773129,
		"lat" : 25.513116
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2170,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77871852281817,
		  25.510740016763105
		]
	  },
	  "properties" : {
		"FID" : 2170,
		"name" : "抗日志士王开诚故居",
		"lng" : 119.78319,
		"lat" : 25.507906999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2171,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78740066057506,
		  25.50788326929235
		]
	  },
	  "properties" : {
		"FID" : 2171,
		"name" : "风力田文体公园",
		"lng" : 119.791853,
		"lat" : 25.505040000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2172,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78724629065266,
		  25.50806811050699
		]
	  },
	  "properties" : {
		"FID" : 2172,
		"name" : "江继芸纪念馆",
		"lng" : 119.79169899999999,
		"lat" : 25.505224999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2173,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79319363135366,
		  25.506362318225957
		]
	  },
	  "properties" : {
		"FID" : 2173,
		"name" : "人口文化主题公园",
		"lng" : 119.79763199999999,
		"lat" : 25.503511
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2174,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79923442827699,
		  25.514087385090459
		]
	  },
	  "properties" : {
		"FID" : 2174,
		"name" : "平潭海岛国家森林公园",
		"lng" : 119.803658,
		"lat" : 25.511223999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2175,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79044192448517,
		  25.548587224576412
		]
	  },
	  "properties" : {
		"FID" : 2175,
		"name" : "平潭中楼乡马鞍寺",
		"lng" : 119.79489,
		"lat" : 25.545725999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2176,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77845009409901,
		  25.509089193461286
		]
	  },
	  "properties" : {
		"FID" : 2176,
		"name" : "五福观音堂",
		"lng" : 119.782922,
		"lat" : 25.506257000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2177,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.7911507045407,
		  25.50545994879063
		]
	  },
	  "properties" : {
		"FID" : 2177,
		"name" : "翠园",
		"lng" : 119.79559399999999,
		"lat" : 25.502611999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2178,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78322709055089,
		  25.496305169590908
		]
	  },
	  "properties" : {
		"FID" : 2178,
		"name" : "万宝公园",
		"lng" : 119.787688,
		"lat" : 25.493471
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2179,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.7747869639704,
		  25.54984984555934
		]
	  },
	  "properties" : {
		"FID" : 2179,
		"name" : "平潭站站前广场",
		"lng" : 119.779269,
		"lat" : 25.547008000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2180,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76976367392982,
		  25.496508571433601
		]
	  },
	  "properties" : {
		"FID" : 2180,
		"name" : "金峰寺",
		"lng" : 119.77425100000001,
		"lat" : 25.493689
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2181,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78982355988096,
		  25.504911823610009
		]
	  },
	  "properties" : {
		"FID" : 2181,
		"name" : "平潭双拥主题公园",
		"lng" : 119.79427,
		"lat" : 25.502065999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2182,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.80315443249503,
		  25.547442252792528
		]
	  },
	  "properties" : {
		"FID" : 2182,
		"name" : "松南基督教堂",
		"lng" : 119.80757,
		"lat" : 25.544561000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2183,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.7975493440814,
		  25.552328615073808
		]
	  },
	  "properties" : {
		"FID" : 2183,
		"name" : "文昌庙",
		"lng" : 119.80198,
		"lat" : 25.549454999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2184,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78166957930773,
		  25.498299783914028
		]
	  },
	  "properties" : {
		"FID" : 2184,
		"name" : "承启堂",
		"lng" : 119.786134,
		"lat" : 25.495467000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2185,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76808120976884,
		  25.505227758020961
		]
	  },
	  "properties" : {
		"FID" : 2185,
		"name" : "平潭水仙花口袋公园",
		"lng" : 119.772572,
		"lat" : 25.502407000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2186,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.783338184176,
		  25.498401931618933
		]
	  },
	  "properties" : {
		"FID" : 2186,
		"name" : "天天向上室",
		"lng" : 119.78779900000001,
		"lat" : 25.495567000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2187,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77158170242568,
		  25.498747878820371
		]
	  },
	  "properties" : {
		"FID" : 2187,
		"name" : "陈氏宗祠",
		"lng" : 119.776066,
		"lat" : 25.495926000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2188,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79528736338914,
		  25.499209424494964
		]
	  },
	  "properties" : {
		"FID" : 2188,
		"name" : "平潭白马三尊王府",
		"lng" : 119.79971999999999,
		"lat" : 25.496357
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2189,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76963534778851,
		  25.497985895101646
		]
	  },
	  "properties" : {
		"FID" : 2189,
		"name" : "闽王纪念堂",
		"lng" : 119.774123,
		"lat" : 25.495166000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2190,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77485110324042,
		  25.493715632683053
		]
	  },
	  "properties" : {
		"FID" : 2190,
		"name" : "藏音阁",
		"lng" : 119.779329,
		"lat" : 25.490891999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2191,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.80393055146655,
		  25.504740460473037
		]
	  },
	  "properties" : {
		"FID" : 2191,
		"name" : "龙王头海洋公园",
		"lng" : 119.808341,
		"lat" : 25.501871999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2192,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.7428785274285,
		  25.503626125184102
		]
	  },
	  "properties" : {
		"FID" : 2192,
		"name" : "竹屿湖公园",
		"lng" : 119.747398,
		"lat" : 25.500814999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2193,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.8298085261611,
		  25.549979268481788
		]
	  },
	  "properties" : {
		"FID" : 2193,
		"name" : "金沙湾沙滩",
		"lng" : 119.834149,
		"lat" : 25.547048
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2194,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77696590298936,
		  25.567954912022202
		]
	  },
	  "properties" : {
		"FID" : 2194,
		"name" : "平潭天峰寺",
		"lng" : 119.78144500000001,
		"lat" : 25.565104000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2195,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73198663941949,
		  25.48620945480269
		]
	  },
	  "properties" : {
		"FID" : 2195,
		"name" : "潮海寺",
		"lng" : 119.736509,
		"lat" : 25.4834
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2196,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73741656875066,
		  25.465452636340192
		]
	  },
	  "properties" : {
		"FID" : 2196,
		"name" : "平潭国际旅游岛·南寨山景区",
		"lng" : 119.741936,
		"lat" : 25.462651000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2197,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.80431984211911,
		  25.501359115465853
		]
	  },
	  "properties" : {
		"FID" : 2197,
		"name" : "平潭岛沙滩",
		"lng" : 119.808729,
		"lat" : 25.498491000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2198,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.81794464285048,
		  25.476522826307317
		]
	  },
	  "properties" : {
		"FID" : 2198,
		"name" : "澳前台湾小镇",
		"lng" : 119.82231400000001,
		"lat" : 25.473637
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2199,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78971510794236,
		  25.493593299013643
		]
	  },
	  "properties" : {
		"FID" : 2199,
		"name" : "西航公园西园",
		"lng" : 119.794161,
		"lat" : 25.490750999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2200,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.80287341735571,
		  25.494783666612822
		]
	  },
	  "properties" : {
		"FID" : 2200,
		"name" : "华阳寺",
		"lng" : 119.807286,
		"lat" : 25.49192
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2201,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77902578123764,
		  25.487925586383074
		]
	  },
	  "properties" : {
		"FID" : 2201,
		"name" : "万森郎园",
		"lng" : 119.783495,
		"lat" : 25.485099000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2202,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78212560450164,
		  25.469607373461002
		]
	  },
	  "properties" : {
		"FID" : 2202,
		"name" : "海坛古城",
		"lng" : 119.786587,
		"lat" : 25.466781999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2203,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79455013865375,
		  25.490399693175771
		]
	  },
	  "properties" : {
		"FID" : 2203,
		"name" : "平潭龙山俚欢乐小镇",
		"lng" : 119.798984,
		"lat" : 25.487551
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2204,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.82326630853777,
		  25.584182011662961
		]
	  },
	  "properties" : {
		"FID" : 2204,
		"name" : "蓝眼泪观景点(流水镇文创村海滩)",
		"lng" : 119.827628,
		"lat" : 25.581250000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2205,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.80700960348928,
		  25.466991281297542
		]
	  },
	  "properties" : {
		"FID" : 2205,
		"name" : "前进基督教堂",
		"lng" : 119.811409,
		"lat" : 25.464127999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2206,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.84214596685595,
		  25.568417606422557
		]
	  },
	  "properties" : {
		"FID" : 2206,
		"name" : "模镜码头",
		"lng" : 119.846453,
		"lat" : 25.565456999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2207,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77910140397618,
		  25.453346635803431
		]
	  },
	  "properties" : {
		"FID" : 2207,
		"name" : "平潭彩虹湾旅游景点",
		"lng" : 119.783568,
		"lat" : 25.450529
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2208,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77175132342133,
		  25.494314734548812
		]
	  },
	  "properties" : {
		"FID" : 2208,
		"name" : "舍人宫",
		"lng" : 119.776235,
		"lat" : 25.491493999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2209,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77086741985379,
		  25.568734048529674
		]
	  },
	  "properties" : {
		"FID" : 2209,
		"name" : "平潭综合实验区主题党日馆",
		"lng" : 119.775358,
		"lat" : 25.565888999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2210,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78852977717646,
		  25.458920280245763
		]
	  },
	  "properties" : {
		"FID" : 2210,
		"name" : "坛南湾七号沙滩",
		"lng" : 119.792976,
		"lat" : 25.456088999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2211,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78656372146033,
		  25.494041960069932
		]
	  },
	  "properties" : {
		"FID" : 2211,
		"name" : "城关教堂海滨城祷告点",
		"lng" : 119.791017,
		"lat" : 25.491204
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2212,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78449423656997,
		  25.491409402232897
		]
	  },
	  "properties" : {
		"FID" : 2212,
		"name" : "伊甸楼",
		"lng" : 119.78895199999999,
		"lat" : 25.488575000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2213,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.82371836531429,
		  25.587634259538664
		]
	  },
	  "properties" : {
		"FID" : 2213,
		"name" : "北港村石头厝",
		"lng" : 119.828079,
		"lat" : 25.584700000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2214,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.82438226848713,
		  25.587739553913281
		]
	  },
	  "properties" : {
		"FID" : 2214,
		"name" : "北港村",
		"lng" : 119.82874099999999,
		"lat" : 25.584803999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2215,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77482228156434,
		  25.490452661608675
		]
	  },
	  "properties" : {
		"FID" : 2215,
		"name" : "福墓山",
		"lng" : 119.77930000000001,
		"lat" : 25.487629999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2216,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.86588916103038,
		  25.552796764863967
		]
	  },
	  "properties" : {
		"FID" : 2216,
		"name" : "平潭国际旅游岛·仙人井",
		"lng" : 119.870136,
		"lat" : 25.549806
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2217,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.75866495799477,
		  25.441213664690416
		]
	  },
	  "properties" : {
		"FID" : 2217,
		"name" : "平潭岛海滩",
		"lng" : 119.763165,
		"lat" : 25.438416
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2218,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.75541100817296,
		  25.441328309188208
		]
	  },
	  "properties" : {
		"FID" : 2218,
		"name" : "平潭国际旅游岛·坛南湾",
		"lng" : 119.75991500000001,
		"lat" : 25.438531999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2219,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.80333764521572,
		  25.480918541994868
		]
	  },
	  "properties" : {
		"FID" : 2219,
		"name" : "平潭高福宫",
		"lng" : 119.807748,
		"lat" : 25.478058000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2220,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78300385388377,
		  25.46474023847189
		]
	  },
	  "properties" : {
		"FID" : 2220,
		"name" : "平潭国际旅游岛",
		"lng" : 119.787463,
		"lat" : 25.461915000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2221,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.68934681248345,
		  25.585861547984688
		]
	  },
	  "properties" : {
		"FID" : 2221,
		"name" : "半洋石帆",
		"lng" : 119.69385,
		"lat" : 25.582967
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2222,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.7711074511451,
		  25.574209387228574
		]
	  },
	  "properties" : {
		"FID" : 2222,
		"name" : "大坪上王宫",
		"lng" : 119.775598,
		"lat" : 25.571362000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2223,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78609195801937,
		  25.489651047603502
		]
	  },
	  "properties" : {
		"FID" : 2223,
		"name" : "西航金座广场",
		"lng" : 119.79054600000001,
		"lat" : 25.486815
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2224,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.8103348406034,
		  25.480635879945055
		]
	  },
	  "properties" : {
		"FID" : 2224,
		"name" : "姜太公神庙",
		"lng" : 119.81472599999999,
		"lat" : 25.477762999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2225,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78829725285276,
		  25.458638879471184
		]
	  },
	  "properties" : {
		"FID" : 2225,
		"name" : "坛南湾",
		"lng" : 119.792744,
		"lat" : 25.455808000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2226,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76349937294948,
		  25.444626203057162
		]
	  },
	  "properties" : {
		"FID" : 2226,
		"name" : "崎沙澳",
		"lng" : 119.767993,
		"lat" : 25.441825000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2227,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76601054294726,
		  25.411880146785755
		]
	  },
	  "properties" : {
		"FID" : 2227,
		"name" : "三军联合作战演习纪念碑",
		"lng" : 119.770498,
		"lat" : 25.409084
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2228,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77743822568065,
		  25.464704532753824
		]
	  },
	  "properties" : {
		"FID" : 2228,
		"name" : "鸣凤山公园",
		"lng" : 119.781909,
		"lat" : 25.461886
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2229,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.79985411105301,
		  25.485032763864943
		]
	  },
	  "properties" : {
		"FID" : 2229,
		"name" : "大岚寺",
		"lng" : 119.80427400000001,
		"lat" : 25.482177
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2230,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73617225084924,
		  25.644129351763347
		]
	  },
	  "properties" : {
		"FID" : 2230,
		"name" : "平潭琉球驸马墓",
		"lng" : 119.74070500000001,
		"lat" : 25.641262000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2231,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78184727345526,
		  25.465866059988215
		]
	  },
	  "properties" : {
		"FID" : 2231,
		"name" : "台风体验馆",
		"lng" : 119.786309,
		"lat" : 25.463042000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2232,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73662366880286,
		  25.418279271161129
		]
	  },
	  "properties" : {
		"FID" : 2232,
		"name" : "山岐澳度假区",
		"lng" : 119.74114,
		"lat" : 25.415488
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2233,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73220753635424,
		  25.50201994118483
		]
	  },
	  "properties" : {
		"FID" : 2233,
		"name" : "高氏祖厅",
		"lng" : 119.73673100000001,
		"lat" : 25.499206000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2234,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77054458826785,
		  25.55848188649923
		]
	  },
	  "properties" : {
		"FID" : 2234,
		"name" : "蟒天大王宫",
		"lng" : 119.775035,
		"lat" : 25.555641000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2235,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.80645374227865,
		  25.570483583740756
		]
	  },
	  "properties" : {
		"FID" : 2235,
		"name" : "谢厝基督教堂",
		"lng" : 119.810862,
		"lat" : 25.567588000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2236,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.71380673813775,
		  25.440339073473336
		]
	  },
	  "properties" : {
		"FID" : 2236,
		"name" : "刘氏宗祠",
		"lng" : 119.718322,
		"lat" : 25.437525999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2237,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.80427315211529,
		  25.481099213490964
		]
	  },
	  "properties" : {
		"FID" : 2237,
		"name" : "林诚波故居",
		"lng" : 119.80868100000001,
		"lat" : 25.478237
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2238,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78183927314014,
		  25.465629989729173
		]
	  },
	  "properties" : {
		"FID" : 2238,
		"name" : "开闽坊",
		"lng" : 119.78630099999999,
		"lat" : 25.462806
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2239,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.82120427634622,
		  25.585638713563572
		]
	  },
	  "properties" : {
		"FID" : 2239,
		"name" : "圣帝宫",
		"lng" : 119.82557199999999,
		"lat" : 25.582709999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2240,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78675374460177,
		  25.6118390848806
		]
	  },
	  "properties" : {
		"FID" : 2240,
		"name" : "平潭国际旅游岛·长江澳",
		"lng" : 119.79121499999999,
		"lat" : 25.608958000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2241,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.70555694607918,
		  25.613557844952705
		]
	  },
	  "properties" : {
		"FID" : 2241,
		"name" : "苏澳基督教堂",
		"lng" : 119.71007899999999,
		"lat" : 25.610676999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2242,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77150333118307,
		  25.571758801107023
		]
	  },
	  "properties" : {
		"FID" : 2242,
		"name" : "大坪国平寺",
		"lng" : 119.775993,
		"lat" : 25.568912000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2243,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77823376935811,
		  25.46548463257086
		]
	  },
	  "properties" : {
		"FID" : 2243,
		"name" : "凤鸣山公园",
		"lng" : 119.782703,
		"lat" : 25.462665000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2244,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78142410991428,
		  25.469504470882029
		]
	  },
	  "properties" : {
		"FID" : 2244,
		"name" : "宗道廊",
		"lng" : 119.785887,
		"lat" : 25.46668
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2245,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78220483952816,
		  25.468704238870171
		]
	  },
	  "properties" : {
		"FID" : 2245,
		"name" : "平潭水仙馆",
		"lng" : 119.786666,
		"lat" : 25.465879000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2246,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78150532942691,
		  25.468853402577579
		]
	  },
	  "properties" : {
		"FID" : 2246,
		"name" : "七出亭",
		"lng" : 119.785968,
		"lat" : 25.466028999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2247,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73271622774845,
		  25.479718290748949
		]
	  },
	  "properties" : {
		"FID" : 2247,
		"name" : "北厝基督教堂",
		"lng" : 119.737238,
		"lat" : 25.476911000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2248,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78257062695906,
		  25.46874471236902
		]
	  },
	  "properties" : {
		"FID" : 2248,
		"name" : "半岛桥",
		"lng" : 119.787031,
		"lat" : 25.465919
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2249,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76638206339574,
		  25.412818603639465
		]
	  },
	  "properties" : {
		"FID" : 2249,
		"name" : "平潭国际旅游岛·将军山",
		"lng" : 119.770869,
		"lat" : 25.410022000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2250,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.74914147761217,
		  25.624678883759234
		]
	  },
	  "properties" : {
		"FID" : 2250,
		"name" : "壳丘头遗址",
		"lng" : 119.753665,
		"lat" : 25.621822000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2251,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.68959451671822,
		  25.585747074404978
		]
	  },
	  "properties" : {
		"FID" : 2251,
		"name" : "石牌洋",
		"lng" : 119.694098,
		"lat" : 25.582853
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2252,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.71089357551516,
		  25.53642876365187
		]
	  },
	  "properties" : {
		"FID" : 2252,
		"name" : "神马三相府",
		"lng" : 119.715414,
		"lat" : 25.533584999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2253,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.8187125980684,
		  25.479927187710995
		]
	  },
	  "properties" : {
		"FID" : 2253,
		"name" : "竹溪兴山寺",
		"lng" : 119.82308,
		"lat" : 25.477039000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2254,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.80607944586227,
		  25.475627897578512
		]
	  },
	  "properties" : {
		"FID" : 2254,
		"name" : "瀚江境",
		"lng" : 119.81048199999999,
		"lat" : 25.472764000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2255,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.85384060501424,
		  25.557024655278997
		]
	  },
	  "properties" : {
		"FID" : 2255,
		"name" : "福灵寺",
		"lng" : 119.858116,
		"lat" : 25.554048999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2256,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.7213852812454,
		  25.611427853694405
		]
	  },
	  "properties" : {
		"FID" : 2256,
		"name" : "桃花寨遗址",
		"lng" : 119.725916,
		"lat" : 25.608566
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2257,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73845497688137,
		  25.465563358016944
		]
	  },
	  "properties" : {
		"FID" : 2257,
		"name" : "南寨遗址",
		"lng" : 119.742974,
		"lat" : 25.462762000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2258,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.8174192382901,
		  25.475169480610788
		]
	  },
	  "properties" : {
		"FID" : 2258,
		"name" : "游艇旅游城",
		"lng" : 119.82178999999999,
		"lat" : 25.472284999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2259,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.83215186534967,
		  25.469759725254637
		]
	  },
	  "properties" : {
		"FID" : 2259,
		"name" : "平潭帆船蓝色风帆之旅",
		"lng" : 119.83647999999999,
		"lat" : 25.466849
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2260,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78199841782741,
		  25.468389897900668
		]
	  },
	  "properties" : {
		"FID" : 2260,
		"name" : "状元楼",
		"lng" : 119.78646000000001,
		"lat" : 25.465565000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2261,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.85250752410802,
		  25.481368214762764
		]
	  },
	  "properties" : {
		"FID" : 2261,
		"name" : "五福帝爷宫",
		"lng" : 119.856781,
		"lat" : 25.478418999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2262,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78189225757571,
		  25.467441520191915
		]
	  },
	  "properties" : {
		"FID" : 2262,
		"name" : "海坛古城-马头",
		"lng" : 119.786354,
		"lat" : 25.464617000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2263,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.72407317605222,
		  25.493725815881202
		]
	  },
	  "properties" : {
		"FID" : 2263,
		"name" : "平潭廉政文化主题公园",
		"lng" : 119.728596,
		"lat" : 25.490908999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2264,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78187424040647,
		  25.467140420203783
		]
	  },
	  "properties" : {
		"FID" : 2264,
		"name" : "海坛古城-冰雪极地世界",
		"lng" : 119.78633600000001,
		"lat" : 25.464316
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2265,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78148738425025,
		  25.467548043102376
		]
	  },
	  "properties" : {
		"FID" : 2265,
		"name" : "街市鱼丸",
		"lng" : 119.78595,
		"lat" : 25.464724
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2266,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76479289742441,
		  25.46442885986119
		]
	  },
	  "properties" : {
		"FID" : 2266,
		"name" : "三兴寺",
		"lng" : 119.76928599999999,
		"lat" : 25.461621999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2267,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78256364506436,
		  25.468278582899185
		]
	  },
	  "properties" : {
		"FID" : 2267,
		"name" : "元敬坊",
		"lng" : 119.787024,
		"lat" : 25.465453
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2268,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76825778370659,
		  25.487338649013967
		]
	  },
	  "properties" : {
		"FID" : 2268,
		"name" : "玉封元帅府",
		"lng" : 119.772747,
		"lat" : 25.484522999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2269,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78247472131952,
		  25.464508504667972
		]
	  },
	  "properties" : {
		"FID" : 2269,
		"name" : "聚龙潭",
		"lng" : 119.786935,
		"lat" : 25.461684000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2270,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78149639003972,
		  25.467736102722824
		]
	  },
	  "properties" : {
		"FID" : 2270,
		"name" : "景弘廊",
		"lng" : 119.78595900000001,
		"lat" : 25.464912000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2271,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.8038561245969,
		  25.60644367747031
		]
	  },
	  "properties" : {
		"FID" : 2271,
		"name" : "君山插云",
		"lng" : 119.808274,
		"lat" : 25.603538
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2272,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78246566429628,
		  25.465033626569717
		]
	  },
	  "properties" : {
		"FID" : 2272,
		"name" : "博戏雕塑",
		"lng" : 119.78692599999999,
		"lat" : 25.462209000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2273,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.7825468669138,
		  25.464656633831144
		]
	  },
	  "properties" : {
		"FID" : 2273,
		"name" : "清平廊",
		"lng" : 119.787007,
		"lat" : 25.461832000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2274,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78251979546923,
		  25.464836645172753
		]
	  },
	  "properties" : {
		"FID" : 2274,
		"name" : "连理桥",
		"lng" : 119.78698,
		"lat" : 25.462012000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2275,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.85800253017906,
		  25.461094162932245
		]
	  },
	  "properties" : {
		"FID" : 2275,
		"name" : "平潭国际旅游岛·68海里景区",
		"lng" : 119.862261,
		"lat" : 25.458141999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2276,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.84871103365271,
		  25.462434141124859
		]
	  },
	  "properties" : {
		"FID" : 2276,
		"name" : "猴研岛海滩",
		"lng" : 119.852993,
		"lat" : 25.459496000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2277,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77525271870233,
		  25.6214792574293
		]
	  },
	  "properties" : {
		"FID" : 2277,
		"name" : "平潭国际旅游岛-长江澳风力田景观区",
		"lng" : 119.77973900000001,
		"lat" : 25.618607999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2278,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.75935483871103,
		  25.441371042872277
		]
	  },
	  "properties" : {
		"FID" : 2278,
		"name" : "田美澳海滩",
		"lng" : 119.76385399999999,
		"lat" : 25.438573000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2279,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78212594539735,
		  25.464836147224048
		]
	  },
	  "properties" : {
		"FID" : 2279,
		"name" : "路海坛",
		"lng" : 119.786587,
		"lat" : 25.462012000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2280,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78144213668351,
		  25.469667535622246
		]
	  },
	  "properties" : {
		"FID" : 2280,
		"name" : "融合桥",
		"lng" : 119.785905,
		"lat" : 25.466843000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2281,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.8460862147538,
		  25.46043126134866
		]
	  },
	  "properties" : {
		"FID" : 2281,
		"name" : "平潭国际旅游岛68小镇",
		"lng" : 119.850375,
		"lat" : 25.457498000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2282,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78236850985427,
		  25.464254305678157
		]
	  },
	  "properties" : {
		"FID" : 2282,
		"name" : "雨霖廊",
		"lng" : 119.786829,
		"lat" : 25.46143
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2283,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78584271673616,
		  25.61111051894515
		]
	  },
	  "properties" : {
		"FID" : 2283,
		"name" : "蓝眼泪观景点(长江澳海滩)",
		"lng" : 119.790306,
		"lat" : 25.608231
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2284,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.8494477222288,
		  25.465868216182354
		]
	  },
	  "properties" : {
		"FID" : 2284,
		"name" : "平潭石厝民宿沙滩",
		"lng" : 119.853728,
		"lat" : 25.462928000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2285,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.68640867980034,
		  25.597338407812437
		]
	  },
	  "properties" : {
		"FID" : 2285,
		"name" : "渔舟识趣",
		"lng" : 119.690909,
		"lat" : 25.594434
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2286,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.74561091342456,
		  25.426245296841838
		]
	  },
	  "properties" : {
		"FID" : 2286,
		"name" : "坛南湾·白金海滩",
		"lng" : 119.750123,
		"lat" : 25.423454
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2287,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.72428538197818,
		  25.448656837662412
		]
	  },
	  "properties" : {
		"FID" : 2287,
		"name" : "鳌峰境",
		"lng" : 119.72880499999999,
		"lat" : 25.445851999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2288,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.81552972274793,
		  25.604303832858591
		]
	  },
	  "properties" : {
		"FID" : 2288,
		"name" : "海坛岛风景区",
		"lng" : 119.81991499999999,
		"lat" : 25.601378
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2289,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77009354583434,
		  25.659475006777335
		]
	  },
	  "properties" : {
		"FID" : 2289,
		"name" : "北部生态廊道F1观景台",
		"lng" : 119.774592,
		"lat" : 25.656590999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2290,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.76636039471894,
		  25.65865253313692
		]
	  },
	  "properties" : {
		"FID" : 2290,
		"name" : "北部生态廊道F2观景台",
		"lng" : 119.770865,
		"lat" : 25.655771999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2291,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.75764582417328,
		  25.647857065445706
		]
	  },
	  "properties" : {
		"FID" : 2291,
		"name" : "北部生态廊道F5观景台",
		"lng" : 119.762162,
		"lat" : 25.644987
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2292,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.77930395424565,
		  25.661069314085129
		]
	  },
	  "properties" : {
		"FID" : 2292,
		"name" : "平潭北部湾生态廊道",
		"lng" : 119.78378499999999,
		"lat" : 25.658175
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2293,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73570126959366,
		  25.641804432774244
		]
	  },
	  "properties" : {
		"FID" : 2293,
		"name" : "猫头墘",
		"lng" : 119.740234,
		"lat" : 25.638938
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2294,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78148732485108,
		  25.468379257507575
		]
	  },
	  "properties" : {
		"FID" : 2294,
		"name" : "海坛古城-祈风祭海",
		"lng" : 119.78595,
		"lat" : 25.465554999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2295,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.70171073906361,
		  25.482859550562051
		]
	  },
	  "properties" : {
		"FID" : 2295,
		"name" : "金井湾市民广场",
		"lng" : 119.70622,
		"lat" : 25.48002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2296,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.6984140640274,
		  25.481486154389604
		]
	  },
	  "properties" : {
		"FID" : 2296,
		"name" : "如意湖公园",
		"lng" : 119.70292000000001,
		"lat" : 25.478642000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2297,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.7322481240904,
		  25.480040611853063
		]
	  },
	  "properties" : {
		"FID" : 2297,
		"name" : "祠堂后山遗址",
		"lng" : 119.73677000000001,
		"lat" : 25.477232999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2298,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.81223891385504,
		  25.583148004449544
		]
	  },
	  "properties" : {
		"FID" : 2298,
		"name" : "山门水磨坊",
		"lng" : 119.816632,
		"lat" : 25.580237
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2299,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78247865946516,
		  25.465495760724558
		]
	  },
	  "properties" : {
		"FID" : 2299,
		"name" : "三生桥",
		"lng" : 119.786939,
		"lat" : 25.462671
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2300,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78182923765857,
		  25.465826027214778
		]
	  },
	  "properties" : {
		"FID" : 2300,
		"name" : "镜子迷宫",
		"lng" : 119.78629100000001,
		"lat" : 25.463001999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2301,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78149637896054,
		  25.467891142684874
		]
	  },
	  "properties" : {
		"FID" : 2301,
		"name" : "天伦之乐",
		"lng" : 119.78595900000001,
		"lat" : 25.465067000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2302,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73201965897644,
		  25.486007381029921
		]
	  },
	  "properties" : {
		"FID" : 2302,
		"name" : "华光府",
		"lng" : 119.736542,
		"lat" : 25.483198000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2303,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.7815065594326,
		  25.465664584119097
		]
	  },
	  "properties" : {
		"FID" : 2303,
		"name" : "三郎亭",
		"lng" : 119.78596899999999,
		"lat" : 25.462841000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2304,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.7820615615887,
		  25.468276947995705
		]
	  },
	  "properties" : {
		"FID" : 2304,
		"name" : "海坛风铃许愿树",
		"lng" : 119.786523,
		"lat" : 25.465451999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2305,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78205555237729,
		  25.468224927003043
		]
	  },
	  "properties" : {
		"FID" : 2305,
		"name" : "平潭两岸人文街区",
		"lng" : 119.786517,
		"lat" : 25.465399999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2306,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.799699986202,
		  25.467011674323164
		]
	  },
	  "properties" : {
		"FID" : 2306,
		"name" : "赤岑大王宫",
		"lng" : 119.804119,
		"lat" : 25.464161000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2307,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78247454181945,
		  25.46702114582332
		]
	  },
	  "properties" : {
		"FID" : 2307,
		"name" : "镇远亭",
		"lng" : 119.786935,
		"lat" : 25.464196000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2308,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.70857833549378,
		  25.478534865047109
		]
	  },
	  "properties" : {
		"FID" : 2308,
		"name" : "天牛河公园",
		"lng" : 119.713093,
		"lat" : 25.475705999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2309,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78252980808928,
		  25.464963690176898
		]
	  },
	  "properties" : {
		"FID" : 2309,
		"name" : "绮怀廊",
		"lng" : 119.78699,
		"lat" : 25.462139000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2310,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78235948108605,
		  25.464384327208542
		]
	  },
	  "properties" : {
		"FID" : 2310,
		"name" : "月老亭",
		"lng" : 119.78682000000001,
		"lat" : 25.461559999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2311,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78146027418948,
		  25.468281198618548
		]
	  },
	  "properties" : {
		"FID" : 2311,
		"name" : "三保坊",
		"lng" : 119.785923,
		"lat" : 25.465457000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2312,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.82511328670999,
		  25.588951425214848
		]
	  },
	  "properties" : {
		"FID" : 2312,
		"name" : "北港妈祖宫",
		"lng" : 119.82947,
		"lat" : 25.586013999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2313,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.73900312031681,
		  25.466880549486895
		]
	  },
	  "properties" : {
		"FID" : 2313,
		"name" : "南寨山管理处",
		"lng" : 119.743522,
		"lat" : 25.464079000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2314,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78146934408795,
		  25.467572026907426
		]
	  },
	  "properties" : {
		"FID" : 2314,
		"name" : "曦和桥",
		"lng" : 119.785932,
		"lat" : 25.464748
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2315,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78225006665602,
		  25.466885827096146
		]
	  },
	  "properties" : {
		"FID" : 2315,
		"name" : "海坛古城-海坛词明戏",
		"lng" : 119.786711,
		"lat" : 25.464061000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2316,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.78155055549287,
		  25.46703598982063
		]
	  },
	  "properties" : {
		"FID" : 2316,
		"name" : "子文坊",
		"lng" : 119.786013,
		"lat" : 25.464212
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2317,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.87341089760638,
		  26.346340807996757
		]
	  },
	  "properties" : {
		"FID" : 2317,
		"name" : "义窟古瓷窑遗址",
		"lng" : 118.877979,
		"lat" : 26.342869
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2318,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86425505949285,
		  26.338244034143692
		]
	  },
	  "properties" : {
		"FID" : 2318,
		"name" : "仙灵宫",
		"lng" : 118.868833,
		"lat" : 26.334786000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2319,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.91062729873852,
		  26.396939461782143
		]
	  },
	  "properties" : {
		"FID" : 2319,
		"name" : "瓷天下海丝谷",
		"lng" : 118.915194,
		"lat" : 26.393439000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2320,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.90075081782277,
		  26.377535567343145
		]
	  },
	  "properties" : {
		"FID" : 2320,
		"name" : "古榕花海园",
		"lng" : 118.905311,
		"lat" : 26.374039
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2321,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.90142859505079,
		  26.377928611123664
		]
	  },
	  "properties" : {
		"FID" : 2321,
		"name" : "迷乐谷文化旅游景区",
		"lng" : 118.90598900000001,
		"lat" : 26.374431999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2322,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.90052000122141,
		  26.375861922858345
		]
	  },
	  "properties" : {
		"FID" : 2322,
		"name" : "官圳里(光禄第)",
		"lng" : 118.90508,
		"lat" : 26.372366
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2323,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.9165031595023,
		  26.393956022710725
		]
	  },
	  "properties" : {
		"FID" : 2323,
		"name" : "九野小镇",
		"lng" : 118.921075,
		"lat" : 26.390460999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2324,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.9110552482779,
		  26.393106736315403
		]
	  },
	  "properties" : {
		"FID" : 2324,
		"name" : "闽清东桥镇溪沙村24号林氏古厝古民居",
		"lng" : 118.915622,
		"lat" : 26.389607999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2325,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.89891562805448,
		  26.372084552160747
		]
	  },
	  "properties" : {
		"FID" : 2325,
		"name" : "思远亭",
		"lng" : 118.903475,
		"lat" : 26.368590000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2326,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.75110841485647,
		  26.330327340100215
		]
	  },
	  "properties" : {
		"FID" : 2326,
		"name" : "梅雄候船亭",
		"lng" : 118.75585700000001,
		"lat" : 26.327034000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2327,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.91916346673632,
		  26.348966024252171
		]
	  },
	  "properties" : {
		"FID" : 2327,
		"name" : "天池孔雀园",
		"lng" : 118.92373499999999,
		"lat" : 26.345492
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2328,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76367548225667,
		  26.257935530918584
		]
	  },
	  "properties" : {
		"FID" : 2328,
		"name" : "白云山",
		"lng" : 118.768413,
		"lat" : 26.254673
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2329,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.70125906126728,
		  26.284178195786279
		]
	  },
	  "properties" : {
		"FID" : 2329,
		"name" : "黄褚林温泉",
		"lng" : 118.70596500000001,
		"lat" : 26.280873
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2330,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.87168828819409,
		  26.28997926747434
		]
	  },
	  "properties" : {
		"FID" : 2330,
		"name" : "闽清北站站前广场",
		"lng" : 118.876254,
		"lat" : 26.286536000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2331,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.95005213660501,
		  26.351090442244363
		]
	  },
	  "properties" : {
		"FID" : 2331,
		"name" : "安仁境",
		"lng" : 118.954683,
		"lat" : 26.347666
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2332,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.95205533667666,
		  26.345197308431374
		]
	  },
	  "properties" : {
		"FID" : 2332,
		"name" : "谢氏宗祠",
		"lng" : 118.95669100000001,
		"lat" : 26.34178
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2333,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.94748678882254,
		  26.362356901177538
		]
	  },
	  "properties" : {
		"FID" : 2333,
		"name" : "车山府",
		"lng" : 118.952112,
		"lat" : 26.358922
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2334,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.92169615174598,
		  26.296287579883884
		]
	  },
	  "properties" : {
		"FID" : 2334,
		"name" : "闽侯小箬乡九仙岩",
		"lng" : 118.926267,
		"lat" : 26.292840999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2335,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.89132400454784,
		  26.270466893921466
		]
	  },
	  "properties" : {
		"FID" : 2335,
		"name" : "大坂新丰正境",
		"lng" : 118.895876,
		"lat" : 26.267021
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2336,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.87866532813214,
		  26.279248975675351
		]
	  },
	  "properties" : {
		"FID" : 2336,
		"name" : "基督教小箬堂",
		"lng" : 118.883224,
		"lat" : 26.275804999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2337,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.88710958243574,
		  26.259691690842967
		]
	  },
	  "properties" : {
		"FID" : 2337,
		"name" : "林氏宗祠",
		"lng" : 118.891662,
		"lat" : 26.256253000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2338,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.8629913228194,
		  26.270697220175155
		]
	  },
	  "properties" : {
		"FID" : 2338,
		"name" : "闽清北溪五顯大帝殿",
		"lng" : 118.867566,
		"lat" : 26.267274
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2339,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86500832524408,
		  26.279446344885219
		]
	  },
	  "properties" : {
		"FID" : 2339,
		"name" : "北溪廉洁文化公园",
		"lng" : 118.869581,
		"lat" : 26.276015999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2340,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.71627402583678,
		  26.279514630271752
		]
	  },
	  "properties" : {
		"FID" : 2340,
		"name" : "青龙山大峡谷",
		"lng" : 118.721001,
		"lat" : 26.276230999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2341,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.88549489918617,
		  26.259748971615487
		]
	  },
	  "properties" : {
		"FID" : 2341,
		"name" : "漈恩境",
		"lng" : 118.89004799999999,
		"lat" : 26.256311
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2342,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.7254929955306,
		  26.153651675283303
		]
	  },
	  "properties" : {
		"FID" : 2342,
		"name" : "弘法寺",
		"lng" : 118.73022,
		"lat" : 26.150448999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2343,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.7366208532148,
		  26.142614680408034
		]
	  },
	  "properties" : {
		"FID" : 2343,
		"name" : "仙峰山公园",
		"lng" : 118.741354,
		"lat" : 26.139424999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2344,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.73499620146181,
		  26.133949760676817
		]
	  },
	  "properties" : {
		"FID" : 2344,
		"name" : "彭城钱氏宗祠",
		"lng" : 118.739728,
		"lat" : 26.130765
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2345,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.71560235956717,
		  26.150947995284469
		]
	  },
	  "properties" : {
		"FID" : 2345,
		"name" : "霞溪公园",
		"lng" : 118.720319,
		"lat" : 26.147738
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2346,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.73529934546818,
		  26.130112184352843
		]
	  },
	  "properties" : {
		"FID" : 2346,
		"name" : "溪演吴氏宗祠",
		"lng" : 118.740031,
		"lat" : 26.126930000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2347,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.74200682441752,
		  26.148824336040079
		]
	  },
	  "properties" : {
		"FID" : 2347,
		"name" : "八卦厝",
		"lng" : 118.746742,
		"lat" : 26.145631999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2348,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.71523581028842,
		  26.150855333058047
		]
	  },
	  "properties" : {
		"FID" : 2348,
		"name" : "俞氏宗祠",
		"lng" : 118.71995200000001,
		"lat" : 26.147645000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2349,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.70706038652878,
		  26.143706713578688
		]
	  },
	  "properties" : {
		"FID" : 2349,
		"name" : "洞灵桥",
		"lng" : 118.711765,
		"lat" : 26.140491000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2350,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.74724288458661,
		  26.142938434399699
		]
	  },
	  "properties" : {
		"FID" : 2350,
		"name" : "黄石林氏宗祠",
		"lng" : 118.75197799999999,
		"lat" : 26.139749999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2351,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.72385868900048,
		  26.123065468084345
		]
	  },
	  "properties" : {
		"FID" : 2351,
		"name" : "云坑吴氏宗祠",
		"lng" : 118.728582,
		"lat" : 26.119880999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2352,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.72392147302493,
		  26.12521780558394
		]
	  },
	  "properties" : {
		"FID" : 2352,
		"name" : "黄坑里吴氏古民居",
		"lng" : 118.728645,
		"lat" : 26.122032000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2353,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.726612268754,
		  26.124004002656676
		]
	  },
	  "properties" : {
		"FID" : 2353,
		"name" : "吴氏祠堂(岳飞将军庙)",
		"lng" : 118.73133799999999,
		"lat" : 26.120820999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2354,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.70526358301636,
		  26.150608501506778
		]
	  },
	  "properties" : {
		"FID" : 2354,
		"name" : "上大墓(霞溪村)",
		"lng" : 118.70996599999999,
		"lat" : 26.147386000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2355,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.7411996836435,
		  26.125857822274909
		]
	  },
	  "properties" : {
		"FID" : 2355,
		"name" : "鹿角公园",
		"lng" : 118.74593299999999,
		"lat" : 26.122679999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2356,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.74372050306735,
		  26.122797554951077
		]
	  },
	  "properties" : {
		"FID" : 2356,
		"name" : "杏园",
		"lng" : 118.748454,
		"lat" : 26.119622
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2357,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.69836885974058,
		  26.12264377157004
		]
	  },
	  "properties" : {
		"FID" : 2357,
		"name" : "池园欢迎门",
		"lng" : 118.703058,
		"lat" : 26.119429
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2358,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.74176973216656,
		  26.123647310080496
		]
	  },
	  "properties" : {
		"FID" : 2358,
		"name" : "鹿坂刘氏宗祠",
		"lng" : 118.746503,
		"lat" : 26.120470999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2359,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.7669193261046,
		  26.117943892858669
		]
	  },
	  "properties" : {
		"FID" : 2359,
		"name" : "凤洋刘氏宗祠",
		"lng" : 118.77164399999999,
		"lat" : 26.114763
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2360,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.6915608884763,
		  26.165765085987452
		]
	  },
	  "properties" : {
		"FID" : 2360,
		"name" : "鹤林寺",
		"lng" : 118.696241,
		"lat" : 26.162512
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2361,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.77354333353054,
		  26.10787328634796
		]
	  },
	  "properties" : {
		"FID" : 2361,
		"name" : "黄乃裳石像",
		"lng" : 118.778261,
		"lat" : 26.104693000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2362,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.70520119823898,
		  26.102908920151787
		]
	  },
	  "properties" : {
		"FID" : 2362,
		"name" : "普贤寺",
		"lng" : 118.7099,
		"lat" : 26.099716999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2363,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.69299185869293,
		  26.116635515424829
		]
	  },
	  "properties" : {
		"FID" : 2363,
		"name" : "文化公园",
		"lng" : 118.697671,
		"lat" : 26.113416000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2364,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.70678403684951,
		  26.181049275369087
		]
	  },
	  "properties" : {
		"FID" : 2364,
		"name" : "张圣真君祖殿",
		"lng" : 118.711491,
		"lat" : 26.177810000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2365,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76563271913233,
		  26.112231199422187
		]
	  },
	  "properties" : {
		"FID" : 2365,
		"name" : "维济公故居",
		"lng" : 118.770358,
		"lat" : 26.109055000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2366,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.75632476719444,
		  26.117933546370228
		]
	  },
	  "properties" : {
		"FID" : 2366,
		"name" : "良佺古民居",
		"lng" : 118.761056,
		"lat" : 26.114758999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2367,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.69926031233142,
		  26.123023646299252
		]
	  },
	  "properties" : {
		"FID" : 2367,
		"name" : "福斗公园",
		"lng" : 118.703951,
		"lat" : 26.119810000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2368,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76249201002436,
		  26.104964300360031
		]
	  },
	  "properties" : {
		"FID" : 2368,
		"name" : "显应长生祖坛",
		"lng" : 118.767219,
		"lat" : 26.101794999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2369,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.75684956224725,
		  26.1236854836087
		]
	  },
	  "properties" : {
		"FID" : 2369,
		"name" : "明玉亭",
		"lng" : 118.76158100000001,
		"lat" : 26.120507
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2370,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.77153133679785,
		  26.106876675460537
		]
	  },
	  "properties" : {
		"FID" : 2370,
		"name" : "许永俤黄乃顺纪念楼",
		"lng" : 118.776251,
		"lat" : 26.103698999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2371,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.77895216582016,
		  26.11361993321303
		]
	  },
	  "properties" : {
		"FID" : 2371,
		"name" : "黄乃裳纪念馆",
		"lng" : 118.783664,
		"lat" : 26.110430000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2372,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.74494854931254,
		  26.10726140805825
		]
	  },
	  "properties" : {
		"FID" : 2372,
		"name" : "紫竹苑闾山宗坛",
		"lng" : 118.749681,
		"lat" : 26.104095999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2373,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.71304877856807,
		  26.188357888349952
		]
	  },
	  "properties" : {
		"FID" : 2373,
		"name" : "闽清县金沙镇光辉村生命公园",
		"lng" : 118.717765,
		"lat" : 26.185122
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2374,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.75328735621979,
		  26.122733588987249
		]
	  },
	  "properties" : {
		"FID" : 2374,
		"name" : "报国寺",
		"lng" : 118.75802,
		"lat" : 26.119557
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2375,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76833020299337,
		  26.09522418514101
		]
	  },
	  "properties" : {
		"FID" : 2375,
		"name" : "宏琳厝",
		"lng" : 118.77305200000001,
		"lat" : 26.092057
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2376,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.67863725680694,
		  26.098673248874711
		]
	  },
	  "properties" : {
		"FID" : 2376,
		"name" : "芝山公园丽星登山道凉亭",
		"lng" : 118.68328700000001,
		"lat" : 26.09544
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2377,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.6866977840869,
		  26.103070470885719
		]
	  },
	  "properties" : {
		"FID" : 2377,
		"name" : "观音寺",
		"lng" : 118.69136399999999,
		"lat" : 26.099848999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2378,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.67644383004715,
		  26.097869827360523
		]
	  },
	  "properties" : {
		"FID" : 2378,
		"name" : "泰山殿",
		"lng" : 118.681089,
		"lat" : 26.094633000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2379,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.7699824118971,
		  26.112698053793164
		]
	  },
	  "properties" : {
		"FID" : 2379,
		"name" : "坂东演庐",
		"lng" : 118.774704,
		"lat" : 26.109518000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2380,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.77325074035269,
		  26.09815562420998
		]
	  },
	  "properties" : {
		"FID" : 2380,
		"name" : "六叶祠",
		"lng" : 118.777968,
		"lat" : 26.094982000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2381,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.72989012033038,
		  26.093330873852825
		]
	  },
	  "properties" : {
		"FID" : 2381,
		"name" : "柯洋仙阁",
		"lng" : 118.734616,
		"lat" : 26.090170000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2382,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.78317726365862,
		  26.119736118141642
		]
	  },
	  "properties" : {
		"FID" : 2382,
		"name" : "广德禅寺",
		"lng" : 118.78788400000001,
		"lat" : 26.116537000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2383,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.67689396311928,
		  26.097015419439284
		]
	  },
	  "properties" : {
		"FID" : 2383,
		"name" : "思乡亭",
		"lng" : 118.68154,
		"lat" : 26.093779999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2384,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.77983812532784,
		  26.129318129079742
		]
	  },
	  "properties" : {
		"FID" : 2384,
		"name" : "闽清县坂东镇五台山仙君殿",
		"lng" : 118.78455,
		"lat" : 26.126117000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2385,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.77199054736501,
		  26.110255316711221
		]
	  },
	  "properties" : {
		"FID" : 2385,
		"name" : "湖峰黄氏宗祠",
		"lng" : 118.77670999999999,
		"lat" : 26.107074999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2386,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.78394571780095,
		  26.195824574951121
		]
	  },
	  "properties" : {
		"FID" : 2386,
		"name" : "羊顺玫瑰花海",
		"lng" : 118.788657,
		"lat" : 26.192577
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2387,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76367548225667,
		  26.257935530918584
		]
	  },
	  "properties" : {
		"FID" : 2387,
		"name" : "白云山",
		"lng" : 118.768413,
		"lat" : 26.254673
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2388,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.85890351733549,
		  26.216575693610835
		]
	  },
	  "properties" : {
		"FID" : 2388,
		"name" : "梅城森林公园",
		"lng" : 118.86348,
		"lat" : 26.213187999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2389,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76685546226203,
		  26.101845344853665
		]
	  },
	  "properties" : {
		"FID" : 2389,
		"name" : "墘上祠堂",
		"lng" : 118.771579,
		"lat" : 26.098675
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2390,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76729872870614,
		  26.10321859603442
		]
	  },
	  "properties" : {
		"FID" : 2390,
		"name" : "芝田宫",
		"lng" : 118.77202200000001,
		"lat" : 26.100047
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2391,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76746676361284,
		  26.104660675328176
		]
	  },
	  "properties" : {
		"FID" : 2391,
		"name" : "坂东镇天主堂",
		"lng" : 118.77218999999999,
		"lat" : 26.101488
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2392,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76270256498833,
		  26.11286559032559
		]
	  },
	  "properties" : {
		"FID" : 2392,
		"name" : "学龙厝",
		"lng" : 118.76743,
		"lat" : 26.109691000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2393,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86282215496799,
		  26.228727963303474
		]
	  },
	  "properties" : {
		"FID" : 2393,
		"name" : "溪滨公园",
		"lng" : 118.867394,
		"lat" : 26.225328000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2394,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.71729395355116,
		  26.197110512827511
		]
	  },
	  "properties" : {
		"FID" : 2394,
		"name" : "闽清金沙白马尊王庙",
		"lng" : 118.722016,
		"lat" : 26.193874000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2395,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.77275225601323,
		  26.111213679181457
		]
	  },
	  "properties" : {
		"FID" : 2395,
		"name" : "荃庐",
		"lng" : 118.77747100000001,
		"lat" : 26.108032000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2396,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.77901019534379,
		  26.114201379403546
		]
	  },
	  "properties" : {
		"FID" : 2396,
		"name" : "黄乃裳墓",
		"lng" : 118.783722,
		"lat" : 26.111011000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2397,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.75843468928365,
		  26.199396228813477
		]
	  },
	  "properties" : {
		"FID" : 2397,
		"name" : "闽清龙贡大帝祖殿",
		"lng" : 118.763171,
		"lat" : 26.196169999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2398,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86257671397141,
		  26.230227496345524
		]
	  },
	  "properties" : {
		"FID" : 2398,
		"name" : "龙洲公园",
		"lng" : 118.867149,
		"lat" : 26.226827
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2399,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.68133526569949,
		  26.09183775388345
		]
	  },
	  "properties" : {
		"FID" : 2399,
		"name" : "里段小区公园",
		"lng" : 118.68599,
		"lat" : 26.088614
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2400,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.85893803045501,
		  26.223953994013133
		]
	  },
	  "properties" : {
		"FID" : 2400,
		"name" : "乃裳广场",
		"lng" : 118.86351500000001,
		"lat" : 26.220562000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2401,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76460210978705,
		  26.231517540550868
		]
	  },
	  "properties" : {
		"FID" : 2401,
		"name" : "白云寺",
		"lng" : 118.76933699999999,
		"lat" : 26.228269000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2402,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.77848490823943,
		  26.177003441449095
		]
	  },
	  "properties" : {
		"FID" : 2402,
		"name" : "陈宅",
		"lng" : 118.783202,
		"lat" : 26.173774000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2403,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.68371614773305,
		  26.110080385001822
		]
	  },
	  "properties" : {
		"FID" : 2403,
		"name" : "龙门桥",
		"lng" : 118.688377,
		"lat" : 26.106849
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2404,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.80691177315722,
		  26.136536109490368
		]
	  },
	  "properties" : {
		"FID" : 2404,
		"name" : "鹫峰寺",
		"lng" : 118.81158000000001,
		"lat" : 26.133289000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2405,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.68338002673072,
		  26.107240139862629
		]
	  },
	  "properties" : {
		"FID" : 2405,
		"name" : "昭显庙",
		"lng" : 118.68804,
		"lat" : 26.104009999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2406,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76992460899208,
		  26.095742900014763
		]
	  },
	  "properties" : {
		"FID" : 2406,
		"name" : "宏琳厝广场",
		"lng" : 118.77464500000001,
		"lat" : 26.092573999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2407,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.79232276381529,
		  26.17791268232855
		]
	  },
	  "properties" : {
		"FID" : 2407,
		"name" : "九龙山公园",
		"lng" : 118.79702,
		"lat" : 26.174664
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2408,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.8612070794272,
		  26.226766716623402
		]
	  },
	  "properties" : {
		"FID" : 2408,
		"name" : "毓麟宫",
		"lng" : 118.865781,
		"lat" : 26.223369999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2409,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.69720633343235,
		  26.102773658366424
		]
	  },
	  "properties" : {
		"FID" : 2409,
		"name" : "田尾仙公园",
		"lng" : 118.701892,
		"lat" : 26.09957
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2410,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.68453900577971,
		  26.103365512752685
		]
	  },
	  "properties" : {
		"FID" : 2410,
		"name" : "昭显候白马王庙",
		"lng" : 118.689201,
		"lat" : 26.10014
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2411,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.68498682356142,
		  26.093781409370873
		]
	  },
	  "properties" : {
		"FID" : 2411,
		"name" : "井后公园",
		"lng" : 118.689649,
		"lat" : 26.090563
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2412,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.70125906126728,
		  26.284178195786279
		]
	  },
	  "properties" : {
		"FID" : 2412,
		"name" : "黄褚林温泉",
		"lng" : 118.70596500000001,
		"lat" : 26.280873
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2413,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.67445759476779,
		  26.102691742167092
		]
	  },
	  "properties" : {
		"FID" : 2413,
		"name" : "王公宫",
		"lng" : 118.67909899999999,
		"lat" : 26.099447999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2414,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.67858582624152,
		  26.092342174651108
		]
	  },
	  "properties" : {
		"FID" : 2414,
		"name" : "池园村公园",
		"lng" : 118.683235,
		"lat" : 26.089113000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2415,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86933240438317,
		  26.2260652366306
		]
	  },
	  "properties" : {
		"FID" : 2415,
		"name" : "天王寺",
		"lng" : 118.873896,
		"lat" : 26.222659
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2416,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76402609569263,
		  26.050254905920173
		]
	  },
	  "properties" : {
		"FID" : 2416,
		"name" : "仙娘庙",
		"lng" : 118.768748,
		"lat" : 26.047121000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2417,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.78749837395058,
		  26.107755171416912
		]
	  },
	  "properties" : {
		"FID" : 2417,
		"name" : "张氏宗祠",
		"lng" : 118.792198,
		"lat" : 26.104558000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2418,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.64905267509184,
		  26.049101831604766
		]
	  },
	  "properties" : {
		"FID" : 2418,
		"name" : "上莲森林公园",
		"lng" : 118.653638,
		"lat" : 26.045846000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2419,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.78569581255763,
		  26.106375772380435
		]
	  },
	  "properties" : {
		"FID" : 2419,
		"name" : "张鸣岐墓",
		"lng" : 118.790398,
		"lat" : 26.103182
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2420,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.67993508628898,
		  26.092116519590562
		]
	  },
	  "properties" : {
		"FID" : 2420,
		"name" : "真神堂",
		"lng" : 118.68458699999999,
		"lat" : 26.088889999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2421,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.79713515486004,
		  26.174014876718591
		]
	  },
	  "properties" : {
		"FID" : 2421,
		"name" : "仙娘宫",
		"lng" : 118.801824,
		"lat" : 26.170760999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2422,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.67628920662479,
		  26.097092606996515
		]
	  },
	  "properties" : {
		"FID" : 2422,
		"name" : "仙君殿",
		"lng" : 118.68093399999999,
		"lat" : 26.093855999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2423,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86638235625963,
		  26.068771171001661
		]
	  },
	  "properties" : {
		"FID" : 2423,
		"name" : "白岩山",
		"lng" : 118.870938,
		"lat" : 26.065467000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2424,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.79155747507838,
		  26.178588935607827
		]
	  },
	  "properties" : {
		"FID" : 2424,
		"name" : "吴氏宗祠",
		"lng" : 118.796256,
		"lat" : 26.175341
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2425,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86594580126088,
		  26.068993798020575
		]
	  },
	  "properties" : {
		"FID" : 2425,
		"name" : "白岩寺",
		"lng" : 118.870502,
		"lat" : 26.06569
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2426,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76834687628995,
		  26.072735279426148
		]
	  },
	  "properties" : {
		"FID" : 2426,
		"name" : "梅寮影剧院",
		"lng" : 118.773067,
		"lat" : 26.069583000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2427,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.77911034025516,
		  26.195198166487362
		]
	  },
	  "properties" : {
		"FID" : 2427,
		"name" : "梦幻月季园",
		"lng" : 118.783828,
		"lat" : 26.191956999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2428,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.88601782310968,
		  26.181504228524922
		]
	  },
	  "properties" : {
		"FID" : 2428,
		"name" : "闽清闾山大法院",
		"lng" : 118.890565,
		"lat" : 26.178111000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2429,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.67602820752555,
		  26.09079894875828
		]
	  },
	  "properties" : {
		"FID" : 2429,
		"name" : "洋头詹氏新友公祠",
		"lng" : 118.680672,
		"lat" : 26.087565999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2430,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.88703902631336,
		  26.198239756680231
		]
	  },
	  "properties" : {
		"FID" : 2430,
		"name" : "闽清江滨生态公园",
		"lng" : 118.891587,
		"lat" : 26.194835999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2431,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86598260047471,
		  26.223897151258235
		]
	  },
	  "properties" : {
		"FID" : 2431,
		"name" : "将军庙",
		"lng" : 118.87054999999999,
		"lat" : 26.220496000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2432,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.7800475488683,
		  26.194920117716183
		]
	  },
	  "properties" : {
		"FID" : 2432,
		"name" : "梦幻生态园",
		"lng" : 118.784764,
		"lat" : 26.191678
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2433,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.87196735174545,
		  26.22442806698503
		]
	  },
	  "properties" : {
		"FID" : 2433,
		"name" : "台山公园",
		"lng" : 118.87652799999999,
		"lat" : 26.221019999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2434,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.8566521267411,
		  26.230417403731231
		]
	  },
	  "properties" : {
		"FID" : 2434,
		"name" : "城北森林公园",
		"lng" : 118.861233,
		"lat" : 26.227025000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2435,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86763175425826,
		  26.221789879356695
		]
	  },
	  "properties" : {
		"FID" : 2435,
		"name" : "南门公园",
		"lng" : 118.872197,
		"lat" : 26.218388000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2436,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.82345252574885,
		  26.218246550165819
		]
	  },
	  "properties" : {
		"FID" : 2436,
		"name" : "钟石仙娘宫",
		"lng" : 118.82809399999999,
		"lat" : 26.214918999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2437,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.64646950777272,
		  26.050519341960566
		]
	  },
	  "properties" : {
		"FID" : 2437,
		"name" : "上蓮森林公园新月亭",
		"lng" : 118.65105,
		"lat" : 26.047257999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2438,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.95402620092968,
		  26.003417027846844
		]
	  },
	  "properties" : {
		"FID" : 2438,
		"name" : "北山寨",
		"lng" : 118.958642,
		"lat" : 26.000208000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2439,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.6750802562981,
		  26.089649978054936
		]
	  },
	  "properties" : {
		"FID" : 2439,
		"name" : "洋头叶氏支祠",
		"lng" : 118.679722,
		"lat" : 26.086416
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2440,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.6801718678566,
		  26.088522706581713
		]
	  },
	  "properties" : {
		"FID" : 2440,
		"name" : "俊丽寨",
		"lng" : 118.68482400000001,
		"lat" : 26.085298999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2441,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.8336179634567,
		  26.16196476994541
		]
	  },
	  "properties" : {
		"FID" : 2441,
		"name" : "中共闽清二都支部旧址",
		"lng" : 118.838235,
		"lat" : 26.158652
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2442,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76421966551976,
		  26.233744531780918
		]
	  },
	  "properties" : {
		"FID" : 2442,
		"name" : "凤凰峡谷",
		"lng" : 118.76895500000001,
		"lat" : 26.230495000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2443,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.83619892781624,
		  26.204115064846519
		]
	  },
	  "properties" : {
		"FID" : 2443,
		"name" : "时坤厝",
		"lng" : 118.84081399999999,
		"lat" : 26.200772000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2444,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.83697795508546,
		  26.197014271267335
		]
	  },
	  "properties" : {
		"FID" : 2444,
		"name" : "华伦广场",
		"lng" : 118.84159099999999,
		"lat" : 26.193674000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2445,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76820048205583,
		  26.076346566280066
		]
	  },
	  "properties" : {
		"FID" : 2445,
		"name" : "闽清林氏宗祠(茶口)",
		"lng" : 118.772921,
		"lat" : 26.073191999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2446,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86529559031987,
		  26.23967124635822
		]
	  },
	  "properties" : {
		"FID" : 2446,
		"name" : "桃花顶道观",
		"lng" : 118.869865,
		"lat" : 26.236262
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2447,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.84565749443719,
		  26.178893615620307
		]
	  },
	  "properties" : {
		"FID" : 2447,
		"name" : "典利厝",
		"lng" : 118.850253,
		"lat" : 26.175549
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2448,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76558308128762,
		  26.025430205522937
		]
	  },
	  "properties" : {
		"FID" : 2448,
		"name" : "闽清虎丘黄氏祖厝",
		"lng" : 118.770302,
		"lat" : 26.022311999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2449,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86344511846231,
		  26.226939746127492
		]
	  },
	  "properties" : {
		"FID" : 2449,
		"name" : "文庙",
		"lng" : 118.868016,
		"lat" : 26.22354
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2450,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.77113033414543,
		  26.020105215044762
		]
	  },
	  "properties" : {
		"FID" : 2450,
		"name" : "冬畴寨",
		"lng" : 118.77584400000001,
		"lat" : 26.016985999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2451,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.88027973855911,
		  26.207172181143584
		]
	  },
	  "properties" : {
		"FID" : 2451,
		"name" : "篷崎将军庙",
		"lng" : 118.884832,
		"lat" : 26.203766999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2452,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.85354283320522,
		  26.222070974995756
		]
	  },
	  "properties" : {
		"FID" : 2452,
		"name" : "闽清黄楮林自然保护区管理处",
		"lng" : 118.85812799999999,
		"lat" : 26.218688
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2453,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.82594879668324,
		  26.160312412894026
		]
	  },
	  "properties" : {
		"FID" : 2453,
		"name" : "五顯大帝寶殿",
		"lng" : 118.830581,
		"lat" : 26.157015000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2454,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.87898843798976,
		  26.212385292391833
		]
	  },
	  "properties" : {
		"FID" : 2454,
		"name" : "闽清江滨休闲公园",
		"lng" : 118.88354200000001,
		"lat" : 26.208977999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2455,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.78355354808573,
		  26.014165112155418
		]
	  },
	  "properties" : {
		"FID" : 2455,
		"name" : "七叠石界文化广场",
		"lng" : 118.788252,
		"lat" : 26.011036000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2456,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.85711869714915,
		  26.218651347011782
		]
	  },
	  "properties" : {
		"FID" : 2456,
		"name" : "闽清县梅城森林公园管理处",
		"lng" : 118.861698,
		"lat" : 26.215264999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2457,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.84948003112679,
		  26.22244076511388
		]
	  },
	  "properties" : {
		"FID" : 2457,
		"name" : "临水夫人分堂",
		"lng" : 118.854072,
		"lat" : 26.219063999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2458,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.87184304799644,
		  26.226849325504926
		]
	  },
	  "properties" : {
		"FID" : 2458,
		"name" : "怀远楼",
		"lng" : 118.87640399999999,
		"lat" : 26.22344
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2459,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.64169741467695,
		  26.048682219936904
		]
	  },
	  "properties" : {
		"FID" : 2459,
		"name" : "仰高厝",
		"lng" : 118.646269,
		"lat" : 26.045414000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2460,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.83336149610714,
		  26.1751444305342
		]
	  },
	  "properties" : {
		"FID" : 2460,
		"name" : "台鼎文体公园",
		"lng" : 118.83798,
		"lat" : 26.171824000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2461,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.84044518822439,
		  26.174893124495959
		]
	  },
	  "properties" : {
		"FID" : 2461,
		"name" : "云龙乡宣传文化广场",
		"lng" : 118.84505,
		"lat" : 26.171559999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2462,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.7888606832836,
		  25.886177724235086
		]
	  },
	  "properties" : {
		"FID" : 2462,
		"name" : "名山寺",
		"lng" : 118.793542,
		"lat" : 25.883127999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2463,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.90244403783569,
		  26.216631207432645
		]
	  },
	  "properties" : {
		"FID" : 2463,
		"name" : "下梅埔公园",
		"lng" : 118.906993,
		"lat" : 26.213215000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2464,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.88184202780235,
		  26.230962964502503
		]
	  },
	  "properties" : {
		"FID" : 2464,
		"name" : "同兴境(白河江廿四位诸天庙)",
		"lng" : 118.88639499999999,
		"lat" : 26.227543000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2465,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.99880240288854,
		  26.167160132444742
		]
	  },
	  "properties" : {
		"FID" : 2465,
		"name" : "鸿尾乡市民公园",
		"lng" : 119.003575,
		"lat" : 26.163969999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2466,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86340981437706,
		  26.23047070933022
		]
	  },
	  "properties" : {
		"FID" : 2466,
		"name" : "龙洲公园-闽清体育文化公园",
		"lng" : 118.867981,
		"lat" : 26.227069
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2467,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86194805883436,
		  26.227435083940453
		]
	  },
	  "properties" : {
		"FID" : 2467,
		"name" : "清代古厝",
		"lng" : 118.86652100000001,
		"lat" : 26.224036999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2468,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.85195140403106,
		  26.219642103116588
		]
	  },
	  "properties" : {
		"FID" : 2468,
		"name" : "洋陶境",
		"lng" : 118.856539,
		"lat" : 26.216263000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2469,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.71627402583678,
		  26.279514630271752
		]
	  },
	  "properties" : {
		"FID" : 2469,
		"name" : "青龙山大峡谷",
		"lng" : 118.721001,
		"lat" : 26.276230999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2470,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.81066798799408,
		  26.013905408461767
		]
	  },
	  "properties" : {
		"FID" : 2470,
		"name" : "地藏寺",
		"lng" : 118.81532,
		"lat" : 26.010732999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2471,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.85072746217429,
		  26.094534261332946
		]
	  },
	  "properties" : {
		"FID" : 2471,
		"name" : "普济宫护国太夫人",
		"lng" : 118.85530799999999,
		"lat" : 26.091235000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2472,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.6504023132688,
		  26.04548897427054
		]
	  },
	  "properties" : {
		"FID" : 2472,
		"name" : "连云亭",
		"lng" : 118.65499,
		"lat" : 26.042238000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2473,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.89098620594514,
		  26.129208369436938
		]
	  },
	  "properties" : {
		"FID" : 2473,
		"name" : "大湖仙徐赵薛仙君殿",
		"lng" : 118.895528,
		"lat" : 26.125845999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2474,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.85859999079334,
		  26.080055551756281
		]
	  },
	  "properties" : {
		"FID" : 2474,
		"name" : "建砥古寨",
		"lng" : 118.863167,
		"lat" : 26.076754000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2475,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.80202906480696,
		  26.185255890048207
		]
	  },
	  "properties" : {
		"FID" : 2475,
		"name" : "道铺厝",
		"lng" : 118.80671,
		"lat" : 26.181986999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2476,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.87847726311698,
		  26.181985801250978
		]
	  },
	  "properties" : {
		"FID" : 2476,
		"name" : "南泉坑石拱桥",
		"lng" : 118.88302899999999,
		"lat" : 26.178597
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2477,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.59707303376811,
		  25.975383951867613
		]
	  },
	  "properties" : {
		"FID" : 2477,
		"name" : "绥福堂",
		"lng" : 118.60159299999999,
		"lat" : 25.972121000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2478,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.80887940496244,
		  26.179336351176556
		]
	  },
	  "properties" : {
		"FID" : 2478,
		"name" : "大樟玉理胜境",
		"lng" : 118.813547,
		"lat" : 26.176058999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2479,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.95917779392157,
		  26.274863045630365
		]
	  },
	  "properties" : {
		"FID" : 2479,
		"name" : "五奇山仙君殿",
		"lng" : 118.96382800000001,
		"lat" : 26.271497
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2480,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86251625635849,
		  26.207921541360129
		]
	  },
	  "properties" : {
		"FID" : 2480,
		"name" : "金钟山观音寺",
		"lng" : 118.867087,
		"lat" : 26.204533999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2481,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.80104996987772,
		  26.107853391097407
		]
	  },
	  "properties" : {
		"FID" : 2481,
		"name" : "许氏始祖十一公纪念馆",
		"lng" : 118.805727,
		"lat" : 26.104634999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2482,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.82019662856982,
		  25.962713189700882
		]
	  },
	  "properties" : {
		"FID" : 2482,
		"name" : "方壶岩张圣君母殿",
		"lng" : 118.824826,
		"lat" : 25.959558000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2483,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.88912445490851,
		  26.202076849601838
		]
	  },
	  "properties" : {
		"FID" : 2483,
		"name" : "车山府",
		"lng" : 118.893672,
		"lat" : 26.19867
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2484,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.94083028364652,
		  26.146180887664549
		]
	  },
	  "properties" : {
		"FID" : 2484,
		"name" : "穆源崇福禅寺",
		"lng" : 118.945424,
		"lat" : 26.142848999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2485,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.75110841485647,
		  26.330327340100215
		]
	  },
	  "properties" : {
		"FID" : 2485,
		"name" : "梅雄候船亭",
		"lng" : 118.75585700000001,
		"lat" : 26.327034000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2486,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.81070717905787,
		  26.108075572424749
		]
	  },
	  "properties" : {
		"FID" : 2486,
		"name" : "刘家洙纪念堂",
		"lng" : 118.815366,
		"lat" : 26.104839999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2487,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.71332043593745,
		  26.066437470300862
		]
	  },
	  "properties" : {
		"FID" : 2487,
		"name" : "柯洋石限尊王殿",
		"lng" : 118.718028,
		"lat" : 26.063279999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2488,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.68961060046422,
		  26.233024300601581
		]
	  },
	  "properties" : {
		"FID" : 2488,
		"name" : "金洋湖山庄",
		"lng" : 118.694292,
		"lat" : 26.229728000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2489,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.8629913228194,
		  26.270697220175155
		]
	  },
	  "properties" : {
		"FID" : 2489,
		"name" : "闽清北溪五顯大帝殿",
		"lng" : 118.867566,
		"lat" : 26.267274
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2490,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.61719792495238,
		  26.180200259037107
		]
	  },
	  "properties" : {
		"FID" : 2490,
		"name" : "城门宫祖殿",
		"lng" : 118.62174400000001,
		"lat" : 26.176814
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2491,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.87828009717941,
		  26.182189772275844
		]
	  },
	  "properties" : {
		"FID" : 2491,
		"name" : "南泉镜(仁主尊王庙)",
		"lng" : 118.88283199999999,
		"lat" : 26.178801
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2492,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.8619821038282,
		  26.227460143160627
		]
	  },
	  "properties" : {
		"FID" : 2492,
		"name" : "福建省声远乐长",
		"lng" : 118.86655500000001,
		"lat" : 26.224062
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2493,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.83993603082973,
		  26.136436155793799
		]
	  },
	  "properties" : {
		"FID" : 2493,
		"name" : "际上石刻群",
		"lng" : 118.844539,
		"lat" : 26.133127999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2494,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.82568726798866,
		  26.160346941768527
		]
	  },
	  "properties" : {
		"FID" : 2494,
		"name" : "雲中路大帝殿",
		"lng" : 118.83032,
		"lat" : 26.157050000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2495,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.88408831737371,
		  26.203325311118991
		]
	  },
	  "properties" : {
		"FID" : 2495,
		"name" : "大王仑山体公园",
		"lng" : 118.888638,
		"lat" : 26.199919999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2496,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.83993414565076,
		  26.175957868448823
		]
	  },
	  "properties" : {
		"FID" : 2496,
		"name" : "吴孟超院士馆",
		"lng" : 118.84453999999999,
		"lat" : 26.172625
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2497,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.8852549505161,
		  26.202544468838727
		]
	  },
	  "properties" : {
		"FID" : 2497,
		"name" : "大王仑公园",
		"lng" : 118.889804,
		"lat" : 26.199138999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2498,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.90133759918861,
		  26.213855823041733
		]
	  },
	  "properties" : {
		"FID" : 2498,
		"name" : "橄榄主题文化墙",
		"lng" : 118.905886,
		"lat" : 26.210440999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2499,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.78802184895336,
		  26.084850832636828
		]
	  },
	  "properties" : {
		"FID" : 2499,
		"name" : "洪厝里联络站旧址",
		"lng" : 118.79271900000001,
		"lat" : 26.081668000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2500,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.8833630743119,
		  26.049553510324259
		]
	  },
	  "properties" : {
		"FID" : 2500,
		"name" : "姬岩风景区",
		"lng" : 118.887902,
		"lat" : 26.046247000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2501,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86264200847374,
		  26.227398972813507
		]
	  },
	  "properties" : {
		"FID" : 2501,
		"name" : "县署旧址",
		"lng" : 118.867214,
		"lat" : 26.224
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2502,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.77120738584821,
		  26.074754152199134
		]
	  },
	  "properties" : {
		"FID" : 2502,
		"name" : "航城公园",
		"lng" : 118.775925,
		"lat" : 26.071598000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2503,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.71732974516591,
		  25.955384699905192
		]
	  },
	  "properties" : {
		"FID" : 2503,
		"name" : "卢公殿景区",
		"lng" : 118.72203399999999,
		"lat" : 25.952307000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2504,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.87135869090078,
		  26.224850690610108
		]
	  },
	  "properties" : {
		"FID" : 2504,
		"name" : "台山石塔",
		"lng" : 118.87591999999999,
		"lat" : 26.221443000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2505,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86377640126166,
		  26.229069380244674
		]
	  },
	  "properties" : {
		"FID" : 2505,
		"name" : "双拥·国防教育主题公园",
		"lng" : 118.868347,
		"lat" : 26.225667999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2506,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.85113244550654,
		  26.227771468891291
		]
	  },
	  "properties" : {
		"FID" : 2506,
		"name" : "万旭公园",
		"lng" : 118.855722,
		"lat" : 26.224388999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2507,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.99386587000696,
		  26.202473499463171
		]
	  },
	  "properties" : {
		"FID" : 2507,
		"name" : "水谷瑶",
		"lng" : 118.99862400000001,
		"lat" : 26.199247
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2508,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.99532042715512,
		  26.167713065060099
		]
	  },
	  "properties" : {
		"FID" : 2508,
		"name" : "井宅",
		"lng" : 119.00008099999999,
		"lat" : 26.164511999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2509,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.878080790426,
		  26.211804255269556
		]
	  },
	  "properties" : {
		"FID" : 2509,
		"name" : "陈世猛纪念楼",
		"lng" : 118.88263499999999,
		"lat" : 26.208397999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2510,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76614581176796,
		  26.0622224879803
		]
	  },
	  "properties" : {
		"FID" : 2510,
		"name" : "白石瑞香寺",
		"lng" : 118.770867,
		"lat" : 26.059079000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2511,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.74837344253496,
		  25.987302858023881
		]
	  },
	  "properties" : {
		"FID" : 2511,
		"name" : "漢闽越王",
		"lng" : 118.753097,
		"lat" : 25.984217999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2512,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.92396636211581,
		  26.155007633501153
		]
	  },
	  "properties" : {
		"FID" : 2512,
		"name" : "探花府祖殿",
		"lng" : 118.92852999999999,
		"lat" : 26.151644000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2513,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.01148934320059,
		  26.256791258204977
		]
	  },
	  "properties" : {
		"FID" : 2513,
		"name" : "清水湾景区",
		"lng" : 119.016312,
		"lat" : 26.253587
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2514,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96071867404964,
		  26.09375936823983
		]
	  },
	  "properties" : {
		"FID" : 2514,
		"name" : "龙门隔(阁)将军庙",
		"lng" : 118.96536,
		"lat" : 26.090506000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2515,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.85948055474141,
		  26.227630852278203
		]
	  },
	  "properties" : {
		"FID" : 2515,
		"name" : "植物圣地",
		"lng" : 118.864057,
		"lat" : 26.224236000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2516,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.72401222446602,
		  25.991921543657671
		]
	  },
	  "properties" : {
		"FID" : 2516,
		"name" : "省璜镇革命斗争史迹陈列馆",
		"lng" : 118.72872599999999,
		"lat" : 25.988824999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2517,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.88710958243574,
		  26.259691690842967
		]
	  },
	  "properties" : {
		"FID" : 2517,
		"name" : "林氏宗祠",
		"lng" : 118.891662,
		"lat" : 26.256253000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2518,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.80245808312901,
		  25.991161335015306
		]
	  },
	  "properties" : {
		"FID" : 2518,
		"name" : "新丰革命老区基点村综合文化公园",
		"lng" : 118.807124,
		"lat" : 25.988019000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2519,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.00409909514747,
		  26.154513238093635
		]
	  },
	  "properties" : {
		"FID" : 2519,
		"name" : "闽侯鸿尾龙泉禅寺",
		"lng" : 119.008889,
		"lat" : 26.151347000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2520,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.05852306979916,
		  26.5294402619636
		]
	  },
	  "properties" : {
		"FID" : 2520,
		"name" : "官洋亭",
		"lng" : 119.06349299999999,
		"lat" : 26.526243000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2521,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.10904512614539,
		  26.50609170397572
		]
	  },
	  "properties" : {
		"FID" : 2521,
		"name" : "池坑溪岭亭",
		"lng" : 119.11404,
		"lat" : 26.502921000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2522,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.08683160269757,
		  26.578762390082403
		]
	  },
	  "properties" : {
		"FID" : 2522,
		"name" : "林下经济景观栈道",
		"lng" : 119.091836,
		"lat" : 26.575583000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2523,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.99853992483361,
		  26.517062979262718
		]
	  },
	  "properties" : {
		"FID" : 2523,
		"name" : "上盘岭文化公园",
		"lng" : 119.003338,
		"lat" : 26.513718999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2524,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1853793671354,
		  26.492425129774517
		]
	  },
	  "properties" : {
		"FID" : 2524,
		"name" : "险桥亭",
		"lng" : 119.190242,
		"lat" : 26.489139000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2525,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.06640253272975,
		  26.335002143068809
		]
	  },
	  "properties" : {
		"FID" : 2525,
		"name" : "马墘村水漫山牡丹园",
		"lng" : 119.07137,
		"lat" : 26.331880000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2526,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.03578528765166,
		  26.367145006949613
		]
	  },
	  "properties" : {
		"FID" : 2526,
		"name" : "观音亭",
		"lng" : 119.040691,
		"lat" : 26.363952999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2527,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.04427783959649,
		  26.323334525744993
		]
	  },
	  "properties" : {
		"FID" : 2527,
		"name" : "龙洋寺",
		"lng" : 119.04920199999999,
		"lat" : 26.320181000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2528,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.05890498299283,
		  26.314132582757761
		]
	  },
	  "properties" : {
		"FID" : 2528,
		"name" : "蓝田宫",
		"lng" : 119.06385899999999,
		"lat" : 26.31101
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2529,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.03897624107941,
		  26.400260689278952
		]
	  },
	  "properties" : {
		"FID" : 2529,
		"name" : "雪峰崇圣禅寺",
		"lng" : 119.043893,
		"lat" : 26.397062999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2530,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.0865978947285,
		  26.356381508957156
		]
	  },
	  "properties" : {
		"FID" : 2530,
		"name" : "郎官陈氏宗祠",
		"lng" : 119.09158499999999,
		"lat" : 26.353265
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2531,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.04107278210458,
		  26.401181330389026
		]
	  },
	  "properties" : {
		"FID" : 2531,
		"name" : "雪峰山",
		"lng" : 119.045995,
		"lat" : 26.397988000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2532,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.09127945174599,
		  26.359166818985763
		]
	  },
	  "properties" : {
		"FID" : 2532,
		"name" : "大湖抗日阵亡将士墓",
		"lng" : 119.09626799999999,
		"lat" : 26.35605
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2533,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.08855557161392,
		  26.365152748709033
		]
	  },
	  "properties" : {
		"FID" : 2533,
		"name" : "基督教大湖堂",
		"lng" : 119.09354399999999,
		"lat" : 26.362033
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2534,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.09121889344583,
		  26.366527934258809
		]
	  },
	  "properties" : {
		"FID" : 2534,
		"name" : "闽侯县大湖分县衙署",
		"lng" : 119.096208,
		"lat" : 26.363408
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2535,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.04367052006519,
		  26.398839833213625
		]
	  },
	  "properties" : {
		"FID" : 2535,
		"name" : "枯木庵",
		"lng" : 119.048599,
		"lat" : 26.395652999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2536,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.0376646572681,
		  26.413803661974011
		]
	  },
	  "properties" : {
		"FID" : 2536,
		"name" : "罗汉台",
		"lng" : 119.042579,
		"lat" : 26.410598
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2537,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.06496567890538,
		  26.294813644088972
		]
	  },
	  "properties" : {
		"FID" : 2537,
		"name" : "马岚山车山府祖殿",
		"lng" : 119.069928,
		"lat" : 26.291709000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2538,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.07320861973942,
		  26.303128868040282
		]
	  },
	  "properties" : {
		"FID" : 2538,
		"name" : "罗氏宗祠",
		"lng" : 119.078182,
		"lat" : 26.300028999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2539,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.98000146239652,
		  26.376187905697083
		]
	  },
	  "properties" : {
		"FID" : 2539,
		"name" : "仙洋闽越王庙",
		"lng" : 118.984725,
		"lat" : 26.372831999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2540,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.02928566883111,
		  26.419862322580276
		]
	  },
	  "properties" : {
		"FID" : 2540,
		"name" : "应潮泉",
		"lng" : 119.034177,
		"lat" : 26.416633999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2541,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96745070471688,
		  26.344650203341686
		]
	  },
	  "properties" : {
		"FID" : 2541,
		"name" : "锡地境",
		"lng" : 118.972131,
		"lat" : 26.341272
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2542,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.97381814240734,
		  26.360793453861248
		]
	  },
	  "properties" : {
		"FID" : 2542,
		"name" : "新见闽越王庙",
		"lng" : 118.97852,
		"lat" : 26.357426
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2543,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.02017061156027,
		  26.275094139740332
		]
	  },
	  "properties" : {
		"FID" : 2543,
		"name" : "远济廊桥",
		"lng" : 119.025023,
		"lat" : 26.271905
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2544,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96681930240787,
		  26.363042897651201
		]
	  },
	  "properties" : {
		"FID" : 2544,
		"name" : "伽蓝殿",
		"lng" : 118.97149899999999,
		"lat" : 26.359655
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2545,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.95911434114963,
		  26.364363604990004
		]
	  },
	  "properties" : {
		"FID" : 2545,
		"name" : "花桥江氏宗祠(大夫第)",
		"lng" : 118.96377099999999,
		"lat" : 26.360955000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2546,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.10469502559606,
		  26.422063917214743
		]
	  },
	  "properties" : {
		"FID" : 2546,
		"name" : "张氏宗祠",
		"lng" : 119.109686,
		"lat" : 26.41892
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2547,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.10524133303753,
		  26.421693060561644
		]
	  },
	  "properties" : {
		"FID" : 2547,
		"name" : "齐天大圣府",
		"lng" : 119.110232,
		"lat" : 26.418548999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2548,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.95205533667666,
		  26.345197308431374
		]
	  },
	  "properties" : {
		"FID" : 2548,
		"name" : "谢氏宗祠",
		"lng" : 118.95669100000001,
		"lat" : 26.34178
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2549,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.95005213660501,
		  26.351090442244363
		]
	  },
	  "properties" : {
		"FID" : 2549,
		"name" : "安仁境",
		"lng" : 118.954683,
		"lat" : 26.347666
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2550,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.10388353744906,
		  26.4233489795491
		]
	  },
	  "properties" : {
		"FID" : 2550,
		"name" : "泰山府",
		"lng" : 119.108875,
		"lat" : 26.420204999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2551,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.06851158432433,
		  26.258291399305396
		]
	  },
	  "properties" : {
		"FID" : 2551,
		"name" : "中亭",
		"lng" : 119.073476,
		"lat" : 26.255210000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2552,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.14866021324413,
		  26.292953221467286
		]
	  },
	  "properties" : {
		"FID" : 2552,
		"name" : "总管府",
		"lng" : 119.153583,
		"lat" : 26.289811
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2553,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.94748678882254,
		  26.362356901177538
		]
	  },
	  "properties" : {
		"FID" : 2553,
		"name" : "车山府",
		"lng" : 118.952112,
		"lat" : 26.358922
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2554,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1510318979557,
		  26.266103498980403
		]
	  },
	  "properties" : {
		"FID" : 2554,
		"name" : "三叠井森林公园",
		"lng" : 119.155948,
		"lat" : 26.262971
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2555,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.01148934320059,
		  26.256791258204977
		]
	  },
	  "properties" : {
		"FID" : 2555,
		"name" : "清水湾景区",
		"lng" : 119.016312,
		"lat" : 26.253587
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2556,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.09116574846917,
		  26.264505176763588
		]
	  },
	  "properties" : {
		"FID" : 2556,
		"name" : "溪坪旗鼓合境大王庙",
		"lng" : 119.096147,
		"lat" : 26.261434000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2557,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.09418714267601,
		  26.256357722016482
		]
	  },
	  "properties" : {
		"FID" : 2557,
		"name" : "知青小镇",
		"lng" : 119.09916800000001,
		"lat" : 26.253291000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2558,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.00677025804298,
		  26.243724074386506
		]
	  },
	  "properties" : {
		"FID" : 2558,
		"name" : "闽侯县白沙镇大目溪村张氏古宅",
		"lng" : 119.01157600000001,
		"lat" : 26.240513
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2559,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.10377392403804,
		  26.23562665169629
		]
	  },
	  "properties" : {
		"FID" : 2559,
		"name" : "闽侯白沙峰龙禅寺",
		"lng" : 119.108751,
		"lat" : 26.232569000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2560,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.95917779392157,
		  26.274863045630365
		]
	  },
	  "properties" : {
		"FID" : 2560,
		"name" : "五奇山仙君殿",
		"lng" : 118.96382800000001,
		"lat" : 26.271497
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2561,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.92169615174598,
		  26.296287579883884
		]
	  },
	  "properties" : {
		"FID" : 2561,
		"name" : "闽侯小箬乡九仙岩",
		"lng" : 118.926267,
		"lat" : 26.292840999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2562,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.09188216831133,
		  26.244756385876403
		]
	  },
	  "properties" : {
		"FID" : 2562,
		"name" : "孔源村花海",
		"lng" : 119.096862,
		"lat" : 26.241696000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2563,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.0451179640468,
		  26.216930720455455
		]
	  },
	  "properties" : {
		"FID" : 2563,
		"name" : "玉磬楼(马坑观景平台)",
		"lng" : 119.05003600000001,
		"lat" : 26.213835
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2564,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.91062729873852,
		  26.396939461782143
		]
	  },
	  "properties" : {
		"FID" : 2564,
		"name" : "瓷天下海丝谷",
		"lng" : 118.915194,
		"lat" : 26.393439000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2565,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.04956149176219,
		  26.208621071993701
		]
	  },
	  "properties" : {
		"FID" : 2565,
		"name" : "金钟阁",
		"lng" : 119.054489,
		"lat" : 26.205539000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2566,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.09256556322154,
		  26.238727002861882
		]
	  },
	  "properties" : {
		"FID" : 2566,
		"name" : "孔元花世界花海",
		"lng" : 119.097545,
		"lat" : 26.235669999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2567,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18376440761028,
		  26.238658098791664
		]
	  },
	  "properties" : {
		"FID" : 2567,
		"name" : "云林禅寺",
		"lng" : 119.18861099999999,
		"lat" : 26.235479999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2568,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.87341089760638,
		  26.346340807996757
		]
	  },
	  "properties" : {
		"FID" : 2568,
		"name" : "义窟古瓷窑遗址",
		"lng" : 118.877979,
		"lat" : 26.342869
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2569,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.05345284448345,
		  26.215089747525127
		]
	  },
	  "properties" : {
		"FID" : 2569,
		"name" : "白沙滩",
		"lng" : 119.05838900000001,
		"lat" : 26.212011
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2570,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19174691904821,
		  26.224247670785317
		]
	  },
	  "properties" : {
		"FID" : 2570,
		"name" : "三峰寺",
		"lng" : 119.196577,
		"lat" : 26.221063999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2571,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.9165031595023,
		  26.393956022710725
		]
	  },
	  "properties" : {
		"FID" : 2571,
		"name" : "九野小镇",
		"lng" : 118.921075,
		"lat" : 26.390460999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2572,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.90142859505079,
		  26.377928611123664
		]
	  },
	  "properties" : {
		"FID" : 2572,
		"name" : "迷乐谷文化旅游景区",
		"lng" : 118.90598900000001,
		"lat" : 26.374431999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2573,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.99158911982654,
		  26.251115130522354
		]
	  },
	  "properties" : {
		"FID" : 2573,
		"name" : "圆明寺",
		"lng" : 118.996343,
		"lat" : 26.247854
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2574,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.07079337063774,
		  26.211216515578986
		]
	  },
	  "properties" : {
		"FID" : 2574,
		"name" : "闽侯白沙",
		"lng" : 119.075757,
		"lat" : 26.208164
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2575,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.89132400454784,
		  26.270466893921466
		]
	  },
	  "properties" : {
		"FID" : 2575,
		"name" : "大坂新丰正境",
		"lng" : 118.895876,
		"lat" : 26.267021
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2576,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.90075081782277,
		  26.377535567343145
		]
	  },
	  "properties" : {
		"FID" : 2576,
		"name" : "古榕花海园",
		"lng" : 118.905311,
		"lat" : 26.374039
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2577,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.9110552482779,
		  26.393106736315403
		]
	  },
	  "properties" : {
		"FID" : 2577,
		"name" : "闽清东桥镇溪沙村24号林氏古厝古民居",
		"lng" : 118.915622,
		"lat" : 26.389607999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2578,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.91916346673632,
		  26.348966024252171
		]
	  },
	  "properties" : {
		"FID" : 2578,
		"name" : "天池孔雀园",
		"lng" : 118.92373499999999,
		"lat" : 26.345492
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2579,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.06510951118199,
		  26.215958706410852
		]
	  },
	  "properties" : {
		"FID" : 2579,
		"name" : "龙头境",
		"lng" : 119.070066,
		"lat" : 26.212897000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2580,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.90052000122141,
		  26.375861922858345
		]
	  },
	  "properties" : {
		"FID" : 2580,
		"name" : "官圳里(光禄第)",
		"lng" : 118.90508,
		"lat" : 26.372366
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2581,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.05926348618166,
		  26.234118167719004
		]
	  },
	  "properties" : {
		"FID" : 2581,
		"name" : "永奋永襄厝",
		"lng" : 119.064212,
		"lat" : 26.231038000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2582,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.06498025920773,
		  26.22172319477815
		]
	  },
	  "properties" : {
		"FID" : 2582,
		"name" : "后坑境",
		"lng" : 119.069937,
		"lat" : 26.218658000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2583,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1663370086812,
		  26.243761685437853
		]
	  },
	  "properties" : {
		"FID" : 2583,
		"name" : "中共五县西区工委旧址",
		"lng" : 119.17122000000001,
		"lat" : 26.240613
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2584,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.95623207151469,
		  26.208436401147836
		]
	  },
	  "properties" : {
		"FID" : 2584,
		"name" : "闽侯县沙都澳沙滩",
		"lng" : 118.960869,
		"lat" : 26.205100000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2585,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18419624684476,
		  26.238927015630111
		]
	  },
	  "properties" : {
		"FID" : 2585,
		"name" : "云林院八角井",
		"lng" : 119.189042,
		"lat" : 26.235748000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2586,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.12905323693718,
		  26.217150343143366
		]
	  },
	  "properties" : {
		"FID" : 2586,
		"name" : "荆溪荷洋玉封齐天府",
		"lng" : 119.134004,
		"lat" : 26.214079999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2587,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.00112306880067,
		  26.211318633263279
		]
	  },
	  "properties" : {
		"FID" : 2587,
		"name" : "圣君殿",
		"lng" : 119.00590699999999,
		"lat" : 26.208109
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2588,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.00532643476537,
		  26.213841424588026
		]
	  },
	  "properties" : {
		"FID" : 2588,
		"name" : "三十四都太兴境白马尊王庙",
		"lng" : 119.010125,
		"lat" : 26.210643000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2589,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18527758244343,
		  26.249598835460429
		]
	  },
	  "properties" : {
		"FID" : 2589,
		"name" : "仙坂正境",
		"lng" : 119.190122,
		"lat" : 26.246411999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2590,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1681833333005,
		  26.23780684860958
		]
	  },
	  "properties" : {
		"FID" : 2590,
		"name" : "东坑境",
		"lng" : 119.173062,
		"lat" : 26.234658
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2591,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.09559214104452,
		  26.230892709283935
		]
	  },
	  "properties" : {
		"FID" : 2591,
		"name" : "玉封伡山府",
		"lng" : 119.100571,
		"lat" : 26.22784
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2592,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18366545265111,
		  26.354419683331376
		]
	  },
	  "properties" : {
		"FID" : 2592,
		"name" : "慈法宫",
		"lng" : 119.18852099999999,
		"lat" : 26.351184
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2593,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.08960333031709,
		  26.208631048453629
		]
	  },
	  "properties" : {
		"FID" : 2593,
		"name" : "燕坪禅寺",
		"lng" : 119.09457999999999,
		"lat" : 26.205590999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2594,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.05431998258346,
		  26.216878284473616
		]
	  },
	  "properties" : {
		"FID" : 2594,
		"name" : "玉封泰山府",
		"lng" : 119.059258,
		"lat" : 26.213799999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2595,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.04039518198492,
		  26.235353378144364
		]
	  },
	  "properties" : {
		"FID" : 2595,
		"name" : "白马尊王庙(白沙镇马坑村)",
		"lng" : 119.045303,
		"lat" : 26.232237000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2596,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18957674915922,
		  26.238604163399213
		]
	  },
	  "properties" : {
		"FID" : 2596,
		"name" : "金沙洋境",
		"lng" : 119.194412,
		"lat" : 26.235416000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2597,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1665730888872,
		  26.236039821473373
		]
	  },
	  "properties" : {
		"FID" : 2597,
		"name" : "仁洲汉闽越王庙",
		"lng" : 119.17145499999999,
		"lat" : 26.232894999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2598,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.87866532813214,
		  26.279248975675351
		]
	  },
	  "properties" : {
		"FID" : 2598,
		"name" : "基督教小箬堂",
		"lng" : 118.883224,
		"lat" : 26.275804999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2599,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86598260047471,
		  26.223897151258235
		]
	  },
	  "properties" : {
		"FID" : 2599,
		"name" : "将军庙",
		"lng" : 118.87054999999999,
		"lat" : 26.220496000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2600,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.89891562805448,
		  26.372084552160747
		]
	  },
	  "properties" : {
		"FID" : 2600,
		"name" : "思远亭",
		"lng" : 118.903475,
		"lat" : 26.368590000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2601,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.16267178601731,
		  26.237866499824044
		]
	  },
	  "properties" : {
		"FID" : 2601,
		"name" : "玉泉禅寺",
		"lng" : 119.167562,
		"lat" : 26.234728
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2602,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22926777410675,
		  26.328626110817833
		]
	  },
	  "properties" : {
		"FID" : 2602,
		"name" : "下万胜境",
		"lng" : 119.234055,
		"lat" : 26.325344000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2603,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.92293016254352,
		  26.232430094807334
		]
	  },
	  "properties" : {
		"FID" : 2603,
		"name" : "建灵寺",
		"lng" : 118.927498,
		"lat" : 26.229019000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2604,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.15574709511587,
		  26.216856652171732
		]
	  },
	  "properties" : {
		"FID" : 2604,
		"name" : "闽侯金山生命公园",
		"lng" : 119.16065,
		"lat" : 26.213743000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2605,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21788340672842,
		  26.444733665159742
		]
	  },
	  "properties" : {
		"FID" : 2605,
		"name" : "中国畲山水景区",
		"lng" : 119.22269,
		"lat" : 26.441414999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2606,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86763175425826,
		  26.221789879356695
		]
	  },
	  "properties" : {
		"FID" : 2606,
		"name" : "南门公园",
		"lng" : 118.872197,
		"lat" : 26.218388000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2607,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22500730776335,
		  26.329505703315718
		]
	  },
	  "properties" : {
		"FID" : 2607,
		"name" : "上万胜境",
		"lng" : 119.229798,
		"lat" : 26.326225999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2608,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.12700532735117,
		  26.217096637439752
		]
	  },
	  "properties" : {
		"FID" : 2608,
		"name" : "师公殿",
		"lng" : 119.13195899999999,
		"lat" : 26.214029
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2609,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.9586835359607,
		  26.229994793432528
		]
	  },
	  "properties" : {
		"FID" : 2609,
		"name" : "望江台",
		"lng" : 118.963329,
		"lat" : 26.226652000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2610,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21046219372541,
		  26.310116294410911
		]
	  },
	  "properties" : {
		"FID" : 2610,
		"name" : "文山北境",
		"lng" : 119.21526799999999,
		"lat" : 26.30686
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2611,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.88710958243574,
		  26.259691690842967
		]
	  },
	  "properties" : {
		"FID" : 2611,
		"name" : "林氏宗祠",
		"lng" : 118.891662,
		"lat" : 26.256253000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2612,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.90244403783569,
		  26.216631207432645
		]
	  },
	  "properties" : {
		"FID" : 2612,
		"name" : "下梅埔公园",
		"lng" : 118.906993,
		"lat" : 26.213215000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2613,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.87184304799644,
		  26.226849325504926
		]
	  },
	  "properties" : {
		"FID" : 2613,
		"name" : "怀远楼",
		"lng" : 118.87640399999999,
		"lat" : 26.22344
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2614,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.87196735174545,
		  26.22442806698503
		]
	  },
	  "properties" : {
		"FID" : 2614,
		"name" : "台山公园",
		"lng" : 118.87652799999999,
		"lat" : 26.221019999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2615,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19326180673416,
		  26.223083487987768
		]
	  },
	  "properties" : {
		"FID" : 2615,
		"name" : "石花夫人祖殿",
		"lng" : 119.198089,
		"lat" : 26.219898000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2616,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.87898843798976,
		  26.212385292391833
		]
	  },
	  "properties" : {
		"FID" : 2616,
		"name" : "闽清江滨休闲公园",
		"lng" : 118.88354200000001,
		"lat" : 26.208977999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2617,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.87168828819409,
		  26.28997926747434
		]
	  },
	  "properties" : {
		"FID" : 2617,
		"name" : "闽清北站站前广场",
		"lng" : 118.876254,
		"lat" : 26.286536000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2618,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19392008229617,
		  26.222109995199499
		]
	  },
	  "properties" : {
		"FID" : 2618,
		"name" : "苏氏宗祠",
		"lng" : 119.198746,
		"lat" : 26.218924000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2619,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.88184202780235,
		  26.230962964502503
		]
	  },
	  "properties" : {
		"FID" : 2619,
		"name" : "同兴境(白河江廿四位诸天庙)",
		"lng" : 118.88639499999999,
		"lat" : 26.227543000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2620,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19139979876364,
		  26.21724306495781
		]
	  },
	  "properties" : {
		"FID" : 2620,
		"name" : "大岩探花府",
		"lng" : 119.19623,
		"lat" : 26.214064
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2621,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21834024589184,
		  26.214888898758922
		]
	  },
	  "properties" : {
		"FID" : 2621,
		"name" : "松庵禅寺",
		"lng" : 119.223129,
		"lat" : 26.211675
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2622,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.88549489918617,
		  26.259748971615487
		]
	  },
	  "properties" : {
		"FID" : 2622,
		"name" : "漈恩境",
		"lng" : 118.89004799999999,
		"lat" : 26.256311
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2623,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18654866051494,
		  26.228622337983627
		]
	  },
	  "properties" : {
		"FID" : 2623,
		"name" : "下洋正境",
		"lng" : 119.191389,
		"lat" : 26.225445000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2624,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18386582098252,
		  26.209347500155147
		]
	  },
	  "properties" : {
		"FID" : 2624,
		"name" : "闽侯县五十二都溪东正境(裡店庙泰山府)",
		"lng" : 119.18871,
		"lat" : 26.206185999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2625,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.87135869090078,
		  26.224850690610108
		]
	  },
	  "properties" : {
		"FID" : 2625,
		"name" : "台山石塔",
		"lng" : 118.87591999999999,
		"lat" : 26.221443000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2626,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.16764546739877,
		  26.221131369150353
		]
	  },
	  "properties" : {
		"FID" : 2626,
		"name" : "崇福寺",
		"lng" : 119.172524,
		"lat" : 26.217993
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2627,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18406119008702,
		  26.209608999982251
		]
	  },
	  "properties" : {
		"FID" : 2627,
		"name" : "齐天府",
		"lng" : 119.18890500000001,
		"lat" : 26.206447000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2628,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19355633668398,
		  26.223204035009662
		]
	  },
	  "properties" : {
		"FID" : 2628,
		"name" : "长信境",
		"lng" : 119.19838300000001,
		"lat" : 26.220018
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2629,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20691228577216,
		  26.227755286116889
		]
	  },
	  "properties" : {
		"FID" : 2629,
		"name" : "南涧境",
		"lng" : 119.21171699999999,
		"lat" : 26.224547000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2630,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19172135760819,
		  26.217792915819505
		]
	  },
	  "properties" : {
		"FID" : 2630,
		"name" : "溪東正境",
		"lng" : 119.196551,
		"lat" : 26.214613
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2631,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1853793671354,
		  26.492425129774517
		]
	  },
	  "properties" : {
		"FID" : 2631,
		"name" : "险桥亭",
		"lng" : 119.190242,
		"lat" : 26.489139000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2632,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17916668184104,
		  26.217940021266742
		]
	  },
	  "properties" : {
		"FID" : 2632,
		"name" : "田沙洋齐天大圣王",
		"lng" : 119.184021,
		"lat" : 26.214782
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2633,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.878080790426,
		  26.211804255269556
		]
	  },
	  "properties" : {
		"FID" : 2633,
		"name" : "陈世猛纪念楼",
		"lng" : 118.88263499999999,
		"lat" : 26.208397999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2634,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.87127466697358,
		  26.223969099466448
		]
	  },
	  "properties" : {
		"FID" : 2634,
		"name" : "台山公园-黄乃裳纪念馆",
		"lng" : 118.87583600000001,
		"lat" : 26.220562000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2635,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.97386329640804,
		  26.303144821620148
		]
	  },
	  "properties" : {
		"FID" : 2635,
		"name" : "芹岩寺",
		"lng" : 118.978561,
		"lat" : 26.299804000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2636,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.97507918349999,
		  26.264627549035605
		]
	  },
	  "properties" : {
		"FID" : 2636,
		"name" : "水谷瑶民俗景区",
		"lng" : 118.979778,
		"lat" : 26.261310000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2637,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.90800756571547,
		  26.226785072081007
		]
	  },
	  "properties" : {
		"FID" : 2637,
		"name" : "福州·云溪漫谷",
		"lng" : 118.91256,
		"lat" : 26.223365000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2638,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.04997148436463,
		  26.131408835698242
		]
	  },
	  "properties" : {
		"FID" : 2638,
		"name" : "闽侯竹岐佛地禅寺",
		"lng" : 119.054894,
		"lat" : 26.128374999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2639,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.05586749480258,
		  26.14471888610634
		]
	  },
	  "properties" : {
		"FID" : 2639,
		"name" : "得磬寺",
		"lng" : 119.06080300000001,
		"lat" : 26.141687000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2640,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.06142274801337,
		  26.117415885138779
		]
	  },
	  "properties" : {
		"FID" : 2640,
		"name" : "下洋探花府",
		"lng" : 119.066366,
		"lat" : 26.114409999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2641,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.08472968285676,
		  26.14799042139208
		]
	  },
	  "properties" : {
		"FID" : 2641,
		"name" : "五仙寺",
		"lng" : 119.08969999999999,
		"lat" : 26.144985999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2642,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.11637191093163,
		  26.134078146730609
		]
	  },
	  "properties" : {
		"FID" : 2642,
		"name" : "龙旺·闽越水镇",
		"lng" : 119.121332,
		"lat" : 26.131073000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2643,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.11915668458776,
		  26.149249497572498
		]
	  },
	  "properties" : {
		"FID" : 2643,
		"name" : "甘蔗湿地公园",
		"lng" : 119.124115,
		"lat" : 26.146232000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2644,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.11857804369092,
		  26.136224655239097
		]
	  },
	  "properties" : {
		"FID" : 2644,
		"name" : "闽越水镇节庆广场",
		"lng" : 119.123536,
		"lat" : 26.133216000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2645,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.10472977573956,
		  26.12582354267321
		]
	  },
	  "properties" : {
		"FID" : 2645,
		"name" : "神龙谷",
		"lng" : 119.10969799999999,
		"lat" : 26.122831999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2646,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.07092917014769,
		  26.159450115841068
		]
	  },
	  "properties" : {
		"FID" : 2646,
		"name" : "泰山府",
		"lng" : 119.075889,
		"lat" : 26.156428999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2647,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.10397161606967,
		  26.149342159049883
		]
	  },
	  "properties" : {
		"FID" : 2647,
		"name" : "竹岐廉政文化公园",
		"lng" : 119.108942,
		"lat" : 26.146336000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2648,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.10561961883781,
		  26.133916181347672
		]
	  },
	  "properties" : {
		"FID" : 2648,
		"name" : "竹岐乡中埕·齊天府",
		"lng" : 119.11058800000001,
		"lat" : 26.130918999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2649,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.12806419767222,
		  26.146506198878299
		]
	  },
	  "properties" : {
		"FID" : 2649,
		"name" : "闽侯江滨生态园",
		"lng" : 119.133011,
		"lat" : 26.14348
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2650,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.10246248650002,
		  26.14257824441701
		]
	  },
	  "properties" : {
		"FID" : 2650,
		"name" : "皇天陵园烈士纪念园",
		"lng" : 119.107433,
		"lat" : 26.139576999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2651,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.12369830041226,
		  26.120299024545037
		]
	  },
	  "properties" : {
		"FID" : 2651,
		"name" : "榕岸泰山宫",
		"lng" : 119.128649,
		"lat" : 26.117294999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2652,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.11679239387225,
		  26.133290037539762
		]
	  },
	  "properties" : {
		"FID" : 2652,
		"name" : "梦幻水族馆",
		"lng" : 119.121752,
		"lat" : 26.130285000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2653,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.12761117333285,
		  26.164665969086631
		]
	  },
	  "properties" : {
		"FID" : 2653,
		"name" : "岭山寺",
		"lng" : 119.13256,
		"lat" : 26.161629000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2654,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.03257639240454,
		  26.154449595434592
		]
	  },
	  "properties" : {
		"FID" : 2654,
		"name" : "燕钦家山顶",
		"lng" : 119.037457,
		"lat" : 26.151363
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2655,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.02932129897516,
		  26.094511237076595
		]
	  },
	  "properties" : {
		"FID" : 2655,
		"name" : "龙溪境",
		"lng" : 119.034188,
		"lat" : 26.091455
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2656,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.12327552594169,
		  26.123439558039454
		]
	  },
	  "properties" : {
		"FID" : 2656,
		"name" : "林氏宗祠",
		"lng" : 119.128227,
		"lat" : 26.120433999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2657,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.09477903370149,
		  26.179570452496598
		]
	  },
	  "properties" : {
		"FID" : 2657,
		"name" : "三益观禅寺",
		"lng" : 119.099754,
		"lat" : 26.176548
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2658,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.12158578447917,
		  26.158426843246346
		]
	  },
	  "properties" : {
		"FID" : 2658,
		"name" : "临水宫",
		"lng" : 119.126542,
		"lat" : 26.155401000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2659,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.12156989368965,
		  26.156744775631818
		]
	  },
	  "properties" : {
		"FID" : 2659,
		"name" : "玉封十三太保庙",
		"lng" : 119.126526,
		"lat" : 26.15372
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2660,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.12311514038119,
		  26.125857929852909
		]
	  },
	  "properties" : {
		"FID" : 2660,
		"name" : "基督教榕岸堂",
		"lng" : 119.128067,
		"lat" : 26.122851000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2661,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.13749540454627,
		  26.140767078416765
		]
	  },
	  "properties" : {
		"FID" : 2661,
		"name" : "生态公园",
		"lng" : 119.142427,
		"lat" : 26.137730999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2662,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.12173737513604,
		  26.126815981993566
		]
	  },
	  "properties" : {
		"FID" : 2662,
		"name" : "玉封探花府",
		"lng" : 119.12669099999999,
		"lat" : 26.123809999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2663,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1211147470638,
		  26.125320333026625
		]
	  },
	  "properties" : {
		"FID" : 2663,
		"name" : "杨氏宗祠",
		"lng" : 119.126069,
		"lat" : 26.122316000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2664,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1229809898142,
		  26.1256316292476
		]
	  },
	  "properties" : {
		"FID" : 2664,
		"name" : "榕岸境泰山府",
		"lng" : 119.127933,
		"lat" : 26.122624999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2665,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.12843580128722,
		  26.119265267237758
		]
	  },
	  "properties" : {
		"FID" : 2665,
		"name" : "榕岸冯氏大宗祠",
		"lng" : 119.13338,
		"lat" : 26.116256
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2666,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.11515401487614,
		  26.169614348890111
		]
	  },
	  "properties" : {
		"FID" : 2666,
		"name" : "灵峰寺",
		"lng" : 119.12011800000001,
		"lat" : 26.166588000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2667,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.13088485876568,
		  26.152812966890835
		]
	  },
	  "properties" : {
		"FID" : 2667,
		"name" : "街心公园",
		"lng" : 119.135828,
		"lat" : 26.149778999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2668,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.09052857014517,
		  26.176884920858747
		]
	  },
	  "properties" : {
		"FID" : 2668,
		"name" : "观音亭禅寺",
		"lng" : 119.09550299999999,
		"lat" : 26.173863999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2669,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.13641595857663,
		  26.149028644404769
		]
	  },
	  "properties" : {
		"FID" : 2669,
		"name" : "五通殿泰山宫",
		"lng" : 119.14135,
		"lat" : 26.145989
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2670,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.08432283693536,
		  26.187774120709527
		]
	  },
	  "properties" : {
		"FID" : 2670,
		"name" : "镇国寺",
		"lng" : 119.089296,
		"lat" : 26.184744999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2671,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1345599249921,
		  26.109283361469735
		]
	  },
	  "properties" : {
		"FID" : 2671,
		"name" : "昆山禅寺",
		"lng" : 119.139494,
		"lat" : 26.106272000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2672,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.13234510062351,
		  26.152796007774477
		]
	  },
	  "properties" : {
		"FID" : 2672,
		"name" : "甘蔗广场",
		"lng" : 119.137286,
		"lat" : 26.149760000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2673,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.12938619684768,
		  26.119035383473566
		]
	  },
	  "properties" : {
		"FID" : 2673,
		"name" : "庄边山遗址",
		"lng" : 119.13432899999999,
		"lat" : 26.116025
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2674,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.12960324701616,
		  26.122567958827215
		]
	  },
	  "properties" : {
		"FID" : 2674,
		"name" : "叶氏大宗祠",
		"lng" : 119.134546,
		"lat" : 26.119554999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2675,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.12306157235678,
		  26.158687676521055
		]
	  },
	  "properties" : {
		"FID" : 2675,
		"name" : "龙磹寺",
		"lng" : 119.128016,
		"lat" : 26.155660000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2676,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.14294815325889,
		  26.139077764586002
		]
	  },
	  "properties" : {
		"FID" : 2676,
		"name" : "江滨市民广场",
		"lng" : 119.14787,
		"lat" : 26.136033999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2677,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.13348771308239,
		  26.155225173905652
		]
	  },
	  "properties" : {
		"FID" : 2677,
		"name" : "闽侯县基督教甘蔗堂",
		"lng" : 119.13842699999999,
		"lat" : 26.152186
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2678,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.15248003027757,
		  26.14413753716007
		]
	  },
	  "properties" : {
		"FID" : 2678,
		"name" : "昙石公园",
		"lng" : 119.15738399999999,
		"lat" : 26.141074
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2679,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1329187834915,
		  26.155618597318956
		]
	  },
	  "properties" : {
		"FID" : 2679,
		"name" : "程氏宗祠",
		"lng" : 119.13785900000001,
		"lat" : 26.15258
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2680,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.15004734869609,
		  26.142506152677232
		]
	  },
	  "properties" : {
		"FID" : 2680,
		"name" : "闽都民俗园",
		"lng" : 119.154956,
		"lat" : 26.139448000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2681,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.12303954204633,
		  26.158723673513162
		]
	  },
	  "properties" : {
		"FID" : 2681,
		"name" : "官龙殿",
		"lng" : 119.127994,
		"lat" : 26.155695999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2682,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.14478559532122,
		  26.151587754221719
		]
	  },
	  "properties" : {
		"FID" : 2682,
		"name" : "慈恩寺",
		"lng" : 119.149705,
		"lat" : 26.148533
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2683,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.15093677915637,
		  26.146682376994796
		]
	  },
	  "properties" : {
		"FID" : 2683,
		"name" : "昙石山遗址",
		"lng" : 119.155844,
		"lat" : 26.143619999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2684,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17565616815224,
		  26.115604460497885
		]
	  },
	  "properties" : {
		"FID" : 2684,
		"name" : "闽侯法治廉政文化公园",
		"lng" : 119.18051,
		"lat" : 26.112515999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2685,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.14072480429689,
		  26.064450255557674
		]
	  },
	  "properties" : {
		"FID" : 2685,
		"name" : "溪源宫",
		"lng" : 119.145645,
		"lat" : 26.061458999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2686,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1778434225191,
		  26.079146535746098
		]
	  },
	  "properties" : {
		"FID" : 2686,
		"name" : "时珍园",
		"lng" : 119.18268999999999,
		"lat" : 26.076077999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2687,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.14490466261336,
		  26.153628236457742
		]
	  },
	  "properties" : {
		"FID" : 2687,
		"name" : "樟山公园",
		"lng" : 119.149824,
		"lat" : 26.150572
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2688,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18956538920528,
		  26.096833036514475
		]
	  },
	  "properties" : {
		"FID" : 2688,
		"name" : "上街玉皇宫",
		"lng" : 119.19439,
		"lat" : 26.093731999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2689,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2206382441364,
		  26.101167287010586
		]
	  },
	  "properties" : {
		"FID" : 2689,
		"name" : "分水岭",
		"lng" : 119.225416,
		"lat" : 26.098022
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2690,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.14305757534716,
		  26.149327432732555
		]
	  },
	  "properties" : {
		"FID" : 2690,
		"name" : "山前村探花府",
		"lng" : 119.14798,
		"lat" : 26.146277000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2691,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.15933151670092,
		  26.070421035962315
		]
	  },
	  "properties" : {
		"FID" : 2691,
		"name" : "超山禅寺",
		"lng" : 119.164216,
		"lat" : 26.067392999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2692,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22613830404048,
		  26.075730825855473
		]
	  },
	  "properties" : {
		"FID" : 2692,
		"name" : "金山寺",
		"lng" : 119.230909,
		"lat" : 26.072597999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2693,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.12752915094407,
		  26.176568186064561
		]
	  },
	  "properties" : {
		"FID" : 2693,
		"name" : "半岭亭",
		"lng" : 119.132479,
		"lat" : 26.173524
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2694,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.15751187605521,
		  26.135295117489346
		]
	  },
	  "properties" : {
		"FID" : 2694,
		"name" : "洽浦庙",
		"lng" : 119.16240500000001,
		"lat" : 26.132228000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2695,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23686820102924,
		  26.10024644213706
		]
	  },
	  "properties" : {
		"FID" : 2695,
		"name" : "观音亭普觉寺",
		"lng" : 119.241634,
		"lat" : 26.097092
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2696,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17840010765521,
		  26.085232599211214
		]
	  },
	  "properties" : {
		"FID" : 2696,
		"name" : "晓星天主堂",
		"lng" : 119.183246,
		"lat" : 26.082159000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2697,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18495696656754,
		  26.076626693809555
		]
	  },
	  "properties" : {
		"FID" : 2697,
		"name" : "齐天大圣",
		"lng" : 119.189789,
		"lat" : 26.073547000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2698,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.15006819812096,
		  26.145031788691334
		]
	  },
	  "properties" : {
		"FID" : 2698,
		"name" : "珠岩寺",
		"lng" : 119.154977,
		"lat" : 26.141971999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2699,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22154039544736,
		  26.098109064742715
		]
	  },
	  "properties" : {
		"FID" : 2699,
		"name" : "接官道",
		"lng" : 119.22631699999999,
		"lat" : 26.094964999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2700,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18284479028566,
		  26.089620563863093
		]
	  },
	  "properties" : {
		"FID" : 2700,
		"name" : "基督教上街堂",
		"lng" : 119.187682,
		"lat" : 26.086535999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2701,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21188083675543,
		  26.07404834915063
		]
	  },
	  "properties" : {
		"FID" : 2701,
		"name" : "闽都基督教堂",
		"lng" : 119.216667,
		"lat" : 26.070930000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2702,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22146315717833,
		  26.100256408800671
		]
	  },
	  "properties" : {
		"FID" : 2702,
		"name" : "三相公祖殿",
		"lng" : 119.22624,
		"lat" : 26.097111000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2703,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.0502812926904,
		  26.190804150602315
		]
	  },
	  "properties" : {
		"FID" : 2703,
		"name" : "塔岚殿",
		"lng" : 119.055209,
		"lat" : 26.187733999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2704,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18836386057471,
		  26.046549439963773
		]
	  },
	  "properties" : {
		"FID" : 2704,
		"name" : "圣女小德兰天主教堂",
		"lng" : 119.19318699999999,
		"lat" : 26.043483999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2705,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19174691904821,
		  26.224247670785317
		]
	  },
	  "properties" : {
		"FID" : 2705,
		"name" : "三峰寺",
		"lng" : 119.196577,
		"lat" : 26.221063999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2706,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20806757854285,
		  26.113223514369611
		]
	  },
	  "properties" : {
		"FID" : 2706,
		"name" : "绿洲寨公园",
		"lng" : 119.212862,
		"lat" : 26.110084000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2707,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.0711035984841,
		  26.203493674553208
		]
	  },
	  "properties" : {
		"FID" : 2707,
		"name" : "白沙市民公园",
		"lng" : 119.07606699999999,
		"lat" : 26.200445999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2708,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18722976810872,
		  26.191720955743257
		]
	  },
	  "properties" : {
		"FID" : 2708,
		"name" : "东林寺",
		"lng" : 119.192066,
		"lat" : 26.188564
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2709,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.00409909514747,
		  26.154513238093635
		]
	  },
	  "properties" : {
		"FID" : 2709,
		"name" : "闽侯鸿尾龙泉禅寺",
		"lng" : 119.008889,
		"lat" : 26.151347000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2710,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18263645048657,
		  26.128511546984065
		]
	  },
	  "properties" : {
		"FID" : 2710,
		"name" : "荆山胜迹",
		"lng" : 119.187477,
		"lat" : 26.125402000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2711,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20701091544986,
		  26.061170723970882
		]
	  },
	  "properties" : {
		"FID" : 2711,
		"name" : "汉闽越王庙",
		"lng" : 119.211803,
		"lat" : 26.058067000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2712,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1865398999181,
		  26.118920259590826
		]
	  },
	  "properties" : {
		"FID" : 2712,
		"name" : "坛山玄帝宫",
		"lng" : 119.191372,
		"lat" : 26.11581
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2713,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.04956149176219,
		  26.208621071993701
		]
	  },
	  "properties" : {
		"FID" : 2713,
		"name" : "金钟阁",
		"lng" : 119.054489,
		"lat" : 26.205539000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2714,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19193147270587,
		  26.061667615484758
		]
	  },
	  "properties" : {
		"FID" : 2714,
		"name" : "福州大学旗山校区晋江园",
		"lng" : 119.196749,
		"lat" : 26.058585999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2715,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.00917105606381,
		  26.178194720199784
		]
	  },
	  "properties" : {
		"FID" : 2715,
		"name" : "五谷仙公园",
		"lng" : 119.01398,
		"lat" : 26.175028999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2716,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18348240138729,
		  26.085135733988867
		]
	  },
	  "properties" : {
		"FID" : 2716,
		"name" : "兰陵萧氏支祠",
		"lng" : 119.188318,
		"lat" : 26.082052999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2717,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.94083028364652,
		  26.146180887664549
		]
	  },
	  "properties" : {
		"FID" : 2717,
		"name" : "穆源崇福禅寺",
		"lng" : 118.945424,
		"lat" : 26.142848999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2718,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.13656719229323,
		  26.149281034118371
		]
	  },
	  "properties" : {
		"FID" : 2718,
		"name" : "玉封五通殿",
		"lng" : 119.14150100000001,
		"lat" : 26.146241
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2719,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.14099262225254,
		  26.112733603758961
		]
	  },
	  "properties" : {
		"FID" : 2719,
		"name" : "闽侯基督教赐恩堂",
		"lng" : 119.145916,
		"lat" : 26.10971
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2720,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.98694029006941,
		  26.169257442403307
		]
	  },
	  "properties" : {
		"FID" : 2720,
		"name" : "黄土仑遗址",
		"lng" : 118.99167199999999,
		"lat" : 26.166029999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2721,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22608671392859,
		  26.083059662110568
		]
	  },
	  "properties" : {
		"FID" : 2721,
		"name" : "沙滩公园",
		"lng" : 119.230858,
		"lat" : 26.079922
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2722,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.99880240288854,
		  26.167160132444742
		]
	  },
	  "properties" : {
		"FID" : 2722,
		"name" : "鸿尾乡市民公园",
		"lng" : 119.003575,
		"lat" : 26.163969999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2723,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.15014734225062,
		  26.145175019667747
		]
	  },
	  "properties" : {
		"FID" : 2723,
		"name" : "黄氏宗祠",
		"lng" : 119.155056,
		"lat" : 26.142115
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2724,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24722721120845,
		  26.088102586342139
		]
	  },
	  "properties" : {
		"FID" : 2724,
		"name" : "天主教洪山天主堂",
		"lng" : 119.25199000000001,
		"lat" : 26.084955000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2725,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.14120408737726,
		  26.111578195567443
		]
	  },
	  "properties" : {
		"FID" : 2725,
		"name" : "白马庙",
		"lng" : 119.14612700000001,
		"lat" : 26.108554999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2726,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.97158961475444,
		  26.169215369399733
		]
	  },
	  "properties" : {
		"FID" : 2726,
		"name" : "定福岩寺",
		"lng" : 118.97627,
		"lat" : 26.165942999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2727,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.16775051263298,
		  26.091020538138228
		]
	  },
	  "properties" : {
		"FID" : 2727,
		"name" : "沙堤市民公园",
		"lng" : 119.172619,
		"lat" : 26.087962999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2728,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.99309474096562,
		  26.199842288138928
		]
	  },
	  "properties" : {
		"FID" : 2728,
		"name" : "闽侯大目埕草原",
		"lng" : 118.99785,
		"lat" : 26.196615000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2729,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22539564376208,
		  26.089520448874556
		]
	  },
	  "properties" : {
		"FID" : 2729,
		"name" : "龙江寺",
		"lng" : 119.23016800000001,
		"lat" : 26.086379000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2730,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25369325974498,
		  26.088660609214909
		]
	  },
	  "properties" : {
		"FID" : 2730,
		"name" : "金牛山儿童乐园",
		"lng" : 119.25845700000001,
		"lat" : 26.085514
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2731,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17223379017008,
		  26.145550261206353
		]
	  },
	  "properties" : {
		"FID" : 2731,
		"name" : "革命烈士纪念碑",
		"lng" : 119.177097,
		"lat" : 26.142448999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2732,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.14127220592624,
		  26.111621334532394
		]
	  },
	  "properties" : {
		"FID" : 2732,
		"name" : "狮公庙",
		"lng" : 119.14619500000001,
		"lat" : 26.108598000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2733,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1897270003674,
		  26.10611039359414
		]
	  },
	  "properties" : {
		"FID" : 2733,
		"name" : "侯官村观景亭",
		"lng" : 119.194552,
		"lat" : 26.103003000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2734,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.0451179640468,
		  26.216930720455455
		]
	  },
	  "properties" : {
		"FID" : 2734,
		"name" : "玉磬楼(马坑观景平台)",
		"lng" : 119.05003600000001,
		"lat" : 26.213835
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2735,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17278689772935,
		  26.13291226165769
		]
	  },
	  "properties" : {
		"FID" : 2735,
		"name" : "启福·城市公园",
		"lng" : 119.177648,
		"lat" : 26.129818
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2736,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18654235603694,
		  26.059591076589591
		]
	  },
	  "properties" : {
		"FID" : 2736,
		"name" : "青春广场",
		"lng" : 119.19137000000001,
		"lat" : 26.056519999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2737,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18197423123034,
		  26.166889553651039
		]
	  },
	  "properties" : {
		"FID" : 2737,
		"name" : "荆溪龙文王庙",
		"lng" : 119.186819,
		"lat" : 26.163757
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2738,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.15654011586436,
		  26.132302410407522
		]
	  },
	  "properties" : {
		"FID" : 2738,
		"name" : "滨水公园",
		"lng" : 119.161435,
		"lat" : 26.129238999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2739,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19273263030415,
		  26.119366013421466
		]
	  },
	  "properties" : {
		"FID" : 2739,
		"name" : "天主堂",
		"lng" : 119.197553,
		"lat" : 26.116244999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2740,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23606056200684,
		  26.07735805274638
		]
	  },
	  "properties" : {
		"FID" : 2740,
		"name" : "妙峰山妙峰禅寺",
		"lng" : 119.240825,
		"lat" : 26.074218999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2741,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18504410015171,
		  26.103786788342862
		]
	  },
	  "properties" : {
		"FID" : 2741,
		"name" : "华棣山仙境",
		"lng" : 119.18987799999999,
		"lat" : 26.100688999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2742,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18305295545912,
		  26.106283889365663
		]
	  },
	  "properties" : {
		"FID" : 2742,
		"name" : "鲤鱼洲樱花岛",
		"lng" : 119.18789099999999,
		"lat" : 26.103187999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2743,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.16478342284555,
		  26.142395235439537
		]
	  },
	  "properties" : {
		"FID" : 2743,
		"name" : "洽浦大山镇海楼公园",
		"lng" : 119.169662,
		"lat" : 26.139309999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2744,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.16582058827704,
		  26.129224788776483
		]
	  },
	  "properties" : {
		"FID" : 2744,
		"name" : "佛顶寺",
		"lng" : 119.17069600000001,
		"lat" : 26.126145999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2745,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25776390668383,
		  26.10087099752284
		]
	  },
	  "properties" : {
		"FID" : 2745,
		"name" : "福州保福太子府1号",
		"lng" : 119.26253,
		"lat" : 26.097718
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2746,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.15785971437703,
		  26.080690143988321
		]
	  },
	  "properties" : {
		"FID" : 2746,
		"name" : "博士后广场",
		"lng" : 119.16274799999999,
		"lat" : 26.077658
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2747,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19434547335892,
		  26.040617362986815
		]
	  },
	  "properties" : {
		"FID" : 2747,
		"name" : "旗山湖公园",
		"lng" : 119.199157,
		"lat" : 26.037545999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2748,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19504001260064,
		  26.063495880853342
		]
	  },
	  "properties" : {
		"FID" : 2748,
		"name" : "福州大学旗山校区福清生态文化园",
		"lng" : 119.19985200000001,
		"lat" : 26.060407999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2749,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19472386018727,
		  26.044573642656442
		]
	  },
	  "properties" : {
		"FID" : 2749,
		"name" : "旗山湖公园观光游船",
		"lng" : 119.199535,
		"lat" : 26.041499000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2750,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25881123894838,
		  26.090037342065148
		]
	  },
	  "properties" : {
		"FID" : 2750,
		"name" : "观景台",
		"lng" : 119.263577,
		"lat" : 26.086891999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2751,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.05345284448345,
		  26.215089747525127
		]
	  },
	  "properties" : {
		"FID" : 2751,
		"name" : "白沙滩",
		"lng" : 119.05838900000001,
		"lat" : 26.212011
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2752,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18769708225952,
		  26.106479171175625
		]
	  },
	  "properties" : {
		"FID" : 2752,
		"name" : "镇国宝塔",
		"lng" : 119.192526,
		"lat" : 26.103375
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2753,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18739265877916,
		  26.104269200856795
		]
	  },
	  "properties" : {
		"FID" : 2753,
		"name" : "城隍庙",
		"lng" : 119.192222,
		"lat" : 26.101167
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2754,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.95623207151469,
		  26.208436401147836
		]
	  },
	  "properties" : {
		"FID" : 2754,
		"name" : "闽侯县沙都澳沙滩",
		"lng" : 118.960869,
		"lat" : 26.205100000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2755,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24390130213463,
		  26.09763394661794
		]
	  },
	  "properties" : {
		"FID" : 2755,
		"name" : "张经墓",
		"lng" : 119.248665,
		"lat" : 26.094480000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2756,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18050605693034,
		  26.08984949932303
		]
	  },
	  "properties" : {
		"FID" : 2756,
		"name" : "十二都文华境",
		"lng" : 119.185348,
		"lat" : 26.086769
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2757,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17375099831293,
		  26.144976738210332
		]
	  },
	  "properties" : {
		"FID" : 2757,
		"name" : "关口龟山公园",
		"lng" : 119.178611,
		"lat" : 26.141873
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2758,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19993875223363,
		  26.073846335626598
		]
	  },
	  "properties" : {
		"FID" : 2758,
		"name" : "观音阁",
		"lng" : 119.20474299999999,
		"lat" : 26.070744000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2759,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.98432323718582,
		  26.088849793231621
		]
	  },
	  "properties" : {
		"FID" : 2759,
		"name" : "车山府将军公园",
		"lng" : 118.98904,
		"lat" : 26.085666
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2760,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.14351215519132,
		  26.152670291651798
		]
	  },
	  "properties" : {
		"FID" : 2760,
		"name" : "闽侯县抗美援朝纪念亭",
		"lng" : 119.14843399999999,
		"lat" : 26.149616999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2761,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18588057372688,
		  26.079433183029067
		]
	  },
	  "properties" : {
		"FID" : 2761,
		"name" : "兴琳寺",
		"lng" : 119.19071099999999,
		"lat" : 26.076350000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2762,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25622260868059,
		  26.09982200751806
		]
	  },
	  "properties" : {
		"FID" : 2762,
		"name" : "沈葆桢墓",
		"lng" : 119.260988,
		"lat" : 26.096668999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2763,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20404655113913,
		  26.072272172872452
		]
	  },
	  "properties" : {
		"FID" : 2763,
		"name" : "余盛公园",
		"lng" : 119.208844,
		"lat" : 26.069165000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2764,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1993029453841,
		  26.043542036394886
		]
	  },
	  "properties" : {
		"FID" : 2764,
		"name" : "碧玲桥(旗山湖)",
		"lng" : 119.204106,
		"lat" : 26.040461000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2765,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.15922905260574,
		  26.166419868272275
		]
	  },
	  "properties" : {
		"FID" : 2765,
		"name" : "观音寺",
		"lng" : 119.16412099999999,
		"lat" : 26.163329999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2766,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17580031288028,
		  26.144205065899417
		]
	  },
	  "properties" : {
		"FID" : 2766,
		"name" : "普润庵",
		"lng" : 119.180656,
		"lat" : 26.141098
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2767,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.99386587000696,
		  26.202473499463171
		]
	  },
	  "properties" : {
		"FID" : 2767,
		"name" : "水谷瑶",
		"lng" : 118.99862400000001,
		"lat" : 26.199247
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2768,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22055629837551,
		  26.12605738774522
		]
	  },
	  "properties" : {
		"FID" : 2768,
		"name" : "盘古接佛禅寺",
		"lng" : 119.225336,
		"lat" : 26.122896000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2769,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19289435105077,
		  26.060346309663586
		]
	  },
	  "properties" : {
		"FID" : 2769,
		"name" : "福州大学旗山校区陈嘉庚先生雕像",
		"lng" : 119.19771,
		"lat" : 26.057264
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2770,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.16760375227928,
		  26.083755453090895
		]
	  },
	  "properties" : {
		"FID" : 2770,
		"name" : "上街沙堤嘉禾境丰埕庙",
		"lng" : 119.172472,
		"lat" : 26.080703
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2771,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.15848551133999,
		  26.166538558898012
		]
	  },
	  "properties" : {
		"FID" : 2771,
		"name" : "孔子庙",
		"lng" : 119.16337900000001,
		"lat" : 26.163450000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2772,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17625786123264,
		  26.136218840694763
		]
	  },
	  "properties" : {
		"FID" : 2772,
		"name" : "闽侯县荆溪镇南亭",
		"lng" : 119.181112,
		"lat" : 26.133116000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2773,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25553421711686,
		  26.068220345611593
		]
	  },
	  "properties" : {
		"FID" : 2773,
		"name" : "闽江公园南园-玉皇大帝庙",
		"lng" : 119.26029699999999,
		"lat" : 26.065087999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2774,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.92396636211581,
		  26.155007633501153
		]
	  },
	  "properties" : {
		"FID" : 2774,
		"name" : "探花府祖殿",
		"lng" : 118.92852999999999,
		"lat" : 26.151644000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2775,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19552837563047,
		  26.056952262530658
		]
	  },
	  "properties" : {
		"FID" : 2775,
		"name" : "福州大学旗山校区福友阁",
		"lng" : 119.200339,
		"lat" : 26.053868000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2776,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20374322228309,
		  26.043512431461025
		]
	  },
	  "properties" : {
		"FID" : 2776,
		"name" : "福州高新区黄风车公园",
		"lng" : 119.208539,
		"lat" : 26.040424999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2777,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18855643491132,
		  26.070515867644215
		]
	  },
	  "properties" : {
		"FID" : 2777,
		"name" : "福建江夏学院月牙湖",
		"lng" : 119.193381,
		"lat" : 26.067433999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2778,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17586296036605,
		  26.203629576957191
		]
	  },
	  "properties" : {
		"FID" : 2778,
		"name" : "伏虎禅寺",
		"lng" : 119.180723,
		"lat" : 26.200486000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2779,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19504510803989,
		  26.089053908909275
		]
	  },
	  "properties" : {
		"FID" : 2779,
		"name" : "吉人厝",
		"lng" : 119.199859,
		"lat" : 26.085948999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2780,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19218207793561,
		  26.086493580624598
		]
	  },
	  "properties" : {
		"FID" : 2780,
		"name" : "伽蓝府",
		"lng" : 119.197001,
		"lat" : 26.083394999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2781,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20415914463572,
		  26.133508407769032
		]
	  },
	  "properties" : {
		"FID" : 2781,
		"name" : "李纲墓",
		"lng" : 119.208961,
		"lat" : 26.130361000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2782,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.15931927562127,
		  26.165933735645105
		]
	  },
	  "properties" : {
		"FID" : 2782,
		"name" : "凤仙山霞天镇海殿",
		"lng" : 119.16421099999999,
		"lat" : 26.162844
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2783,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1823181723805,
		  26.030447927396121
		]
	  },
	  "properties" : {
		"FID" : 2783,
		"name" : "宝积寺",
		"lng" : 119.187152,
		"lat" : 26.027404000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2784,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.0981953364148,
		  26.049472794373127
		]
	  },
	  "properties" : {
		"FID" : 2784,
		"name" : "桃园谷",
		"lng" : 119.10316,
		"lat" : 26.046534000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2785,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23979464083128,
		  26.2018028403382
		]
	  },
	  "properties" : {
		"FID" : 2785,
		"name" : "菩提寺",
		"lng" : 119.244567,
		"lat" : 26.198584
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2786,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19719966920489,
		  26.092426514325499
		]
	  },
	  "properties" : {
		"FID" : 2786,
		"name" : "梁国公张睦祠",
		"lng" : 119.20201,
		"lat" : 26.089316
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2787,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22653629626599,
		  26.080251107956474
		]
	  },
	  "properties" : {
		"FID" : 2787,
		"name" : "平安福州反恐主题公园",
		"lng" : 119.231307,
		"lat" : 26.077114999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2788,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20072179062851,
		  26.090806746950605
		]
	  },
	  "properties" : {
		"FID" : 2788,
		"name" : "厚美村大公园",
		"lng" : 119.20552600000001,
		"lat" : 26.087692000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2789,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21464181143244,
		  26.148866085468423
		]
	  },
	  "properties" : {
		"FID" : 2789,
		"name" : "石佛寺",
		"lng" : 119.21943,
		"lat" : 26.145696000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2790,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2032215533094,
		  26.068152271535411
		]
	  },
	  "properties" : {
		"FID" : 2790,
		"name" : "浦口林氏宗祠",
		"lng" : 119.20802,
		"lat" : 26.065048999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2791,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25375253646597,
		  26.084738993858615
		]
	  },
	  "properties" : {
		"FID" : 2791,
		"name" : "月崖观景台",
		"lng" : 119.258516,
		"lat" : 26.081595
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2792,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17503482940569,
		  26.089695331186952
		]
	  },
	  "properties" : {
		"FID" : 2792,
		"name" : "允山古厝",
		"lng" : 119.17988800000001,
		"lat" : 26.086625000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2793,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18403228075263,
		  26.12794467187144
		]
	  },
	  "properties" : {
		"FID" : 2793,
		"name" : "宝胜寺",
		"lng" : 119.18886999999999,
		"lat" : 26.124832999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2794,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.14714562698221,
		  26.143966991034091
		]
	  },
	  "properties" : {
		"FID" : 2794,
		"name" : "丽景公园",
		"lng" : 119.15206000000001,
		"lat" : 26.140913000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2795,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19267398283625,
		  26.059846613934102
		]
	  },
	  "properties" : {
		"FID" : 2795,
		"name" : "福州大学旗山校区鲁迅雕像",
		"lng" : 119.19749,
		"lat" : 26.056764999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2796,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25608544048268,
		  26.075985301673249
		]
	  },
	  "properties" : {
		"FID" : 2796,
		"name" : "锦江园-西河园",
		"lng" : 119.26084899999999,
		"lat" : 26.072848
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2797,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19450765696445,
		  26.055447626876301
		]
	  },
	  "properties" : {
		"FID" : 2797,
		"name" : "福州大学旗山校区双子火山遗址",
		"lng" : 119.19932,
		"lat" : 26.052365999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2798,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23750048497341,
		  26.099840361580149
		]
	  },
	  "properties" : {
		"FID" : 2798,
		"name" : "镇海楼",
		"lng" : 119.242266,
		"lat" : 26.096685999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2799,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21723886183042,
		  26.029406088098405
		]
	  },
	  "properties" : {
		"FID" : 2799,
		"name" : "将军府",
		"lng" : 119.222015,
		"lat" : 26.026312000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2800,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24626805602372,
		  26.116814458470458
		]
	  },
	  "properties" : {
		"FID" : 2800,
		"name" : "青竹镜",
		"lng" : 119.25103300000001,
		"lat" : 26.113648000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2801,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20216102936871,
		  26.065722143296984
		]
	  },
	  "properties" : {
		"FID" : 2801,
		"name" : "基督教上街堂浦口聚会点",
		"lng" : 119.20696100000001,
		"lat" : 26.062622000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2802,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22294985438228,
		  26.110470325902181
		]
	  },
	  "properties" : {
		"FID" : 2802,
		"name" : "古山洲兴仁新正境",
		"lng" : 119.227726,
		"lat" : 26.107316999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2803,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19863408907516,
		  26.039757470741353
		]
	  },
	  "properties" : {
		"FID" : 2803,
		"name" : "童梦奇境-旗山湖公园",
		"lng" : 119.20343800000001,
		"lat" : 26.03668
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2804,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22846203991119,
		  26.077108267261202
		]
	  },
	  "properties" : {
		"FID" : 2804,
		"name" : "吕祖庙",
		"lng" : 119.233231,
		"lat" : 26.073972999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2805,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19121061979007,
		  26.028382948773373
		]
	  },
	  "properties" : {
		"FID" : 2805,
		"name" : "蔗洲元帅宫",
		"lng" : 119.196027,
		"lat" : 26.025324999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2806,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20449071785455,
		  26.065965568276635
		]
	  },
	  "properties" : {
		"FID" : 2806,
		"name" : "浦口村公园",
		"lng" : 119.209287,
		"lat" : 26.062861999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2807,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20630976875627,
		  26.049079670109368
		]
	  },
	  "properties" : {
		"FID" : 2807,
		"name" : "轮船港滨水公园",
		"lng" : 119.211102,
		"lat" : 26.045985000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2808,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20575507789158,
		  26.1273035978788
		]
	  },
	  "properties" : {
		"FID" : 2808,
		"name" : "光明临水宫",
		"lng" : 119.210554,
		"lat" : 26.124158000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2809,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23767493608321,
		  26.108088808783567
		]
	  },
	  "properties" : {
		"FID" : 2809,
		"name" : "汉闽越王庙",
		"lng" : 119.242441,
		"lat" : 26.104928999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2810,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1996752188318,
		  26.088410617727824
		]
	  },
	  "properties" : {
		"FID" : 2810,
		"name" : "淑显故居",
		"lng" : 119.204481,
		"lat" : 26.085298999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2811,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20622585723831,
		  26.059588630700027
		]
	  },
	  "properties" : {
		"FID" : 2811,
		"name" : "后山陈氏宗祠",
		"lng" : 119.21101899999999,
		"lat" : 26.056487000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2812,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.06510951118199,
		  26.215958706410852
		]
	  },
	  "properties" : {
		"FID" : 2812,
		"name" : "龙头境",
		"lng" : 119.070066,
		"lat" : 26.212897000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2813,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.15902757694516,
		  26.127548969354429
		]
	  },
	  "properties" : {
		"FID" : 2813,
		"name" : "妙峰古寺",
		"lng" : 119.163917,
		"lat" : 26.124483999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2814,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.15167362087348,
		  26.141591473427258
		]
	  },
	  "properties" : {
		"FID" : 2814,
		"name" : "闽都民俗园-广场",
		"lng" : 119.15657899999999,
		"lat" : 26.138531
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2815,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18128398002499,
		  26.138436457675937
		]
	  },
	  "properties" : {
		"FID" : 2815,
		"name" : "恩福境齐天府尚善轩",
		"lng" : 119.186128,
		"lat" : 26.135323
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2816,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.07079337063774,
		  26.211216515578986
		]
	  },
	  "properties" : {
		"FID" : 2816,
		"name" : "闽侯白沙",
		"lng" : 119.075757,
		"lat" : 26.208164
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2817,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22733378308727,
		  26.082333024001397
		]
	  },
	  "properties" : {
		"FID" : 2817,
		"name" : "沙滩公园-主入口广场",
		"lng" : 119.23210400000001,
		"lat" : 26.079194999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2818,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19622389508058,
		  26.039773770458723
		]
	  },
	  "properties" : {
		"FID" : 2818,
		"name" : "旗山湖公园27号古厝",
		"lng" : 119.201032,
		"lat" : 26.0367
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2819,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20012990422876,
		  26.089462988201074
		]
	  },
	  "properties" : {
		"FID" : 2819,
		"name" : "厚美张氏宗祠",
		"lng" : 119.20493500000001,
		"lat" : 26.086349999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2820,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19554489342872,
		  26.037051860191749
		]
	  },
	  "properties" : {
		"FID" : 2820,
		"name" : "太清宫",
		"lng" : 119.200354,
		"lat" : 26.033981000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2821,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18319084869938,
		  26.058087157232972
		]
	  },
	  "properties" : {
		"FID" : 2821,
		"name" : "报恩寺",
		"lng" : 119.188025,
		"lat" : 26.055022999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2822,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17642929408753,
		  26.068701960176437
		]
	  },
	  "properties" : {
		"FID" : 2822,
		"name" : "劳星天主堂",
		"lng" : 119.18127800000001,
		"lat" : 26.065643000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2823,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18122936119339,
		  26.105301969710307
		]
	  },
	  "properties" : {
		"FID" : 2823,
		"name" : "港里樱花园",
		"lng" : 119.186071,
		"lat" : 26.102209999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2824,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17222268557805,
		  26.080243812768263
		]
	  },
	  "properties" : {
		"FID" : 2824,
		"name" : "联心张宅",
		"lng" : 119.177081,
		"lat" : 26.077185
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2825,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18157221942688,
		  26.063142645530398
		]
	  },
	  "properties" : {
		"FID" : 2825,
		"name" : "新浦太保庙",
		"lng" : 119.18641,
		"lat" : 26.060078000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2826,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.16761116054364,
		  26.184577721227324
		]
	  },
	  "properties" : {
		"FID" : 2826,
		"name" : "白云寺",
		"lng" : 119.172487,
		"lat" : 26.181460999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2827,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.13515817833903,
		  25.920536899034332
		]
	  },
	  "properties" : {
		"FID" : 2827,
		"name" : "溪沙境",
		"lng" : 119.14007700000001,
		"lat" : 25.917652
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2828,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17607475885858,
		  25.892474985662783
		]
	  },
	  "properties" : {
		"FID" : 2828,
		"name" : "兔耳山景区",
		"lng" : 119.18091099999999,
		"lat" : 25.889536
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2829,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18374459708693,
		  25.91576452088345
		]
	  },
	  "properties" : {
		"FID" : 2829,
		"name" : "南屿碗窑山遗址",
		"lng" : 119.18856700000001,
		"lat" : 25.912796
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2830,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17455252908466,
		  25.906921798047854
		]
	  },
	  "properties" : {
		"FID" : 2830,
		"name" : "龙湖陈氏宗祠",
		"lng" : 119.179393,
		"lat" : 25.903976
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2831,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.16714238404823,
		  25.889241088185447
		]
	  },
	  "properties" : {
		"FID" : 2831,
		"name" : "金龙禅寺",
		"lng" : 119.171997,
		"lat" : 25.886320999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2832,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17089891270724,
		  25.880248212027894
		]
	  },
	  "properties" : {
		"FID" : 2832,
		"name" : "中共福建省委旧址",
		"lng" : 119.17574500000001,
		"lat" : 25.877327000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2833,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17091806090158,
		  25.892184155938661
		]
	  },
	  "properties" : {
		"FID" : 2833,
		"name" : "厚美亭",
		"lng" : 119.175765,
		"lat" : 25.889254999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2834,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17087285888785,
		  25.880240157727865
		]
	  },
	  "properties" : {
		"FID" : 2834,
		"name" : "革命烈士纪念碑",
		"lng" : 119.175719,
		"lat" : 25.877319
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2835,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17115445225498,
		  25.880169640481348
		]
	  },
	  "properties" : {
		"FID" : 2835,
		"name" : "福建省委旧址纪念馆",
		"lng" : 119.176,
		"lat" : 25.877248000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2836,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.10759165867007,
		  25.951263846501998
		]
	  },
	  "properties" : {
		"FID" : 2836,
		"name" : "六都历山境大王宫",
		"lng" : 119.112545,
		"lat" : 25.948388000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2837,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.11233277116206,
		  25.955753185841868
		]
	  },
	  "properties" : {
		"FID" : 2837,
		"name" : "六都际溪境大王庙",
		"lng" : 119.117283,
		"lat" : 25.952870999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2838,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.16380729927141,
		  25.877441998951728
		]
	  },
	  "properties" : {
		"FID" : 2838,
		"name" : "东龙泉寺",
		"lng" : 119.168668,
		"lat" : 25.874535999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2839,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.16869529918782,
		  25.880332118613904
		]
	  },
	  "properties" : {
		"FID" : 2839,
		"name" : "王翰公祠",
		"lng" : 119.173546,
		"lat" : 25.877414999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2840,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20826269190786,
		  25.927789753535595
		]
	  },
	  "properties" : {
		"FID" : 2840,
		"name" : "广泽尊王",
		"lng" : 119.213043,
		"lat" : 25.924775
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2841,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18365936170737,
		  25.956833174171869
		]
	  },
	  "properties" : {
		"FID" : 2841,
		"name" : "芝山广信堂",
		"lng" : 119.188485,
		"lat" : 25.953837
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2842,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19977917319211,
		  25.970872297565734
		]
	  },
	  "properties" : {
		"FID" : 2842,
		"name" : "仙宗禅寺",
		"lng" : 119.204576,
		"lat" : 25.967839999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2843,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.15812051401775,
		  25.877661506462438
		]
	  },
	  "properties" : {
		"FID" : 2843,
		"name" : "万虾溪",
		"lng" : 119.162993,
		"lat" : 25.874766000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2844,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20282750927278,
		  25.93963147098594
		]
	  },
	  "properties" : {
		"FID" : 2844,
		"name" : "精严勝境大王宫",
		"lng" : 119.207617,
		"lat" : 25.936616000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2845,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1957772915038,
		  25.956885638487304
		]
	  },
	  "properties" : {
		"FID" : 2845,
		"name" : "芝田三圣王庙",
		"lng" : 119.20058,
		"lat" : 25.953869000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2846,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.13685570405414,
		  25.857907938488921
		]
	  },
	  "properties" : {
		"FID" : 2846,
		"name" : "莒溪风景区",
		"lng" : 119.141767,
		"lat" : 25.855062
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2847,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.08768481874341,
		  25.894072603226565
		]
	  },
	  "properties" : {
		"FID" : 2847,
		"name" : "方广岩寺",
		"lng" : 119.092637,
		"lat" : 25.891238999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2848,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.11326351616574,
		  25.863806384712383
		]
	  },
	  "properties" : {
		"FID" : 2848,
		"name" : "大樟溪休闲游乐区",
		"lng" : 119.118206,
		"lat" : 25.860984999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2849,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18766343949792,
		  25.967269298199845
		]
	  },
	  "properties" : {
		"FID" : 2849,
		"name" : "福建省委电台旧址纪念馆",
		"lng" : 119.192482,
		"lat" : 25.964258999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2850,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21672948487289,
		  25.905463428014123
		]
	  },
	  "properties" : {
		"FID" : 2850,
		"name" : "安德寺",
		"lng" : 119.221497,
		"lat" : 25.902453999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2851,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.14862096353444,
		  25.858824975095825
		]
	  },
	  "properties" : {
		"FID" : 2851,
		"name" : "龙山",
		"lng" : 119.15351099999999,
		"lat" : 25.855958999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2852,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21704875570038,
		  25.933786818245036
		]
	  },
	  "properties" : {
		"FID" : 2852,
		"name" : "文山林氏宗祠",
		"lng" : 119.221818,
		"lat" : 25.930758000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2853,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.08853150989169,
		  25.89475186319746
		]
	  },
	  "properties" : {
		"FID" : 2853,
		"name" : "福州桃花洲",
		"lng" : 119.093484,
		"lat" : 25.891918
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2854,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20154842881331,
		  25.885943615528046
		]
	  },
	  "properties" : {
		"FID" : 2854,
		"name" : "兔耳山",
		"lng" : 119.20633599999999,
		"lat" : 25.882966
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2855,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20483718662244,
		  25.959650862482473
		]
	  },
	  "properties" : {
		"FID" : 2855,
		"name" : "蕉府行宫新垱分庙",
		"lng" : 119.209625,
		"lat" : 25.956619
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2856,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22759686858778,
		  25.922705068242909
		]
	  },
	  "properties" : {
		"FID" : 2856,
		"name" : "双江陈氏支祠",
		"lng" : 119.232355,
		"lat" : 25.919675000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2857,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21994033466636,
		  25.92898333792434
		]
	  },
	  "properties" : {
		"FID" : 2857,
		"name" : "碧珠亭",
		"lng" : 119.224706,
		"lat" : 25.925954999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2858,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21074799573498,
		  25.87663665947791
		]
	  },
	  "properties" : {
		"FID" : 2858,
		"name" : "老爷洞",
		"lng" : 119.215521,
		"lat" : 25.873653000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2859,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17917598492771,
		  25.988029348242986
		]
	  },
	  "properties" : {
		"FID" : 2859,
		"name" : "五凤湖",
		"lng" : 119.18401299999999,
		"lat" : 25.985019999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2860,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17260647178641,
		  25.987220618004947
		]
	  },
	  "properties" : {
		"FID" : 2860,
		"name" : "户外草坪区",
		"lng" : 119.177457,
		"lat" : 25.984224000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2861,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.08033191946983,
		  25.876251828387812
		]
	  },
	  "properties" : {
		"FID" : 2861,
		"name" : "福州欧乐堡海洋世界",
		"lng" : 119.085279,
		"lat" : 25.873427
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2862,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23707383961492,
		  25.904640427372964
		]
	  },
	  "properties" : {
		"FID" : 2862,
		"name" : "灵隐寺",
		"lng" : 119.24182500000001,
		"lat" : 25.901617999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2863,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19670525318602,
		  25.979377419657688
		]
	  },
	  "properties" : {
		"FID" : 2863,
		"name" : "溪坂齐天府古迹",
		"lng" : 119.201508,
		"lat" : 25.976344000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2864,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.13602725738203,
		  25.858786246610261
		]
	  },
	  "properties" : {
		"FID" : 2864,
		"name" : "大樟溪休闲游乐区东区",
		"lng" : 119.14094,
		"lat" : 25.855941000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2865,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17328782420645,
		  25.988118506118408
		]
	  },
	  "properties" : {
		"FID" : 2865,
		"name" : "森林人家松果乐园",
		"lng" : 119.17813700000001,
		"lat" : 25.985119999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2866,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22816043704383,
		  25.907401141949265
		]
	  },
	  "properties" : {
		"FID" : 2866,
		"name" : "闽侯县南通古灵庙管委会",
		"lng" : 119.232917,
		"lat" : 25.904381000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2867,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23510838361751,
		  25.831453918988593
		]
	  },
	  "properties" : {
		"FID" : 2867,
		"name" : "大化山风景区",
		"lng" : 119.23985500000001,
		"lat" : 25.828479999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2868,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17546034319082,
		  25.988020489944887
		]
	  },
	  "properties" : {
		"FID" : 2868,
		"name" : "幸福林",
		"lng" : 119.180305,
		"lat" : 25.985018
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2869,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2434396805816,
		  25.943986094162852
		]
	  },
	  "properties" : {
		"FID" : 2869,
		"name" : "上洲公园",
		"lng" : 119.248192,
		"lat" : 25.940936000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2870,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32149340345202,
		  25.929138433490895
		]
	  },
	  "properties" : {
		"FID" : 2870,
		"name" : "五虎山五灵岩禅寺",
		"lng" : 119.326336,
		"lat" : 25.926189999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2871,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20461695888014,
		  25.971549669156964
		]
	  },
	  "properties" : {
		"FID" : 2871,
		"name" : "孝道馆",
		"lng" : 119.209406,
		"lat" : 25.968509999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2872,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21302598935381,
		  25.984973347339018
		]
	  },
	  "properties" : {
		"FID" : 2872,
		"name" : "忠观公园",
		"lng" : 119.217804,
		"lat" : 25.981914
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2873,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21736408810139,
		  25.974592875225529
		]
	  },
	  "properties" : {
		"FID" : 2873,
		"name" : "上井林氏宗祠",
		"lng" : 119.22213600000001,
		"lat" : 25.971536
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2874,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23347644492402,
		  25.954168556258217
		]
	  },
	  "properties" : {
		"FID" : 2874,
		"name" : "唐氏宗祠",
		"lng" : 119.23823299999999,
		"lat" : 25.951114
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2875,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21479350686735,
		  25.981330811019895
		]
	  },
	  "properties" : {
		"FID" : 2875,
		"name" : "基督教南屿堂",
		"lng" : 119.21956900000001,
		"lat" : 25.978272
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2876,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.07488454369637,
		  25.888371652777192
		]
	  },
	  "properties" : {
		"FID" : 2876,
		"name" : "普光明寺",
		"lng" : 119.07982800000001,
		"lat" : 25.885535000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2877,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22485099795392,
		  25.863171609475565
		]
	  },
	  "properties" : {
		"FID" : 2877,
		"name" : "知音瀑布",
		"lng" : 119.229607,
		"lat" : 25.860182999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2878,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17711880671884,
		  25.987499206205435
		]
	  },
	  "properties" : {
		"FID" : 2878,
		"name" : "李先才纪念碑",
		"lng" : 119.18196,
		"lat" : 25.984494000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2879,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27446058487297,
		  26.003690733211691
		]
	  },
	  "properties" : {
		"FID" : 2879,
		"name" : "严复墓(不对外开放)",
		"lng" : 119.27923199999999,
		"lat" : 26.000616000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2880,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22220448937844,
		  25.890710656289887
		]
	  },
	  "properties" : {
		"FID" : 2880,
		"name" : "石风帆",
		"lng" : 119.22696500000001,
		"lat" : 25.887706000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2881,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26109114785814,
		  26.021762212038844
		]
	  },
	  "properties" : {
		"FID" : 2881,
		"name" : "劳动者公园",
		"lng" : 119.26585300000001,
		"lat" : 26.018664000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2882,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25870212642286,
		  25.958117185504172
		]
	  },
	  "properties" : {
		"FID" : 2882,
		"name" : "白岩云天宫",
		"lng" : 119.263458,
		"lat" : 25.955061000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2883,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21562481681784,
		  25.977442041516465
		]
	  },
	  "properties" : {
		"FID" : 2883,
		"name" : "南屿镇闽侯县泰山堂",
		"lng" : 119.220399,
		"lat" : 25.974385000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2884,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22900028376631,
		  25.998626556571786
		]
	  },
	  "properties" : {
		"FID" : 2884,
		"name" : "关西杨氏宗祠",
		"lng" : 119.233763,
		"lat" : 25.995543999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2885,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.238934196092,
		  26.030168123792862
		]
	  },
	  "properties" : {
		"FID" : 2885,
		"name" : "乌龙江湿地公园",
		"lng" : 119.243694,
		"lat" : 26.027059999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2886,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26721692585171,
		  26.022287207293491
		]
	  },
	  "properties" : {
		"FID" : 2886,
		"name" : "福州市飞凤山奥体公园(2期)",
		"lng" : 119.27198300000001,
		"lat" : 26.019193000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2887,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.18978784414601,
		  26.002910231647601
		]
	  },
	  "properties" : {
		"FID" : 2887,
		"name" : "棋盘石景区",
		"lng" : 119.194605,
		"lat" : 25.999872
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2888,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20859232912235,
		  25.992813396821251
		]
	  },
	  "properties" : {
		"FID" : 2888,
		"name" : "旗山万佛寺",
		"lng" : 119.21337699999999,
		"lat" : 25.989754000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2889,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22382390760272,
		  25.973186647330085
		]
	  },
	  "properties" : {
		"FID" : 2889,
		"name" : "水西林氏家庙",
		"lng" : 119.228589,
		"lat" : 25.970124999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2890,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3004881244658,
		  25.991023171035863
		]
	  },
	  "properties" : {
		"FID" : 2890,
		"name" : "峬山禅寺",
		"lng" : 119.305296,
		"lat" : 25.987994
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2891,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29761083200454,
		  25.994275244896592
		]
	  },
	  "properties" : {
		"FID" : 2891,
		"name" : "行乐宫",
		"lng" : 119.302414,
		"lat" : 25.991239
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2892,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20063502369403,
		  25.978656870361913
		]
	  },
	  "properties" : {
		"FID" : 2892,
		"name" : "安源禅寺",
		"lng" : 119.205431,
		"lat" : 25.975618000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2893,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23760547835765,
		  25.97968040568913
		]
	  },
	  "properties" : {
		"FID" : 2893,
		"name" : "兴隆寺",
		"lng" : 119.242362,
		"lat" : 25.976607000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2894,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24773569165794,
		  25.947244206804381
		]
	  },
	  "properties" : {
		"FID" : 2894,
		"name" : "洲头村文化广场",
		"lng" : 119.252488,
		"lat" : 25.944192000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2895,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24737744615469,
		  25.937189422862872
		]
	  },
	  "properties" : {
		"FID" : 2895,
		"name" : "陈壁故居",
		"lng" : 119.252129,
		"lat" : 25.934144
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2896,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21364059989995,
		  25.987421705990926
		]
	  },
	  "properties" : {
		"FID" : 2896,
		"name" : "福田泰山祖殿",
		"lng" : 119.218418,
		"lat" : 25.984359999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2897,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29352586933101,
		  26.003685277896455
		]
	  },
	  "properties" : {
		"FID" : 2897,
		"name" : "李氏宗祠",
		"lng" : 119.298323,
		"lat" : 26.000636
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2898,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29379735025758,
		  26.004782596337407
		]
	  },
	  "properties" : {
		"FID" : 2898,
		"name" : "林氏支祠",
		"lng" : 119.29859500000001,
		"lat" : 26.001733000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2899,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26874975527846,
		  26.020996033483328
		]
	  },
	  "properties" : {
		"FID" : 2899,
		"name" : "飞凤山休闲步道",
		"lng" : 119.273517,
		"lat" : 26.017904000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2900,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29618236248596,
		  26.019178556516184
		]
	  },
	  "properties" : {
		"FID" : 2900,
		"name" : "齐安圣王庙",
		"lng" : 119.300985,
		"lat" : 26.016123
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2901,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.01438512958238,
		  25.824993966141317
		]
	  },
	  "properties" : {
		"FID" : 2901,
		"name" : "天门山-景山寺",
		"lng" : 119.01918499999999,
		"lat" : 25.822077
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2902,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.04310145683804,
		  25.957977412494841
		]
	  },
	  "properties" : {
		"FID" : 2902,
		"name" : "和城寨",
		"lng" : 119.047995,
		"lat" : 25.955045999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2903,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24303640260445,
		  26.040983067744357
		]
	  },
	  "properties" : {
		"FID" : 2903,
		"name" : "金山公园",
		"lng" : 119.24779599999999,
		"lat" : 26.037866999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2904,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27763651103371,
		  25.997675108121019
		]
	  },
	  "properties" : {
		"FID" : 2904,
		"name" : "玉屏山庄",
		"lng" : 119.282411,
		"lat" : 25.994607999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2905,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17504748896253,
		  25.988005712219906
		]
	  },
	  "properties" : {
		"FID" : 2905,
		"name" : "旗山文化长廊",
		"lng" : 119.17989300000001,
		"lat" : 25.985004
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2906,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25381641321063,
		  25.93848493028386
		]
	  },
	  "properties" : {
		"FID" : 2906,
		"name" : "南通基督教堂",
		"lng" : 119.25856899999999,
		"lat" : 25.93544
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2907,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33234870866256,
		  25.953135023259669
		]
	  },
	  "properties" : {
		"FID" : 2907,
		"name" : "云天宫",
		"lng" : 119.337214,
		"lat" : 25.950191
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2908,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24247251939073,
		  25.9709083351792
		]
	  },
	  "properties" : {
		"FID" : 2908,
		"name" : "镜江公园",
		"lng" : 119.247227,
		"lat" : 25.967839999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2909,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.16562576943896,
		  26.001869469751583
		]
	  },
	  "properties" : {
		"FID" : 2909,
		"name" : "旗山旗云谷",
		"lng" : 119.170492,
		"lat" : 25.998875999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2910,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.07824248116319,
		  25.88950389438352
		]
	  },
	  "properties" : {
		"FID" : 2910,
		"name" : "卢公祖师堂",
		"lng" : 119.083189,
		"lat" : 25.886669000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2911,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26286194612973,
		  26.023635360704223
		]
	  },
	  "properties" : {
		"FID" : 2911,
		"name" : "玉封白府衙",
		"lng" : 119.267625,
		"lat" : 26.020537000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2912,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20809093962581,
		  26.028546088630026
		]
	  },
	  "properties" : {
		"FID" : 2912,
		"name" : "福建师范大学-星雨湖",
		"lng" : 119.212879,
		"lat" : 26.025462999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2913,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27137346948571,
		  26.03330198055929
		]
	  },
	  "properties" : {
		"FID" : 2913,
		"name" : "浦上林氏祠堂",
		"lng" : 119.276144,
		"lat" : 26.030204000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2914,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27105922681706,
		  25.97352358368698
		]
	  },
	  "properties" : {
		"FID" : 2914,
		"name" : "岐山古迹",
		"lng" : 119.275825,
		"lat" : 25.970465999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2915,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21254012263202,
		  26.001507071825291
		]
	  },
	  "properties" : {
		"FID" : 2915,
		"name" : "龙安禅寺",
		"lng" : 119.21732,
		"lat" : 25.998436999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2916,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2703925399979,
		  26.017813391874569
		]
	  },
	  "properties" : {
		"FID" : 2916,
		"name" : "王氏宗祠",
		"lng" : 119.275161,
		"lat" : 26.014724999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2917,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26153882108063,
		  26.022697574086685
		]
	  },
	  "properties" : {
		"FID" : 2917,
		"name" : "锦江陈理真君",
		"lng" : 119.266301,
		"lat" : 26.019598999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2918,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29474610338049,
		  26.040871589190346
		]
	  },
	  "properties" : {
		"FID" : 2918,
		"name" : "福州市上渡基督教堂",
		"lng" : 119.299548,
		"lat" : 26.037799
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2919,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.08968336470551,
		  25.839923794260432
		]
	  },
	  "properties" : {
		"FID" : 2919,
		"name" : "乐峰赤壁景区",
		"lng" : 119.094632,
		"lat" : 25.837126000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2920,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30952942244173,
		  25.941414295684933
		]
	  },
	  "properties" : {
		"FID" : 2920,
		"name" : "九仙观",
		"lng" : 119.31435,
		"lat" : 25.938434999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2921,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30449143910684,
		  26.01173329223273
		]
	  },
	  "properties" : {
		"FID" : 2921,
		"name" : "鹤巢寺",
		"lng" : 119.309308,
		"lat" : 26.008697000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2922,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22010663914628,
		  25.981081903922167
		]
	  },
	  "properties" : {
		"FID" : 2922,
		"name" : "水西林建筑群",
		"lng" : 119.22487599999999,
		"lat" : 25.978017999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2923,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30449143910684,
		  26.01173329223273
		]
	  },
	  "properties" : {
		"FID" : 2923,
		"name" : "鹤巢寺",
		"lng" : 119.309308,
		"lat" : 26.008697000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2924,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26183921911151,
		  25.974722700328702
		]
	  },
	  "properties" : {
		"FID" : 2924,
		"name" : "砂之船奥莱1号广场",
		"lng" : 119.266598,
		"lat" : 25.971657
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2925,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24256980670249,
		  25.98073604528135
		]
	  },
	  "properties" : {
		"FID" : 2925,
		"name" : "高速花博园",
		"lng" : 119.247325,
		"lat" : 25.977661000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2926,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3148787378982,
		  26.014859326828482
		]
	  },
	  "properties" : {
		"FID" : 2926,
		"name" : "高盖五台山文殊寺",
		"lng" : 119.319715,
		"lat" : 26.011839999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2927,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29779751663665,
		  26.034238111892499
		]
	  },
	  "properties" : {
		"FID" : 2927,
		"name" : "白泉庵",
		"lng" : 119.302604,
		"lat" : 26.031175000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2928,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32681851424539,
		  25.923537470459081
		]
	  },
	  "properties" : {
		"FID" : 2928,
		"name" : "五虎岩佛寺",
		"lng" : 119.331671,
		"lat" : 25.920603
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2929,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21845071690436,
		  26.009590801071361
		]
	  },
	  "properties" : {
		"FID" : 2929,
		"name" : "高岐河智慧体育公园",
		"lng" : 119.223224,
		"lat" : 26.006509000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2930,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20001871218541,
		  25.99586169863813
		]
	  },
	  "properties" : {
		"FID" : 2930,
		"name" : "翠旗衍秀",
		"lng" : 119.20481700000001,
		"lat" : 25.992812000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2931,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.9639894760206,
		  25.868220934338652
		]
	  },
	  "properties" : {
		"FID" : 2931,
		"name" : "法治公园",
		"lng" : 118.96862400000001,
		"lat" : 25.865127999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2932,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22666540831679,
		  25.972759426523041
		]
	  },
	  "properties" : {
		"FID" : 2932,
		"name" : "大王庙水泥埕",
		"lng" : 119.23142799999999,
		"lat" : 25.969695999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2933,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21934688965239,
		  25.980216617319446
		]
	  },
	  "properties" : {
		"FID" : 2933,
		"name" : "水西林氏宗祠",
		"lng" : 119.22411700000001,
		"lat" : 25.977153999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2934,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21984327823121,
		  25.982172408550401
		]
	  },
	  "properties" : {
		"FID" : 2934,
		"name" : "焦府行宫",
		"lng" : 119.22461300000001,
		"lat" : 25.979108
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2935,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19434547335892,
		  26.040617362986815
		]
	  },
	  "properties" : {
		"FID" : 2935,
		"name" : "旗山湖公园",
		"lng" : 119.199157,
		"lat" : 26.037545999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2936,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26615883927491,
		  26.021087239660396
		]
	  },
	  "properties" : {
		"FID" : 2936,
		"name" : "飞凤山奥体主题公园",
		"lng" : 119.27092399999999,
		"lat" : 26.017993000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2937,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28293526591412,
		  25.992936319730326
		]
	  },
	  "properties" : {
		"FID" : 2937,
		"name" : "白马王庙",
		"lng" : 119.287716,
		"lat" : 25.989878999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2938,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29416917463898,
		  26.039109319511628
		]
	  },
	  "properties" : {
		"FID" : 2938,
		"name" : "天主堂",
		"lng" : 119.29897,
		"lat" : 26.036037
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2939,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26481439225732,
		  26.026896205653767
		]
	  },
	  "properties" : {
		"FID" : 2939,
		"name" : "山海恒达标本观光工厂",
		"lng" : 119.26957899999999,
		"lat" : 26.023796999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2940,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27685230346364,
		  25.999128998746908
		]
	  },
	  "properties" : {
		"FID" : 2940,
		"name" : "阳岐-严复故里",
		"lng" : 119.281626,
		"lat" : 25.99606
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2941,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24669752978552,
		  26.030183769313375
		]
	  },
	  "properties" : {
		"FID" : 2941,
		"name" : "建新基督教堂",
		"lng" : 119.251456,
		"lat" : 26.027075
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2942,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25233524196034,
		  25.932236154315742
		]
	  },
	  "properties" : {
		"FID" : 2942,
		"name" : "盛丰亭",
		"lng" : 119.257087,
		"lat" : 25.929195
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2943,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.1823181723805,
		  26.030447927396121
		]
	  },
	  "properties" : {
		"FID" : 2943,
		"name" : "宝积寺",
		"lng" : 119.187152,
		"lat" : 26.027404000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2944,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25122528955453,
		  25.934489964841287
		]
	  },
	  "properties" : {
		"FID" : 2944,
		"name" : "潘氏宗祠",
		"lng" : 119.255977,
		"lat" : 25.931446999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2945,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.20795929749687,
		  25.9943496419132
		]
	  },
	  "properties" : {
		"FID" : 2945,
		"name" : "旗山万佛寺-大雄宝殿",
		"lng" : 119.212745,
		"lat" : 25.991289999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2946,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2314649180247,
		  25.972213900848896
		]
	  },
	  "properties" : {
		"FID" : 2946,
		"name" : "乡贤宋公祠",
		"lng" : 119.23622400000001,
		"lat" : 25.969148000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2947,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3239907019037,
		  25.927263389312824
		]
	  },
	  "properties" : {
		"FID" : 2947,
		"name" : "正吉寺",
		"lng" : 119.328838,
		"lat" : 25.924320999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2948,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33729939111741,
		  25.901295849209422
		]
	  },
	  "properties" : {
		"FID" : 2948,
		"name" : "闽侯兴福禅寺",
		"lng" : 119.34217,
		"lat" : 25.898396000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2949,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30792081556328,
		  25.842710817230472
		]
	  },
	  "properties" : {
		"FID" : 2949,
		"name" : "福海禅寺",
		"lng" : 119.312731,
		"lat" : 25.839794000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2950,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26088183050938,
		  25.973910733008204
		]
	  },
	  "properties" : {
		"FID" : 2950,
		"name" : "瑞吉蹦床公园",
		"lng" : 119.26564,
		"lat" : 25.970845000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2951,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27176875395018,
		  25.917113649242982
		]
	  },
	  "properties" : {
		"FID" : 2951,
		"name" : "五显殿",
		"lng" : 119.27653100000001,
		"lat" : 25.914095
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2952,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23618801080659,
		  25.924239314426803
		]
	  },
	  "properties" : {
		"FID" : 2952,
		"name" : "招盛自然村龙舟厝",
		"lng" : 119.24094100000001,
		"lat" : 25.921203999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2953,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30293820580971,
		  25.825151551871759
		]
	  },
	  "properties" : {
		"FID" : 2953,
		"name" : "洪氏宗祠",
		"lng" : 119.307738,
		"lat" : 25.822237000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2954,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30120231936247,
		  26.03832710514607
		]
	  },
	  "properties" : {
		"FID" : 2954,
		"name" : "长安山公园",
		"lng" : 119.306015,
		"lat" : 26.035267000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2955,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2750998702889,
		  26.004126345800383
		]
	  },
	  "properties" : {
		"FID" : 2955,
		"name" : "严复公园",
		"lng" : 119.279872,
		"lat" : 26.001052000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2956,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37170888574224,
		  25.994489463985367
		]
	  },
	  "properties" : {
		"FID" : 2956,
		"name" : "春伦茶",
		"lng" : 119.376636,
		"lat" : 25.991578000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2957,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.38592882942723,
		  25.937450808592718
		]
	  },
	  "properties" : {
		"FID" : 2957,
		"name" : "祥谦陵园",
		"lng" : 119.39086,
		"lat" : 25.934588999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2958,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21711117308489,
		  25.982953325134183
		]
	  },
	  "properties" : {
		"FID" : 2958,
		"name" : "寿轩黄公祠",
		"lng" : 119.221884,
		"lat" : 25.979890999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2959,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24768566956556,
		  25.947560426718095
		]
	  },
	  "properties" : {
		"FID" : 2959,
		"name" : "洲头瀛洲泰山祖殿",
		"lng" : 119.252438,
		"lat" : 25.944507999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2960,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27861698440424,
		  26.016035461459669
		]
	  },
	  "properties" : {
		"FID" : 2960,
		"name" : "台屿河公园",
		"lng" : 119.283394,
		"lat" : 26.012957
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2961,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29869999203621,
		  25.900573945160794
		]
	  },
	  "properties" : {
		"FID" : 2961,
		"name" : "鱼山宫",
		"lng" : 119.303498,
		"lat" : 25.897603
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2962,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2682644663753,
		  26.003564589072869
		]
	  },
	  "properties" : {
		"FID" : 2962,
		"name" : "湾边天主堂",
		"lng" : 119.27303000000001,
		"lat" : 26.000484
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2963,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.00977877628863,
		  25.820268457136905
		]
	  },
	  "properties" : {
		"FID" : 2963,
		"name" : "望夫岩五指峰观景台",
		"lng" : 119.014563,
		"lat" : 25.817340999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2964,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.00411812140932,
		  25.818105994469594
		]
	  },
	  "properties" : {
		"FID" : 2964,
		"name" : "天门湖",
		"lng" : 119.008883,
		"lat" : 25.815162999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2965,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.23131643382771,
		  26.004354743580237
		]
	  },
	  "properties" : {
		"FID" : 2965,
		"name" : "三聖王庙",
		"lng" : 119.23607800000001,
		"lat" : 26.001266999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2966,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26700880515384,
		  25.918728986441639
		]
	  },
	  "properties" : {
		"FID" : 2966,
		"name" : "瓜山村厚里境",
		"lng" : 119.271767,
		"lat" : 25.915704999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2967,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19121061979007,
		  26.028382948773373
		]
	  },
	  "properties" : {
		"FID" : 2967,
		"name" : "蔗洲元帅宫",
		"lng" : 119.196027,
		"lat" : 26.025324999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2968,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26012522090387,
		  25.974176353890165
		]
	  },
	  "properties" : {
		"FID" : 2968,
		"name" : "2号广场",
		"lng" : 119.264883,
		"lat" : 25.971109999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2969,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32204197392129,
		  26.000362825133159
		]
	  },
	  "properties" : {
		"FID" : 2969,
		"name" : "义序基督教堂",
		"lng" : 119.326891,
		"lat" : 25.997367000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2970,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.33727151017472,
		  25.873859722528866
		]
	  },
	  "properties" : {
		"FID" : 2970,
		"name" : "双龙禅寺",
		"lng" : 119.34214,
		"lat" : 25.870978000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2971,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25554119935492,
		  25.934148362266818
		]
	  },
	  "properties" : {
		"FID" : 2971,
		"name" : "瑞安亭",
		"lng" : 119.260294,
		"lat" : 25.931107000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2972,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.07828144807165,
		  25.889528884837514
		]
	  },
	  "properties" : {
		"FID" : 2972,
		"name" : "地藏寺",
		"lng" : 119.08322800000001,
		"lat" : 25.886693999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2973,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30711328461368,
		  26.016441790159188
		]
	  },
	  "properties" : {
		"FID" : 2973,
		"name" : "高盖山妙峰寺",
		"lng" : 119.31193500000001,
		"lat" : 26.013407000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2974,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31024916725121,
		  26.019947434240034
		]
	  },
	  "properties" : {
		"FID" : 2974,
		"name" : "普照寺",
		"lng" : 119.315077,
		"lat" : 26.016915999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2975,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25968239194555,
		  25.974964138710291
		]
	  },
	  "properties" : {
		"FID" : 2975,
		"name" : "6号广场",
		"lng" : 119.26443999999999,
		"lat" : 25.971896999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2976,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96886738847445,
		  25.855220297446614
		]
	  },
	  "properties" : {
		"FID" : 2976,
		"name" : "永泰章氏宗祠",
		"lng" : 118.973516,
		"lat" : 25.852149000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2977,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2496536609446,
		  26.039966035203317
		]
	  },
	  "properties" : {
		"FID" : 2977,
		"name" : "上元村15号",
		"lng" : 119.254413,
		"lat" : 26.036850999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2978,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21723886183042,
		  26.029406088098405
		]
	  },
	  "properties" : {
		"FID" : 2978,
		"name" : "将军府",
		"lng" : 119.222015,
		"lat" : 26.026312000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2979,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26942005894541,
		  26.022540490764044
		]
	  },
	  "properties" : {
		"FID" : 2979,
		"name" : "飞凤山奥体主题公园-音乐喷泉",
		"lng" : 119.274188,
		"lat" : 26.019448000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2980,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30057275930889,
		  25.993917999714895
		]
	  },
	  "properties" : {
		"FID" : 2980,
		"name" : "道教福州市九门局九仙宫",
		"lng" : 119.305381,
		"lat" : 25.990887000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2981,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27497546075422,
		  25.998010311743439
		]
	  },
	  "properties" : {
		"FID" : 2981,
		"name" : "福州阳岐严复纪念馆",
		"lng" : 119.279747,
		"lat" : 25.99494
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2982,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.31921971386851,
		  25.837179119840091
		]
	  },
	  "properties" : {
		"FID" : 2982,
		"name" : "白马寺",
		"lng" : 119.324051,
		"lat" : 25.834287
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2983,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32152922617576,
		  26.023463524989715
		]
	  },
	  "properties" : {
		"FID" : 2983,
		"name" : "王氏宗祠",
		"lng" : 119.326379,
		"lat" : 26.020451000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2984,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27932734019723,
		  25.999822568950226
		]
	  },
	  "properties" : {
		"FID" : 2984,
		"name" : "伽仕公祖殿",
		"lng" : 119.284104,
		"lat" : 25.996756000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2985,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.28835437495924,
		  26.03676760908337
		]
	  },
	  "properties" : {
		"FID" : 2985,
		"name" : "新亭尚书庙",
		"lng" : 119.29314599999999,
		"lat" : 26.033688000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2986,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22474481942346,
		  25.972131629913196
		]
	  },
	  "properties" : {
		"FID" : 2986,
		"name" : "榕屿强氏宗祠",
		"lng" : 119.22950899999999,
		"lat" : 25.969069999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2987,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.07644570962398,
		  25.880167994224347
		]
	  },
	  "properties" : {
		"FID" : 2987,
		"name" : "葛岭1958米谷文创园",
		"lng" : 119.08139,
		"lat" : 25.877338000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2988,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26176871861504,
		  26.022261134332435
		]
	  },
	  "properties" : {
		"FID" : 2988,
		"name" : "劳动者公园-凉亭",
		"lng" : 119.266531,
		"lat" : 26.019162999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2989,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25368623995108,
		  26.021933786337527
		]
	  },
	  "properties" : {
		"FID" : 2989,
		"name" : "兴洲境三圣王庙第一行宫",
		"lng" : 119.25844499999999,
		"lat" : 26.018832
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2990,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.35797110936673,
		  26.000716793495119
		]
	  },
	  "properties" : {
		"FID" : 2990,
		"name" : "福州市城门三清道观",
		"lng" : 119.362883,
		"lat" : 25.997783999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2991,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29987194933443,
		  26.020980623739785
		]
	  },
	  "properties" : {
		"FID" : 2991,
		"name" : "福州市仓山区高盖山观音寺",
		"lng" : 119.304681,
		"lat" : 26.01793
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2992,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29508343603332,
		  26.015749007254975
		]
	  },
	  "properties" : {
		"FID" : 2992,
		"name" : "天王寺",
		"lng" : 119.29988400000001,
		"lat" : 26.012694
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2993,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30751209050796,
		  26.035792198503238
		]
	  },
	  "properties" : {
		"FID" : 2993,
		"name" : "施埔将军庙",
		"lng" : 119.312336,
		"lat" : 26.032744999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2994,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19863408907516,
		  26.039757470741353
		]
	  },
	  "properties" : {
		"FID" : 2994,
		"name" : "童梦奇境-旗山湖公园",
		"lng" : 119.20343800000001,
		"lat" : 26.03668
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2995,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22747238891881,
		  26.022016530883082
		]
	  },
	  "properties" : {
		"FID" : 2995,
		"name" : "朱仙姑道院",
		"lng" : 119.232238,
		"lat" : 26.018919
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2996,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2537402278531,
		  26.021898744681472
		]
	  },
	  "properties" : {
		"FID" : 2996,
		"name" : "福州道教兴洲三圣宫",
		"lng" : 119.258499,
		"lat" : 26.018796999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2997,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.40923893670313,
		  26.03996288269893
		]
	  },
	  "properties" : {
		"FID" : 2997,
		"name" : "龙泉寺",
		"lng" : 119.414171,
		"lat" : 26.037030999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2998,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21291478022728,
		  25.985837811277381
		]
	  },
	  "properties" : {
		"FID" : 2998,
		"name" : "翠旗名山",
		"lng" : 119.217693,
		"lat" : 25.982778
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 2999,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24475872497703,
		  25.94551617673725
		]
	  },
	  "properties" : {
		"FID" : 2999,
		"name" : "道山林氏支祠",
		"lng" : 119.249511,
		"lat" : 25.942464999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3000,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.2402790037205,
		  25.97102911774823
		]
	  },
	  "properties" : {
		"FID" : 3000,
		"name" : "崇兴亭",
		"lng" : 119.245034,
		"lat" : 25.967960999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3001,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.36953000916746,
		  25.927452197876864
		]
	  },
	  "properties" : {
		"FID" : 3001,
		"name" : "尚干林氏祠堂",
		"lng" : 119.37445,
		"lat" : 25.924583999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3002,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29163668592776,
		  26.006031817516575
		]
	  },
	  "properties" : {
		"FID" : 3002,
		"name" : "劝善庵",
		"lng" : 119.296431,
		"lat" : 26.002977999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3003,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22945334615511,
		  25.961806717648006
		]
	  },
	  "properties" : {
		"FID" : 3003,
		"name" : "剑津李氏祠堂",
		"lng" : 119.234213,
		"lat" : 25.958749000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3004,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.27208149123396,
		  25.997106676827414
		]
	  },
	  "properties" : {
		"FID" : 3004,
		"name" : "尚书祖庙",
		"lng" : 119.27685,
		"lat" : 25.994033999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3005,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19622389508058,
		  26.039773770458723
		]
	  },
	  "properties" : {
		"FID" : 3005,
		"name" : "旗山湖公园27号古厝",
		"lng" : 119.201032,
		"lat" : 26.0367
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3006,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26830051098641,
		  26.002561874943126
		]
	  },
	  "properties" : {
		"FID" : 3006,
		"name" : "西安境玄帝庙",
		"lng" : 119.273066,
		"lat" : 25.999482
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3007,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.24669037610484,
		  26.032245167452125
		]
	  },
	  "properties" : {
		"FID" : 3007,
		"name" : "三圣王祖殿",
		"lng" : 119.25144899999999,
		"lat" : 26.029135
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3008,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.19554489342872,
		  26.037051860191749
		]
	  },
	  "properties" : {
		"FID" : 3008,
		"name" : "太清宫",
		"lng" : 119.200354,
		"lat" : 26.033981000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3009,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26774348548172,
		  25.915092935578418
		]
	  },
	  "properties" : {
		"FID" : 3009,
		"name" : "仙里宫(闽南港四十八都仙里境)",
		"lng" : 119.272502,
		"lat" : 25.912071999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3010,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.17786234067347,
		  26.040795831423562
		]
	  },
	  "properties" : {
		"FID" : 3010,
		"name" : "岐头白马王庙",
		"lng" : 119.182706,
		"lat" : 26.037752999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3011,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26477054240247,
		  25.91787314084166
		]
	  },
	  "properties" : {
		"FID" : 3011,
		"name" : "新安汪氏宗祠",
		"lng" : 119.269527,
		"lat" : 25.914847999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3012,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.21816215545962,
		  26.012783697273502
		]
	  },
	  "properties" : {
		"FID" : 3012,
		"name" : "三盛托斯卡纳滨河公园",
		"lng" : 119.222936,
		"lat" : 26.009699999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3013,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.26650834627951,
		  25.943593193036453
		]
	  },
	  "properties" : {
		"FID" : 3013,
		"name" : "泽江张氏宗祠",
		"lng" : 119.27126800000001,
		"lat" : 25.940552
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3014,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.37437376568371,
		  26.032466690233768
		]
	  },
	  "properties" : {
		"FID" : 3014,
		"name" : "魁峰境将军庙",
		"lng" : 119.379306,
		"lat" : 26.029532
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3015,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.25039352561176,
		  25.946502291235841
		]
	  },
	  "properties" : {
		"FID" : 3015,
		"name" : "黄觉民故居",
		"lng" : 119.255146,
		"lat" : 25.943451
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3016,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.3545690833557,
		  25.893452241980114
		]
	  },
	  "properties" : {
		"FID" : 3016,
		"name" : "宏山寺",
		"lng" : 119.35946800000001,
		"lat" : 25.890587
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3017,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.32361667678126,
		  25.923940863735147
		]
	  },
	  "properties" : {
		"FID" : 3017,
		"name" : "五虎山紫云宫",
		"lng" : 119.328463,
		"lat" : 25.920999999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3018,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.30050987307612,
		  26.020509213553417
		]
	  },
	  "properties" : {
		"FID" : 3018,
		"name" : "齐安村临水宫",
		"lng" : 119.30531999999999,
		"lat" : 26.01746
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3019,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29452507739531,
		  26.006032289470124
		]
	  },
	  "properties" : {
		"FID" : 3019,
		"name" : "探花府",
		"lng" : 119.299324,
		"lat" : 26.002983
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3020,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.29652865497849,
		  26.02090916585172
		]
	  },
	  "properties" : {
		"FID" : 3020,
		"name" : "齐氏宗祠",
		"lng" : 119.301332,
		"lat" : 26.017852999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3021,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.22229748023015,
		  26.01319169490824
		]
	  },
	  "properties" : {
		"FID" : 3021,
		"name" : "福州清华紫光科技园-海峡广场",
		"lng" : 119.22706700000001,
		"lat" : 26.010103999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3022,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.56973032637819,
		  25.872525724810163
		]
	  },
	  "properties" : {
		"FID" : 3022,
		"name" : "永泰能仁禅寺",
		"lng" : 118.574259,
		"lat" : 25.869344000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3023,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58480699111976,
		  25.800517528197101
		]
	  },
	  "properties" : {
		"FID" : 3023,
		"name" : "嵩口古镇",
		"lng" : 118.58931699999999,
		"lat" : 25.797370999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3024,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58594705419426,
		  25.807414190178338
		]
	  },
	  "properties" : {
		"FID" : 3024,
		"name" : "天后宫",
		"lng" : 118.590457,
		"lat" : 25.804262999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3025,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58528467184877,
		  25.80837056009981
		]
	  },
	  "properties" : {
		"FID" : 3025,
		"name" : "古榕树",
		"lng" : 118.589795,
		"lat" : 25.805219000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3026,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.57009277553591,
		  25.872671197874144
		]
	  },
	  "properties" : {
		"FID" : 3026,
		"name" : "永泰县磬扬法师纪念馆",
		"lng" : 118.57462099999999,
		"lat" : 25.869489000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3027,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58353382426026,
		  25.807110090629447
		]
	  },
	  "properties" : {
		"FID" : 3027,
		"name" : "龙口祖厝",
		"lng" : 118.58804499999999,
		"lat" : 25.80396
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3028,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.5830317447129,
		  25.804051973951207
		]
	  },
	  "properties" : {
		"FID" : 3028,
		"name" : "方家里厝",
		"lng" : 118.587543,
		"lat" : 25.800903999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3029,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58358085703352,
		  25.807032062471308
		]
	  },
	  "properties" : {
		"FID" : 3029,
		"name" : "和也厝",
		"lng" : 118.588092,
		"lat" : 25.803882000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3030,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.5853086929009,
		  25.808240487757917
		]
	  },
	  "properties" : {
		"FID" : 3030,
		"name" : "嵩口古镇古榕广场",
		"lng" : 118.58981900000001,
		"lat" : 25.805088999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3031,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58423026621303,
		  25.80640194115038
		]
	  },
	  "properties" : {
		"FID" : 3031,
		"name" : "鹤形路",
		"lng" : 118.588741,
		"lat" : 25.803252000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3032,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58316662985638,
		  25.806802738421268
		]
	  },
	  "properties" : {
		"FID" : 3032,
		"name" : "封火墙",
		"lng" : 118.587678,
		"lat" : 25.803653000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3033,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58361900467077,
		  25.80526898605444
		]
	  },
	  "properties" : {
		"FID" : 3033,
		"name" : "嵩口乐善堂",
		"lng" : 118.58813000000001,
		"lat" : 25.802119999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3034,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58610528363027,
		  25.805201869338152
		]
	  },
	  "properties" : {
		"FID" : 3034,
		"name" : "嵩口关帝庙",
		"lng" : 118.590615,
		"lat" : 25.802052
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3035,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.61557691707395,
		  25.89682364384003
		]
	  },
	  "properties" : {
		"FID" : 3035,
		"name" : "仙妈殿",
		"lng" : 118.62010100000001,
		"lat" : 25.893623999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3036,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58372623100917,
		  25.802954600405393
		]
	  },
	  "properties" : {
		"FID" : 3036,
		"name" : "旺誉厝",
		"lng" : 118.58823700000001,
		"lat" : 25.799807000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3037,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58609327851487,
		  25.805197863058766
		]
	  },
	  "properties" : {
		"FID" : 3037,
		"name" : "关帝庙",
		"lng" : 118.590603,
		"lat" : 25.802047999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3038,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58436333957023,
		  25.806382982274865
		]
	  },
	  "properties" : {
		"FID" : 3038,
		"name" : "嵩口古镇杨氏宗祠",
		"lng" : 118.588874,
		"lat" : 25.803232999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3039,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58598014668289,
		  25.806328527430004
		]
	  },
	  "properties" : {
		"FID" : 3039,
		"name" : "嵩口林氏宗祠",
		"lng" : 118.59049,
		"lat" : 25.803177999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3040,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58397613434585,
		  25.806287767174904
		]
	  },
	  "properties" : {
		"FID" : 3040,
		"name" : "燕魁厝",
		"lng" : 118.588487,
		"lat" : 25.803138000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3041,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.62893887021303,
		  25.815240599178246
		]
	  },
	  "properties" : {
		"FID" : 3041,
		"name" : "张圣君诞生祖殿",
		"lng" : 118.633473,
		"lat" : 25.812109
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3042,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.62275905579563,
		  25.814985175405617
		]
	  },
	  "properties" : {
		"FID" : 3042,
		"name" : "宁远庄",
		"lng" : 118.627285,
		"lat" : 25.811845999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3043,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58536379904783,
		  25.807128816916528
		]
	  },
	  "properties" : {
		"FID" : 3043,
		"name" : "民俗博物馆",
		"lng" : 118.58987399999999,
		"lat" : 25.803978000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3044,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.62515703895482,
		  25.815067364308334
		]
	  },
	  "properties" : {
		"FID" : 3044,
		"name" : "张氏宗祠",
		"lng" : 118.62968600000001,
		"lat" : 25.811931000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3045,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58073077651825,
		  25.880302696712643
		]
	  },
	  "properties" : {
		"FID" : 3045,
		"name" : "吴氏宗祠",
		"lng" : 118.585249,
		"lat" : 25.877106999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3046,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58458544676611,
		  25.806537164354229
		]
	  },
	  "properties" : {
		"FID" : 3046,
		"name" : "前厅祖厝",
		"lng" : 118.589096,
		"lat" : 25.803387000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3047,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58332608172186,
		  25.80179170975428
		]
	  },
	  "properties" : {
		"FID" : 3047,
		"name" : "叶庆厝",
		"lng" : 118.58783699999999,
		"lat" : 25.798645
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3048,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.62512717487374,
		  25.813710552889276
		]
	  },
	  "properties" : {
		"FID" : 3048,
		"name" : "芦川小集",
		"lng" : 118.629656,
		"lat" : 25.810575
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3049,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58289578017877,
		  25.802392886757293
		]
	  },
	  "properties" : {
		"FID" : 3049,
		"name" : "下车碓厝",
		"lng" : 118.587407,
		"lat" : 25.799246
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3050,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.58094902702842,
		  25.920939956065567
		]
	  },
	  "properties" : {
		"FID" : 3050,
		"name" : "中埔寨",
		"lng" : 118.58547,
		"lat" : 25.917717
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3051,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.62503921633682,
		  25.814723293986177
		]
	  },
	  "properties" : {
		"FID" : 3051,
		"name" : "张元幹故居",
		"lng" : 118.62956800000001,
		"lat" : 25.811586999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3052,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.62529378232986,
		  25.81616688383831
		]
	  },
	  "properties" : {
		"FID" : 3052,
		"name" : "状元桥",
		"lng" : 118.629823,
		"lat" : 25.813030000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3053,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.57881281382923,
		  25.915045714621417
		]
	  },
	  "properties" : {
		"FID" : 3053,
		"name" : "牛童宫",
		"lng" : 118.58333500000001,
		"lat" : 25.911828
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3054,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.51482551111732,
		  25.79827719494256
		]
	  },
	  "properties" : {
		"FID" : 3054,
		"name" : "乌石寺",
		"lng" : 118.51948299999999,
		"lat" : 25.795256999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3055,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.61173554622785,
		  25.766007023824866
		]
	  },
	  "properties" : {
		"FID" : 3055,
		"name" : "观景平台",
		"lng" : 118.616247,
		"lat" : 25.762886999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3056,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.61283569657692,
		  25.765669959739871
		]
	  },
	  "properties" : {
		"FID" : 3056,
		"name" : "大喜水库",
		"lng" : 118.61734800000001,
		"lat" : 25.762550999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3057,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.68172873155501,
		  25.827964340612386
		]
	  },
	  "properties" : {
		"FID" : 3057,
		"name" : "天蛇孵蛋",
		"lng" : 118.686365,
		"lat" : 25.824918
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3058,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.66693826268087,
		  25.911317812508919
		]
	  },
	  "properties" : {
		"FID" : 3058,
		"name" : "谷贻堂",
		"lng" : 118.67155,
		"lat" : 25.908189
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3059,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.67594382158484,
		  25.782685083558185
		]
	  },
	  "properties" : {
		"FID" : 3059,
		"name" : "百漈沟生态景区",
		"lng" : 118.680565,
		"lat" : 25.779655999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3060,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.69033367818628,
		  25.92741046675436
		]
	  },
	  "properties" : {
		"FID" : 3060,
		"name" : "学士府",
		"lng" : 118.69499399999999,
		"lat" : 25.924313999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3061,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.69798891829377,
		  25.761916169214896
		]
	  },
	  "properties" : {
		"FID" : 3061,
		"name" : "小坪寨",
		"lng" : 118.702651,
		"lat" : 25.758938000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3062,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.59707303376811,
		  25.975383951867613
		]
	  },
	  "properties" : {
		"FID" : 3062,
		"name" : "绥福堂",
		"lng" : 118.60159299999999,
		"lat" : 25.972121000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3063,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.66640451084665,
		  25.909502616019711
		]
	  },
	  "properties" : {
		"FID" : 3063,
		"name" : "积善堂",
		"lng" : 118.671015,
		"lat" : 25.906374
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3064,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.73397972677422,
		  25.697780880738062
		]
	  },
	  "properties" : {
		"FID" : 3064,
		"name" : "教忠寺",
		"lng" : 118.738679,
		"lat" : 25.694876000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3065,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.72914334268185,
		  25.838952627383229
		]
	  },
	  "properties" : {
		"FID" : 3065,
		"name" : "凤凰寺",
		"lng" : 118.73385,
		"lat" : 25.835961999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3066,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.71732974516591,
		  25.955384699905192
		]
	  },
	  "properties" : {
		"FID" : 3066,
		"name" : "卢公殿景区",
		"lng" : 118.72203399999999,
		"lat" : 25.952307000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3067,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.69626878337142,
		  25.763671910375177
		]
	  },
	  "properties" : {
		"FID" : 3067,
		"name" : "演溪宫",
		"lng" : 118.700928,
		"lat" : 25.76069
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3068,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.72014564066741,
		  25.942132952067773
		]
	  },
	  "properties" : {
		"FID" : 3068,
		"name" : "福长五谷仙山景区",
		"lng" : 118.724852,
		"lat" : 25.939067000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3069,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.6611403119536,
		  25.925553463132083
		]
	  },
	  "properties" : {
		"FID" : 3069,
		"name" : "天泉禅寺",
		"lng" : 118.665741,
		"lat" : 25.922404
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3070,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.73030834181631,
		  25.96447351193202
		]
	  },
	  "properties" : {
		"FID" : 3070,
		"name" : "鹤顶岩璜溪仙境",
		"lng" : 118.73502499999999,
		"lat" : 25.961400000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3071,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.67664344171413,
		  25.946992452056371
		]
	  },
	  "properties" : {
		"FID" : 3071,
		"name" : "永泰仙亭寺",
		"lng" : 118.68127800000001,
		"lat" : 25.943857999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3072,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.70985017990019,
		  25.96987107185846
		]
	  },
	  "properties" : {
		"FID" : 3072,
		"name" : "明兰寨",
		"lng" : 118.714546,
		"lat" : 25.966774999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3073,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.5837265922551,
		  25.979766275965211
		]
	  },
	  "properties" : {
		"FID" : 3073,
		"name" : "香盖寺",
		"lng" : 118.58825,
		"lat" : 25.976502
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3074,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.703637399223,
		  25.956414206574298
		]
	  },
	  "properties" : {
		"FID" : 3074,
		"name" : "闽清县省璜佳垅玉峰社白马庙",
		"lng" : 118.70832299999999,
		"lat" : 25.953319
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3075,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.68994651537712,
		  25.939645411044214
		]
	  },
	  "properties" : {
		"FID" : 3075,
		"name" : "留芳庄",
		"lng" : 118.694607,
		"lat" : 25.936540000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3076,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.73300525546102,
		  25.711306563437976
		]
	  },
	  "properties" : {
		"FID" : 3076,
		"name" : "郑侨墓",
		"lng" : 118.73770500000001,
		"lat" : 25.708393999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3077,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.72401222446602,
		  25.991921543657671
		]
	  },
	  "properties" : {
		"FID" : 3077,
		"name" : "省璜镇革命斗争史迹陈列馆",
		"lng" : 118.72872599999999,
		"lat" : 25.988824999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3078,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.95402620092968,
		  26.003417027846844
		]
	  },
	  "properties" : {
		"FID" : 3078,
		"name" : "北山寨",
		"lng" : 118.958642,
		"lat" : 26.000208000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3079,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.92817063327922,
		  25.966731953288733
		]
	  },
	  "properties" : {
		"FID" : 3079,
		"name" : "永泰阴阳聖境",
		"lng" : 118.932727,
		"lat" : 25.963498999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3080,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.88591323700589,
		  25.995555186651185
		]
	  },
	  "properties" : {
		"FID" : 3080,
		"name" : "仁量麋鹿园&玫瑰谷",
		"lng" : 118.89044699999999,
		"lat" : 25.992284000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3081,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.8833630743119,
		  26.049553510324259
		]
	  },
	  "properties" : {
		"FID" : 3081,
		"name" : "姬岩风景区",
		"lng" : 118.887902,
		"lat" : 26.046247000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3082,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96124018422645,
		  26.052375435696653
		]
	  },
	  "properties" : {
		"FID" : 3082,
		"name" : "春光凤峰境",
		"lng" : 118.96588,
		"lat" : 26.049150999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3083,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.99556652881711,
		  26.007469965199107
		]
	  },
	  "properties" : {
		"FID" : 3083,
		"name" : "赤岸铳楼群",
		"lng" : 119.000316,
		"lat" : 26.004375
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3084,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86638235625963,
		  26.068771171001661
		]
	  },
	  "properties" : {
		"FID" : 3084,
		"name" : "白岩山",
		"lng" : 118.870938,
		"lat" : 26.065467000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3085,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.81995915296925,
		  25.962694730350943
		]
	  },
	  "properties" : {
		"FID" : 3085,
		"name" : "方壶岩",
		"lng" : 118.824589,
		"lat" : 25.959540000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3086,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.81972972218658,
		  25.962284018985756
		]
	  },
	  "properties" : {
		"FID" : 3086,
		"name" : "方壶寺",
		"lng" : 118.82436,
		"lat" : 25.959129999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3087,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.81066798799408,
		  26.013905408461767
		]
	  },
	  "properties" : {
		"FID" : 3087,
		"name" : "地藏寺",
		"lng" : 118.81532,
		"lat" : 26.010732999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3088,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.86594580126088,
		  26.068993798020575
		]
	  },
	  "properties" : {
		"FID" : 3088,
		"name" : "白岩寺",
		"lng" : 118.870502,
		"lat" : 26.06569
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3089,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.00742162392118,
		  26.036267705519684
		]
	  },
	  "properties" : {
		"FID" : 3089,
		"name" : "将军庙",
		"lng" : 119.012214,
		"lat" : 26.033189
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3090,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.98031948874205,
		  26.0661645997717
		]
	  },
	  "properties" : {
		"FID" : 3090,
		"name" : "三仙阁",
		"lng" : 118.985021,
		"lat" : 26.062984
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3091,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.03323942525226,
		  25.997037747783438
		]
	  },
	  "properties" : {
		"FID" : 3091,
		"name" : "灵龟公园",
		"lng" : 119.03811,
		"lat" : 25.994057000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3092,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.01503174285985,
		  25.949185097532599
		]
	  },
	  "properties" : {
		"FID" : 3092,
		"name" : "松仔山",
		"lng" : 119.01984299999999,
		"lat" : 25.946187999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3093,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.80245808312901,
		  25.991161335015306
		]
	  },
	  "properties" : {
		"FID" : 3093,
		"name" : "新丰革命老区基点村综合文化公园",
		"lng" : 118.807124,
		"lat" : 25.988019000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3094,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.04162585313189,
		  26.014261967623018
		]
	  },
	  "properties" : {
		"FID" : 3094,
		"name" : "天台寺",
		"lng" : 119.04652,
		"lat" : 26.011289000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3095,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.04310145683804,
		  25.957977412494841
		]
	  },
	  "properties" : {
		"FID" : 3095,
		"name" : "和城寨",
		"lng" : 119.047995,
		"lat" : 25.955045999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3096,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.01245780178172,
		  26.061735007389164
		]
	  },
	  "properties" : {
		"FID" : 3096,
		"name" : "夾竹境",
		"lng" : 119.017269,
		"lat" : 26.058654000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3097,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.77113033414543,
		  26.020105215044762
		]
	  },
	  "properties" : {
		"FID" : 3097,
		"name" : "冬畴寨",
		"lng" : 118.77584400000001,
		"lat" : 26.016985999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3098,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76848165665469,
		  25.927732983260764
		]
	  },
	  "properties" : {
		"FID" : 3098,
		"name" : "荣寿庄",
		"lng" : 118.773191,
		"lat" : 25.924679000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3099,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76867094887433,
		  25.926029992271609
		]
	  },
	  "properties" : {
		"FID" : 3099,
		"name" : "昇平庄",
		"lng" : 118.77338,
		"lat" : 25.922976999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3100,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76402609569263,
		  26.050254905920173
		]
	  },
	  "properties" : {
		"FID" : 3100,
		"name" : "仙娘庙",
		"lng" : 118.768748,
		"lat" : 26.047121000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3101,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76834687628995,
		  26.072735279426148
		]
	  },
	  "properties" : {
		"FID" : 3101,
		"name" : "梅寮影剧院",
		"lng" : 118.773067,
		"lat" : 26.069583000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3102,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76558308128762,
		  26.025430205522937
		]
	  },
	  "properties" : {
		"FID" : 3102,
		"name" : "闽清虎丘黄氏祖厝",
		"lng" : 118.770302,
		"lat" : 26.022311999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3103,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.78355354808573,
		  26.014165112155418
		]
	  },
	  "properties" : {
		"FID" : 3103,
		"name" : "七叠石界文化广场",
		"lng" : 118.788252,
		"lat" : 26.011036000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3104,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.73030834181631,
		  25.96447351193202
		]
	  },
	  "properties" : {
		"FID" : 3104,
		"name" : "鹤顶岩璜溪仙境",
		"lng" : 118.73502499999999,
		"lat" : 25.961400000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3105,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.7467615240617,
		  25.944321447308095
		]
	  },
	  "properties" : {
		"FID" : 3105,
		"name" : "冬坑宫",
		"lng" : 118.751482,
		"lat" : 25.941265999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3106,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76820048205583,
		  26.076346566280066
		]
	  },
	  "properties" : {
		"FID" : 3106,
		"name" : "闽清林氏宗祠(茶口)",
		"lng" : 118.772921,
		"lat" : 26.073191999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3107,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.77120738584821,
		  26.074754152199134
		]
	  },
	  "properties" : {
		"FID" : 3107,
		"name" : "航城公园",
		"lng" : 118.775925,
		"lat" : 26.071598000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3108,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.09198867550631,
		  25.975907272917773
		]
	  },
	  "properties" : {
		"FID" : 3108,
		"name" : "巫山中兴境",
		"lng" : 119.096948,
		"lat" : 25.973019000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3109,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.74837344253496,
		  25.987302858023881
		]
	  },
	  "properties" : {
		"FID" : 3109,
		"name" : "漢闽越王",
		"lng" : 118.753097,
		"lat" : 25.984217999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3110,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.08979566077851,
		  25.980872885732648
		]
	  },
	  "properties" : {
		"FID" : 3110,
		"name" : "玉封田公元帅勅封护国留侯庙",
		"lng" : 119.09475500000001,
		"lat" : 25.977981
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3111,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.74669853267481,
		  25.944191356142234
		]
	  },
	  "properties" : {
		"FID" : 3111,
		"name" : "闽清县严氏宗祠",
		"lng" : 118.751419,
		"lat" : 25.941136
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3112,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.72401222446602,
		  25.991921543657671
		]
	  },
	  "properties" : {
		"FID" : 3112,
		"name" : "省璜镇革命斗争史迹陈列馆",
		"lng" : 118.72872599999999,
		"lat" : 25.988824999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3113,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.76614581176796,
		  26.0622224879803
		]
	  },
	  "properties" : {
		"FID" : 3113,
		"name" : "白石瑞香寺",
		"lng" : 118.770867,
		"lat" : 26.059079000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3114,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.0981953364148,
		  26.049472794373127
		]
	  },
	  "properties" : {
		"FID" : 3114,
		"name" : "桃园谷",
		"lng" : 119.10316,
		"lat" : 26.046534000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3115,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.10759165867007,
		  25.951263846501998
		]
	  },
	  "properties" : {
		"FID" : 3115,
		"name" : "六都历山境大王宫",
		"lng" : 119.112545,
		"lat" : 25.948388000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3116,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.07939045043501,
		  25.917811079595538
		]
	  },
	  "properties" : {
		"FID" : 3116,
		"name" : "龙门峡谷景区(暂停开放)",
		"lng" : 119.08434,
		"lat" : 25.914957999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3117,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.95428346000806,
		  25.79818876967725
		]
	  },
	  "properties" : {
		"FID" : 3117,
		"name" : "永泰御温泉景区",
		"lng" : 118.958885,
		"lat" : 25.795116
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3118,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.9774875895816,
		  25.813181072716716
		]
	  },
	  "properties" : {
		"FID" : 3118,
		"name" : "仙洞风景区",
		"lng" : 118.982161,
		"lat" : 25.810161000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3119,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.97631041377916,
		  25.81407404620419
		]
	  },
	  "properties" : {
		"FID" : 3119,
		"name" : "永泰腾山自然保护区",
		"lng" : 118.98098,
		"lat" : 25.811050000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3120,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96254972217396,
		  25.786921322112214
		]
	  },
	  "properties" : {
		"FID" : 3120,
		"name" : "灵芝岩",
		"lng" : 118.967174,
		"lat" : 25.783875999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3121,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96261256945868,
		  25.78644887230223
		]
	  },
	  "properties" : {
		"FID" : 3121,
		"name" : "天门山-雷音洞",
		"lng" : 118.967237,
		"lat" : 25.783404000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3122,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96133647810251,
		  25.784639081942277
		]
	  },
	  "properties" : {
		"FID" : 3122,
		"name" : "仙人洞",
		"lng" : 118.965957,
		"lat" : 25.781592
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3123,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.9596192578847,
		  25.787753343608408
		]
	  },
	  "properties" : {
		"FID" : 3123,
		"name" : "女神头像",
		"lng" : 118.964235,
		"lat" : 25.784700000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3124,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.95989650511702,
		  25.787073230231634
		]
	  },
	  "properties" : {
		"FID" : 3124,
		"name" : "迎客松",
		"lng" : 118.964513,
		"lat" : 25.784020999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3125,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96213797752995,
		  25.786478123817695
		]
	  },
	  "properties" : {
		"FID" : 3125,
		"name" : "镇山大钟",
		"lng" : 118.96676100000001,
		"lat" : 25.783432000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3126,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96128043214068,
		  25.787534978361119
		]
	  },
	  "properties" : {
		"FID" : 3126,
		"name" : "拜仙台",
		"lng" : 118.965901,
		"lat" : 25.784486000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3127,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.95819040419681,
		  25.787069508397973
		]
	  },
	  "properties" : {
		"FID" : 3127,
		"name" : "仙足岩",
		"lng" : 118.962802,
		"lat" : 25.784013000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3128,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96262152203195,
		  25.786734021621164
		]
	  },
	  "properties" : {
		"FID" : 3128,
		"name" : "石走廊",
		"lng" : 118.967246,
		"lat" : 25.783688999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3129,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96214695332506,
		  25.786445080534211
		]
	  },
	  "properties" : {
		"FID" : 3129,
		"name" : "天门洞",
		"lng" : 118.96677,
		"lat" : 25.783398999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3130,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.95865504904464,
		  25.787482601182418
		]
	  },
	  "properties" : {
		"FID" : 3130,
		"name" : "济生潭",
		"lng" : 118.963268,
		"lat" : 25.784427000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3131,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.95808372011639,
		  25.786895667988649
		]
	  },
	  "properties" : {
		"FID" : 3131,
		"name" : "剑劈石开",
		"lng" : 118.962695,
		"lat" : 25.783839
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3132,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96000419696347,
		  25.787016923184822
		]
	  },
	  "properties" : {
		"FID" : 3132,
		"name" : "青云山云天石廊-凉亭",
		"lng" : 118.96462099999999,
		"lat" : 25.783964999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3133,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.9594788303781,
		  25.78545630712404
		]
	  },
	  "properties" : {
		"FID" : 3133,
		"name" : "羚羊洞",
		"lng" : 118.964094,
		"lat" : 25.782404
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3134,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.99259203825095,
		  25.801962932355217
		]
	  },
	  "properties" : {
		"FID" : 3134,
		"name" : "天门山",
		"lng" : 118.997316,
		"lat" : 25.798995000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3135,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.95952274615941,
		  25.784871843116342
		]
	  },
	  "properties" : {
		"FID" : 3135,
		"name" : "玉女会大王",
		"lng" : 118.96413800000001,
		"lat" : 25.78182
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3136,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96047004246563,
		  25.784264074018324
		]
	  },
	  "properties" : {
		"FID" : 3136,
		"name" : "通天大王庙",
		"lng" : 118.96508799999999,
		"lat" : 25.781215
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3137,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.93728656199691,
		  25.860954785461292
		]
	  },
	  "properties" : {
		"FID" : 3137,
		"name" : "塔山公园",
		"lng" : 118.941852,
		"lat" : 25.857807000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3138,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.91633404222699,
		  25.75028298894016
		]
	  },
	  "properties" : {
		"FID" : 3138,
		"name" : "仙瓢白云岩",
		"lng" : 118.92085899999999,
		"lat" : 25.747176
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3139,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.9552663930191,
		  25.762123771924017
		]
	  },
	  "properties" : {
		"FID" : 3139,
		"name" : "青云山景区",
		"lng" : 118.959868,
		"lat" : 25.759074999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3140,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.9639894760206,
		  25.868220934338652
		]
	  },
	  "properties" : {
		"FID" : 3140,
		"name" : "法治公园",
		"lng" : 118.96862400000001,
		"lat" : 25.865127999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3141,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.94559637274878,
		  25.857459583877414
		]
	  },
	  "properties" : {
		"FID" : 3141,
		"name" : "香米拉温泉园",
		"lng" : 118.95018,
		"lat" : 25.854330000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3142,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.94310156633261,
		  25.866386458799504
		]
	  },
	  "properties" : {
		"FID" : 3142,
		"name" : "江滨公园",
		"lng" : 118.94768000000001,
		"lat" : 25.863246
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3143,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.97235086012333,
		  25.84758964546614
		]
	  },
	  "properties" : {
		"FID" : 3143,
		"name" : "大坑口赏梅园",
		"lng" : 118.97701000000001,
		"lat" : 25.844532999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3144,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.94041567995961,
		  25.768043151439457
		]
	  },
	  "properties" : {
		"FID" : 3144,
		"name" : "白马观音殿",
		"lng" : 118.944981,
		"lat" : 25.764959000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3145,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96886738847445,
		  25.855220297446614
		]
	  },
	  "properties" : {
		"FID" : 3145,
		"name" : "永泰章氏宗祠",
		"lng" : 118.973516,
		"lat" : 25.852149000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3146,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.94042465977599,
		  25.7680521398838
		]
	  },
	  "properties" : {
		"FID" : 3146,
		"name" : "圆通宝殿",
		"lng" : 118.94499,
		"lat" : 25.764968
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3147,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.0032533910468,
		  25.759876265312972
		]
	  },
	  "properties" : {
		"FID" : 3147,
		"name" : "云顶旅游度假区",
		"lng" : 119.008011,
		"lat" : 25.756965999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3148,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.97797090014208,
		  25.855230437130228
		]
	  },
	  "properties" : {
		"FID" : 3148,
		"name" : "南江滨公园",
		"lng" : 118.98264899999999,
		"lat" : 25.852184999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3149,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.9749596557909,
		  25.857616703146935
		]
	  },
	  "properties" : {
		"FID" : 3149,
		"name" : "大樟溪自行车道花海公园",
		"lng" : 118.97962800000001,
		"lat" : 25.854561
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3150,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.93053185816854,
		  25.867365899847549
		]
	  },
	  "properties" : {
		"FID" : 3150,
		"name" : "永阳古城",
		"lng" : 118.935085,
		"lat" : 25.864203
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3151,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.94059671687634,
		  25.858868399682066
		]
	  },
	  "properties" : {
		"FID" : 3151,
		"name" : "永泰文化公园",
		"lng" : 118.94516900000001,
		"lat" : 25.855727999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3152,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96102569889842,
		  25.739138217037279
		]
	  },
	  "properties" : {
		"FID" : 3152,
		"name" : "青云山神谷景区",
		"lng" : 118.965642,
		"lat" : 25.736117
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3153,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.93921739413014,
		  25.86295262362453
		]
	  },
	  "properties" : {
		"FID" : 3153,
		"name" : "塔山公园-联奎公园",
		"lng" : 118.943787,
		"lat" : 25.859807
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3154,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.11326351616574,
		  25.863806384712383
		]
	  },
	  "properties" : {
		"FID" : 3154,
		"name" : "大樟溪休闲游乐区",
		"lng" : 119.118206,
		"lat" : 25.860984999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3155,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.94028599277964,
		  25.850596622199294
		]
	  },
	  "properties" : {
		"FID" : 3155,
		"name" : "祖师殿",
		"lng" : 118.944857,
		"lat" : 25.847460999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3156,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.94499758365366,
		  25.860409736894042
		]
	  },
	  "properties" : {
		"FID" : 3156,
		"name" : "爱情公园",
		"lng" : 118.94958,
		"lat" : 25.857277
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3157,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96445763165558,
		  25.750675862456205
		]
	  },
	  "properties" : {
		"FID" : 3157,
		"name" : "观景台",
		"lng" : 118.96908500000001,
		"lat" : 25.747657
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3158,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.93747203447818,
		  25.863001793329431
		]
	  },
	  "properties" : {
		"FID" : 3158,
		"name" : "天主堂",
		"lng" : 118.942038,
		"lat" : 25.859853000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3159,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.92381324085295,
		  25.800666419045385
		]
	  },
	  "properties" : {
		"FID" : 3159,
		"name" : "庄边园",
		"lng" : 118.92835100000001,
		"lat" : 25.797536999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3160,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96468094392674,
		  25.750823354588885
		]
	  },
	  "properties" : {
		"FID" : 3160,
		"name" : "状元印",
		"lng" : 118.969309,
		"lat" : 25.747805
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3161,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.92480791720639,
		  25.854735429786796
		]
	  },
	  "properties" : {
		"FID" : 3161,
		"name" : "探花府",
		"lng" : 118.929351,
		"lat" : 25.851572999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3162,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.92014521725339,
		  25.896086888686195
		]
	  },
	  "properties" : {
		"FID" : 3162,
		"name" : "清凉寺",
		"lng" : 118.924685,
		"lat" : 25.892892
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3163,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.93074448039246,
		  25.867477657841182
		]
	  },
	  "properties" : {
		"FID" : 3163,
		"name" : "永阳古城登高山历史文化街区",
		"lng" : 118.935298,
		"lat" : 25.864315000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3164,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.93476454217067,
		  25.861319322769624
		]
	  },
	  "properties" : {
		"FID" : 3164,
		"name" : "福音堂",
		"lng" : 118.939325,
		"lat" : 25.858167000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3165,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.93945095156417,
		  25.862191698495074
		]
	  },
	  "properties" : {
		"FID" : 3165,
		"name" : "永泰县小汤山生态公园",
		"lng" : 118.94402100000001,
		"lat" : 25.859047
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3166,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.00571263843787,
		  25.805217174868137
		]
	  },
	  "properties" : {
		"FID" : 3166,
		"name" : "庐公庙",
		"lng" : 119.010482,
		"lat" : 25.802287
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3167,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96342972440776,
		  25.750756622499988
		]
	  },
	  "properties" : {
		"FID" : 3167,
		"name" : "观音栈道",
		"lng" : 118.968054,
		"lat" : 25.747734999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3168,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.97391602345347,
		  25.858114013102671
		]
	  },
	  "properties" : {
		"FID" : 3168,
		"name" : "龙山寺",
		"lng" : 118.97858100000001,
		"lat" : 25.855055
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3169,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.00574850371581,
		  25.80538817318579
		]
	  },
	  "properties" : {
		"FID" : 3169,
		"name" : "生命之源",
		"lng" : 119.010518,
		"lat" : 25.802458000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3170,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.01290412267497,
		  25.823482309537081
		]
	  },
	  "properties" : {
		"FID" : 3170,
		"name" : "骆驼峰",
		"lng" : 119.01769899999999,
		"lat" : 25.820561999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3171,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96384854038929,
		  25.749725925872067
		]
	  },
	  "properties" : {
		"FID" : 3171,
		"name" : "钓鱼潭",
		"lng" : 118.968474,
		"lat" : 25.746706
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3172,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.94662013887796,
		  25.771410766293084
		]
	  },
	  "properties" : {
		"FID" : 3172,
		"name" : "鲤鱼跳龙门",
		"lng" : 118.9512,
		"lat" : 25.768336999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3173,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.01557575708064,
		  25.817971116726184
		]
	  },
	  "properties" : {
		"FID" : 3173,
		"name" : "天门山水滑",
		"lng" : 119.02037900000001,
		"lat" : 25.815062000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3174,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.01397248947866,
		  25.824942127348006
		]
	  },
	  "properties" : {
		"FID" : 3174,
		"name" : "天门山峡谷生态旅游景区-影视厅",
		"lng" : 119.018771,
		"lat" : 25.822023999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3175,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96396516987596,
		  25.749987768977583
		]
	  },
	  "properties" : {
		"FID" : 3175,
		"name" : "吉祥瀑布",
		"lng" : 118.968591,
		"lat" : 25.746967999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3176,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.94054039817028,
		  25.768184000140806
		]
	  },
	  "properties" : {
		"FID" : 3176,
		"name" : "青云山白马峡谷-凉亭",
		"lng" : 118.945106,
		"lat" : 25.7651
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3177,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96949992645672,
		  25.752135032034161
		]
	  },
	  "properties" : {
		"FID" : 3177,
		"name" : "对山宫",
		"lng" : 118.974143,
		"lat" : 25.749129
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3178,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.01653073878386,
		  25.816806653118466
		]
	  },
	  "properties" : {
		"FID" : 3178,
		"name" : "神龙滩",
		"lng" : 119.021337,
		"lat" : 25.813901000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3179,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.94581737480713,
		  25.753463919197966
		]
	  },
	  "properties" : {
		"FID" : 3179,
		"name" : "涵江区庄边镇后楼坑",
		"lng" : 118.950394,
		"lat" : 25.750399000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3180,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96470790180354,
		  25.750277968343024
		]
	  },
	  "properties" : {
		"FID" : 3180,
		"name" : "龙游松",
		"lng" : 118.969336,
		"lat" : 25.747260000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3181,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96259734459156,
		  25.74893374983932
		]
	  },
	  "properties" : {
		"FID" : 3181,
		"name" : "红豆杉",
		"lng" : 118.967219,
		"lat" : 25.745911
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3182,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96527020110952,
		  25.75013638787242
		]
	  },
	  "properties" : {
		"FID" : 3182,
		"name" : "珠帘瀑布",
		"lng" : 118.9699,
		"lat" : 25.747119999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3183,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.93541896699416,
		  25.86551396864737
		]
	  },
	  "properties" : {
		"FID" : 3183,
		"name" : "天后宫",
		"lng" : 118.939981,
		"lat" : 25.862359999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3184,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.94398648881938,
		  25.77019447450672
		]
	  },
	  "properties" : {
		"FID" : 3184,
		"name" : "溪底二叠瀑布",
		"lng" : 118.94856,
		"lat" : 25.767116000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3185,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96338396537688,
		  25.749330920939318
		]
	  },
	  "properties" : {
		"FID" : 3185,
		"name" : "流米石",
		"lng" : 118.968008,
		"lat" : 25.746310000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3186,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.99359592255836,
		  25.770057578973649
		]
	  },
	  "properties" : {
		"FID" : 3186,
		"name" : "金窝",
		"lng" : 118.998321,
		"lat" : 25.767112000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3187,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96442973934167,
		  25.750356752378309
		]
	  },
	  "properties" : {
		"FID" : 3187,
		"name" : "水帘长廊",
		"lng" : 118.96905700000001,
		"lat" : 25.747337999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3188,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96227531610926,
		  25.748735473455881
		]
	  },
	  "properties" : {
		"FID" : 3188,
		"name" : "林间休闲区",
		"lng" : 118.96689600000001,
		"lat" : 25.745712000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3189,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96291938252233,
		  25.748960925066896
		]
	  },
	  "properties" : {
		"FID" : 3189,
		"name" : "雄狮出洞",
		"lng" : 118.96754199999999,
		"lat" : 25.745939
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3190,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.11435260123646,
		  25.782689211333174
		]
	  },
	  "properties" : {
		"FID" : 3190,
		"name" : "后溪旅游区",
		"lng" : 119.119288,
		"lat" : 25.779917999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3191,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.00282467632888,
		  25.816392820412972
		]
	  },
	  "properties" : {
		"FID" : 3191,
		"name" : "天门山-石龙岭",
		"lng" : 119.00758500000001,
		"lat" : 25.813447
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3192,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.97743989235036,
		  25.770256071343169
		]
	  },
	  "properties" : {
		"FID" : 3192,
		"name" : "青云山景区-陈氏宗祠",
		"lng" : 118.98211000000001,
		"lat" : 25.767261999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3193,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.94378989695086,
		  25.77085926400515
		]
	  },
	  "properties" : {
		"FID" : 3193,
		"name" : "根劈石开",
		"lng" : 118.948363,
		"lat" : 25.767779999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3194,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96418050146733,
		  25.750242346595801
		]
	  },
	  "properties" : {
		"FID" : 3194,
		"name" : "仙台",
		"lng" : 118.968807,
		"lat" : 25.747223000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3195,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96368002095656,
		  25.750091580685023
		]
	  },
	  "properties" : {
		"FID" : 3195,
		"name" : "照天公殿",
		"lng" : 118.968305,
		"lat" : 25.747070999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3196,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96381356519392,
		  25.750832656213063
		]
	  },
	  "properties" : {
		"FID" : 3196,
		"name" : "飞来石",
		"lng" : 118.968439,
		"lat" : 25.747812
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3197,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.94100014477935,
		  25.854549832305082
		]
	  },
	  "properties" : {
		"FID" : 3197,
		"name" : "玄灵靖长生坛",
		"lng" : 118.945573,
		"lat" : 25.851413000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3198,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.93016453515276,
		  25.852921037957966
		]
	  },
	  "properties" : {
		"FID" : 3198,
		"name" : "永泰站站前广场",
		"lng" : 118.93471599999999,
		"lat" : 25.849767
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3199,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96461817054669,
		  25.750326234645136
		]
	  },
	  "properties" : {
		"FID" : 3199,
		"name" : "鸳鸯亭",
		"lng" : 118.969246,
		"lat" : 25.747308
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3200,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.94054839071214,
		  25.768045903431418
		]
	  },
	  "properties" : {
		"FID" : 3200,
		"name" : "观音瀑布",
		"lng" : 118.945114,
		"lat" : 25.764962000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3201,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.994282573375,
		  25.769742302872256
		]
	  },
	  "properties" : {
		"FID" : 3201,
		"name" : "QQ山寨",
		"lng" : 118.99901,
		"lat" : 25.766798999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3202,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96206994990308,
		  25.748391808613505
		]
	  },
	  "properties" : {
		"FID" : 3202,
		"name" : "灵龟岩",
		"lng" : 118.96669,
		"lat" : 25.745367999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3203,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.00914194908832,
		  25.819819058769514
		]
	  },
	  "properties" : {
		"FID" : 3203,
		"name" : "剑壁石",
		"lng" : 119.013924,
		"lat" : 25.816890000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3204,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.01205206933179,
		  25.821839761698559
		]
	  },
	  "properties" : {
		"FID" : 3204,
		"name" : "天门山-溪降",
		"lng" : 119.01684400000001,
		"lat" : 25.818918
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3205,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.00693945206604,
		  25.818955067234654
		]
	  },
	  "properties" : {
		"FID" : 3205,
		"name" : "迎客松",
		"lng" : 119.011714,
		"lat" : 25.816020000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3206,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96223042092487,
		  25.749125814638941
		]
	  },
	  "properties" : {
		"FID" : 3206,
		"name" : "相思亭",
		"lng" : 118.96685100000001,
		"lat" : 25.746102
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3207,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.00661308734804,
		  25.81183658993853
		]
	  },
	  "properties" : {
		"FID" : 3207,
		"name" : "天门山-园潭",
		"lng" : 119.011386,
		"lat" : 25.808904999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3208,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.00762039160125,
		  25.761706239419926
		]
	  },
	  "properties" : {
		"FID" : 3208,
		"name" : "七彩瀑布景区",
		"lng" : 119.012393,
		"lat" : 25.758807999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3209,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.962297316188,
		  25.871352419356171
		]
	  },
	  "properties" : {
		"FID" : 3209,
		"name" : "观音阁凉亭",
		"lng" : 118.966927,
		"lat" : 25.868252999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3210,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.9620619038952,
		  25.749352382155848
		]
	  },
	  "properties" : {
		"FID" : 3210,
		"name" : "攀岩绳",
		"lng" : 118.96668200000001,
		"lat" : 25.746327999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3211,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.96385842704035,
		  25.75087456208956
		]
	  },
	  "properties" : {
		"FID" : 3211,
		"name" : "神龙含珠",
		"lng" : 118.968484,
		"lat" : 25.747854
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3212,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.06610088675089,
		  25.783929111360347
		]
	  },
	  "properties" : {
		"FID" : 3212,
		"name" : "赤壁斗湖",
		"lng" : 119.071026,
		"lat" : 25.78115
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3213,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.93355747942145,
		  25.866264516541253
		]
	  },
	  "properties" : {
		"FID" : 3213,
		"name" : "重光禅寺",
		"lng" : 118.93811599999999,
		"lat" : 25.863106999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3214,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.07488454369637,
		  25.888371652777192
		]
	  },
	  "properties" : {
		"FID" : 3214,
		"name" : "普光明寺",
		"lng" : 119.07982800000001,
		"lat" : 25.885535000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3215,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.08968336470551,
		  25.839923794260432
		]
	  },
	  "properties" : {
		"FID" : 3215,
		"name" : "乐峰赤壁景区",
		"lng" : 119.094632,
		"lat" : 25.837126000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3216,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.9289364029017,
		  25.869604669437049
		]
	  },
	  "properties" : {
		"FID" : 3216,
		"name" : "永福激情广场",
		"lng" : 118.933487,
		"lat" : 25.866437999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3217,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.00966169456055,
		  25.759293769209386
		]
	  },
	  "properties" : {
		"FID" : 3217,
		"name" : "密林潭",
		"lng" : 119.01444100000001,
		"lat" : 25.756402999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3218,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.93099303276774,
		  25.867654402698278
		]
	  },
	  "properties" : {
		"FID" : 3218,
		"name" : "一善堂",
		"lng" : 118.935547,
		"lat" : 25.864491999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3219,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.00799916424329,
		  25.760998697241888
		]
	  },
	  "properties" : {
		"FID" : 3219,
		"name" : "水墨瀑布",
		"lng" : 119.012773,
		"lat" : 25.758102000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3220,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.93175364382272,
		  25.868212617209807
		]
	  },
	  "properties" : {
		"FID" : 3220,
		"name" : "文魁(三落厝)",
		"lng" : 118.93630899999999,
		"lat" : 25.865051000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3221,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.93123351516408,
		  25.868956894279826
		]
	  },
	  "properties" : {
		"FID" : 3221,
		"name" : "仰止楼",
		"lng" : 118.935788,
		"lat" : 25.865794000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3222,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.93100894185669,
		  25.868525949450937
		]
	  },
	  "properties" : {
		"FID" : 3222,
		"name" : "干厝(干氏私塾)",
		"lng" : 118.935563,
		"lat" : 25.865362999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3223,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.01143801661914,
		  25.755796499726817
		]
	  },
	  "properties" : {
		"FID" : 3223,
		"name" : "金钟瀑布",
		"lng" : 119.016223,
		"lat" : 25.752912999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3224,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.93085510363152,
		  25.870018157080491
		]
	  },
	  "properties" : {
		"FID" : 3224,
		"name" : "张元幹故居(世科)",
		"lng" : 118.93540900000001,
		"lat" : 25.866854
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3225,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.02646227175643,
		  25.754896868554532
		]
	  },
	  "properties" : {
		"FID" : 3225,
		"name" : "古梯田",
		"lng" : 119.031295,
		"lat" : 25.752056
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3226,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.92432194876729,
		  25.877922182312997
		]
	  },
	  "properties" : {
		"FID" : 3226,
		"name" : "仙佛寺",
		"lng" : 118.928866,
		"lat" : 25.874744
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3227,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.08768481874341,
		  25.894072603226565
		]
	  },
	  "properties" : {
		"FID" : 3227,
		"name" : "方广岩寺",
		"lng" : 119.092637,
		"lat" : 25.891238999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3228,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.78280735544845,
		  25.783874355630349
		]
	  },
	  "properties" : {
		"FID" : 3228,
		"name" : "三洋凤凰寺",
		"lng" : 118.78749000000001,
		"lat" : 25.780898000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3229,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.93127651725919,
		  25.867876121715504
		]
	  },
	  "properties" : {
		"FID" : 3229,
		"name" : "新安林氏宗祠",
		"lng" : 118.93583099999999,
		"lat" : 25.864713999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3230,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.01221055126075,
		  25.754420438417004
		]
	  },
	  "properties" : {
		"FID" : 3230,
		"name" : "双谷据点",
		"lng" : 119.016998,
		"lat" : 25.751539999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3231,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.9298975272941,
		  25.873196651675109
		]
	  },
	  "properties" : {
		"FID" : 3231,
		"name" : "大圣庙",
		"lng" : 118.93445,
		"lat" : 25.870028999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3232,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.92859709414077,
		  25.867788956131555
		]
	  },
	  "properties" : {
		"FID" : 3232,
		"name" : "远邻广场",
		"lng" : 118.93314700000001,
		"lat" : 25.864623000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3233,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.06843091944944,
		  25.754986252283178
		]
	  },
	  "properties" : {
		"FID" : 3233,
		"name" : "云岩汉堡岩",
		"lng" : 119.073357,
		"lat" : 25.752227000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3234,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.01110608103497,
		  25.75635680005141
		]
	  },
	  "properties" : {
		"FID" : 3234,
		"name" : "感恩桥",
		"lng" : 119.01589,
		"lat" : 25.753471999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3235,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.85745390353692,
		  25.780165480637887
		]
	  },
	  "properties" : {
		"FID" : 3235,
		"name" : "人民公园",
		"lng" : 118.86200100000001,
		"lat" : 25.777063999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3236,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.92159667571509,
		  25.864192309278256
		]
	  },
	  "properties" : {
		"FID" : 3236,
		"name" : "永泰伽蓝寺",
		"lng" : 118.926136,
		"lat" : 25.86102
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3237,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.92169626257387,
		  25.868117767011324
		]
	  },
	  "properties" : {
		"FID" : 3237,
		"name" : "永泰城隍庙",
		"lng" : 118.926236,
		"lat" : 25.864943
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3238,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.03031526812049,
		  25.763549931116835
		]
	  },
	  "properties" : {
		"FID" : 3238,
		"name" : "红石洋",
		"lng" : 119.03516,
		"lat" : 25.760714
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3239,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.82603275091508,
		  25.888428096855051
		]
	  },
	  "properties" : {
		"FID" : 3239,
		"name" : "高盖山风景区",
		"lng" : 118.830645,
		"lat" : 25.885311999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3240,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.9634443808015,
		  25.905661169661755
		]
	  },
	  "properties" : {
		"FID" : 3240,
		"name" : "极乐寺",
		"lng" : 118.96808,
		"lat" : 25.902542
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3241,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.07644570962398,
		  25.880167994224347
		]
	  },
	  "properties" : {
		"FID" : 3241,
		"name" : "葛岭1958米谷文创园",
		"lng" : 119.08139,
		"lat" : 25.877338000000002
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3242,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.04805555651927,
		  25.842527444800474
		]
	  },
	  "properties" : {
		"FID" : 3242,
		"name" : "天门山-梅岩寺",
		"lng" : 119.052952,
		"lat" : 25.839683000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3243,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.92510868045677,
		  25.865759233524756
		]
	  },
	  "properties" : {
		"FID" : 3243,
		"name" : "平安祈福堂",
		"lng" : 118.929653,
		"lat" : 25.862590000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3244,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.06200843552806,
		  25.884959681942696
		]
	  },
	  "properties" : {
		"FID" : 3244,
		"name" : "三岛观音亭",
		"lng" : 119.066935,
		"lat" : 25.882110999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3245,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.07112499497336,
		  25.882494173193738
		]
	  },
	  "properties" : {
		"FID" : 3245,
		"name" : "永泰壁舟里森林公园",
		"lng" : 119.076064,
		"lat" : 25.879657999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3246,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.85059588698165,
		  25.780871446154098
		]
	  },
	  "properties" : {
		"FID" : 3246,
		"name" : "五显灵公庙",
		"lng" : 118.855154,
		"lat" : 25.77778
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3247,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.02996541546821,
		  25.761751766597254
		]
	  },
	  "properties" : {
		"FID" : 3247,
		"name" : "冰臼群",
		"lng" : 119.034809,
		"lat" : 25.758915999999999
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3248,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.07824248116319,
		  25.88950389438352
		]
	  },
	  "properties" : {
		"FID" : 3248,
		"name" : "卢公祖师堂",
		"lng" : 119.083189,
		"lat" : 25.886669000000001
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3249,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.03032526672294,
		  25.76318168933404
		]
	  },
	  "properties" : {
		"FID" : 3249,
		"name" : "野人山寨",
		"lng" : 119.03516999999999,
		"lat" : 25.760345999999998
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3250,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  119.07616858345006,
		  25.805722462154424
		]
	  },
	  "properties" : {
		"FID" : 3250,
		"name" : "石龙脊",
		"lng" : 119.081107,
		"lat" : 25.80294
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3251,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.93009902549032,
		  25.875375791152127
		]
	  },
	  "properties" : {
		"FID" : 3251,
		"name" : "五显华光大帝殿",
		"lng" : 118.934652,
		"lat" : 25.872207
	  }
	},
	{
	  "type" : "Feature",
	  "id" : 3252,
	  "geometry" : {
		"type" : "Point",
		"coordinates" : [
		  118.88057248793297,
		  25.839521648514562
		]
	  },
	  "properties" : {
		"FID" : 3252,
		"name" : "永泰爱竹口舒园",
		"lng" : 118.885098,
		"lat" : 25.836358000000001
	  }
	}
  ]